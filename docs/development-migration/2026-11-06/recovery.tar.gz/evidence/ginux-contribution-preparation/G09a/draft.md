Title: Separate VFS file bytes from metadata and support truncation

Keep the existing inline storage default while allowing bounded external file
backing. Shared offsets and unlinked-file lifetime stay with the VFS; truncation
preserves offsets and zeroes regrown bytes. O_TRUNC avoids copying discarded
image contents, so a smaller owned backing can still truncate an image file.

Validation: 80 unit tests, make check/build and clean patch replay pass locally;
four ordinary native smoke scenarios pass. Full Linux runtime and macOS Actions
remain pending. Prepare against main only after the VFS prerequisites merge.
