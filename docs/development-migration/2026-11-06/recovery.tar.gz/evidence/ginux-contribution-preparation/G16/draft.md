Resolve image and owned paths through one namespace

Allow owned symlinks, cwd and registered image-directory descriptors to cross
into existing readonly image operations. Reuse the component walker and native
path rewrite; preserve assignment precedence and absent device paths. Canonicalize
owned script interpreter aliases only in the sealed execution copy while keeping
the original source and interpreter argv names.

Local validation:95 units, selected builds and ordinary path/exec/script/storage
checks pass in source and clean replay. Security/full runtime coverage, remote CI
and prerequisite merges remain pending; not ready to submit.
