from pathlib import Path
import subprocess
src=Path('/tmp/ginux-contribution-preparation/G16/source')
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
p=src/'crates/ginux-init/src/tracee_io.rs';s=p.read_text();donor=git('show','1da0ce13:crates/ginux-init/src/tracee_io.rs').decode();a=donor.index('pub fn image_fd_path(');b=donor.index('/// Only callers',a);at=s.index('pub fn image_link(');s=s[:at]+donor[a:b]+s[at:];p.write_text(s)
p=src/'crates/ginux-init/src/path_hooks.rs';s=p.read_text().replace('pub(crate) struct ScriptHeader {','#[derive(Clone, Copy)]\npub(crate) struct ScriptHeader {').replace('    pub argument: Option<ginux_domain::Text<MAX_PATH>>,','    pub argument: Option<ginux_domain::Text<MAX_PATH>>,\n    pub payload: usize,');s=s.replace('        argument,\n    }))','        argument,\n        payload: bytes.iter().position(|b| *b == b\'\\n\').map_or(bytes.len(), |n| n + 1),\n    }))',1)
s=s.replace('    pub fn finish(mut self, pid:', '''    pub fn original_args(&mut self, r: &UserRegs) {
        self.args = [r.rdi, r.rsi, r.rdx, r.r10, r.r8, r.r9, r.orig_rax];
    }
    pub fn finish(mut self, pid:''');p.write_text(s)
p=src/'crates/ginux-init/src/exec_script.rs';s=p.read_text().replace('    held: [Option<Executable>; SCRIPTS],','    held: [Option<Executable>; SCRIPTS],\n    native_header: Option<crate::path_hooks::ScriptHeader>,\n    native_name: Option<Path>,').replace('            held: [None; SCRIPTS],','            held: [None; SCRIPTS],\n            native_header: None,\n            native_name: None,')
s=s.replace('''                    None => {
                        script.kernel_script = true;''','''                    None => {
                        let resolved = fs.interpreter_path(host, header.interpreter.as_bytes())?;
                        if resolved != header.interpreter {
                            script.native_name = Some(header.interpreter);
                            script.native_header = Some(crate::path_hooks::ScriptHeader { interpreter: resolved, ..header });
                        }
                        script.kernel_script = true;''',1)
donor=git('show','1da0ce13:crates/ginux-init/src/exec_script.rs').decode();a=donor.index('    /// Canonicalize only');b=donor.index('    pub fn release_held',a);s=s.replace('    pub fn release_held',donor[a:b]+'    pub fn release_held',1)
a=s.index('        // Keep any prefix');b=s.index('        let mut append',a);da=donor.index('        // The kernel may have expanded');db=donor.index('        let mut append',da);s=s[:a]+donor[da:db]+s[b:];p.write_text(s)
p=src/'crates/ginux-init/src/exec_image.rs';s=p.read_text();donor=git('show','1da0ce13:crates/ginux-init/src/exec_image.rs').decode();p.write_text(donor)
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text().replace('        let mut native_dirfd = r.rdi;','        let original = *r;\n        let mut translated = *r;\n        let mut native_dirfd = r.rdi;',1);needle='''                native_dirfd = (-100i64) as u64;
                self.objects''';s=s.replace(needle,'''                native_dirfd = (-100i64) as u64;
                translated.rdi = dirfd;
                self.objects''',1)
s=s.replace('''            let rewrite = crate::path_hooks::Rewrite::prepare(self.objects.filesystem, host, r)?;
            self.task_mut(index).path_rewrite = rewrite;
            if r.orig_rax == 59''','''            let rewrite = crate::path_hooks::Rewrite::prepare(self.objects.filesystem, host, &mut translated)?;
            if let Some(mut rewrite) = rewrite {
                rewrite.original_args(&original);
                self.task_mut(index).path_rewrite = Some(rewrite);
                *r = translated;
            }
            if r.orig_rax == 59''',1)
s=s.replace('''                            owned.image,
                        )''','''                            owned.image,
                            owned.script.as_ref(),
                        )''',1);p.write_text(s)
print('G16 port on G14 only')
