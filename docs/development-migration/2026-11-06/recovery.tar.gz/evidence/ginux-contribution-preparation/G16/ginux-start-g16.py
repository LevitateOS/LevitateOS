from pathlib import Path
import subprocess,tarfile,io,json
root=Path('/tmp/ginux-contribution-preparation/G16');root.mkdir(exist_ok=True);src=root/'source';assert not src.exists();src.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='ec6f9c480b7de187350672478500448e59a54ea3'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(src,filter='data')
(root/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G14'],'excluded':['G15 hardlinks','G12 mappings','G07 threads'],'donors':['1da0ce137de73e13b66a331de8f7ff7b12903925','93a1a56dbdf5c4af0a66b73cd5e8a932c0894418'],'existing_foundations':['G03c component walker/native Rewrite','G13 owned symlinks and device absence','G14 task-owned cwd']},indent=2)+'\n')
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text().replace('pub const FD_BASE: usize = 1 << 20;','pub const FD_BASE: usize = 1 << 20;\n// Internal tag for a registered native image directory, never a public FD.\npub const IMAGE_DIR_BASE: u64 = 0x0800_0000;')
s=s.replace('        let mut owned_link = false;\n        let mut crossed = false;\n','').replace('                    owned_link = true;\n','')
a=s.index('            // Owned links remain');b=s.index('            if path == b"/dev"',a);s=s[:a]+s[b:]
s=s.replace('            image.lookup(path, target)','            if [b"/proc".as_slice(), b"/sys"].iter().any(|p| within(path, p)) {\n                return Err(VfsError::PermissionDenied);\n            }\n            image.lookup(path, target)',1)
a=s.index('        .map_err(|error| if crossed');b=s.index('        Path::from_bytes(&output[..n])',a);s=s[:a]+'        .map_err(errno)?;\n'+s[b:]
a=s.index('        if (dirfd as i32 != -100 || self.cwd.is_some())');b=s.index('        Ok(Some((argument, path)))',a);s=s[:a]+s[b:]
s=s.replace('        let raw = read_path(pid, address)?;\n        let path = self.path(pid, address, (-100i64) as u64)?;', '        let path = self.path(pid, address, (-100i64) as u64)?;',1)
s=s.replace('        if self.cwd.is_some() && raw.as_bytes().first() != Some(&b\'/\') {\n            return Err(-95);\n        }\n','',1)
a=s.index('    pub fn exec_path(');b=s.index('    pub fn exec_descriptor',a);chunk=s[a:b].replace('        let raw = read_path(pid, address)?;\n','');c=chunk.index('        if (dirfd as i32 != -100');d=chunk.index('        Ok(None)',c);chunk=chunk[:c]+'        self.check_exec_owner(path.as_bytes())?;\n        self.check_interpreters(pid, path)?;\n'+chunk[d:];s=s[:a]+chunk+s[b:]
a=s.index('    pub fn exec_interpreter(');b=s.index('    pub fn read_executable(',a);s=s[:a]+'''    pub fn interpreter_path(&self, pid: usize, name: &[u8]) -> Result<Path, i64> {
        let cwd;
        let base = if name.first() == Some(&b'/') { b"".as_slice() } else {
            cwd = self.cwd_path(pid)?;
            cwd.as_bytes()
        };
        let joined = join_path(base, name)?;
        self.resolve(pid, joined.as_bytes(), true, false)
    }

    pub fn exec_interpreter(&mut self, pid: usize, name: &[u8]) -> Result<Option<Executable>, i64> {
        let path = self.interpreter_path(pid, name)?;
        if self.owns_path(path.as_bytes()) {
            let image = self.fs.pin_executable(path.as_bytes()).map_err(errno)?;
            return self.check_exec(pid, image).map(Some);
        }
        self.check_exec_owner(path.as_bytes())?;
        self.check_interpreters(pid, path)?;
        Ok(None)
    }

'''+s[b:]
needle='''        } else {
            let fd = (dirfd as u32)''';assert needle in s;s=s.replace(needle,'''        } else if (IMAGE_DIR_BASE..IMAGE_DIR_BASE + 256).contains(&dirfd) {
            cwd = crate::tracee_io::image_fd_path(pid, (dirfd - IMAGE_DIR_BASE) as u32)?;
            let image = crate::path_hooks::ImageRoot::new(pid)?;
            if image.lookup(cwd.as_bytes(), &mut [0; MAX_PATH]).map_err(errno)?.0 != NodeKind::Directory {
                return Err(-20);
            }
            cwd.as_bytes()
        } else {
            let fd = (dirfd as u32)''',1);p.write_text(s)
p=src/'crates/ginux-init/src/descriptors.rs';s=p.read_text().replace('            Handle::Native { .. } => Err(-95),','            Handle::Native { fd, .. } => Ok(crate::fs_hooks::IMAGE_DIR_BASE + fd as u64),',1);p.write_text(s)
p=src/'crates/ginux-init/src/tracee_io.rs';s=p.read_text();donor=git('show','1da0ce13:crates/ginux-init/src/tracee_io.rs').decode();a=donor.index('pub fn image_fd_path(');b=donor.index('/// Only callers',a);at=s.index('/// Only callers');s=s[:at]+donor[a:b]+s[at:];p.write_text(s)
p=src/'crates/ginux-init/src/path_hooks.rs';s=p.read_text().replace('pub(crate) struct ScriptHeader {','#[derive(Clone, Copy)]\npub(crate) struct ScriptHeader {').replace('    pub argument: Option<ginux_domain::Text<MAX_PATH>>,','    pub argument: Option<ginux_domain::Text<MAX_PATH>>,\n    pub payload: usize,');s=s.replace('        argument,\n    }))','        argument,\n        payload: bytes.iter().position(|b| *b == b\'\\n\').map_or(bytes.len(), |n| n + 1),\n    }))',1)
s=s.replace('    pub fn finish(mut self, pid:', '''    pub fn original_args(&mut self, r: &UserRegs) {
        self.args = [r.rdi, r.rsi, r.rdx, r.r10, r.r8, r.r9, r.orig_rax];
    }
    pub fn finish(mut self, pid:''');p.write_text(s)
p=src/'crates/ginux-init/src/exec_script.rs';s=p.read_text().replace('    held: [Option<Executable>; SCRIPTS],','    held: [Option<Executable>; SCRIPTS],\n    native_header: Option<crate::path_hooks::ScriptHeader>,\n    native_name: Option<Path>,').replace('            held: [None; SCRIPTS],','            held: [None; SCRIPTS],\n            native_header: None,\n            native_name: None,')
s=s.replace('''                    None => {
                        script.kernel_script = true;''','''                    None => {
                        let resolved = fs.interpreter_path(host, header.interpreter.as_bytes())?;
                        if resolved != header.interpreter {
                            script.native_name = Some(header.interpreter);
                            script.native_header = Some(crate::path_hooks::ScriptHeader { interpreter: resolved, ..header });
                        }
                        script.kernel_script = true;''',1)
donor=git('show','1da0ce13:crates/ginux-init/src/exec_script.rs').decode();a=donor.index('    /// Canonicalize only');b=donor.index('    pub fn release_held',a);s=s.replace('    pub fn release_held',donor[a:b]+'    pub fn release_held',1)
a=s.index('        // Keep any prefix');b=s.index('        let mut append',a);da=donor.index('        // The kernel may have expanded');db=donor.index('        let mut append',da);s=s[:a]+donor[da:db]+s[b:];p.write_text(s)
p=src/'crates/ginux-init/src/exec_image.rs';s=p.read_text();donor=git('show','1da0ce13:crates/ginux-init/src/exec_image.rs').decode();p.write_text(donor)
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text().replace('        let mut native_dirfd = r.rdi;','        let original = *r;\n        let mut translated = *r;\n        let mut native_dirfd = r.rdi;',1);needle='''                native_dirfd = (-100i64) as u64;
                self.objects''';s=s.replace(needle,'''                native_dirfd = (-100i64) as u64;
                translated.rdi = dirfd;
                self.objects''',1)
s=s.replace('''            let rewrite = crate::path_hooks::Rewrite::prepare(self.objects.filesystem, host, r)?;
            self.task_mut(index).path_rewrite = rewrite;
            if r.orig_rax == 59''','''            let rewrite = crate::path_hooks::Rewrite::prepare(self.objects.filesystem, host, &mut translated)?;
            if let Some(mut rewrite) = rewrite {
                rewrite.original_args(&original);
                self.task_mut(index).path_rewrite = Some(rewrite);
                *r = translated;
            }
            if r.orig_rax == 59''',1)
s=s.replace('''                            owned.image,
                        )''','''                            owned.image,
                            owned.script.as_ref(),
                        )''',1);p.write_text(s)
print('G16 port on G14 only')
