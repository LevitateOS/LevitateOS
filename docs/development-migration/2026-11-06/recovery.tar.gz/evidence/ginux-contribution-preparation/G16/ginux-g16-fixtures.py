from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G16/source')
p=src/'crates/ginux-init/src/exec_script.rs';s=p.read_text().replace('    crate::path_hooks::script_metadata(&bytes[..n])','''    let mut header = crate::path_hooks::script_metadata(&bytes[..n])?;
    if !bytes[..n].contains(&b'\\n') {
        if let Some(header) = header.as_mut() { header.payload = image.size; }
    }
    Ok(header)''');p.write_text(s)
p=src/'tests/fixtures/launch-directory-fixture.c';s=p.read_text();at=s.index('long directory_main(');s=s[:at]+'''static long cross_paths(int execute) {
    CHECK(create("/work/data","owned")==0,170);
    CHECK(DO(88,"/image","/work/image-link",0)==0,171);
    long fd=DO(2,"/work/image-link",0,0); CHECK(fd>=3,172);
    CHECK(DO(0,fd,buffer,9)==9 && buffer[0]=='i' && DO(3,fd,0,0)==0,173);
    CHECK(DO(88,"/bin","/work/bin-link",0)==0,174);
    fd=DO(2,"/work/bin-link/../image",0,0); CHECK(fd>=3 && DO(3,fd,0,0)==0,175);
    CHECK(create("/image-work/through-image","safe")==0,176);
    long image_dir=DO(2,"/bin",0200000,0); CHECK(image_dir>=3,177);
    fd=DO(257,image_dir,"../image-work/through-image",0); CHECK(fd>=3,178);
    CHECK(DO(0,fd,buffer,4)==4 && buffer[0]=='s' && DO(3,fd,0,0)==0,179);
    fd=DO(257,image_dir,"../image",0); CHECK(fd>=3 && DO(0,fd,buffer,9)==9 && DO(3,fd,0,0)==0,180);
    CHECK(call(262,image_dir,(word)"../image",(word)meta,0,0,0)==0 && *(word *)(meta+48)==15,181);
    CHECK(call(332,image_dir,(word)"../image",0,0x7ff,(word)meta,0)==0 && *(word *)(meta+40)==15,182);
    CHECK(DO(258,image_dir,"../image-work/new-dir",0755)==0,183);
    CHECK(DO(80,"/work/new-dir",0,0)==0 && DO(79,buffer,sizeof buffer,0)==14 && equal(buffer,"/work/new-dir"),184);
    fd=DO(2,"../../image",0,0); CHECK(fd>=3 && DO(3,fd,0,0)==0,185);
    if(execute) {
        char *args[]={"fixture","cross-exec-child",0},*env[]={0};
        if(execute==1) DO(59,"../bin-link/fixture",args,env);
        else call(322,image_dir,(word)"fixture",(word)args,(word)env,0,0);
        return 186;
    }
    CHECK(DO(80,"../../bin",0,0)==0 && DO(79,buffer,sizeof buffer,0)==5 && equal(buffer,"/bin"),187);
    CHECK(DO(3,image_dir,0,0)==0,188);
    DO(1,1,"owned-directories: PASS\\n",24); return 0;
}
'''+s[at:]
s=s.replace('    char **argv=(char **)(stack+1);','''    char **argv=(char **)(stack+1);
    if(stack[0]>1 && equal(argv[1],"cross-exec-child")) {
        CHECK(DO(79,buffer,sizeof buffer,0)==14 && equal(buffer,"/work/new-dir"),189);
        long fd=DO(2,"../../image",0,0); CHECK(fd>=3 && DO(0,fd,buffer,9)==9 && DO(3,fd,0,0)==0,190);
        DO(1,1,"owned-directories: PASS\\n",24); return 0;
    }
    if(stack[0]>1 && equal(argv[1],"ordinary-cross")) return cross_paths(0);
    if(stack[0]>1 && equal(argv[1],"ordinary-cross-exec")) return cross_paths(1);
    if(stack[0]>1 && equal(argv[1],"ordinary-image-dir-exec")) return cross_paths(2);''',1)
s=s.replace('        CHECK(DO(257,dir,"../../image",0)==-95,38);','''        long crossing=DO(257,dir,"../../image",0);
        CHECK(crossing>=3 && DO(0,crossing,buffer,9)==9 && buffer[0]=='i' && DO(3,crossing,0,0)==0,38);''');p.write_text(s)
p=src/'scripts/test-launch-directories.py';s=p.read_text().replace("        config=template.replace", "        (root/'image-work').symlink_to('/work')\n        config=template.replace",1).replace("'ordinary-cwd-budget'","'ordinary-cwd-budget', 'ordinary-cross', 'ordinary-cross-exec', 'ordinary-image-dir-exec'");p.write_text(s)
p=src/'tests/fixtures/launch-script-fixture.c';s=p.read_text();s=s.replace('    int chain=equal(mode,"ordinary-chain");','''    int cross=equal(mode,"ordinary-cross") || equal(mode,"ordinary-cross-nested") || equal(mode,"ordinary-cross-relative");
    int chain=equal(mode,"ordinary-chain");''',1).replace('int nested=equal(mode,"ordinary-nested") || equal(mode,"ordinary-joined");','int nested=equal(mode,"ordinary-nested") || equal(mode,"ordinary-joined") || equal(mode,"ordinary-cross-nested");',1)
s=s.replace('equal(mode,"ordinary-interpreter-link")?"/work/interpreter-link":"/work/interpreter"):"/bin/interpreter"','equal(mode,"ordinary-interpreter-link")?"/work/interpreter-link":"/work/interpreter"):(cross && !nested?(equal(mode,"ordinary-cross-relative")?"work/interpreter-link":"/work/interpreter-link"):"/bin/interpreter")',1)
s=s.replace('equal(mode,"ordinary-joined")?"/work/middle":"/bin/wrapper"','equal(mode,"ordinary-joined")?"/work/middle":(equal(mode,"ordinary-cross-nested")?"/work/interpreter-link":"/bin/wrapper")',1)
needle='    if(equal(mode,"ordinary-joined")) CHECK(publish';at=s.index(needle);s=s[:at]+'''    if(cross) {
        CHECK(DO(88,equal(mode,"ordinary-cross-nested")?"/bin/wrapper":"/bin/interpreter","/work/interpreter-link",0)==0,98);
        CHECK(publish("/work/program",equal(mode,"ordinary-cross-relative")?"#!work/interpreter-link option with spaces\\nbody\\n":"#!/work/interpreter-link option with spaces\\nbody\\n")==0,99);
    }
'''+s[at:];p.write_text(s)
p=src/'scripts/test-launch-scripts.py';s=p.read_text().replace("'ordinary-interpreter-link')","'ordinary-interpreter-link', 'ordinary-cross', 'ordinary-cross-nested', 'ordinary-cross-relative')",1);p.write_text(s)
p=src/'tests/fixtures/launch-storage-fixture.c';s=p.read_text().replace('CHECK(DO(88,"/image","/work/image",0)==0 && DO(2,"/work/image",0,0)<0,177);','CHECK(DO(88,"/image","/work/image",0)==0 && DO(2,"/work/image",0,0)==3,177);\n        CHECK(DO(0,3,output,9)==9 && output[0]==\'i\' && DO(3,3,0,0)==0,216);').replace('DO(2,"/work/link/../../image",0,0)<0','DO(2,"/work/link/../../image",0,0)==3 && DO(3,3,0,0)==0');p.write_text(s)
p=src/'README.md';s=p.read_text().replace('Entering\nowned directories as cwd, relative image-directory FD access, hardlinks and\nguest file mappings remain unsupported.','Owned directories can be selected as cwd; relative image-directory descriptors\njoin the same virtual namespace. Hardlinks and guest file mappings remain unsupported.').replace('Entering\nowned directories as cwd, relative image-directory FD access and guest file\nmappings remain unsupported.','Owned directories can be selected as cwd; relative image-directory descriptors\njoin the same virtual namespace. Guest file mappings remain unsupported.')
s+='''
Configured image and owned storage paths use one bounded component traversal.
Owned links may lead to readonly image paths or assigned virtual devices; image
links may lead into owned storage. Directory descriptors and cwd use the same
assignment precedence. Link expansion precedes parent components. Image mutations
remain unsupported; hidden device paths retain absent semantics. Owned script
interpreter aliases are canonicalized only in the sealed execution copy; original
script bytes and interpreter names in argv remain unchanged. Kernel-selected
nested native interpreters must still match the image namespace.
''';p.write_text(s)
print('G16 ordinary traversal and script fixture joins')
