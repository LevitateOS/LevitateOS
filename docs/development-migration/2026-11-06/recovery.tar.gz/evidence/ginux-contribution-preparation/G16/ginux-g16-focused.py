from pathlib import Path
import subprocess,json
root=Path('/tmp/ginux-contribution-preparation/G16');src=root/'source'
commands=[['sudo','-n','python3','scripts/test-launch-directories.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-directory-fixture','ordinary-cross','ordinary-cross-exec','ordinary-image-dir-exec'],['sudo','-n','python3','scripts/test-launch-scripts.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-script-fixture','ordinary-cross','ordinary-cross-nested','ordinary-cross-relative']]
receipts=[]
for i,cmd in enumerate(commands):
 with (root/f'focused-{i}.log').open('w') as f:r=subprocess.run(cmd,cwd=src,stdout=f,stderr=subprocess.STDOUT)
 receipts.append({'command':cmd,'exit_code':r.returncode});(root/'focused-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n');print(i,r.returncode,flush=True)
 if r.returncode:break
