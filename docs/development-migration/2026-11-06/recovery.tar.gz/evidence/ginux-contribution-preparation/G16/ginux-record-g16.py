from pathlib import Path
import json,shutil,hashlib
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G16');art=root/'.artifacts/ginux-contribution-preparation/G16'
m=json.loads((temp/'manifest.json').read_text());m.update(status='source separately self-reviewed; static/unit/build and selected ordinary runtime pass in source/clean replay; security/full CI/current-main independence pending',unit_tests=95,vfs_tests=37,clean_matched_paths=177,review='separate self-review; no independent reviewer/security acceptance claimed',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=json.loads((temp/'final-static-receipt.json').read_text())['binary_sha256'],clean_binary_sha256=json.loads((temp/'clean-static-receipt.json').read_text())['binary_sha256'],final_clean_export='verified-head',new_ordinary_directory_scenarios=3,new_ordinary_script_scenarios=5)
assert m['source_binary_sha256']==m['clean_binary_sha256'];fixtures={}
for name in ['launch-directory-fixture','launch-storage-fixture','launch-script-fixture','launch-owned-exec-fixture']:
 a=(temp/'source/.artifacts/launch'/name).read_bytes();b=(temp/'verified-head/.artifacts/launch'/name).read_bytes();assert a==b,name;fixtures[name]=hashlib.sha256(a).hexdigest()
m['fixture_sha256']=fixtures
for prefix in ['', 'clean-']:
 rs=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(rs)==4 and all(r['exit_code']==0 for r in rs)
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.patch','.diff']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g16*.py'):shutil.copyfile(p,art/p.name)
(art/'draft.md').write_text('''Resolve image and owned paths through one namespace

Allow owned symlinks, cwd and registered image-directory descriptors to cross
into existing readonly image operations. Reuse the component walker and native
path rewrite; preserve assignment precedence and absent device paths. Canonicalize
owned script interpreter aliases only in the sealed execution copy while keeping
the original source and interpreter argv names.

Local validation:95 units, selected builds and ordinary path/exec/script/storage
checks pass in source and clean replay. Security/full runtime coverage, remote CI
and prerequisite merges remain pending; not ready to submit.
''');assert not any(s in (art/'draft.md').read_text() for s in ['LevitateOS','Recipe','Daybreak'])
shutil.copyfile(temp/'candidate.patch',docs/'patches/G16.patch')
(docs/'g16-review.md').write_text(f'''# G16 — unified image/owned traversal; security acceptance pending

Head `{m['head']}`, tree `{m['tree']}`, sole local prerequisite
G14 `{m['base']}`. [Retained patch](patches/G16.patch). Thirteen files,+274/-85.
Source/ordinary preparation is retained; security/full CI/current-main independence
remain pending. No G15 hardlink, G12 mapping or G07 thread ancestry is imported.

## Scope and separate self-review

The shared component walker, image lookup, native scratch transaction, assignment
precedence, owned final-entry mutation and current null-device absence owner
already exist in G03c/G13/G14. Do not copy the donor's obsolete walker or task-group
owners. This delta removes the temporary prohibition on owned links reaching image
components, and on owned cwd/dirFD paths resolving to image paths. /dev retains
NotFound for unassigned entries; /proc and /sys remain explicitly denied.

Registered native image directory descriptors get an internal bounded tag before
path resolution. Only public-table lookup can produce that tag; the existing
tracee-root projection obtains its image name and verifies directory type. Native
fallback receives the existing canonical absolute rewrite, and saved public
arguments are restored through current descriptor/task owners. Relative execveat
uses the translated dirFD for resolution while retaining original public registers
for failure restoration. Explicit native exec validates the already-resolved path
and preserves final symlink nofollow handling; it does not reinterpret a public
image dirFD as AT_FDCWD.

Owned scripts can select an image interpreter through an owned alias or relative
virtual cwd. Only the sealed private backing's shebang is canonicalized; original
VFS bytes are unchanged. The common header reader records the payload start;
missing-newline input skips the complete original header. Existing pin/task owners
retain and release script images. On exec commit, the known native argv prefix
position is restored to the requested interpreter name, preserving nested native
arguments and original script names. Native kernel-selected interpreter chains
still require image/virtual namespace agreement; relative native interpreters from
an owned cwd remain explicitly unsupported.

A separate final self-review read the complete final diff and relevant current
walker/image lookup, device dispatch, descriptor translation/finish/reservation,
native rewrite, task entry/exit/exec/failure, script argv and private populate
callers. This is self-review, not independent or security acceptance. VFS, core,
process/native supervisor, storage backing, devices and dispatch implementations
remain byte-for-byte identical to G14. No public configuration or VFS API changes.

- **High, ownership/port correction:** keep current per-process Task and descriptor
  restore paths; no donor DescriptorGroups or second Rewrite owner. Relative
  image-dirFD exec resolves using the same capability as ordinary path operations.
  The new ordinary exec fixture succeeds with an owned cwd and image directory FD.
- **High, interpreter source preservation:** resolve only the private kernel
  execution header; retain original virtual argv names and source bytes. Five
  ordinary cases exercise absolute and relative aliases, native nested scripts,
  no optional argument, and relative interpreters from an owned cwd. Existing16
  script cases still pass. The interpreter reopens original owned script data.
- **High, canonical token boundary:** source review found that an image target
  containing shebang separators could change kernel tokenization after canonical
  rewriting. private_header now rejects space/tab/newline/NUL targets with ENOTSUP
  before publishing an execution backing. Oversized rewritten headers fail with
  E2BIG. Adversarial confirmation remains with DaybreakBlue, not claimed passing.
- **Moderate, donor reconciliation:** 93a1a56d hidden-device absence is already
  present in G13 and preserved, rather than applied twice. Donor hardlink-specific
  joins stay with G15/F02; donor image-directory exec scenario is covered by the
  new ordinary directory fixture without private-FD inspection. Old G13 full-mode
  cross-image expectations change to successful readonly behavior, with explicit
  read/close checks. Default security modes remain compiled and registered.
- **Blocking for publication:** adversarial cross-namespace authority, private FD,
  mutable arguments/races, protected scratch, implicit interpreter and exec-stack
  verification remain in the [DaybreakBlue handoff](daybreakblue-handoff.md).
  The inherited shared-argument hold remains; ordinary results prove no security
  acceptance. Combined hardlink/mapping/thread interactions remain for F02.

## Exact evidence

Source and strict clean prerequisite-plus-patch export both pass `make check
 test-unit build build-launch-script-fixture build-launch-owned-exec-fixture
 build-launch-directory-fixture build-launch-storage-fixture`:95 units,37 VFS,
177 matching tracked paths. Ginux and all four fixture binaries match. Apply uses
--whitespace=error. Existing tests/default CI coverage remain intact.

Three new ordinary directory modes pass twice each in both exports: image reads
through owned links, link-before-parent, image aliases into storage, relative
native directory-FD open/stat/statx/mkdir, owned-cwd parent traversal, native chdir,
exec through owned links and relative image-dirFD exec preserving owned cwd.
Five new ordinary script modes pass, plus16 earlier script controls, six owned ELF
modes, ordinary owned-cwd/capacity/functional/native-cwd directories and ordinary
symlink/storage growth/bounds/quota. Exact G14 rejects the owned-link image open
with ENOTSUP(-95), producing workload172 on the same valid-cross fixture.

The initial adapted static check caught an unused legacy native_exec_path; it was
replaced with a canonical-path helper preserving nofollow, without warning
suppression. Initial/final logs and intermediate helpers are retained. Full cross
confinement/hidden-device/loop/protected modes are compiled but unrun here. No
independent reviewer, macOS Actions, remote CI or refreshed standalone validation
is claimed. Linux-local success is not green remote CI.

Patch, generic draft, manifests, commands, receipts, hashes and logs live under
.artifacts/ginux-contribution-preparation/G16/. No branch, real source checkout/
index, remote, PR text or maintainer message changed. F04 remains the inspection
stop before any publication.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G16');row.update(m);row.update(evidence='g16-review.md',source_patch='patches/G16.patch');p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''

### G16 exact retained revision

Candidate {m['head']} on G14 {m['base']} has95 routine units, three new ordinary
path/exec modes and five new valid script-interpreter modes passing in source and
clean replay, plus existing controls. [Review/evidence](g16-review.md) records the
canonical-token rejection added through source review; its adversarial validation
and the previously listed boundary/FD/race/stack checks remain pending. VFS walker
and native lookup are preserved. Full cross modes remain present and unrun here.
No monitored agent was dispatched; security acceptance is still pending.
''')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text();a=s.index('Exact next task: **G16');b=s.index('\nActive skill:',a)
s=s[:a]+f'''G16 source/ordinary preparation is retained at `{m['head'][:8]}` on G14{m['base'][:8]}.
[Review/evidence](ginux-contributions/g16-review.md) records95 units,177-path strict
replay, three new ordinary cross-path/FD/cwd/exec modes and five script-interpreter
alias modes, plus existing controls in source/clean exports. The current walker,
image lookup and native rewrite owners are reused; canonical script targets with
shebang separators now fail explicitly. Exact G14 rejects the new valid-cross
fixture. G15/G12/G07 joins and security/full CI/current-main independence remain
pending. No Ginux checkout, branch/index, remote or human text changed.

Exact next task: **G18 — configurable bounded namespace capacity**, before G17.
Inspect38fa14fd and derive the minimum actual configuration/VFS/storage capability
base. Preserve shared data/alias charging, checked namespace and byte accounting,
whiteouts, cwd/exec references and failure rollback; do not import accidental
thread/mapping/archive ancestry. Implement and run ordinary nonempty-file scale
and exhaustion checks. Record adversarial overflow/allocation/authority probes
for DaybreakBlue. Then continue G17 in approved dependency order; no publication
before F04, and inherited security holds remain pending.
''' +s[b:];p.write_text(s)
print('Retained G16',m['head'])
