The process table leaves children attached to a dead parent. Reparent them to a live virtual init group after the parent's final running thread exits or is signaled. Keep them attached while another parent thread remains alive, and do not adopt into an already-dead init group.

Three regression cases fail on current main and pass with this library-only correction. Static checks,68 unit tests and all required Linux launch/native/process/setup checks pass locally, including a clean main-plus-patch replay. The existing typed wait/status API stays intact. macOS CI is pending.
