    #[test]
    fn exited_and_signaled_parents_reparent_children() {
        for signal in [false, true] {
            let mut table: ProcessTable<6> = ProcessTable::new();
            let init = table.create_init(Credentials::root()).unwrap();
            let parent = table.fork(init).unwrap();
            let child = table.fork(parent).unwrap();
            let child_thread = table.clone_thread(child).unwrap();
            if signal { table.signaled(parent, 9).unwrap(); }
            else { table.exit(parent, 37).unwrap(); }
            assert_eq!(table.view(child).unwrap().parent, init.pid);
            assert_eq!(table.view(child_thread).unwrap().parent, init.pid);
            let outcome = table.wait(init, WaitTarget::Specific(parent.pid), 0).unwrap();
            assert_eq!(outcome.status, if signal { ChildStatus::Signaled(9) } else { ChildStatus::Exited(37) });
            table.exit(child_thread, 0).unwrap();
            table.reap_thread(child_thread).unwrap();
            table.exit(child, 23).unwrap();
            assert_eq!(table.wait(init, WaitTarget::Specific(child.pid), 0).unwrap().status, ChildStatus::Exited(23));
        }
    }

    #[test]
    fn orphan_adoption_waits_for_the_last_group_member() {
        for leader_signal in [false, true] {
            let mut table: ProcessTable<6> = ProcessTable::new();
            let init = table.create_init(Credentials::root()).unwrap();
            let parent = table.fork(init).unwrap();
            let parent_thread = table.clone_thread(parent).unwrap();
            // Fork from a thread belongs to its process, not its individual tid.
            let child = table.fork(parent_thread).unwrap();
            assert_eq!(table.view(child).unwrap().parent, parent.pid);
            if leader_signal { table.signaled(parent, 15).unwrap(); }
            else { table.exit(parent, 0).unwrap(); }
            assert_eq!(table.view(child).unwrap().parent, parent.pid);
            if leader_signal { table.exit(parent_thread, 0).unwrap(); }
            else { table.signaled(parent_thread, 9).unwrap(); }
            assert_eq!(table.view(child).unwrap().parent, init.pid);
        }
    }

    #[test]
    fn orphan_adoption_requires_a_live_init_group() {
        for live_thread in [false, true] {
            let mut table: ProcessTable<6> = ProcessTable::new();
            let init = table.create_init(Credentials::root()).unwrap();
            let reaper = if live_thread { table.clone_thread(init).unwrap() } else { init };
            let parent = table.fork(init).unwrap();
            let child = table.fork(parent).unwrap();
            table.exit(init, 0).unwrap();
            table.signaled(parent, 9).unwrap();
            assert_eq!(table.view(child).unwrap().parent, if live_thread { init.pid } else { parent.pid });
            if live_thread {
                table.exit(child, 19).unwrap();
                assert_eq!(table.wait(reaper, WaitTarget::Specific(child.pid), 0).unwrap().status, ChildStatus::Exited(19));
            }
        }
    }

