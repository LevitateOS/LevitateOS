Add a bounded supervisor-owned TCP backend

Provide fixed numeric endpoints, concurrent socket slots and cumulative byte
budgets through the existing device library. The Linux adapter uses private
nonblocking TCP sockets and exposes metadata, readiness, socket error and
half-close, with cleanup on close/drop/revoke. Guest networking stays unchanged.

Local static/build and67 selected routine units pass in source and clean
main-plus-patch replay, including real IPv4/IPv6 peers. Linux CI now explicitly
runs device tests with the existing unit build flags. Two new donor security
tests remain enabled but unrun locally; full CI/security and network-contract
review are pending. Not ready to submit.
