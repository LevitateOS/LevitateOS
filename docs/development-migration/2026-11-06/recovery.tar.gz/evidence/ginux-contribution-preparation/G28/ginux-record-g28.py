from pathlib import Path
import json,hashlib,shutil
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G28');art=root/'.artifacts/ginux-contribution-preparation/G28';assert not (docs/'g28-review.md').exists();m=json.loads((temp/'manifest.json').read_text());stat=[json.loads((temp/(p+'static-receipt.json')).read_text()) for p in ['final-','clean-']];assert all(x['exit_code']==0 and x['head']==m['head'] and x['matched_paths']==150 for x in stat);assert stat[0]['binary_sha256']==stat[1]['binary_sha256']
for prefix in ['', 'clean-']:
 units=json.loads((temp/(prefix+'unit-receipt.json')).read_text());assert len(units)==7 and all(x['exit_code']==0 for x in units) and sum(x['passed'] for x in units)==67
 dev=next(x for x in units if x['command'][3]=='ginux-devices');assert dev['passed']==8 and dev['command'].count('--skip')==2
assert [x['exit_code'] for x in json.loads((temp/'baseline-receipt.json').read_text())]==[1,0]
m.update(status='ordinary source/clean preparation and separate self-review retained; full G28 partial: two new security tests, policy/full CI/fresh upstream acceptance pending',routine_unit_tests=67,device_tests_run=8,security_tests_unrun=2,default_linux_unit_total=69,full_make_test_unit='not run unfiltered on Linux; two new donor security tests left for DaybreakBlue',clean_matched_paths=150,review='separate whole-diff self-review; no independent reviewer or security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=stat[0]['binary_sha256'],clean_binary_sha256=stat[1]['binary_sha256'],functional_evidence='real IPv4/IPv6 loopback metadata/roundtrip, synchronized WouldBlock, half-close, cumulative byte/slot limits and close/drop/normal revoke; all preexisting routine units pass',baseline_evidence='same public API probe fails on exact main library with unresolved TCP types and compiles against source; real peer checks are candidate-only new-feature evidence')
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.patch','.diff','.txt','.rs']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g28*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G28.patch')
(art/'draft.md').write_text('''Add a bounded supervisor-owned TCP backend

Provide fixed numeric endpoints, concurrent socket slots and cumulative byte
budgets through the existing device library. The Linux adapter uses private
nonblocking TCP sockets and exposes metadata, readiness, socket error and
half-close, with cleanup on close/drop/revoke. Guest networking stays unchanged.

Local static/build and67 selected routine units pass in source and clean
main-plus-patch replay, including real IPv4/IPv6 peers. Linux CI now explicitly
runs device tests with the existing unit build flags. Two new donor security
tests remain enabled but unrun locally; full CI/security and network-contract
review are pending. Not ready to submit.
''')
assert not any(x in (art/'draft.md').read_text() for x in ['LevitateOS','Recipe','Daybreak'])
(docs/'g28-review.md').write_text(f'''# G28 — bounded supervisor TCP backend (partial)

Head `{m['head']}`, tree `{m['tree']}`, solely on recorded main
`{m['base']}`. [Patch](patches/G28.patch):3 files,+769.
Ordinary source preparation is retained; two new donor security tests, upstream
network contract, full CI and fresh-main acceptance remain pending.

BoundedTcp owns a fixed endpoint array, fixed socket slots and cumulative sent-
plus-received byte quota. The connection limit is concurrent open slots, not a
lifetime connection-attempt counter. Transfers are capped by4096 bytes and quota;
only returned progress is charged, including across socket close/reuse. Empty
transfers consume no quota. Numeric IPv4/IPv6 grants perform no DNS; scope IDs
are not modelled. Callers own public-FD alias counts and grant selection.

The Linux x86-64 adapter owns nonblocking/CLOEXEC sockets, preserves OS errors,
uses MSG_NOSIGNAL for writes and supports endpoint metadata, NODELAY, socket error,
readiness and half-close. EINPROGRESS retains ownership until completion/close.
Readiness describes transport state; byte policy is enforced by read/write.
Socket error follows native SO_ERROR behavior, so integration must retain any
consumed asynchronous error appropriately. Close takes a live handle once,
revocation takes all handles and Drop revokes. No native handle enters a guest.
This is a trusted supervisor library API, not a new guest network permission.

Separate whole-diff self-review inspected all three changed files, endpoint
validation/representation, slot/index bounds, transfer arithmetic, connection
failure cleanup, borrowed handle ownership, raw syscall ABI/endian/layout,
readiness/error consumption, shutdown/Drop/revoke, complete fixtures and both
CI platforms. Existing device implementation and old test text are byte-preserved;
all other tracked paths, core/domain/config and launch behavior remain unchanged.
This is self-review, not independent or adversarial review.

- **CI coverage fix:** these real TCP tests are Linux-only, while the existing
  static/unit job runs on macOS. Add a Linux devices test invocation so coverage
  actually executes there. It resets RUSTFLAGS and uses the existing unit target
  directory, preserving the freestanding release build and original macOS job.
  The full new CI command is unrun locally because it includes the two security
  tests below; no green remote/default-CI claim is made.
- **Meaningful ordinary coverage:** preserve both donor tests and add two real
  local-peer cases that separate ordinary operations from denied/invalid policy.
  A channel handshake proves a read is nonblocking before the server replies;
  the actual peer address is compared with exported local metadata. No new
  runtime framework or G29 guest socket/config dispatch is introduced.
- **Build correction:** ordinary peer EOF assertions now unwrap io::Result before
  comparing its length. The initial failed static log is retained.

Source and strict clean main-plus-patch replay pass make check build, matching
all150 tracked paths and Ginux release hashes. Existing package-unit commands,
with only the two named new tests filtered from ginux-devices, pass67 routine
units in each copy: all65 preexisting units plus two new real-peer cases. Eight
device tests ran, two new ones were filtered, none ignored. This is explicitly
**not** an unfiltered make test-unit/full Linux CI pass (69 tests would run).
The unchanged base library cannot compile the public TCP API probe; the same
probe compiles with the source candidate. This is new-feature evidence, not a
claim of an existing-main TCP runtime regression.

Ordinary real IPv4 and IPv6 peers exercise connect readiness/SO_ERROR, correct
local/peer metadata, NODELAY toggles, synchronized WouldBlock without quota
charge, write half-close, request data, budget-shortened response/prefix, zero-
length I/O and exhaustion. Separate real peers observe EOF after explicit close,
Drop and repeated normal revocation; concurrent slot exhaustion also behaves as
configured. No scanning, foreign destination, malformed endpoint or bypass
experiment was run. These public-API callers make the backend useful/testable on
main without importing its later guest syscall consumer.

The following default-enabled donor tests remain **unrun**, with
[DaybreakBlue](daybreakblue-handoff.md) responsible for them and broader authority/
race/failure validation:

- tcp_endpoint_slots_budget_and_revocation_use_real_connections;
- tcp_drop_closes_connecting_handles_and_invalid_policy_never_opens.

No test is removed, ignored or weakened in default execution. Full/default units,
Linux integration, macOS/remote CI, independent review and network policy consent
are pending. G29 owns guest assignment/FD/readiness and actual HTTP/TLS/Git;
F02/F03 owns final combined/current Recipe acceptance and prior G23–G27 holds.
This standalone source packet is not ready to submit before those applicable
holds and fresh upstream review. No cloud agent was dispatched.

Patch, generic draft, exact commands/SHAs/hashes, unit filters, logs and helpers
live in .artifacts/ginux-contribution-preparation/G28/. Real Ginux branches,
checkouts/indexes/refs and remote text remain untouched. No publication or
maintainer messages; F04 remains the user inspection boundary.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G28');row.update(m);row.update(evidence='g28-review.md',source_patch='patches/G28.patch');p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'p04-dependencies.md';p.write_text(p.read_text()+f'''\nG28 `{m['head'][:8]}` is independent library source directly on recorded main.
Public API callers use real IPv4/IPv6 peers, metadata, budgets and lifecycle;
no G29/domain/FD/task/readiness policy code is imported. Linux-only coverage now
has an explicit Linux CI step with existing unit flags.67 routine units pass in
source/clean; two donor policy/security tests remain enabled and unrun. Full CI,
network contract and security still hold delivery; [review](g28-review.md).
''')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\n## G28 — supervisor TCP backend (partial)

Exact `{m['head']}` on recorded main `{m['base']}`.
Static/build and67 selected routine units pass in source/clean, including real
IPv4/IPv6 metadata, nonblocking I/O, budget/half-close and normal close/drop/revoke.
Only trusted controlled local peers were contacted; no scans or foreign endpoints.

Default-enabled but unrun donor tests:
`tcp_endpoint_slots_budget_and_revocation_use_real_connections` and
`tcp_drop_closes_connecting_handles_and_invalid_policy_never_opens`.
Local unit commands use explicit filters solely for these two new tests;
unfiltered make test-unit/new Linux CI remains pending, not green.

DaybreakBlue must validate denied/foreign/malformed endpoints and family/scope
representations, policy/assignment bypass, revoked/stale/reused handles and public
alias authority, concurrent revoke/close/connect and failed/in-progress cleanup,
backend error/short-count failures, byte-accounting boundaries and adversarial
network/race/failure probes. Check async SO_ERROR consumption when G29 integrates
it. Host descriptor/CLOEXEC authority and guest confinement need that join too.
No cloud dispatch occurred; upstream network policy/full CI and final consumer
acceptance remain pending; [review/evidence](g28-review.md).
''')
p=root/'docs/ginux-contribution-task-list.md';t=p.read_text();a=t.index('Exact next task: **G28');b=t.index('\nActive skill:',a);t=t[:a]+f'''G28 backend-only source preparation is retained at `{m['head'][:8]}` directly on
recorded main. [Review/evidence](ginux-contributions/g28-review.md) records150-path
strict replay, static/build and67 selected routine units passing in source/clean,
including real IPv4/IPv6 metadata, synchronized nonblocking I/O, half-close,
cumulative budget and close/drop/normal revoke. Linux-only device coverage now
has a Linux CI invocation with the correct unit flags. Two new donor policy/
security tests remain enabled but unrun; unfiltered make test-unit/full CI is
pending, not green. Network contract/security and fresh upstream review still
hold delivery. No G29 guest networking, remote mutation or publication occurred.

Exact next task: **G29 — configured TCP syscall/readiness integration**.
Trace66de2880 against prepared G28, public descriptor/task owners and G08 readiness.
Prove the minimal actual capability base and preserve separate policy holds;
do not import thread/global-clock/scalar-clamp ancestry gratuitously. Use trusted
local HTTP/TLS/Git peers for ordinary acceptance where dependencies permit. Carry
G24 timestamp Stat initialization into the new network encoder and preserve
SO_ERROR/partial I/O/close ownership. Record hostile endpoint/buffer/FD/authority/
race/cancellation probes for DaybreakBlue. Preserve all pending G23–G28/F02/F03
acceptance. No publication or maintainer messages before F04.
''' +t[b:];p.write_text(t);print('saved G28',m['head'])
