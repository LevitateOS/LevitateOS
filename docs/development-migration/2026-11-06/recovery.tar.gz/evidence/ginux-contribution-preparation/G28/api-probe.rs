use ginux_devices::{BoundedTcp, LinuxTcpBackend, NetworkError, TcpEndpoint, TcpFamily};
pub fn configured_peer(port:u16)->Result<(),NetworkError> {
    let endpoint=TcpEndpoint::ipv4([127,0,0,1],port)?;
    let mut network:BoundedTcp<_,1,1>=BoundedTcp::new(LinuxTcpBackend,&[endpoint],1,32)?;
    let socket=network.open(TcpFamily::Ipv4)?;
    network.close(socket)
}
