from pathlib import Path
import subprocess,hashlib,json,os
r=Path('/tmp/ginux-contribution-preparation/G28');probe=r/'api-probe.rs';probe.write_text('''use ginux_devices::{BoundedTcp, LinuxTcpBackend, NetworkError, TcpEndpoint, TcpFamily};
pub fn configured_peer(port:u16)->Result<(),NetworkError> {
    let endpoint=TcpEndpoint::ipv4([127,0,0,1],port)?;
    let mut network:BoundedTcp<_,1,1>=BoundedTcp::new(LinuxTcpBackend,&[endpoint],1,32)?;
    let socket=network.open(TcpFamily::Ipv4)?;
    network.close(socket)
}
''');receipts=[]
for name,source in [('baseline',Path('/tmp/ginux-contribution-preparation/G26a/base')),('source',r/'source')]:
 matches=list((source/'target/x86_64-unknown-linux-gnu/release/deps').glob('libginux_devices-*.rlib'));assert len(matches)==1,matches;library=matches[0];cmd=['rustc','--edition=2021','--crate-type=lib',str(probe),'--extern','ginux_devices='+str(library),'-o',str(r/(name+'-api-probe.rlib'))];p=subprocess.run(cmd,capture_output=True);(r/(name+'-api-probe.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==(1 if name=='baseline' else 0),(name,p.stderr.decode());
 if name=='baseline':assert b'unresolved imports' in p.stderr and b'BoundedTcp' in p.stderr
 receipts.append({'command':cmd,'exit_code':p.returncode,'library_sha256':hashlib.sha256(library.read_bytes()).hexdigest(),'base':'3f2fe7dfadd4b40e235d982a6a3d386dc6490177' if name=='baseline' else 'candidate source'});print(name,'API probe',p.returncode,flush=True)
(r/'baseline-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n')
