from pathlib import Path
import subprocess,os,json,re,sys
r=Path('/tmp/ginux-contribution-preparation/G28');s=r/(sys.argv[1] if len(sys.argv)>1 else 'source');prefix='' if s.name=='source' else 'clean-';results=[]
for package in ['ginux-core','ginux-domain','ginux-devices','ginux-runtime','ginux-process','ginux-vfs','ginux-kernel-views']:
 cmd=['cargo','test','-p',package]
 if package=='ginux-devices':cmd+=['--','--skip','tcp_endpoint_slots_budget_and_revocation_use_real_connections','--skip','tcp_drop_closes_connecting_handles_and_invalid_policy_never_opens']
 log=r/(prefix+'unit-'+package+'.log')
 with log.open('w') as f:p=subprocess.run(cmd,cwd=s,env={**os.environ,'RUSTFLAGS':'','CARGO_TARGET_DIR':str(s/'.artifacts/unit')},stdout=f,stderr=subprocess.STDOUT)
 receipt={'command':cmd,'exit_code':p.returncode,'passed':sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',log.read_text()))};results.append(receipt);(r/(prefix+'unit-receipt.json')).write_text(json.dumps(results,indent=2)+'\n');print(prefix,package,p.returncode,receipt['passed'],flush=True);assert p.returncode==0
print('routine unit total',sum(x['passed'] for x in results),'two new donor network security tests not run; default coverage retained',flush=True)
