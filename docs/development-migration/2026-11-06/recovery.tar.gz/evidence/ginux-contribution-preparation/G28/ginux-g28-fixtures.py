from pathlib import Path
s=Path('/tmp/ginux-contribution-preparation/G28/source');p=s/'crates/ginux-devices/src/lib.rs';t=p.read_text();idx=t.rindex('\n}');extra='''
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    #[test]
    fn tcp_loopback_roundtrip_metadata_and_budget() {
        use std::io::{Read, Write};
        use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, TcpListener};
        use std::sync::mpsc;
        use std::time::{Duration, Instant};

        for address in [IpAddr::V4(Ipv4Addr::LOCALHOST), IpAddr::V6(Ipv6Addr::LOCALHOST)] {
            let listener = TcpListener::bind((address, 0)).unwrap();
            let port = listener.local_addr().unwrap().port();
            let endpoint = match address {
                IpAddr::V4(ip) => TcpEndpoint::ipv4(ip.octets(), port).unwrap(),
                IpAddr::V6(ip) => TcpEndpoint::ipv6(ip.octets(), port).unwrap(),
            };
            let (ready_tx, ready_rx) = mpsc::channel();
            let (reply_tx, reply_rx) = mpsc::channel();
            let peer = std::thread::spawn(move || {
                let (mut stream, remote) = listener.accept().unwrap();
                stream.set_read_timeout(Some(Duration::from_secs(3))).unwrap();
                stream.set_write_timeout(Some(Duration::from_secs(3))).unwrap();
                let mut request = [0u8; 4];
                stream.read_exact(&mut request).unwrap();
                assert_eq!(&request, b"ping");
                assert_eq!(stream.read(&mut [0u8]), Ok(0)); // Ordinary write half-close.
                ready_tx.send(remote).unwrap();
                reply_rx.recv_timeout(Duration::from_secs(3)).unwrap();
                stream.write_all(b"pong").unwrap();
            });
            let mut network: BoundedTcp<_, 1, 1> =
                BoundedTcp::new(LinuxTcpBackend, &[endpoint], 1, 7).unwrap();
            let socket = network.open(endpoint.family).unwrap();
            network.connect(socket, endpoint).unwrap();
            let deadline = Instant::now() + Duration::from_secs(3);
            while !network.readiness(socket).unwrap().writable {
                assert!(Instant::now() < deadline);
                std::thread::sleep(Duration::from_millis(1));
            }
            assert_eq!(network.socket_error(socket), Ok(0));
            assert_eq!(network.endpoint(socket, true), Ok(endpoint));
            network.set_nodelay(socket, true).unwrap();
            network.set_nodelay(socket, false).unwrap();
            assert_eq!(network.write(socket, b"ping"), Ok(4));
            network.shutdown(socket, false, true).unwrap();
            let remote = ready_rx.recv_timeout(Duration::from_secs(3)).unwrap();
            let local = network.endpoint(socket, false).unwrap();
            assert_eq!(local.port, remote.port());
            assert_eq!(local.family, endpoint.family);
            assert_eq!(local.address, endpoint.address);
            let mut reply = [0u8; 16];
            assert_eq!(network.read(socket, &mut reply), Err(NetworkError::WouldBlock));
            assert_eq!(network.remaining_bytes(), 3);
            reply_tx.send(()).unwrap();
            let mut used = 0;
            while used < 3 {
                match network.read(socket, &mut reply[used..]) {
                    Ok(count) => { assert_ne!(count, 0); used += count; }
                    Err(NetworkError::WouldBlock) => {
                        assert!(Instant::now() < deadline);
                        std::thread::sleep(Duration::from_millis(1));
                    }
                    other => panic!("ordinary reply failed: {other:?}"),
                }
            }
            assert_eq!(&reply[..used], b"pon");
            assert_eq!(network.remaining_bytes(), 0);
            assert_eq!(network.write(socket, b"x"), Err(NetworkError::ByteLimit));
            assert_eq!(network.read(socket, &mut reply), Err(NetworkError::ByteLimit));
            assert_eq!(network.write(socket, b""), Ok(0));
            assert_eq!(network.read(socket, &mut []), Ok(0));
            network.close(socket).unwrap();
            peer.join().unwrap();
        }
    }

    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    #[test]
    fn tcp_loopback_close_drop_and_revoke() {
        use std::io::Read;
        use std::net::{Ipv4Addr, TcpListener};
        use std::time::Duration;

        let listener = TcpListener::bind((Ipv4Addr::LOCALHOST, 0)).unwrap();
        let endpoint = TcpEndpoint::ipv4([127, 0, 0, 1], listener.local_addr().unwrap().port()).unwrap();
        for completion in 0..3 {
            let mut network: BoundedTcp<_, 1, 2> =
                BoundedTcp::new(LinuxTcpBackend, &[endpoint], 1, 16).unwrap();
            let socket = network.open(TcpFamily::Ipv4).unwrap();
            assert_eq!(network.open(TcpFamily::Ipv4), Err(NetworkError::DescriptorLimit));
            network.connect(socket, endpoint).unwrap();
            let (mut peer, _) = listener.accept().unwrap();
            peer.set_read_timeout(Some(Duration::from_secs(3))).unwrap();
            if completion == 0 { network.close(socket).unwrap(); }
            if completion == 1 { network.revoke(); network.revoke(); }
            drop(network);
            assert_eq!(peer.read(&mut [0u8]), Ok(0));
        }
    }
''';t=t[:idx]+extra+t[idx:];p.write_text(t)
p=s/'.github/workflows/check.yml';t=p.read_text();needle='      - run: make build build-launch-fixture build-process-fixtures build-gate1-fixture';assert needle in t;t=t.replace(needle,'      - run: cargo test -p ginux-devices --lib\n'+needle);p.write_text(t)
p=s/'README.md';t=p.read_text();t+='''
### Supervisor-owned TCP backend

`ginux-devices` exposes `BoundedTcp` with a fixed numeric IPv4/IPv6 endpoint set,
a concurrent socket-slot limit and a cumulative sent-plus-received byte budget.
Connections use a supervisor-supplied `TcpBackend`; the Linux x86-64 adapter uses
private nonblocking, close-on-exec TCP sockets. Each transfer is at most 4096
bytes and only transferred bytes consume budget. Empty transfers consume none.
Endpoint metadata, TCP_NODELAY, readiness, connect error and half-close are
available through the same owner. Connect may remain in progress; callers check
readiness and socket error before treating it as complete. Readiness reports the
transport state; read/write also enforce the byte budget. Final close, drop and
revocation release private handles. Callers own public descriptor alias counts.

This library capability performs no DNS, accepts no connections and does not
change configured-launch networking or the default-denied guest socket contract.
Callers must grant endpoints explicitly before use. It is not a general network
namespace or firewall implementation. Linux device tests exercise real local
peers; the portable static/unit job remains unchanged.
''';p.write_text(t)
print('ordinary local-peer cases added; donor security tests and default CI remain enabled')
