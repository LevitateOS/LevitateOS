Support bounded local packet pairs and shared nonblocking status

Reuse configured channel/public descriptor owners for AF_UNIX sequenced-packet
pairs and FIONBIO, and size object references from16 channel buffers so nested
process streams retain separate device ownership. Preserve current stat flags.

Local check/unit/build,82 units, ordinary packet/alias/message/EOF/peer and
FIONBIO/metadata/twelve-stream/poll cases pass in source and strict clean replay.
Actual compiler/thread/vector/network integration, full security/runtime/remote
CI and upstream prerequisites remain pending. Not ready to submit.
