from pathlib import Path
s=Path('/tmp/ginux-contribution-preparation/G08b/source');p=s/'tests/fixtures/launch-pipe-fixture.c';t=p.read_text();a='long pipe_main(word *stack)';assert a in t
functions='''static int named(const char *a,const char *b){while(*a && *a==*b){++a;++b;}return *a==*b;}
static long ordinary_fionbio(void){
    int pair[2],value=0; CHECK(DO(293,pair,02004000,0)==0,150);
    long alias=DO(32,pair[1],0,0); CHECK(alias>=3,151);
    CHECK(DO(72,alias,4,06001)==0 && DO(16,alias,0x5421,&value)==0,152);
    CHECK(DO(72,pair[1],3,0)==02001 && DO(72,pair[1],1,0)==1 && DO(72,alias,1,0)==0,153);
    value=-7;CHECK(DO(16,pair[1],0x5421,&value)==0 && DO(72,alias,3,0)==06001,154);
    value=0;CHECK(DO(16,pair[0],0x5421,&value)==0 && DO(72,pair[0],3,0)==0,155);
    long child=DO(57,0,0,0);CHECK(child>=0,156);
    if(child==0)return DO(1,alias,"F",1)==1?0:157;
    CHECK(DO(0,pair[0],buffer,1)==1 && buffer[0]=='F',158);
    int status=-1;CHECK(DO(61,child,&status,0)==child && status==0,159);
    value=1;CHECK(DO(16,pair[0],0x5421,&value)==0 && DO(0,pair[0],buffer,1)==-11,160);
    CHECK(DO(3,alias,0,0)==0 && DO(3,pair[1],0,0)==0 && DO(0,pair[0],buffer,1)==0,161);
    CHECK(DO(3,pair[0],0,0)==0,162);return 0;
}
static long ordinary_streams(void){
    int pipes[12][2];struct {int fd;short events,revents;} polls[12];
    for(int i=0;i<12;++i){CHECK(DO(293,pipes[i],04000,0)==0,170);polls[i].fd=pipes[i][0];polls[i].events=1;polls[i].revents=0;CHECK(DO(1,pipes[i][1],"S",1)==1,171);}
    CHECK(DO(7,polls,12,0)==12,172);
    for(int i=0;i<12;++i)CHECK((polls[i].revents&1) && DO(0,pipes[i][0],buffer,1)==1 && buffer[0]=='S',173);
    long child=DO(57,0,0,0);CHECK(child>=0,174);
    if(child==0){long grandchild=DO(57,0,0,0);CHECK(grandchild>=0,175);if(grandchild==0)return DO(1,pipes[11][1],"G",1)==1?0:176;int status=-1;CHECK(DO(61,grandchild,&status,0)==grandchild && status==0,177);return DO(1,pipes[10][1],"N",1)==1?0:178;}
    int status=-1;CHECK(DO(61,child,&status,0)==child && status==0,179);
    CHECK(DO(0,pipes[11][0],buffer,1)==1 && buffer[0]=='G' && DO(0,pipes[10][0],buffer,1)==1 && buffer[0]=='N',180);
    for(int i=0;i<12;++i)CHECK(DO(3,pipes[i][1],0,0)==0 && DO(0,pipes[i][0],buffer,1)==0 && DO(3,pipes[i][0],0,0)==0,181);
    return 0;
}
'''
t=t.replace(a,functions+a);a='    int pair[2];\n    if (argc > 1 && argv[1][0] == \'p\') {';b='''    int pair[2];
    if(argc>1 && (named(argv[1],"ordinary-fionbio") || named(argv[1],"ordinary-streams"))){
        long result=named(argv[1],"ordinary-fionbio")?ordinary_fionbio():ordinary_streams();
        if(result)return result;DO(1,1,"owned-pipes: PASS\\n",18);return 0;
    }
    if (argc > 1 && (argv[1][0] == 'p' || named(argv[1],"ordinary-packet"))) {
        int full=argv[1][0]=='p';''';assert a in t;t=t.replace(a,b)
a='''        CHECK(call(53,2,5,0,(word)pair,0,0)==-95,100);
        CHECK(call(53,1,1,0,(word)pair,0,0)==-95,101);
        CHECK(call(53,1,5,0,1,0,0)==-14,102);''';assert a in t;t=t.replace(a,'        if(full){\n'+a+'\n        }')
a='''        CHECK(DO(1,pair[0],data,4097)==-90,112);
        CHECK(DO(1,pair[0],1,8)==-14 && DO(0,pair[1],buffer,8)==-11,113);''';assert a in t;t=t.replace(a,'        if(full){\n'+a+'\n        }')
t=t.replace('        CHECK(call(44,alias,(word)"x",1,0x4000,0,0)==-32,118);','        if(full){CHECK(call(44,alias,(word)"x",1,0x4000,0,0)==-32,118);}')
a='''        DO(1,1,"owned-pipes: PASS\\n",18);
        return 0;''';b='''        CHECK(call(53,1,5,0,(word)pair,0,0)==0,122);
        CHECK(DO(1,pair[0],buffer,0)==0 && DO(0,pair[1],buffer,8)==0,123);
        long child=DO(57,0,0,0); CHECK(child>=0,124);
        if(child==0){CHECK(DO(3,pair[0],0,0)==0 && DO(1,pair[1],"child",5)==5,125);return DO(0,pair[1],buffer,1)==1 && buffer[0]=='P'?0:126;}
        CHECK(DO(3,pair[1],0,0)==0 && DO(0,pair[0],buffer,8)==5 && buffer[0]=='c' && buffer[4]=='d',127);
        CHECK(DO(1,pair[0],"P",1)==1,128);int status=-1;
        CHECK(DO(61,child,&status,0)==child && status==0 && DO(0,pair[0],buffer,8)==0 && DO(3,pair[0],0,0)==0,129);
        DO(1,1,"owned-pipes: PASS\\n",18);
        return 0;''';assert a in t;t=t.replace(a,b,1);p.write_text(t)
p=s/'scripts/test-launch-pipes.py';t=p.read_text().replace('if len(sys.argv) != 3 or os.geteuid() != 0:', 'if len(sys.argv) < 3 or os.geteuid() != 0:').replace('<pipe-fixture>\'', '<pipe-fixture> [modes...]\'').replace('for p in sys.argv[1:]', 'for p in sys.argv[1:3]')
a='        invoke()\n        invoke(assigned=True)';b='''        if sys.argv[3:]:
            modes=('ordinary-packet','ordinary-fionbio','ordinary-streams')
            for mode in sys.argv[3:]:
                if mode not in modes:sys.exit('unknown ordinary pipe mode')
                invoke([mode],assigned=True)
            print('test-launch-pipes: PASS ('+', '.join(sys.argv[3:])+')')
            return
        invoke()
        invoke(assigned=True)''';assert a in t;t=t.replace(a,b);p.write_text(t)
print('Ordinary packet/FIONBIO/nested12-stream modes added; all donor/default negative modes retained')
