from pathlib import Path
import subprocess,tarfile,io,json
r=Path('/tmp/ginux-contribution-preparation/G08b');s=r/'source';assert not s.exists();s.mkdir(parents=True);repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='fe27c693bf2629166ee82da2efefb62b298bb567'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(s,filter='data')
f='crates/ginux-init/src/channel_hooks.rs';p=s/f;t=p.read_text();donor=git('show','e954010d:'+f).decode();a='pub const PIPE_FD_BASE';assert a in t and a in donor;p.write_text(t[:t.index(a)]+donor[donor.index(a):])
f='crates/ginux-init/src/descriptors.rs';p=s/f;t=p.read_text().replace('counts: [u16; 144]','counts: [u16; 128 + crate::channel_hooks::FDS]').replace('counts: [0; 144]','counts: [0; 128 + crate::channel_hooks::FDS]').replace('80 + (handle - 0x4000_0000) as usize','64 + crate::channel_hooks::FDS + (handle - 0x4000_0000) as usize').replace('(0x2000_0000..0x2000_0010)','(0x2000_0000..0x2000_0000 + crate::channel_hooks::FDS as u32)').replace('22 | 293 =>','22 | 53 | 293 =>').replace('0 | 1 | 5 | 8 | 16 | 17 | 18 | 19 | 20 | 74','0 | 1 | 5 | 8 | 16 | 17 | 18 | 19 | 20 | 44 | 45 | 74')
a='        let flags = if r.orig_rax == 293 { r.rsi } else { 0 };';b='''        let packet = r.orig_rax == 53;
        if packet && (r.rdi != 1 || r.rsi & !(CLOEXEC | 0o4000) != 5 || r.rdx != 0) {
            return Err(-95);
        }
        let flags = if packet { r.rsi & !5 } else if r.orig_rax == 293 { r.rsi } else { 0 };''';assert a in t;t=t.replace(a,b)
a='        let handles = match backends.channels.allocate(flags & !CLOEXEC) {';b='''        let allocated = if packet {
            backends.channels.allocate_packet_pair(flags & !CLOEXEC)
        } else { backends.channels.allocate(flags & !CLOEXEC) };
        let handles = match allocated {''';assert a in t;t=t.replace(a,b)
a='        let copied = copy_memory(pid, r.rdi, &mut bytes, true);';b='        let copied = copy_memory(pid, if packet { r.r10 } else { r.rdi }, &mut bytes, true);';assert a in t;t=t.replace(a,b);p.write_text(t)
for f in ['tests/fixtures/launch-pipe-fixture.c','scripts/test-launch-pipes.py']:(s/f).write_bytes(git('show','e954010d:'+f))
p=s/'README.md';t=p.read_text();a='Up to eight pipe buffers';
if a in t:t=t.replace(a,'Up to sixteen channel buffers')
else:
 a='Up to eight pipes';assert a in t;t=t.replace(a,'Up to sixteen channel buffers')
t+='\nConfigured local `AF_UNIX` / `SOCK_SEQPACKET` pairs consume two channel buffers\nand support duplex messages up to4096 bytes, aliases, nonblocking IO and poll.\nMessages preserve boundaries; a short receive discards the remaining message.\nLocal socket names, descriptor transfer and socket shutdown are unsupported.\nFIONBIO changes the shared open status of owned pipe and packet endpoints,\npreserving other status flags and each public descriptor\'s CLOEXEC flag.\n';p.write_text(t)
(r/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G08a'],'source':['75acd2beeb95fbc62f9177e5116fd6b5d8f22ca8','3b27b37010110b4ccf14936e259fae0a5487efdb','e954010d7f74151d6ab8d03a1d40f4c4b9cb9b5e'],'source_exclusions':['G01 bootstrap_poll_allowed/native policy prefix','G07 shared thread/DescriptorCall ancestry','G02 guest clocks'],'deferred_joins':['G25 channel vectors and canonical helper','G29 socket operation demux for packet send/recv and dynamic network reference offset','G07 thread/security and nested actual compiler consumer F02/F03']},indent=2)+'\n')
print('G08b source ported on per-process G08a; ordinary fixture extraction/review/build still pending')
