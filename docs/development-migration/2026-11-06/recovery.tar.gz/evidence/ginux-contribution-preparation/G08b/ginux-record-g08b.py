from pathlib import Path
import json,shutil,hashlib
root=Path('/home/vince/Projects/LevitateOS');d=root/'docs/ginux-contributions';r=Path('/tmp/ginux-contribution-preparation/G08b');art=root/'.artifacts/ginux-contribution-preparation/G08b';m=json.loads((r/'manifest.json').read_text());stats=[json.loads((r/(p+'static-receipt.json')).read_text()) for p in ['final-','clean-']];assert all(x['exit_code']==0 and x['head']==m['head'] and x['matched_paths']==170 and x['unit_tests']==82 for x in stats);assert stats[0]['binary_sha256']==stats[1]['binary_sha256']
for prefix in ['final-','clean-']:assert all(x['exit_code']==0 for x in json.loads((r/(prefix+'functional-receipt.json')).read_text()))
baseline=json.loads((r/'baseline-receipt.json').read_text());assert [x['exit_code'] for x in baseline]==[103,152,170,163];pipehashes=[hashlib.sha256((r/p/'.artifacts/launch/launch-pipe-fixture').read_bytes()).hexdigest() for p in ['source','verified-head']];assert pipehashes[0]==pipehashes[1]
m.update(status='minimal per-process source/clean preparation and separate whole-diff self-review retained; full G08 partial: actual compiler/thread/vector/network joins, policy/security/full CI/upstream independence pending',unit_tests=82,clean_matched_paths=170,review='separate full-diff self-review; no independent or security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=stats[0]['binary_sha256'],clean_binary_sha256=stats[1]['binary_sha256'],pipe_fixture_sha256=pipehashes[0],evidence='g08b-review.md',source_patch='patches/G08b.patch');(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.patch','.diff']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g08b*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(r/'candidate.patch',d/'patches/G08b.patch');(art/'draft.md').write_text('''Support bounded local packet pairs and shared nonblocking status

Reuse configured channel/public descriptor owners for AF_UNIX sequenced-packet
pairs and FIONBIO, and size object references from16 channel buffers so nested
process streams retain separate device ownership. Preserve current stat flags.

Local check/unit/build,82 units, ordinary packet/alias/message/EOF/peer and
FIONBIO/metadata/twelve-stream/poll cases pass in source and strict clean replay.
Actual compiler/thread/vector/network integration, full security/runtime/remote
CI and upstream prerequisites remain pending. Not ready to submit.
''')
(d/'g08b-review.md').write_text(f'''# G08b — local packet pairs, FIONBIO and nested stream capacity

Head `{m['head']}`, tree `{m['tree']}`, directly on G08a
`{m['base']}`. [Patch](patches/G08b.patch):5 files,+320/-53.
Sources75acd2be,3b27b370,e954010d. This finishes retaining the useful original G08
channel source gap found during F01; it does not complete actual compiler/thread/
security/policy/consumer acceptance or create a standalone-ready PR.

Existing LaunchChannels buffers now optionally store bounded length-prefixed
packet messages, with a paired endpoint pointing at its opposite receive owner.
Each pair consumes2 buffers; max message4096 bytes, short receive discards the
remaining message, zero-length messages retain their boundary. Public aliases/
fork share existing object references, and final endpoint close releases its
read and opposite write direction. No names, listening, host socket, descriptor
transfer or local shutdown is added. MSG_DONTWAIT/NOSIGNAL stay bounded to their
supported sends/receives; native core/bootstrap poll and guest clocks are untouched.

FIONBIO copies a complete integer before mutating shared open status, preserves
APPEND/access bits and per-public-descriptor CLOEXEC, and updates all aliases of
that endpoint. Capacity increases8→16 channel buffers; reference indices derive
from32 channel handle slots so assigned devices follow rather than overlap them.
The current per-process G08a table needs no G07 DescriptorCall/thread ancestry.
G25 vector support and G29 local/network syscall/reference composition stay F02
joins; no unrelated owners are imported solely to match old donor structure.

Separate full-diff self-review read all5 changed files and existing reservation,
copyout rollback, alias/fork/close/reference, buffer lifecycle/readiness, scheduler
retry, strict copy, metadata flags and existing CI/runner owners. The complete
corrected diff was reviewed after authoring. This is self-review, not independent
or adversarial review.

- **Medium, reproduced/corrected — metadata validation regression:** the initial
  donor port accepted only0x1000 for descriptor stat flags, dropping G08a's current
  valid fstatat/statx masks. Restored the exact existing validation owner and added
  valid0x1100 fstatat/0x5000 statx calls to ordinary and full fixtures. The preserved
  intermediate a4a7111e fails that ordinary check at163; corrected head passes.
- **Dependency correction:** packet/FIONBIO changes use channel/public FD owners,
  not inherent shared-thread or guest-clock behavior. Donor's G01 bootstrap-poll
  prefix was excluded; current launch tick/readiness remains G08a's owner.
- **Coverage retained:** every original/default protected-copy, unsupported socket,
  full-buffer, alias/capacity, SIGPIPE and proc/cancellation case stays enabled.
  Default runner includes packet mode. Explicit ordinary modes name their actual
  coverage; they do not call protected pointers or proc/FD authority probes.
  Existing Make/CI pipe and poll fixture targets already cover these files.

Source and strict clean base-plus-patch replay pass make check test-unit build
build-launch-pipe-fixture build-launch-poll-fixture:82 units,170 matched tracked
paths, identical Ginux and fixtures. Three ordinary channel modes in each copy
cover message boundaries/truncation, duplex and zero messages, socket metadata,
readable+HUP, aliases, repeated normal reclamation, real blocking fork peers,
FIONBIO shared status/CLOEXEC and a blocked reader wakeup, accepted metadata flags,
and12 simultaneously used pipes with child/grandchild streams and final EOF.
Five existing ordinary poll/pipe/alias/timer controls also pass in both copies.

Same final valid fixtures on exact G08a fail packet creation103, FIONBIO152 and
stream allocation170 at the old8-buffer capacity. The initial fixture compiler
caught one misleading-indentation line; an initial child helper also duplicated
the parent's PASS output. Both fixture issues were corrected before freezing.
Initial and superseded-head logs remain clearly labeled. These are functional
checks, not actual nested compiler/application closure.

Remaining: actual compiler streams with current thread/filesystem/vector owners
at F02/F03; G07 shared-path/thread hold; G25 byte-stream vector merge; G29 send/
recv demultiplexing must preserve local packet sockets and place network refs
after the enlarged channel+device range; later Stat links/times must follow their
owners. Full/default security modes, Linux/macOS remote CI, native readiness/
clock policy and fresh current-main independence remain pending. General signal
interruption/restart remains unfinished as documented by G08a.

[DaybreakBlue](daybreakblue-handoff.md) owns protected/mutable packet/IOCTL buffers,
partial copies, invalid flags/families/oversized messages, allocation rollback,
private/native FD authority, stale/reused handles, hostile capacity/race/cancel/
thread/SIGPIPE probes. Default tests are preserved and those probes remain unrun.
No cloud dispatch, publication or maintainer contact occurred.

Patch/draft/helpers/results/failures/hashes live in
.artifacts/ginux-contribution-preparation/G08b/. Real Ginux branch/ref/checkouts/
indexes and remote human text remain intact. F04 is the user inspection stop.
''')
p=d/'p05-package-plan.json';plan=json.loads(p.read_text());assert not any(x['packet']=='G08b' for x in plan['packets']);plan['packets'].append({**m,'purpose':'Bounded local packet pairs, shared FIONBIO and nested stream capacity','source_commits':json.loads((r/'composition.json').read_text())['source'],'artifact_directory':'.artifacts/ginux-contribution-preparation/G08b','acceptance':'Original G08 criteria remain; see g08b-review.md for minimal per-process scope and pending joins'})
row=next(x for x in plan['packets'] if x['packet']=='G08');row.update(status='G08a/G08b source and ordinary preparation retained; actual compiler/thread/vector/network joins and policy/security/full CI remain pending',subpackets=['G08a','G08b'],reconciliation='f01-review.md');row.pop('planned_subpackets',None);p.write_text(json.dumps(plan,indent=2)+'\n')
p=d/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\n## G08b — configured packet pairs/FIONBIO/capacity

Head `{m['head']}` on G08a `{m['base']}`.
82 units and ordinary source/clean packet messages/truncation/zero/alias/EOF/peer,
FIONBIO/metadata,12 nested-process streams and poll controls pass. Current stat
flag handling was restored after a donor-port regression reproduced at163.
No native bootstrap poll or guest clock rules were added. Actual compiler/
thread/vector/network joins and full CI/policy remain pending. [Review](g08b-review.md).

Validate protected/mutable packet receive/send and FIONBIO integers, cross-page
short copies and prefix/atomicity/retained-packet behavior; malformed or oversized
messages, unknown flags/family/protocol and unsupported operations; allocation/
copyout rollback, reused/stale/closed/native/private descriptors and assignment
separation; concurrent aliases/close/fork/exec/cancel, blocked retries, capacity
failure, MSG_NOSIGNAL/SIGPIPE and shared-thread signal/call ownership. Retain full
default source tests. These adversarial/proc/authority/fault probes remain unrun;
no cloud dispatch or security acceptance. G07 shared-path hold remains.
''')
p=d/'p04-dependencies.md';p.write_text(p.read_text()+f'''\nF01 identified G08's missing non-readiness source. G08b `{m['head'][:8]}` now retains
FIONBIO/packet pairs/capacity directly on G08a;82 units and ordinary source/clean
peers/messages/metadata/12 nested streams pass. No G07/native-clock/bootstrap-poll
ancestry is required. Preserve current stat flag validation rather than donor's
older restricted check. Actual compiler/thread/vector/security/full CI remain;
G29 local/network send/recv and reference-index joining is required at F02.
[Review/evidence](g08b-review.md).
''')
p=d/'f01-review.md';t=p.read_text().replace('verifies36 distinct retained heads and36 durable patches','now includes37 retained heads and37 durable patches (36 verified in the initial\nF01 inventory plus the G08b source-gap correction)').replace('The audit found a useful source gap: only G08a readiness has been prepared.','The initial audit found a useful source gap: only G08a readiness had been prepared.').replace('still need a retained minimal extraction.','needed a retained minimal extraction; [G08b](g08b-review.md) now provides it.').replace('Prepare G08b on\nG08a\'s per-process owner, preserving all full/default negative cases and ordinary\npeer/channel acceptance.','G08b uses\nG08a\'s per-process owner, preserves full/default negative cases and passes ordinary\nsource/clean peer/channel checks.').replace('Next finish this already-authorized original G08 remainder,\nthen reconcile all remaining source hunks/old-fork dispositions before F02 shared','The original G08 remainder is now source-prepared;\nreconcile all remaining source hunks/old-fork dispositions before F02 shared');p.write_text(t)
p=root/'docs/ginux-contribution-task-list.md';t=p.read_text();a=t.index('Exact next action under F01:');b=t.index('\nActive skill:',a);t=t[:a]+f'''The initial F01 source gap is corrected: G08b `{m['head'][:8]}` on G08a retains
packet pairs/FIONBIO/nested stream capacity. [Review/evidence](ginux-contributions/g08b-review.md)
records82 units,170-path strict replay, ordinary packets/aliases/EOF/peers,
FIONBIO/accepted metadata flags,12 child/grandchild streams and poll controls
passing in source/clean. Exact G08a fails the new valid capabilities; a donor
metadata-flag regression was reproduced and corrected. All default security
coverage remains enabled/unrun; actual compiler/thread/vector/network joins,
policy/security/full CI/current-main independence remain pending. There are now
37 retained patch units, not37 PRs. No publication occurred.

Exact next action: **finish F01 semantic hunk/old-fork reconciliation**.
Refresh the initial36-patch inventory to include G08b, reconcile every original
261-hunk/P03 commit disposition against actual final owners and explicitly retain
G07/policy/security/consumer holds. Then compose/review shared owners at F02,
run fresh complete current Recipe and actual consumers at F03, and present F04
for user inspection. G29 socket demux must continue supporting local packet
send/recv, and network reference offsets must follow the enlarged channel/device
range. Preserve G25 helper/vector and G24 Stat joins; all open G07/G08/G23–G30
acceptance remains active. No branch/ref/push/PR/maintainer messages before review.
''' +t[b:];p.write_text(t);print('saved G08b',m['head'],'source gap retained; F01 still incomplete with37 patch units')
