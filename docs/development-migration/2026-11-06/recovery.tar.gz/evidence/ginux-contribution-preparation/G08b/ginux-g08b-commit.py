from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';r=Path('/tmp/ginux-contribution-preparation/G08b');s=r/'source';base=json.loads((r/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['README.md','crates/ginux-init/src/descriptors.rs','crates/ginux-init/src/channel_hooks.rs','scripts/test-launch-pipes.py','tests/fixtures/launch-pipe-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g08b-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(s/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',base,input=('feat(channels): support local packet pairs and shared nonblocking flags\n\nReuse public descriptor ownership for bounded duplex packet messages and\nFIONBIO status updates. Size reference ownership from the channel capacity\nto support nested process streams without overlapping assigned devices.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert not any(x in patch for x in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in git('ls-tree','-r','--name-only',base).decode().splitlines():
 if name in files:continue
 p=s/name;assert (os.readlink(p).encode() if p.is_symlink() else p.read_bytes())==git('show',base+':'+name),name
(r/'candidate.patch').write_bytes(patch);(r/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G08b','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':['G08a'],'standalone_source':False,'status':'source ordinary packet/FIONBIO/nested stream checks pass; full diff review/strict clean replay/security/full CI/actual compiler joins pending','patch_sha256':hashlib.sha256(patch).hexdigest(),'deferred_joins':['G07 shared FD/thread/security','G25 channel vectors','G29 local/network socket demux and dynamic reference offsets','actual nested compiler streams F02/F03'],'policy':'configured local packet pairs only; no native bootstrap poll or guest clock rules imported; full security/policy unchanged'};(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
