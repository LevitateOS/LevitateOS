from pathlib import Path
import subprocess,json
r=Path('/tmp/ginux-contribution-preparation/G08b')
for d,prefix in [('source','final-'),('verified-head','clean-')]:
 s=r/d;records=[]
 for name,script,fixture,modes in [('channels','test-launch-pipes.py','launch-pipe-fixture',['ordinary-packet','ordinary-fionbio','ordinary-streams']),('poll','test-launch-poll.py','launch-poll-fixture',['ordinary','read','write','hup','ordinary-timer'])]:
  cmd=['sudo','-n','python3','scripts/'+script,'target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/'+fixture,*modes]
  with (r/(prefix+name+'-functional.log')).open('w') as f:p=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
  records.append({'command':cmd,'exit_code':p.returncode});(r/(prefix+'functional-receipt.json')).write_text(json.dumps(records,indent=2)+'\n');print(d,name,p.returncode,flush=True);assert p.returncode==0
