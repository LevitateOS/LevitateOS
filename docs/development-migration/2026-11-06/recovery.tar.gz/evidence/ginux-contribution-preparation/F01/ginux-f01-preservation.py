from pathlib import Path
import subprocess,json,re,collections
root=Path('/home/vince/Projects/LevitateOS');r=Path('/tmp/ginux-contribution-preparation/F01');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';plan=json.loads((root/'docs/ginux-contributions/p05-package-plan.json').read_text());base=plan['upstream_base'];packages=['ginux-core','ginux-domain','ginux-devices','ginux-runtime','ginux-process','ginux-vfs','ginux-kernel-views']
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a]).decode()
test_pattern=r'#\[test\](?:\s*#\[[^\]]*\])*\s*(?:unsafe\s+)?fn\s+(\w+)'
paths=[(f.split('/')[1],f) for f in git('ls-tree','-r','--name-only',base).splitlines() if f.endswith('.rs') and any(f.startswith('crates/'+p+'/src/') for p in packages)]
original={f:collections.Counter(re.findall(test_pattern,git('show',base+':'+f))) for p,f in paths};files=['scripts/test-process-native.py','tests/fixtures/process-review-fixture.c','crates/ginux-kernel-views/src/cgroup.rs'];expected={f:git('show',base+':'+f) for f in files};names=['read_tracee_pipefds','store_wait_results','store_tracee_status','store_tracee_tid','write_wait_fault']
def function(t,name):
 at=t.index('fn '+name+'(');at=t.index('{',at);depth=0
 for end in range(at,len(t)):
  if t[end]=='{':depth+=1
  elif t[end]=='}':
   depth-=1
   if depth==0:return t[at:end+1]
 raise AssertionError(name)
bmain=git('show',base+':crates/ginux-init/src/main.rs');bfuncs={n:function(bmain,n) for n in names};records=[]
for row in [x for x in plan['packets'] if x.get('head')]+[next(x for x in plan['packets'] if x['packet']=='G07')]:
 head=row.get('head',row.get('unready_snapshot'));missing={}
 for p,f in paths:
  actual=collections.Counter(re.findall(test_pattern,git('show',head+':'+f)));delta=original[f]-actual
  if delta:missing[f]=dict(delta)
 make=git('show',head+':Makefile');ci=git('show',head+':.github/workflows/check.yml');assert '      - run: make test-unit\n' in ci;unit=make[make.index('test-unit:\n'):];unit=unit[:unit.index('\n\n')];assert all('cargo test -p '+p in unit for p in packages)
 main=git('show',head+':crates/ginux-init/src/main.rs');core_unchanged=git('show',head+':crates/ginux-core/src/lib.rs')==git('show',base+':crates/ginux-core/src/lib.rs');assert core_unchanged,row['packet'];record={'native_core_contract_identical_to_base':core_unchanged,'packet':row['packet'],'head':head,'missing_original_test_names':missing,'unit_packages_preserved':packages,'required_ci_unit_invocation_preserved':True,'native_process_fixtures_identical_to_base':{f:git('show',head+':'+f)==expected[f] for f in files},'native_protected_copy_caller_bodies_identical_to_base':{n:function(main,n)==bfuncs[n] for n in names}};records.append(record)
(r/'unit-preservation.json').write_text(json.dumps({'base':base,'base_named_test_counts':{p:sum(sum(original[f].values()) for owner,f in paths if owner==p) for p in packages},'base_named_tests':sum(sum(v.values()) for v in original.values()),'test_source_paths':[f for _,f in paths],'scope':'test names/targets/CI and selected native fixture/caller text comparison only; does not establish security or full CI acceptance','checks':records},indent=2)+'\n')
print('unit/CI/native preservation source checks',len(records),'heads');print('exceptions',[(x['packet'],x['missing_original_test_names'],{k:v for k,v in x['native_process_fixtures_identical_to_base'].items() if not v},{k:v for k,v in x['native_protected_copy_caller_bodies_identical_to_base'].items() if not v}) for x in records if x['missing_original_test_names'] or not all(x['native_process_fixtures_identical_to_base'].values()) or not all(x['native_protected_copy_caller_bodies_identical_to_base'].values())])
