from pathlib import Path
import json,subprocess,collections
root=Path('/home/vince/Projects/LevitateOS');d=root/'docs/ginux-contributions';r=Path('/tmp/ginux-contribution-preparation/F01');plan=json.loads((d/'p05-package-plan.json').read_text());catalog=json.loads((d/'p03-catalog.json').read_text());hunks=json.loads((r/'hunk-provenance.json').read_text());inventory=json.loads((r/'inventory.json').read_text());repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';rows={x['packet']:x for x in plan['packets']};files={}
for row in inventory['patches']:
 files[row['packet']]=set(subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'diff','--name-only',row['base'],row['head']]).decode().splitlines())
files['G07']=set(subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'diff','--name-only',rows['G07']['base'],rows['G07']['unready_snapshot']]).decode().splitlines());merges={'8b5cf5ddf553a9f795a5985daf512dbbffcf9495':['G06b'],'28f0a7d6ce48c148a45c788eeb970576068e36d0':['G06a','G06b','G07']};groups={'G03':['G03a','G03b','G03c'],'G06':['G06a','G06b'],'G08':['G08a','G08b'],'G09':['G09a','G09b','G09c','G09d'],'G17':['G17a','G17b'],'G26':['G26a','G26b'],'G31':['G20','G21']}
core={15:'G01 native bootstrap poll constants: preserve existing #207 source/policy hold; no duplicate candidate or implicit global grant.',16:'Donor native getcwd grant is excluded. G14 mediates configured cwd through its existing owner; all37 prepared heads and unready G07 keep the exact recorded-main core bytes.',17:'G01 console/native poll and G02 global clock/sleep rules remain source/policy-held. Configured G08a readiness uses internal time without changing this contract.',18:'G01 native bootstrap descriptor/time bounds remain held with #207, separate from configured G08a readiness.',19:'G02 realtime/monotonic/sleep argument policy remains held under #179; no dynamic fd/PID clocks or unapproved rule import.'}
for h in hunks:
 path=h['path'];i=h['hunk'];owners=set();provenance=[]
 for e in h['provenance']:
  if e['commit'] in merges:
   e.update(kind='integration merge resolution; no standalone change',owners=merges[e['commit']])
  assert e['kind']!='unresolved provenance',(i,e)
  for owner in e['owners']:
   for candidate in groups.get(owner,[owner]):
    if candidate in files and path in files[candidate]:owners.add(candidate)
    elif candidate in ['G01','G02']:owners.add(candidate)
  provenance.append(e)
 h['current_source_owners']=sorted(owners);h['review_records']=[rows[x].get('evidence','policy-held-packets.md') for x in sorted(owners) if x in rows];h['provenance']=provenance
 if path=='crates/ginux-core/src/lib.rs':text=core[i];kind='explicit policy hold or excluded donor grant'
 elif path in ['scripts/test-process-native.py','tests/fixtures/process-review-fixture.c'] or path=='crates/ginux-init/src/main.rs' and (i==92 or 95<=i<=106):
  text='Preserve current upstream native supervision/protected-copy/error handling and fixtures. Exclude donor legacy helper/fault-test removals/reversions. All38 retained/held heads keep the two native process fixture files and five protected-copy caller bodies byte-identical to recorded main.';kind='preserve upstream; exclude stale donor reversion'
 elif path=='crates/ginux-init/src/supervisor.rs':
  if i==118:text='UserRegs Clone/Copy support is retained with argument/descriptor transactions. Preserve current upstream copy owners; G27 adds its strict copy helper through the existing raw-copy owner.';kind='retained current-owner adaptation'
  elif i==120:text='Old assembly formatting is cosmetic and is not its own contribution. Keep current source formatting and upstream copy semantics.';kind='omit cosmetic donor-only formatting'
  else:text='Exclude deletion of upstream strict/fallback copy helpers, errno constants and caching. Current helpers remain in all retained sources; G27 factors raw process_vm copying while retaining legacy fallback semantics and adds a strict configured identity copy.';kind='preserve upstream; exclude stale donor deletion'
 elif i in [55,56]:text='Configured launch entry dispatch is moved into the G06b task owner; keep only imports needed by the final current owner. Native process/contract code is preserved.';kind='retained owner-local move'
 elif i==68:text='Replace the old blanket unsupported-storage/device startup rejection with G03c/G04/G29 explicit assignment owner preparation; no general host path/device/network fallback.';kind='retained explicit assignment adapters'
 elif i==129:text='G06b separates nonconsuming peek from final wait retirement; the public wait wrapper still retires once. G06a orphan adoption and G07 held thread rollback use current typed process APIs. This is not an independent merge-history PR.';kind='retained typed lifecycle adaptation'
 elif i==154:text='Donor removes one blank line; no behavioral contribution or upstream change is needed.';kind='omit cosmetic formatting'
 elif path in ['Makefile','.github/workflows/check.yml']:
  text='Feature fixture builds and default runner invocations travel with their actual source owners, including G20 checkpoint/G21 restore and G28 Linux TCP units. G31 folds into those owners. Preserve all7 unit package commands, required make test-unit and native fixtures. Combine each coverage invocation once at F02.';kind='folded coverage/build ownership'
 elif path=='config/domain-gate5.toml':text='G26a/b resource comments describe kernel per-process virtual AS and eligible logical CPU subsets. Keep their public contract hold and do not imply aggregate RSS or CPU-time accounting.';kind='retained resource documentation'
 elif i==6 or path=='scripts/test-launch.py' and i==233:
  text='4632b5b2 invalid/incomplete command rejection is already upstream (#165); preserve current parser/CLI checks rather than submit a duplicate. Merge28f0 reconciles current native APIs, not an independent feature.';kind='already upstream or reconciled equivalent'
 elif path=='scripts/test-launch.py' and i==229:text='Native/bootstrap poll scenario remains held with G01/#207. G08a/b configured owned readiness uses its own current runner; do not enable native policy for it.';kind='policy-held native polling coverage'
 elif path=='scripts/test-launch.py' and i in [231,232]:text='G06b configured task identity/audit expectations use actual virtual IDs and task owner. Reconciliation from8b5cf5dd does not authorize unrelated native fixture changes.';kind='retained configured lifecycle assertions'
 else:
  if owners:text='Retain the useful behavior through the linked current source owner(s), including their recorded corrections, generic docs and meaningful fixtures. Preserve current upstream baseline and tests; do not copy mixed donor files wholesale. Exact combined-owner semantics and all remaining security/consumer acceptance stay at F02/F03.';kind='retained adapted source with linked reviews'
  elif all(e['kind']=='upstream ancestry' for e in provenance):text='Keep current upstream behavior/tests instead of donor movement or stale older text. No separate fork-only feature is needed.';kind='preserve current upstream equivalent'
  elif not provenance:text='No new source lines in this hunk; the legacy deletion is superseded by current owner extraction. Preserve original tests and check behavior through the recorded owner reviews and F02 union.';kind='owner-local deletion disposition'
  else:raise AssertionError((i,path,provenance))
 h.update(disposition=text,disposition_class=kind,acceptance='Disposition only. Read linked packet status; local ordinary/source checks do not establish security/full CI/current-main independence.')
assert len(hunks)==261 and all(x['disposition'] and x['disposition_class'] for x in hunks)
(r/'hunk-dispositions.json').write_text(json.dumps(hunks,indent=2)+'\n');print('all261 original hunks have explicit source/current-upstream/held/folded dispositions; classes',dict(collections.Counter(x['disposition_class'] for x in hunks)));print('preserved old-fork behavior questions: current VFS copy-up reader identity remains upstream behavior; no configured EmptyReader storage consumer requires restoring the old prototype redirection. Record existing contract explicitly; do not invent an upstream change.')
