from pathlib import Path
import subprocess,json,re,collections,hashlib
root=Path('/home/vince/Projects/LevitateOS');d=root/'docs/ginux-contributions';r=Path('/tmp/ginux-contribution-preparation/F01');catalog=json.loads((d/'p03-catalog.json').read_text());plan=json.loads((d/'p05-package-plan.json').read_text());hunks=json.loads((root/'.artifacts/ginux-contribution-preparation/p03/hunks.json').read_text());repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base=catalog['base'];donor=catalog['integration']
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
source={}
for row in plan['packets']:
 for sha in row.get('source_commits',[]):source.setdefault(sha,[]).append(row['packet'])
old={x['commit']:x for x in catalog['other_worktree_commits']};known={x['commit']:x for x in catalog['commits']};ranges=[];file=None
for line in git('diff','--no-ext-diff','--unified=0',base,donor,'--').decode().splitlines():
 if line.startswith('+++ b/'):file=line[6:]
 elif line.startswith('@@ '):ranges.append((file,line))
assert ranges==[(x['path'],x['range']) for x in hunks]
blames={};upstream={};out=[]
for path in dict.fromkeys(x['path'] for x in hunks):
 text=git('blame','--line-porcelain',donor,'--',path).decode();lines={};sha=None;at=None
 for line in text.splitlines():
  if re.match(r'^[0-9a-f]{40} \d+ \d+',line):
   parts=line.split();sha=parts[0];at=int(parts[2])
  elif line.startswith('\t'):assert at is not None;lines[at]=sha
 blames[path]=lines
for i,h in enumerate(hunks):
 match=re.match(r'@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@',h['range']);assert match;start=int(match[1]);count=int(match[2]) if match[2] is not None else 1
 provenance=collections.Counter(blames[h['path']][n] for n in range(start,start+count));entries=[]
 for sha,n in provenance.items():
  if sha in source:kind='retained source packet or explicitly held component';owners=source[sha]
  elif sha in old:kind=old[sha]['disposition'];owners=[old[sha]['packet']]
  elif sha in known:kind=known[sha]['packet'];owners=[]
  else:
   if sha not in upstream:upstream[sha]=subprocess.run(['git','-C',repo,'--work-tree='+repo,'merge-base','--is-ancestor',sha,base],capture_output=True).returncode==0
   kind='upstream ancestry' if upstream[sha] else 'unresolved provenance';owners=[]
  entries.append({'commit':sha,'lines':n,'kind':kind,'owners':owners})
 out.append({**h,'hunk':i,'new_line_count':count,'provenance':entries,'disposition':'pending semantic owner reconciliation; provenance is not acceptance'})
(r/'hunk-provenance.json').write_text(json.dumps(out,indent=2)+'\n')
unknown=collections.Counter(e['commit'] for h in out for e in h['provenance'] if e['kind']=='unresolved provenance');print('exact original hunk ranges verified',len(out),'unknown provenance',dict(unknown));print('pure deletions',[(x['hunk'],x['path'],x['range']) for x in out if x['new_line_count']==0]);print('core',[(x['hunk'],[(e['commit'][:8],e['owners']) for e in x['provenance']]) for x in out if x['path']=='crates/ginux-core/src/lib.rs'])
