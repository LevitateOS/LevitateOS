from pathlib import Path
import subprocess,json,hashlib,ast
r=Path('/tmp/ginux-contribution-preparation/G31');r.mkdir(exist_ok=True);repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';receipts=[]
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
source='5e20a65f29b2d45e2840a69ef0e24613dc40e278';diff=git('show','--format=','--no-ext-diff',source).decode();assert git('diff-tree','--no-commit-id','--name-only','-r',source).decode().splitlines()==['.github/workflows/check.yml'];assert '+      - run: sudo make test-launch-checkpoints' in diff;(r/'donor.patch').write_text(diff)
for packet,target,runner in [('G20','test-launch-checkpoints','scripts/test-launch-checkpoints.py'),('G21','test-launch-restore','scripts/test-launch-restore.py')]:
 p=Path('/tmp/ginux-contribution-preparation')/packet;m=json.loads((p/'manifest.json').read_text());assert all(x['exit_code']==0 for x in json.loads((p/'functional-receipt.json').read_text()));assert all(x['exit_code']==0 for x in json.loads((p/'clean-functional-receipt.json').read_text()))
 for d in ['source','verified-head']:
  s=p/d;files=['.github/workflows/check.yml','Makefile',runner,'tests/fixtures/launch-storage-fixture.c']
  for f in files:assert (s/f).read_bytes()==git('show',m['head']+':'+f),(packet,d,f)
  ci=(s/files[0]).read_text();assert '      - run: make test-unit\n' in ci and f'      - run: sudo make {target}\n' in ci and 'build-launch-storage-fixture' in ci
  ast.parse((s/runner).read_text());cmd=['make','-n','build-launch-storage-fixture',target,'test-unit'];p2=subprocess.run(cmd,cwd=s,capture_output=True);assert p2.returncode==0 and (f'python3 {runner}').encode() in p2.stdout
  (r/f'{packet}-{d}-dry-run.log').write_bytes(p2.stdout+p2.stderr);receipts.append({'packet':packet,'head':m['head'],'tree':m['tree'],'export':d,'command':cmd,'exit_code':p2.returncode,'exact_files_verified':files,'existing_runtime_evidence':[str(p/'functional-receipt.json'),str(p/'clean-functional-receipt.json')],'full_default_runtime':'not run; preserve security holds','remote_ci':'not run'})
(r/'receipt.json').write_text(json.dumps({'source':source,'disposition':'folded into G20 checkpoint and G21 restore; no separate patch or PR','checks':receipts},indent=2)+'\n');print('G31 one-line donor coverage accounted in exact G20/G21 owners; source/clean wiring dry runs pass; full CI not run')
