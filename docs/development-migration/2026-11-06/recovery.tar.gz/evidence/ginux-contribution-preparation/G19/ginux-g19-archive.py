from pathlib import Path
root=Path('/tmp/ginux-contribution-preparation/G19');src=root/'source'
archive=(root/'donor-storage-export.rs').read_text();a=archive.index('pub struct Archive(')
header=r'''//! Quiesced owned-file export. Stage privately beside the requested host path,
//! then publish a complete, synced, closed archive without replacing a name.
//! Guest names are archive data and never choose supervisor host destinations.
use crate::supervisor::{syscall1, syscall3, syscall4, syscall5};
use ginux_vfs::{FileMetadata, NodeKind};

type Error = &'static [u8];
const PATH_BYTES: usize = crate::launch::MAX_RESULT_PATH_LEN + 1;
const AT_FDCWD: usize = (-100isize) as usize;
struct Export {
    fd: usize,
    destination: [u8; PATH_BYTES],
    temporary: [u8; PATH_BYTES],
}
static mut EXPORT: Option<Export> = None;

impl Export {
    fn remove(&self) -> Result<(), Error> {
        if unsafe { syscall1(87, self.temporary.as_ptr() as usize) } == 0 {
            Ok(())
        } else {
            Err(b"export staging cleanup failed")
        }
    }
}

fn take() -> Option<Export> {
    unsafe { core::ptr::replace(core::ptr::addr_of_mut!(EXPORT), None) }
}

pub fn prepare(path: *const u8) -> Result<(), Error> {
    if path.is_null() { return Ok(()); }
    let mut destination = [0; PATH_BYTES];
    let mut length = 0;
    while length < PATH_BYTES {
        let byte = unsafe { core::ptr::read_volatile(path.add(length)) };
        if byte == 0 { break; }
        destination[length] = byte;
        length += 1;
    }
    if length == 0 || length == PATH_BYTES { return Err(b"export-file path length invalid"); }
    let mut stat = [0u64; 18];
    let existing = unsafe { syscall4(262, AT_FDCWD, destination.as_ptr() as usize, stat.as_mut_ptr() as usize, 0x100) };
    if existing != -2 { return Err(b"export-file path is not fresh or not creatable"); }
    let parent = destination[..length].iter().rposition(|b| *b == b'/').map_or(0, |n| n + 1);
    let pid = unsafe { syscall1(39, 0) };
    if pid <= 0 { return Err(b"export staging identity unavailable"); }
    let mut digits = [0; 20];
    let mut value = pid as usize;
    let mut count = 0;
    while value != 0 {
        digits[count] = b'0' + (value % 10) as u8;
        value /= 10;
        count += 1;
    }
    let prefix = b".ginux-export-";
    let end = parent.checked_add(prefix.len()).and_then(|n| n.checked_add(count))
        .filter(|n| *n < PATH_BYTES).ok_or(b"export staging path exceeds bound".as_slice())?;
    let mut temporary = [0; PATH_BYTES];
    temporary[..parent].copy_from_slice(&destination[..parent]);
    temporary[parent..parent+prefix.len()].copy_from_slice(prefix);
    for (index, digit) in digits[..count].iter().rev().enumerate() {
        temporary[parent+prefix.len()+index] = *digit;
    }
    if temporary[..end] == destination[..length] { return Err(b"export staging name conflicts with destination"); }
    // O_EXCL and mode0600 keep an incomplete archive private. A stale staging
    // name fails explicitly; it is never overwritten or treated as output.
    let opened = unsafe { syscall4(257, AT_FDCWD, temporary.as_ptr() as usize, 1|64|128|0x80000, 0o600) };
    if opened < 0 { return Err(b"export staging path is not fresh or not creatable"); }
    let mut state = Export { fd: opened as usize, destination, temporary };
    if opened < 3 {
        let duplicate = unsafe { syscall3(72, opened as usize, 1030, 3) };
        let closed = unsafe { syscall1(3, opened as usize) };
        if duplicate < 0 || closed != 0 {
            if duplicate >= 0 { unsafe { syscall1(3, duplicate as usize); } }
            state.remove()?;
            return Err(b"export-file descriptor reservation failed");
        }
        state.fd = duplicate as usize;
    }
    unsafe { core::ptr::write(core::ptr::addr_of_mut!(EXPORT), Some(state)); }
    Ok(())
}

pub fn cancel() -> Result<(), Error> {
    let Some(state) = take() else { return Ok(()); };
    let closed = unsafe { syscall1(3, state.fd) };
    let removed = state.remove();
    if closed != 0 { return Err(b"export-file close failed"); }
    removed
}

pub fn finish(write: impl FnOnce(&mut Archive) -> Result<(), Error>) -> Result<(), Error> {
    let Some(state) = take() else { return Ok(()); };
    let mut archive = Archive(state.fd);
    let result = write(&mut archive).and_then(|_| archive.bytes(&[0;1024])).and_then(|_| {
        loop {
            match unsafe { syscall1(74, state.fd) } {
                0 => break Ok(()),
                -4 => continue,
                _ => break Err(b"export-file sync failed".as_slice()),
            }
        }
    });
    let closed = unsafe { syscall1(3, state.fd) };
    if let Err(reason) = result {
        state.remove()?;
        return Err(reason);
    }
    if closed != 0 {
        state.remove()?;
        return Err(b"export-file close failed");
    }
    // RENAME_NOREPLACE is the publication point, after successful close. An
    // intervening destination creation cannot replace that caller's file.
    if unsafe { syscall5(316, AT_FDCWD, state.temporary.as_ptr() as usize, AT_FDCWD, state.destination.as_ptr() as usize, 1) } != 0 {
        state.remove()?;
        return Err(b"export-file publication failed");
    }
    Ok(())
}

'''
(src/'crates/ginux-init/src/storage_export.rs').write_text(header+archive[a:]);print('atomic archive owner written')
