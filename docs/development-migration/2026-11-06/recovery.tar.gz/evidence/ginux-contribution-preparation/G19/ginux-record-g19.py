from pathlib import Path
import json,hashlib,shutil
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G19');art=root/'.artifacts/ginux-contribution-preparation/G19';art.mkdir(parents=True,exist_ok=True)
m=json.loads((temp/'manifest.json').read_text());m.update(status='per-process source separately self-reviewed; selected ordinary source/clean checks pass; thread/security/full CI/upstream independence pending',unit_tests=92,vfs_tests=34,clean_matched_paths=179,review='separate self-review; no independent reviewer/security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',held_dependencies=['G07 thread quiescence and shared-argument security'],source_binary_sha256=json.loads((temp/'final-static-receipt.json').read_text())['binary_sha256'],clean_binary_sha256=json.loads((temp/'clean-static-receipt.json').read_text())['binary_sha256'],backing_dependency='native fsync uses G12 memfd backing; export alone does not inherently require mappings')
assert m['source_binary_sha256']==m['clean_binary_sha256']
for prefix in ['', 'clean-']:
 rs=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(rs)==3 and all(r['exit_code']==0 for r in rs)
fixtures={}
for name in ['launch-storage-fixture','launch-directory-fixture','launch-script-fixture','launch-owned-exec-fixture']:
 a=(temp/'source/.artifacts/launch'/name).read_bytes();b=(temp/'verified-head/.artifacts/launch'/name).read_bytes();assert a==b;fixtures[name]=hashlib.sha256(a).hexdigest()
m['fixture_sha256']=fixtures;(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');r=json.loads((temp/'review-completion-cleanup-receipt.json').read_text());r['after_head']=m['head'];(temp/'review-completion-cleanup-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
for p in temp.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.patch','.diff','.rs']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g19*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G19.patch')
(art/'draft.md').write_text('''Flush owned files and export after quiesced successful exit

Support fsync/fdatasync on owned backing and --export-file for regular files and
directories after all supported tasks settle. Preserve modes and long paths;
exclude deleted and image data. Stage privately and publish without overwrite
after write/sync/close, cancelling unfinished output on failed completion.

Local92-unit/build checks, ordinary export/cleanup/child-settlement and existing
mapping/script/ELF/storage checks pass in source and clean replay. Thread sharing,
security/full runtime coverage, remote CI and prerequisite merges remain pending;
not ready to submit.
''');assert not any(s in (art/'draft.md').read_text() for s in ['LevitateOS','Recipe','Daybreak'])
(docs/'g19-review.md').write_text(f'''# G19 — flush and quiesced final export

Head `{m['head']}`, tree `{m['tree']}`, on G12
`{m['base']}`. [Patch](patches/G19.patch): ten files,+527/-24.
Per-process source/ordinary preparation is retained; thread/security/full CI and
actual upstream independence remain pending. The real fsync consumer uses G12's
memfd backing. Core export alone does not inherently need mappings; no G18/G17
budget, G13/G15 archive identity or held G07 thread ancestry is imported here.

Owned regular-file fsync/fdatasync reaches its supervisor descriptor, including
write-only and empty files; virtual directory sync succeeds without native path
access. Additive VFS descriptor_storage/overlay_entry/read_overlay APIs keep
backing authority and descriptor-free export reads in the existing owner. No
configuration schema or typed process/native supervisor change is introduced.

The CLI adds --export-file alongside the existing optional result path. After
successful root exit, existing teardown kills/reaps remaining processes, releases
descriptions and executable refs and verifies no active virtual state before
reading live file/directory entries. Export completes before filesystem teardown;
failed export still tears down owned storage before reporting supervision error.
Unsuccessful root completion cancels export. Thread-sharing joins remain held.

Separate final self-review read the full diff and current CLI/config rejection,
completion, task teardown, FD translation, backing sync/read/clear, VFS slot/pin
lifetime and archive callers. This is self-review, not independent/security review.

- **High, partial publication corrected:** donor48b26f8d creates/writes the final
  path directly. The candidate creates a mode0600 same-directory staging file,
  writes the complete tar, syncs and closes it, then publishes with
  RENAME_NOREPLACE. Existing destinations are preserved. All regular failure
  paths remove staging; abrupt supervisor death may leave a private staging file,
  never a valid published output. Hostile parent/staging replacement and injected
  write/sync/close/cleanup failures require DaybreakBlue validation.
- **High, early rejection cleanup fixed:** final review found launch_rejected
  bypassed the initial startup cleanup. A known unknown-section config reproduced
  retained staging on4e2ab6c8. Moving cancellation to write_completion_result before
  its optional-result early return fixes it at the common completion owner. The
  same check now passes; late unsupported-assignment rejection also cleans up.
- **High, quiescence:** an ordinary child writes/syncs a file, signals readiness
  over an owned pipe and blocks. Root exits0; teardown settles it before capture.
  Its file is exported and its post-block write is absent. This demonstrates
  supported process settlement, not hostile race or thread acceptance.
- **Owner reconciliation:** c541a67f's backing c-string and readlink error fixes
  are already in prior owners; module ordering stays with this export wiring.
  Symlink/hardlink, scalable namespace and restore joins remain G13/G15/G18/G21/G22
  and F02 work. No unused checkpoint/control protocol is introduced.

Source and strict clean prerequisite-plus-patch replay pass make check test-unit
build and storage/directory/script/owned-exec fixture builds:92 units,34 VFS,
179 matching tracked paths. Ginux and all four fixture binaries match. Clean apply
uses --whitespace=error. Seven ordinary cases cover flush, binary/mode/long-path/
empty-file export, no output before completion, settled child writes, failed
workload cancellation and both early/late config failure. Existing destination
retry preserves content. Two valid mapping, six ELF,14 script and growth/bounds/
quota controls also pass in source and clean copies. Exact G12 returns ENOTSUP
for fsync, causing workload182 on the same valid flush fixture.

The initial archive check passed; the later config-rejection regression and fix
are retained separately. A harness indentation edit error was corrected and its
log preserved. Prior head/clean evidence is labelled before-completion-cleanup;
final evidence belongs to a36e7644. Existing units/default CI/security fixtures
remain intact. Security/path/FD/failure injection and thread acceptance,
independent review, full Linux suite, macOS/remote CI and refreshed standalone
validation remain unrun. Linux-local success is not green CI.

Patch, generic draft, commands, receipts, hashes and helpers are retained under
.artifacts/ginux-contribution-preparation/G19/. [DaybreakBlue handoff](daybreakblue-handoff.md)
records adversarial work without dispatch. No real branch/checkouts/index/ref,
remote human text or maintainer message changed. Publication waits for F04.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G19');row.update(m);row.update(evidence='g19-review.md',source_patch='patches/G19.patch');p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\nG19 exact retained revision: {m['head']} on G12 {m['base']}.
92 routine units and ordinary flush/export/config-cleanup/child-settlement plus
mapping/exec/storage controls pass in source and clean replay. Early config
rejection staging leakage was reproduced and fixed at common completion. Validate
hostile parent/staging/final-name changes, abrupt interruption, I/O/close/cleanup
failure injection and shared-thread/argument races independently. A complete
archive is published only after close, but no adversarial authority acceptance is
inferred. No cloud agent dispatched; [review/evidence](g19-review.md).
''')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text();a=s.index('Exact next task: **G19');b=s.index('\nActive skill:',a);s=s[:a]+f'''G19 per-process source/ordinary preparation is retained at `{m['head'][:8]}` on
G12{m['base'][:8]}. [Review/evidence](ginux-contributions/g19-review.md) records92
units,179-path strict replay and ordinary flush, binary/long-path/mode export,
publication-after-completion, child settlement, failed workload and early/late
config cleanup in source/clean exports, plus mapping/ELF/script/storage controls.
The donor's direct-final-file output is replaced with private staging and no-
overwrite publication after sync/close. A reproduced early-rejection staging leak
is fixed at common completion. Exact G12 rejects flush. G07 thread/security,
G13/G15/G18/G21/G22 joins, full CI and actual upstream independence remain pending.

Exact next task: **G20 — private checkpoint control and event-driven waiting**.
Inspect2b306eff/990fbb7a against current task/process wait ownership and the reviewed
export owner. Keep the transport host-owned, bounded and absent from workloads;
do not import G08 guest channels or downstream protocols. Preserve typed cleanup
and the held G07 thread/race boundary. Run ordinary capture/acknowledgment and
process event/cancellation paths; record hostile frames, private-FD authority and
races for DaybreakBlue. No publication or maintainer messages before F04.
''' +s[b:];p.write_text(s);print('retained',m['head'])
