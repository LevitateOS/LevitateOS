from pathlib import Path
import subprocess,json
root=Path('/tmp/ginux-contribution-preparation/G19');cmd=['sudo','-n','python3','scripts/test-launch-storage.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-storage-fixture','flush','export','export-wait','child-export','failed-export']
with (root/'focused-export.log').open('w') as f:r=subprocess.run(cmd,cwd=root/'source',stdout=f,stderr=subprocess.STDOUT)
(root/'focused-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode},indent=2)+'\n');print('focused export',r.returncode);raise SystemExit(r.returncode)
