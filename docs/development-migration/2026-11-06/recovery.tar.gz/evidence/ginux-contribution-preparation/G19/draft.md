Flush owned files and export after quiesced successful exit

Support fsync/fdatasync on owned backing and --export-file for regular files and
directories after all supported tasks settle. Preserve modes and long paths;
exclude deleted and image data. Stage privately and publish without overwrite
after write/sync/close, cancelling unfinished output on failed completion.

Local92-unit/build checks, ordinary export/cleanup/child-settlement and existing
mapping/script/ELF/storage checks pass in source and clean replay. Thread sharing,
security/full runtime coverage, remote CI and prerequisite merges remain pending;
not ready to submit.
