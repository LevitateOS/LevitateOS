from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G19/source')
p=src/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();a=s.index('long storage_main(');s=s[:a]+'''static long export_data(const char *mode) {
    CHECK(DO(83,"/out/empty",0755,0)==0,180);
    long fd=DO(2,"/out/product",0101,0700); CHECK(fd==3,181);
    CHECK(DO(1,fd,"result\\0data",11)==11 && DO(74,fd,0,0)==0 && DO(75,fd,0,0)==0,182);
    CHECK(DO(3,fd,0,0)==0,183);
    fd=DO(2,"/out/empty-file",0101,0600); CHECK(fd==3 && DO(74,fd,0,0)==0 && DO(3,fd,0,0)==0,184);
    fd=DO(2,"/out",0200000,0); CHECK(fd==3 && DO(74,fd,0,0)==0 && DO(75,fd,0,0)==0 && DO(3,fd,0,0)==0,185);
    CHECK(DO(2,"/out/deleted",0101,0600)==3 && DO(3,3,0,0)==0 && DO(87,"/out/deleted",0,0)==0,186);
    char longpath[208]="/out/";
    for(word i=5;i<125;++i) longpath[i]='a';
    longpath[125]=0; CHECK(DO(83,longpath,0700,0)==0,187);
    longpath[125]='/';
    for(word i=126;i<206;++i) longpath[i]='b';
    longpath[206]=0;
    CHECK(DO(2,longpath,0101,0600)==3 && DO(1,3,"long",4)==4 && DO(3,3,0,0)==0,188);
    if(equal(mode,"child-export")) {
        int ready[2], wait[2];
        CHECK(DO(293,ready,0,0)==0 && DO(293,wait,0,0)==0,189);
        long child=DO(57,0,0,0); CHECK(child>=0,190);
        if(!child) {
            CHECK(DO(3,ready[0],0,0)==0 && DO(3,wait[1],0,0)==0,191);
            fd=DO(2,"/out/child",0101,0600); CHECK(fd>=3,192);
            CHECK(DO(1,fd,"settled",7)==7 && DO(74,fd,0,0)==0 && DO(3,fd,0,0)==0,193);
            CHECK(DO(1,ready[1],"R",1)==1,194);
            DO(0,wait[0],output,1);
            DO(2,"/out/late",0101,0600); return 195;
        }
        CHECK(DO(3,ready[1],0,0)==0 && DO(3,wait[0],0,0)==0,196);
        CHECK(DO(0,ready[0],output,1)==1 && output[0]=='R',197);
    }
    if(equal(mode,"export-wait")) {
        CHECK(DO(1,1,"export-ready\\n",13)==13 && DO(0,0,output,1)==1 && output[0]=='G',198);
    }
    return equal(mode,"failed-export") ? 7 : 0;
}
'''+s[a:];s=s.replace('    char **argv = (char **)(stack + 1);','    char **argv = (char **)(stack + 1);\n    if(argc>1 && (equal(argv[1],"flush") || equal(argv[1],"export") || equal(argv[1],"export-wait") || equal(argv[1],"failed-export") || equal(argv[1],"child-export"))) return export_data(argv[1]);',1);p.write_text(s)
p=src/'scripts/test-launch-storage.py';s=p.read_text().replace('import tempfile','import tempfile\nimport tarfile',1).replace('def invoke(assignments, args, expected=0, memory=256):','def invoke(assignments, args, expected=0, memory=256, export=False):',1)
needle="            command = [binary, 'launch', str(path), str(root), '--result-file', str(result)]";assert needle in s;s=s.replace(needle,needle+'''
            archive = work / 'export.tar'
            if export:
                archive.unlink(missing_ok=True)
                command += ['--export-file', str(archive)]''',1)
needle="            if args == ['mapping']:";assert needle in s;s=s.replace(needle,'''            if args == ['export-wait']:
                proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                try:
                    assert select.select([proc.stdout], [], [], 5)[0], 'export readiness missing'
                    assert proc.stdout.readline() == b'export-ready\\n'
                    assert not archive.exists(), 'archive published before workload completed'
                    stdout, stderr = proc.communicate(b'G', timeout=10)
                    proc.stdout, proc.stderr = stdout, stderr
                finally:
                    if proc.poll() is None:
                        proc.kill(); proc.communicate(timeout=5)
            elif args == ['mapping']:''',1)
s=s.replace("assert record['outcome'] == ('exited' if expected == 0 else 'supervisor-error'), record","assert record['outcome'] == ('exited' if expected in (0, 7) else 'supervisor-error'), record",1)
needle="            assert not (root / 'out').exists()";assert needle in s;s=s.replace(needle,needle+'''
            if expected == 7: assert record['code'] == 7
            if export:
                assert not list(work.glob('.ginux-export-*')), 'staging output retained'
                if expected != 0:
                    assert not archive.exists(), 'failed workload published an archive'
                else:
                    with tarfile.open(archive) as tar:
                        names = tar.getnames()
                        assert len(names) == len(set(names)), names
                        assert 'out/deleted' not in names and 'image' not in names
                        assert tar.extractfile('out/product').read() == b'result\\0data'
                        assert tar.getmember('out/product').mode == 0o700
                        assert tar.getmember('out/empty').isdir()
                        assert tar.extractfile('out/empty-file').read() == b''
                        assert tar.extractfile('out/' + 'a'*120 + '/' + 'b'*80).read() == b'long'
                        if args == ['child-export']:
                            assert tar.extractfile('out/child').read() == b'settled'
                            assert 'out/late' not in names
                    result.unlink()
                    refused = subprocess.run(command, capture_output=True, timeout=10)
                    assert refused.returncode == 2 and b'not fresh' in refused.stderr
                    with tarfile.open(archive) as tar:
                        assert tar.extractfile('out/product').read() == b'result\\0data'
''',1)
s=s.replace("'growth', 'bounds', 'quota',","'growth', 'bounds', 'quota', 'flush', 'export', 'export-wait', 'failed-export', 'child-export',",1)
needle="                       memory=16 if mode == 'bounds' else 256)";assert needle in s;s=s.replace(needle,"                       expected=7 if mode == 'failed-export' else 0,\n                       memory=16 if mode == 'bounds' else 256,\n                       export=mode in ('export', 'export-wait', 'failed-export', 'child-export'))",1)
s=s.replace("        invoke([], ['no-storage'])","        invoke(['memory:/work', 'memory:/out'], ['flush'])\n        invoke(['memory:/work', 'memory:/out'], ['export'], export=True)\n        invoke(['memory:/work', 'memory:/out'], ['export-wait'], export=True)\n        invoke(['memory:/work', 'memory:/out'], ['child-export'], export=True)\n        invoke(['memory:/work', 'memory:/out'], ['failed-export'], expected=7, export=True)\n        invoke([], ['no-storage'])",1);p.write_text(s)
p=src/'README.md';s=p.read_text()+'''
Configured launch accepts `--export-file <fresh tar path>` to retrieve owned
regular files and directories after a successful workload exit. Remaining tasks
are terminated and reaped before capture. Deleted names and immutable image files
are excluded; file modes and long paths are preserved. Guest names are archive
data and never select host destinations. The supervisor stages mode0600 output
beside the destination, then publishes without overwrite only after complete
write, sync and close. Failed workloads cancel staging. Export failures fail the
launch; an existing destination is preserved. Abrupt supervisor death can leave a
private staging file, which is never a published archive. Consumers must require
both successful completion and a valid archive. This is final export, without
retained storage, checkpoint/restore, symlink or hardlink archive support.
Owned regular files support fsync/fdatasync against their supervisor backing;
these calls do not imply persistence after the in-memory domain ends.
''';p.write_text(s)
print('G19 ordinary flush/export/lifecycle fixture joins')
