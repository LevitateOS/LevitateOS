Execute owned scripts with bounded interpreter chains

Use the configured exec transaction for owned shebang programs, retaining optional
arguments and virtual script names across owned/image interpreter chains. Add
read-only reopening of public owned descriptors with independent offsets.

Local validation:92 unit tests,14 selected ordinary script scenarios, owned-ELF
and cwd/storage controls pass in source and clean replay. Full security/runtime
coverage, remote CI and prerequisite merges remain pending; not ready to submit.
