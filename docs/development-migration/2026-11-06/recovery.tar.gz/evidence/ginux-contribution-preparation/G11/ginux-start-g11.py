from pathlib import Path
import subprocess,tarfile,io,json
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G11');src=root/'source';base='14866b1de07bc8474557396c09f74275e8fb6bf5'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
assert not src.exists();src.mkdir(parents=True);tarfile.open(fileobj=io.BytesIO(git('archive',base))).extractall(src,filter='data')
(root/'composition.json').write_text(json.dumps({'base':base,'donors':['73593745','a08aff7a','cda76faa']},indent=2)+'\n')
files=['.github/workflows/check.yml','Makefile','crates/ginux-init/src/descriptors.rs','crates/ginux-init/src/exec_image.rs','crates/ginux-init/src/fs_hooks.rs','crates/ginux-init/src/launch_tasks.rs','crates/ginux-init/src/main.rs','scripts/test-launch-scripts.py','tests/fixtures/launch-script-fixture.c']
for commit in ['73593745','a08aff7a']:
 names=git('diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines()
 for name in files:
  if name not in names:continue
  p=src/name
  if not p.exists():p.write_bytes(git('show',commit+':'+name));continue
  old=root/'merge-old';new=root/'merge-new';old.write_bytes(git('show',commit+'^:'+name));new.write_bytes(git('show',commit+':'+name))
  r=subprocess.run(['git','merge-file','-L','current','-L','donor-base','-L',commit,str(p),str(old),str(new)])
  assert 0<=r.returncode<128
  print(commit,name,'conflicts',r.returncode)
# VFS reopen manually adapt positions; script final owned chain source imported alone.
(src/'crates/ginux-init/src/exec_script.rs').write_bytes(git('show','cda76faa:crates/ginux-init/src/exec_script.rs'))
# Initial donor added new module; transfer it even when not explicitly in old list.
p=src/'crates/ginux-init/src/main.rs';s=p.read_text();assert 'mod exec_script;' in s
(src/'tests/fixtures/launch-script-fixture.c').write_bytes(git('show','cda76faa:tests/fixtures/launch-script-fixture.c'))
print('export',src)
