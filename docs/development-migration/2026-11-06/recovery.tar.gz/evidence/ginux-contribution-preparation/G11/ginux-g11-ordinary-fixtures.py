from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G11/source')
p=src/'tests/fixtures/launch-script-fixture.c';s=p.read_text();pos=s.index('long script_main(word *stack)')
s=s[:pos]+r'''static int ordinary_mode(const char *s) {
    const char *prefix="ordinary-";
    while(*prefix && *prefix==*s) { ++prefix; ++s; }
    return !*prefix;
}
static int copy_program(void) {
    long input=DO(2,"/bin/interpreter",0,0), output=DO(2,"/work/interpreter",0102,0600);
    if(input<0 || output<0) return -1;
    long n;
    while((n=DO(0,input,buffer,sizeof buffer))>0) {
        if(DO(1,output,buffer,n)!=n) return -1;
    }
    if(n<0 || DO(91,output,0755,0) || DO(3,output,0,0) || DO(3,input,0,0)) return -1;
    return 0;
}
static long ordinary(word argc, char **argv, char **env) {
    const char *mode=argv[argc-1];
    int descriptor=equal(mode,"ordinary-fd") || equal(mode,"ordinary-unlinked");
    int directory=equal(mode,"ordinary-dir") || equal(mode,"ordinary-renamed");
    int chain=equal(mode,"ordinary-chain");
    int owned=chain || equal(mode,"ordinary-owned");
    int nested=equal(mode,"ordinary-nested");
    int plain=equal(mode,"ordinary-plain");
    if(!equal(argv[0],"/bin/fixture")) {
        CHECK(equal(argv[0],owned?"/work/interpreter":"/bin/interpreter"),70);
        CHECK(env[0] && equal(env[0],"SCRIPT_ENV=present") && env[1] && equal(env[1],"SECOND=two words") && !env[2],71);
        CHECK(argc==(word)(chain?10:(nested?6:(plain?3:4))),72);
        const char *name=argv[argc-2];
        CHECK(equal(name,descriptor?"/dev/fd/6":(directory?"/dev/fd/6/program":(equal(mode,"ordinary-relative")?"work/program":"/work/program"))),73);
        if(chain) {
            CHECK(equal(argv[1],"fourth option") && equal(argv[2],"/work/fourth") &&
                  equal(argv[3],"third option") && equal(argv[4],"/work/third") &&
                  equal(argv[5],"second option") && equal(argv[6],"/work/second") && equal(argv[7],"option with spaces"),74);
        } else {
            if(!plain) CHECK(equal(argv[nested?3:1],"option with spaces"),75);
            if(nested) CHECK(equal(argv[1],"nested option") && equal(argv[2],"/bin/wrapper"),76);
        }
        CHECK(DO(72,3,1,0)==-9 && DO(72,5,1,0)==-9 && DO(72,4,1,0)==0,77);
        CHECK(DO(8,4,0,0)==0 && DO(0,4,buffer,1)==1 && buffer[0]=='K',78);
        long fd=DO(2,name,0,0); CHECK(fd>=3 && DO(0,fd,buffer,2)==2 && buffer[0]=='#' && buffer[1]=='!' && DO(3,fd,0,0)==0,79);
        if(descriptor) CHECK(DO(8,6,0,1)==7,80);
        // Script bytes become writable data after the interpreter commits.
        if(!descriptor && !directory) {
            fd=DO(2,name,1,0); CHECK(fd>=3 && DO(3,fd,0,0)==0,81);
        }
        CHECK(DO(1,1,"script: PASS\n",13)==13,82); return 0;
    }
    CHECK(argc==2,83);
    if(owned) CHECK(copy_program()==0,84);
    CHECK(publish("/work/program",plain?"#!/bin/interpreter\nbody\n":
          (nested?"#!/bin/wrapper option with spaces\nbody\n":
          (chain?"#!/work/second option with spaces\nbody\n":
          (owned?"#!/work/interpreter option with spaces\nbody\n":"#! \t/bin/interpreter\toption with spaces \t\nbody\n"))))==0,85);
    if(chain) CHECK(publish("/work/second","#!/work/third second option\n")==0 &&
                    publish("/work/third","#!/work/fourth third option\n")==0 &&
                    publish("/work/fourth","#!/work/interpreter fourth option\n")==0,86);
    CHECK(DO(2,"/work/drop",02000102,0600)==3 && DO(2,"/work/keep",0102,0600)==4 && DO(1,4,"K",1)==1 && DO(2,"/input",02000000,0)==5,87);
    if(descriptor) {
        CHECK(DO(2,"/work/program",0,0)==6 && DO(8,6,7,0)==7,88);
        if(equal(mode,"ordinary-unlinked")) CHECK(DO(87,"/work/program",0,0)==0,89);
    }
    if(directory) {
        CHECK(DO(2,"/work",0200000,0)==6,90);
        if(equal(mode,"ordinary-renamed")) {
            CHECK(DO(83,"/work/sub",0755,0)==0 && DO(82,"/work/program","/work/sub/program",0)==0 &&
                  DO(3,6,0,0)==0 && DO(2,"/work/sub",0200000,0)==6 && DO(82,"/work/sub","/work/moved",0)==0,91);
        }
    }
    if(equal(mode,"ordinary-fork") || equal(mode,"ordinary-vfork")) {
        long child=DO(equal(mode,"ordinary-vfork")?58:57,0,0,0); CHECK(child>=0,92);
        if(child) { int status=-1; CHECK(DO(61,child,&status,0)==child && status==0 && intact(),93);
            DO(1,1,"parent: PASS\n",13); return 0; }
    }
    char *next[]={"ignored-argv-zero",(char *)mode,0};
    char *next_env[]={"SCRIPT_ENV=present","SECOND=two words",0};
    if(descriptor) call(322,6,(word)"",(word)next,(word)next_env,0x1000);
    else if(directory) call(322,6,(word)"program",(word)next,(word)next_env,0);
    else if(equal(mode,"ordinary-at")) call(322,-999,(word)"/work/program",(word)next,(word)next_env,0);
    else DO(59,equal(mode,"ordinary-relative")?"work/program":"/work/program",next,next_env);
    return 94;
}
''' +s[pos:]
s=s.replace('    if (equal(argv[0],"/bin/interpreter")) {','    if(argc && ordinary_mode(argv[argc-1])) return ordinary(argc,argv,env);\n    if (equal(argv[0],"/bin/interpreter")) {',1);p.write_text(s)
p=src/'scripts/test-launch-scripts.py';s=p.read_text().replace('if len(sys.argv) != 3 or os.geteuid() != 0:', 'if len(sys.argv) < 3 or os.geteuid() != 0:').replace('<script-fixture>\'','<script-fixture> [scenario ...]\'').replace('sys.argv[1:]]','sys.argv[1:3]]')
s=s.replace("        for mode in ('plain',", "        full_modes = ('plain',",1).replace("'fd-fork', 'fd-vfork'):\n            path", "'fd-fork', 'fd-vfork')\n        ordinary_modes = ('ordinary-plain', 'ordinary-option', 'ordinary-nested', 'ordinary-relative',\n                          'ordinary-at', 'ordinary-fd', 'ordinary-unlinked', 'ordinary-dir',\n                          'ordinary-renamed', 'ordinary-fork', 'ordinary-vfork', 'ordinary-owned', 'ordinary-chain')\n        modes = sys.argv[3:] or (*full_modes, *ordinary_modes)\n        assert set(modes) <= set(full_modes + ordinary_modes), modes\n        for mode in modes:\n            path",1)
s=s.replace("            with audit_path.open('wb') as audit:",'''            if mode in ordinary_modes:
                with audit_path.open('wb') as audit:
                    proc = subprocess.run([binary, 'launch', str(path), str(root), '--result-file', str(result)],
                                          input=b'', stdout=subprocess.PIPE, stderr=audit, timeout=15)
                expected = b'script: PASS\\n' + (b'parent: PASS\\n' if mode in ('ordinary-fork', 'ordinary-vfork') else b'')
                assert proc.returncode == 0 and proc.stdout == expected, (mode, proc.returncode, proc.stdout, audit_path.read_text())
                assert json.loads(result.read_text()) == dict(version=1, outcome='exited', code=0, signal=None, generation=None)
                assert b'teardown tasks=0 owned-handles=0' in audit_path.read_bytes()
                assert list((root / 'work').iterdir()) == [] and (root / 'input').read_bytes() == b'Q'
                print('PASS owned script ' + mode, flush=True)
                continue
            with audit_path.open('wb') as audit:''',1)
s=s.replace("        print('test-launch-scripts: PASS (argv/env/auxv, optional arguments, native interpreter chain, rollback, CLOEXEC, private fds, fork/vfork)')","        print('test-launch-scripts: PASS (' + ', '.join(modes) + ')')")
p.write_text(s)
print('added ordinary selected modes; full/default legacy scenarios retained')
