from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G11');src=root/'source';base=json.loads((root/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['.github/workflows/check.yml','Makefile','README.md','crates/ginux-init/src/descriptors.rs','crates/ginux-init/src/exec_image.rs','crates/ginux-init/src/exec_script.rs','crates/ginux-init/src/fs_hooks.rs','crates/ginux-init/src/launch_tasks.rs','crates/ginux-init/src/main.rs','crates/ginux-init/src/path_hooks.rs','crates/ginux-vfs/src/lib.rs','scripts/test-launch-scripts.py','scripts/test-launch-owned-exec.py','tests/fixtures/launch-script-fixture.c','tests/fixtures/launch-owned-exec-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g11-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(src/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip()
 head=git('commit-tree',tree,'-p',base,input=('feat(launch): execute owned scripts through bounded interpreter chains\n\nResolve up to four owned scripts to an owned ELF or permitted image\ninterpreter. Preserve virtual names and optional arguments on the new\nexec stack; reopen public owned descriptor names with fresh offsets.\nKeep pin and private backing cleanup with the existing exec transaction.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head)
assert not any(word in patch for word in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in ['crates/ginux-init/src/supervisor.rs','crates/ginux-core/src/lib.rs','crates/ginux-process/src/lib.rs']:assert (src/name).read_bytes()==git('show',base+':'+name)
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G11','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':['G10'],'standalone':False,'status':'source/ordinary scenarios passed; separate final review/clean replay pending; security-held','patch_sha256':hashlib.sha256(patch).hexdigest()};(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
