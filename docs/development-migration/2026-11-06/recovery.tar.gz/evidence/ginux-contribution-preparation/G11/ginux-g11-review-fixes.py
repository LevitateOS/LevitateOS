from pathlib import Path
import subprocess
src=Path('/tmp/ginux-contribution-preparation/G11/source');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def show(path):return subprocess.check_output(['git','-C',repo,'show','cda76faa:'+path]).decode()
p=src/'tests/fixtures/launch-owned-exec-fixture.c';s=p.read_text();d=show('tests/fixtures/launch-owned-exec-fixture.c');start=d.index("    if (mode=='b') {");end=d.index("    if (mode=='r'",start);s=s.replace("    if (mode=='r'",d[start:end]+"    if (mode=='r'",1)
start=d.index("    if (mode=='i' || mode=='j'");end=d.index('    CHECK(DO(2,"/work/program",02000000',start);s=s.replace('    CHECK(DO(2,"/work/program",02000000',d[start:end]+'    CHECK(DO(2,"/work/program",02000000',1)
s=s.replace('publish("/work/script","#!/bin/payload\\n",15)==0 && DO(59,"/work/script",next,next_env)==-95','publish("/work/script","#!/bin/missing\\n",15)==0 && DO(59,"/work/script",next,next_env)==-2');p.write_text(s)
p=src/'scripts/test-launch-owned-exec.py';s=p.read_text();d=show('scripts/test-launch-owned-exec.py');start=d.index("        for mode in ('interpreter'");end=d.index("        print('test-launch-owned-exec",start);chunk=d[start:end];chunk=chunk.replace("for mode in ('interpreter', 'joined-interpreters', 'kernel-interpreter', 'limit-interpreters'):","for mode in (() if sys.argv[3:] else ('interpreter', 'joined-interpreters', 'kernel-interpreter', 'limit-interpreters')):");s=s.replace("        print('test-launch-owned-exec",chunk+"        print('test-launch-owned-exec",1);p.write_text(s)
# One ordinary mixed owned-to-image chain also exercises argument splice.
p=src/'tests/fixtures/launch-script-fixture.c';s=p.read_text().replace('int nested=equal(mode,"ordinary-nested");','int nested=equal(mode,"ordinary-nested") || equal(mode,"ordinary-joined");');s=s.replace('equal(argv[2],"/bin/wrapper"),76)', 'equal(argv[2],equal(mode,"ordinary-joined")?"/work/middle":"/bin/wrapper"),76)')
s=s.replace('(nested?"#!/bin/wrapper option with spaces\\nbody\\n":','(nested?(equal(mode,"ordinary-joined")?"#!/work/middle option with spaces\\nbody\\n":"#!/bin/wrapper option with spaces\\nbody\\n"):');s=s.replace('    if(chain) CHECK(publish','    if(equal(mode,"ordinary-joined")) CHECK(publish("/work/middle","#!/bin/interpreter nested option\\n")==0,95);\n    if(chain) CHECK(publish');p.write_text(s)
p=src/'scripts/test-launch-scripts.py';s=p.read_text().replace("'ordinary-owned', 'ordinary-chain')","'ordinary-owned', 'ordinary-chain', 'ordinary-joined')");p.write_text(s)
p=src/'README.md';s=p.read_text().replace('same assignment checks as image execution. Owned scripts are not supported yet.','same assignment checks as image execution.')
s=s.replace('The configured `/dev` view is an immutable virtual directory, empty by default;','''Owned shebang programs support up to four consecutive owned scripts followed
by an owned ELF or an image interpreter chain. Each shebang has one optional
argument, including spaces. Owned script bytes stay pinned until exec commits;
the final owned ELF retains the running executable pin. The new exec stack
restores the virtual script name in argv and AT_EXECFN; existing arguments and
environment are preserved, with argv[0] replaced as for kernel shebang execution.
Image interpreters use a transient non-CLOEXEC script backing, retired before
the interpreter's first syscall. Stack reconstruction is bounded to 4096 caller
arguments, 4096 environment entries and 64 auxiliary pairs. Unsupported stack
layouts fail the domain after exec rather than resuming a replaced address space.
Descriptor-based scripts require a non-CLOEXEC public file or directory descriptor;
otherwise execveat fails with ENOENT. The interpreter can reopen /dev/fd/<public>
(or an owned directory suffix) read-only through the virtual descriptor owner,
with a fresh offset, including after unlink/rename. This never imports native
or private descriptors. Other /dev/fd operations remain unsupported. Threads,
owned ELF dynamic loaders, guest file mappings and owned cwd remain unsupported.

The configured `/dev` view is an immutable virtual directory, empty by default;''')
s=s.replace('image entries beneath it are hidden. `[devices].assignments', 'image entries beneath it are hidden. The script descriptor reopen operation\ndescribed above is separate from directory enumeration. `[devices].assignments')
s=s.replace('restores public arguments and descriptor state. Owned-file execution is not\nimplemented. Script and ELF interpreter paths must resolve to the same permitted\nimage object in both the configured and native namespaces;', 'restores public arguments and descriptor state. Owned ELF/script execution uses\nthe separate pinned-byte transaction described above. Native script and ELF\ninterpreter paths must resolve to the same permitted image object in both the\nconfigured and native namespaces;')
p.write_text(s)
print('retained full donor chain checks without running them; fixed stale docs/expectation; added ordinary joined chain')
