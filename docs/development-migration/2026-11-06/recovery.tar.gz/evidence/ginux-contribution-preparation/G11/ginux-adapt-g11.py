from pathlib import Path
import subprocess,re
root=Path('/tmp/ginux-contribution-preparation/G11');src=root/'source';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def show(ref,path):return subprocess.check_output(['git','-C',repo,'show',ref+':'+path]).decode()
def resolve(s,choose):
 return re.sub(r'<<<<<<< current\n(.*?)=======\n(.*?)>>>>>>> [^\n]+\n',lambda m:choose(m.group(1),m.group(2)),s,flags=re.S)
p=src/'.github/workflows/check.yml';s=p.read_text();s=resolve(s,lambda a,b:a.rstrip()+' build-launch-script-fixture\n');p.write_text(s)
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();s=resolve(s,lambda a,b:b if not a else b.replace('fn check_exec(&mut self, image:', 'fn check_exec(&mut self, pid: usize, image:'))
start=s.index('    /// The kernel owns binfmt parsing');end=s.index('    pub fn read_executable(',start)
s=s[:start]+'''    pub fn is_script(&self, image: Executable) -> Result<bool, i64> {
        let mut header = [0; 2];
        self.read_executable(image, 0, &mut header)?;
        Ok(header == *b"#!")
    }

    /// Resolve an implicit interpreter through the same component and
    /// assignment owner as an explicit program. Native chains must also match
    /// the image kernel will traverse; owned scripts are resolved separately.
    pub fn exec_interpreter(&mut self, pid: usize, name: &[u8]) -> Result<Option<Executable>, i64> {
        let cwd;
        let base = if name.first() == Some(&b'/') {
            b"".as_slice()
        } else {
            cwd = crate::tracee_io::image_cwd(pid)?;
            cwd.as_bytes()
        };
        let joined = join_path(base, name)?;
        let path = self.resolve(pid, joined.as_bytes(), true, false)?;
        if self.owns_path(path.as_bytes()) {
            let image = self.fs.pin_executable(path.as_bytes()).map_err(errno)?;
            return self.check_exec(pid, image).map(Some);
        }
        self.check_exec_owner(path.as_bytes())?;
        let image = crate::path_hooks::ImageRoot::new(pid)?;
        let mut physical = [0; MAX_PATH];
        let n = image.resolve_image(joined.as_bytes(), &mut physical).map_err(errno)?;
        if physical[..n] != *path.as_bytes() {
            return Err(-95);
        }
        self.check_interpreters(pid, path)?;
        Ok(None)
    }

'''+s[end:]
s=s.replace('pub fn open_descriptor(&mut self, handle:','pub fn open_descriptor(&mut self, pid: usize, handle:')
s=s.replace('let path = normalize(directory, suffix)?;', 'let joined = join_path(directory, &suffix[1..])?;\n            let path = self.resolve(pid, joined.as_bytes(), true, false)?;')
# Share existing non-normalizing join; preserve the component traversal owner.
start=s.index('        let mut bytes = [0; MAX_PATH];',s.index('pub(crate) fn path('));end=s.index('\n    }',start)
join=s[start:end];s=s[:start]+'        join_path(base, text.as_bytes())'+s[end:]
join=join.replace('text.as_bytes().len()','name.len()').replace('text.as_bytes()','name')
s+='\nfn join_path(base: &[u8], name: &[u8]) -> Result<Path, i64> {\n'+join+'\n}\n';p.write_text(s)
# Common script reader: used both by image metadata and owned stack planning.
p=src/'crates/ginux-init/src/path_hooks.rs';s=p.read_text();start=s.index('    if first[..n].starts_with(b"#!")');end=s.index('    if n < 4',start)
s=s[:start]+'''    if let Some(header) = script_metadata(&first[..n])? {
        let name = header.interpreter.as_bytes();
        output[..name.len()].copy_from_slice(name);
        return Ok(Some((name.len(), true)));
    }
'''+s[end:]
pos=s.index('pub(crate) fn interpreter_metadata(')
s=s[:pos]+'''pub(crate) struct ScriptHeader {
    pub interpreter: ginux_domain::Text<MAX_PATH>,
    pub argument: Option<ginux_domain::Text<MAX_PATH>>,
}

/// Linux's bounded shebang line has one optional argument, including spaces.
/// Inspect only bytes actually read, stopping at newline or the first NUL.
pub(crate) fn script_metadata(bytes: &[u8]) -> Result<Option<ScriptHeader>, i64> {
    if !bytes.starts_with(b"#!") {
        return Ok(None);
    }
    let line_end = bytes.iter().position(|b| matches!(b, 0 | b'\\n')).unwrap_or(bytes.len());
    let mut end = line_end;
    while end > 2 && matches!(bytes[end - 1], b' ' | b'\\t') {
        end -= 1;
    }
    let start = (2..end).find(|n| !matches!(bytes[*n], b' ' | b'\\t')).ok_or(-8)?;
    let separator = (start..end).find(|n| matches!(bytes[*n], b' ' | b'\\t')).unwrap_or(end);
    if separator == start || separator == bytes.len() && bytes.len() == 256 {
        return Err(-8);
    }
    let interpreter = ginux_domain::Text::from_bytes(&bytes[start..separator]).map_err(|_| -36)?;
    let argument = (separator..end).find(|n| !matches!(bytes[*n], b' ' | b'\\t'))
        .map(|first| ginux_domain::Text::from_bytes(&bytes[first..end]).map_err(|_| -36)).transpose()?;
    Ok(Some(ScriptHeader { interpreter, argument }))
}

'''+s[pos:];p.write_text(s)
p=src/'crates/ginux-init/src/exec_script.rs';s=p.read_text();start=s.index('struct Header {');end=s.index('#[derive(Clone, Copy)]\npub struct Script',start)
s=s[:start]+'''fn header(fs: &LaunchFs, image: Executable) -> Result<Option<crate::path_hooks::ScriptHeader>, i64> {
    let mut bytes = [0; 256];
    let n = fs.read_executable(image, 0, &mut bytes)?;
    crate::path_hooks::script_metadata(&bytes[..n])
}

'''+s[end:];s=s.replace('Header::read(fs, image)?','header(fs, image)?').replace('Header::read(fs, next)?','header(fs, next)?')
# Do not shadow the header function inside chain resolution.
s=s.replace('fn header(', 'fn read_header(').replace('header(fs,','read_header(fs,');p.write_text(s)
# Per-process task port, retain native rewrite and checked arithmetic.
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text();n=[0]
def tasks(a,b):
 n[0]+=1
 if n[0]==1:
  donor=show('cda76faa','crates/ginux-init/src/launch_tasks.rs');start=donor.index('        let mut image = image;');end=donor.index('        self.task_mut(index).exec = Some(Exec {',start)
  return a+donor[start:end].replace('self.table(index)', 'self.task(index).descriptors')
 return b.replace('self.groups[group].as_mut().unwrap().image','self.task_mut(index).image')
s=resolve(s,tasks)
s=s.replace('u64::from(owned.script.is_none())','u64::from(!owned.script.is_some_and(|script| script.kernel_script))')
# Adopt final chain commit behavior without descriptor groups.
a=s.index('                self.task_mut(index).exec.as_mut().unwrap().retire = Some(fd);',s.index('    fn exec_completed'));b=s.index('            } else {\n                self.task_mut(index).exec.as_mut().unwrap().owned = None;',a)
s=s[:a]+'''                if script.release_held(self.objects.filesystem).is_err() {
                    self.fail(domain, b"committed interpreter references release failed");
                }
                if script.kernel_script {
                    self.task_mut(index).exec.as_mut().unwrap().retire = Some(fd);
                    if self.objects.filesystem.release_executable(owned.image).is_err() {
                        self.fail(domain, b"committed script reference release failed");
                    }
                    None
                } else {
                    Some(owned.image)
                }
'''+s[b:]
# Do not detach pending pins until stack restoration and reference releases succeed.
s=s.replace('                self.task_mut(index).exec.as_mut().unwrap().owned = None;\n                if script.release_held', '                if script.release_held')
# Clear pending state once all commit paths have selected ownership.
a=s.index('        let old = core::mem::replace(',s.index('    fn exec_completed'))
s=s[:a]+'        self.task_mut(index).exec.as_mut().unwrap().owned = None;\n'+s[a:]
start=s.index('        if let Some(owned) = exec.owned {',s.index('    fn finish_exec_failure'))
s=s[:start]+s[start:].replace('        if let Some(owned) = exec.owned {','''        if let Some(owned) = exec.owned {
            if owned.script.is_some_and(|script| script.release_held(self.objects.filesystem).is_err()) {
                self.fail(domain, b"failed interpreter reference release failed");
            }''',1)
start=s.index('        let pending =',s.index('    fn release_task_images'));end=s.index('        let committed =',start)
s=s[:start]+'''        let owned = self.task_mut(index).exec.take().and_then(|exec| exec.owned);
        if owned.and_then(|owned| owned.script).is_some_and(|script| script.release_held(self.objects.filesystem).is_err()) {
            self.fail(domain, b"task interpreter reference release failed");
        }
        let pending = owned.map(|owned| owned.image);
'''+s[end:];p.write_text(s)
# Adapt VFS fresh positions; keep source descriptor read permission.
p=src/'crates/ginux-vfs/src/lib.rs';s=p.read_text();donor=show('a08aff7a','crates/ginux-vfs/src/lib.rs');start=donor.index('    /// Reopen the same object');end=donor.index('    /// Open a directory description.',start);chunk=donor[start:end]
chunk=chunk.replace('        let slot =', '''        if !source.readable { return Err(VfsError::PermissionDenied); }
        let slot =''',1)
chunk=chunk.replace('        self.descriptors[slot] = Descriptor {','''        let position = (0..FDS).find(|position| !self.descriptors.iter().any(|fd| fd.open && fd.position == *position)).ok_or(VfsError::DescriptorLimit)?;
        self.positions[position] = 0;
        self.descriptors[slot] = Descriptor {''')
chunk=chunk.replace('            offset: 0,','            position,');s=s.replace('    /// Open a directory description.',chunk+'    /// Open a directory description.',1)
start=donor.index('    #[test]\n    fn readonly_reopen_retains_deleted');end=donor.index('    #[test]',start+12);s=s.replace('    #[test]\n    fn executable_pins_exclude',donor[start:end]+'    #[test]\n    fn executable_pins_exclude',1);p.write_text(s)
p=src/'crates/ginux-init/src/descriptors.rs';s=p.read_text().replace('backends.filesystem.open_descriptor(handle, tail, flags)?','backends.filesystem.open_descriptor(pid, handle, tail, flags)?');p.write_text(s)
assert not any('<<<<<<<' in p.read_text() for p in src.rglob('*.rs'))
print('adapted G11')
