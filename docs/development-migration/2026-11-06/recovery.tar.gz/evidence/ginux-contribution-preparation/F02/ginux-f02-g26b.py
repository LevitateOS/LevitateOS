from pathlib import Path
import re,json,py_compile,subprocess
s=Path('/tmp/ginux-contribution-preparation/F02/source');x=json.loads((s.parent/'state.json').read_text());assert x['pending_packet']=='G26b'
for f in x['conflicts']:
 p=s/f;t=p.read_text();n=0
 def merge(m):
  global n
  a,b=m[1],m[2];i=n;n+=1
  if f=='README.md':return b
  if f.endswith('launch_tasks.rs'):return a+'                return;\n            }\n'+b
  if f.endswith('launch-task-fixture.c'):return a+'    return 0;\n}\n'+b if i==0 else a+b
  if f.endswith('test-launch-tasks.py'):
   if i in (0,2):return a
   before=b[:b.index("        ordinary =")]
   fun='        def resource_cases():\n'+''.join('    '+l+'\n' for l in before.splitlines())
   return fun+'''        if not sys.argv[3:] or sys.argv[3:] == ['ordinary-resources']:
            resource_cases()
'''+a.replace("allowed=set(modes) | {'OrdinaryLocks'}", "allowed=set(modes) | {'OrdinaryLocks', 'ordinary-resources'}").replace('            modes=sys.argv[3:]','''            modes = ('fork', 'vfork', 'clone', 'shared-vfork', 'libc-fork', 'handler-return',
                     'inherit', 'orphan', 'adopted-zombie') if sys.argv[3:] == ['ordinary-resources'] else sys.argv[3:]''')
  raise AssertionError((f,i))
 p.write_text(re.sub(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',merge,t,flags=re.S))
py_compile.compile(str(s/'scripts/test-launch-tasks.py'),doraise=True)
subprocess.run(['cc','-fsyntax-only',str(s/'tests/fixtures/launch-task-fixture.c')],check=True)
