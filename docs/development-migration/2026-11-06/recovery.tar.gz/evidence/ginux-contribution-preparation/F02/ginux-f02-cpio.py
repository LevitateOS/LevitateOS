from pathlib import Path
import subprocess,shutil,json,re,hashlib,sys
r=Path('/tmp/ginux-contribution-preparation/F02');s=r/(sys.argv[1] if len(sys.argv)>1 else 'source');baseline=len(sys.argv)>2 and sys.argv[2]=='baseline';prefix='baseline-' if baseline else ('clean-' if s.name!='source' else '');root=r/'cpio-root';root.mkdir(exist_ok=True);(root/'work').mkdir(exist_ok=True);(root/'bin').mkdir(exist_ok=True)
files=['/usr/bin/cpio'];out=subprocess.check_output(['ldd','/usr/bin/cpio']).decode();files+=re.findall(r'(?:=>\s+|^\s+)(/[^\s]+)',out,re.MULTILINE);provenance=[]
for name in dict.fromkeys(files):
 p=Path(name);d=root/name.lstrip('/');d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d);d.chmod(0o755);provenance.append({'source':name,'resolved_source':str(p.resolve()),'sha256':hashlib.sha256(d.read_bytes()).hexdigest()})
(r/'cpio-provenance.json').write_text(json.dumps({'version':subprocess.check_output(['cpio','--version']).decode().splitlines()[0],'files':provenance},indent=2)+'\n')
producer=r/'cpio-input';(producer/'work').mkdir(parents=True,exist_ok=True);payload=bytes(i%251 for i in range(8192+37));(producer/'work/file').write_bytes(payload);(producer/'work/file').chmod(0o640)
if not (producer/'work/alias').exists():(producer/'work/alias').hardlink_to(producer/'work/file')
if not (producer/'work/link').is_symlink():(producer/'work/link').symlink_to('file')
archive=r/'cpio-input.cpio'
if not archive.exists():
 a=subprocess.run(['/usr/bin/cpio','-o','-H','newc','--owner=0:0','--quiet'],input=b'file\nalias\nlink\n',cwd=producer/'work',capture_output=True,check=True);archive.write_bytes(a.stdout)
archive_data=archive.read_bytes()
fixture=(s/'tests/fixtures/launch-storage-fixture.c').read_text();head=fixture[:fixture.index('static const char immutable')];program=head+'''static char bytes[4096];
static unsigned long meta[32];
long storage_main(word *stack) {
    (void)stack;
    long child=DO(57,0,0,0); CHECK(child>=0,80);
    if(child==0){char *args[]={"/usr/bin/cpio","-i","--quiet",0};char *env[]={"LC_ALL=C",0};return DO(59,args[0],args,env)<0?81:82;}
    int status=-1; CHECK(DO(61,child,&status,0)==child && status==0,83);
    const char *names[]={"/work/file","/work/alias","/work/link"};word inode=0;
    for(word k=0;k<3;++k){
        long fd=DO(2,names[k],0,0);CHECK(fd>=3,84);
        CHECK(DO(5,fd,meta,0)==0 && ((unsigned *)meta)[7]==0 && ((unsigned *)meta)[8]==0,85);
        CHECK(meta[2]==2 && meta[6]==8229 && (((unsigned *)meta)[6]&0777)==0640,86);
        if(k==0)inode=meta[1];else CHECK(meta[1]==inode,87);
        word at=0;while(at<8229){long n=DO(0,fd,bytes,sizeof bytes);CHECK(n>0 && (word)n<=8229-at,88);for(long j=0;j<n;++j)CHECK((unsigned char)bytes[j]==(at+(word)j)%251,89);at+=n;}
        CHECK(DO(0,fd,bytes,1)==0 && DO(3,fd,0,0)==0,90);
    }
    CHECK(DO(6,"/work/link",meta,0)==0 && (((unsigned *)meta)[6]&0170000)==0120000,91);
    CHECK(((unsigned *)meta)[7]==0 && ((unsigned *)meta)[8]==0,92);
    return DO(1,1,"cpio-owned-root: PASS\\n",22)==22?0:93;
}
__asm__(".global _start\\n_start:\\nmov %rsp,%rdi\\nandq $-16,%rsp\\ncall storage_main\\nmov %rax,%rdi\\nmov $60,%rax\\nsyscall\\nud2\\n");
''';p=r/'cpio-wrapper.c';p.write_text(program);wrapper=root/'bin/wrapper';subprocess.run(['cc','-nostdlib','-static','-fno-stack-protector','-fno-builtin','-O2','-Wall','-Wextra','-Werror',str(p),'-o',str(wrapper)],check=True)
config=(s/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/wrapper"').replace('[storage]\nassignments = []','[storage]\nassignments = ["memory:/work"]');path=r/(prefix+'cpio.toml');path.write_text(config);result=r/(prefix+'cpio-result.json');result.unlink(missing_ok=True);binary=Path('/tmp/ginux-contribution-preparation/G15/verified-head/target/x86_64-unknown-linux-gnu/release/ginux') if baseline else s/'target/x86_64-unknown-linux-gnu/release/ginux';cmd=[str(binary),'launch',str(path),str(root),'--result-file',str(result)]
p=subprocess.run(cmd,input=archive_data,capture_output=True,timeout=20);(r/(prefix+'cpio.audit')).write_bytes(p.stderr);(r/(prefix+'cpio.stdout')).write_bytes(p.stdout);receipt={'command':cmd,'exit_code':p.returncode,'result':json.loads(result.read_text()) if result.exists() else None,'stdout':p.stdout.decode(errors='replace'),'payload_bytes':len(payload),'payload_sha256':hashlib.sha256(payload).hexdigest(),'archive_sha256':hashlib.sha256(archive_data).hexdigest(),'ownership_options':['producer --owner=0:0','consumer -i --quiet; no ownership suppression'],'wrapper_sha256':hashlib.sha256(wrapper.read_bytes()).hexdigest()};(r/(prefix+'cpio-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print('cpio',p.returncode,repr(p.stdout),flush=True)
if p.returncode:print(p.stderr[-4500:].decode(errors='replace'),flush=True)
assert (p.returncode==83 and p.stdout==b'' if baseline else p.returncode==0 and p.stdout==b'cpio-owned-root: PASS\n'),(p.returncode,p.stdout)
