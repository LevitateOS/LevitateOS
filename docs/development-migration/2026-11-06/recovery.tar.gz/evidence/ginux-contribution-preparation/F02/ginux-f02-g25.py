from pathlib import Path
import re,json,py_compile,subprocess
s=Path('/tmp/ginux-contribution-preparation/F02/source');x=json.loads((s.parent/'state.json').read_text());assert x['pending_packet']=='G25'
for f in x['conflicts']:
 p=s/f;t=p.read_text();n=0
 def merge(m):
  global n
  a,b=m[1],m[2];i=n;n+=1
  if f=='README.md':
   prefix=b[b.index('Regular writes'):b.index('Metadata capacity remains')]
   return a.replace('IO is bounded\nto 4096 bytes per call.',prefix.rstrip())
  if f.endswith('channel_hooks.rs'):
   if i==0:return a.replace('0 | 1 | 44 | 45','0 | 1 | 19 | 20 | 44 | 45',1)
   if i==1:return b.replace('1 | 20','1 | 20 | 44').replace('if writing != entry.write','if entry.peer.is_none() && writing != entry.write').replace('if requested == 0','if requested == 0 && entry.peer.is_none()')
   if i==2:return a.replace('r.rdx > IO_SIZE as u64','requested > IO_SIZE').replace('r.rdx <= IO_SIZE as u64','requested <= IO_SIZE').replace('r.rdx != 0','requested != 0').replace('r.rdx as usize','requested')
   if i==3:return a.replace('r.rdx.min(IO_SIZE as u64).min(length as u64) as usize','requested.min(IO_SIZE).min(length)')
   if i==4:return a.replace('copy_memory(pid, r.rsi, &mut buffer[..count], true)? as usize','vectors.copy(pid, &mut buffer[..count], true)?')
  if f.endswith('test-launch-pipes.py'):
   if i==0:return a
   return a.replace("'ordinary-streams')","'ordinary-streams','ordinary-vectors')").replace("invoke([mode],assigned=True)","invoke(['vectors'] if mode=='ordinary-vectors' else [mode],assigned=True)")+"        invoke(['vectors'])\n"
  if f.endswith('test-launch-storage.py'):return a.replace("'positioned',", "'positioned', 'ordinary-vectors', 'ordinary-large-io',") if i==0 else a+b
  if f.endswith('launch-pipe-fixture.c'):return a+'    return 0;\n}\n'+b if i==0 else a+b
  if f.endswith('launch-storage-fixture.c'):return a+b
  raise AssertionError((f,i))
 p.write_text(re.sub(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',merge,t,flags=re.S))
for f in ['scripts/test-launch-pipes.py','scripts/test-launch-storage.py']:py_compile.compile(str(s/f),doraise=True)
for f in ['tests/fixtures/launch-pipe-fixture.c','tests/fixtures/launch-storage-fixture.c']:subprocess.run(['cc','-fsyntax-only',str(s/f)],check=True)
