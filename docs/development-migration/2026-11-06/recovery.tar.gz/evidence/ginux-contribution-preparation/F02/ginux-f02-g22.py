from pathlib import Path
import re,json
s=Path('/tmp/ginux-contribution-preparation/F02/source');x=json.loads((s.parent/'state.json').read_text());assert x['pending_packet']=='G22'
for f in x['conflicts']:
 p=s/f;t=p.read_text();n=0
 def merge(m):
  global n
  a,b=m[1],m[2];i=n;n+=1
  if f=='README.md':
   control=a[a.index('A host coordinator'):a.index('`--restore-file')]
   control=control.replace('Finite guest readiness waits also use a bounded timer tick; shared-thread\ncapture','Finite guest readiness waits\nalso use a bounded timer tick; shared-thread capture')
   return b.replace('retained storage or live checkpoint control.','retained storage.').replace('`--restore-file',control+'`--restore-file',1)
  return a+'    }\n\n'+b if i==0 else a+b
 p.write_text(re.sub(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',merge,t,flags=re.S))
