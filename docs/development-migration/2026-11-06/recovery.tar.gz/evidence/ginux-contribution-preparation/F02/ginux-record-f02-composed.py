from pathlib import Path
import subprocess,json,shutil,hashlib,difflib,os,re
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';r=Path('/tmp/ginux-contribution-preparation/F02');s=r/'source';x=json.loads((r/'state.json').read_text());g12=Path('/tmp/ginux-contribution-preparation/G12');cor=json.loads((g12/'correction-manifest.json').read_text());assert cor['head']=='8bb50aaa50e80428ff417654d35affd468255775';assert cor['static_build']['exit_code']==cor['clean_static_build']['exit_code']==0
cor['status']='corrected source and strict replay pass static/build,92 units and ordinary mapping/storage; full FD/security fixture remains enabled and unrun';(g12/'correction-manifest.json').write_text(json.dumps(cor,indent=2)+'\n')
# Keep previous canonical artifacts recoverable while assigning the fixed fixture to G12.
for name in ['manifest.json','candidate.patch']:
 old=g12/('before-f02-'+name)
 if not old.exists():shutil.copyfile(g12/name,old)
shutil.copyfile(g12/'corrected-candidate.patch',g12/'candidate.patch')
manifest=json.loads((g12/'manifest.json').read_text());manifest.update({k:cor[k] for k in ['head','tree','base','patch_sha256','source_binary_sha256']});manifest['previous_head']=cor['previous_head'];manifest['correction_record']='correction-manifest.json';(g12/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copyfile(g12/'corrected-candidate.patch',docs/'patches/G12.patch')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(q for q in plan['packets'] if q['packet']=='G12');row.update({k:cor[k] for k in ['head','tree','base','patch_sha256','source_binary_sha256','clean_binary_sha256']});row['previous_head']=cor['previous_head'];row['changed_files']=sorted(set(row['changed_files'])|{'tests/fixtures/launch-fd-fixture.c'});row['composition_note']='F02 assigned stale FD read-only mmap assertion correction to G12; source and strict replay pass92 units/178 paths and ordinary mapping/storage. Descendant historical snapshots retain prior bases until refresh; publication still requires correct G12 prerequisite and current-main replay.';p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'g12-review.md';t=p.read_text();assert cor['head'] not in t;t=t.replace('Head `83072ec3ddab3e4712ce8db9ba232a10342557de`, tree `4943047fea72e3e814ca38794fc573e9bd050238`, sole local prerequisite','Current head `'+cor['head']+'`, tree `'+cor['tree']+'`, sole local prerequisite',1).replace('Ten files,+663/-80.','Eleven files,+666/-81.');t=t.replace('## Exact ordinary evidence','## Initial ordinary evidence (previous head83072ec3)',1);t+='''
## F02 fixture correction

The full descriptor fixture still expected an owned read-only mmap to return
EOPNOTSUPP after G12 introduced that operation. The corrected candidate verifies
mapped byte A and unmap, retaining writable-shared denial. This belongs to G12;
it is no longer an unrecorded fix only in a later composition. Earlier descendant
snapshots remain historical and need the corrected prerequisite at extraction.

Current source and a strict G11-plus-patch replay pass `make check test-unit build
build-launch-fd-fixture build-launch-storage-fixture`:92 units,178 matching paths,
and the same binary SHA256cab7a0daf11ce3f927e495a0c285dd537675941aa9d99e7cd2b3d0c355c711c8.
Both also pass ordinary-mapping, ordinary-unlinked-mapping, growth, bounds and
quota. The first correction accidentally redeclared an existing C variable;
the fixture compiler caught it, assignment fixed it, and both final builds pass.
The failure log is retained. Full FD fixture/protected/private-FD checks remain
enabled and locally unrun for DaybreakBlue; this is not full CI acceptance.
''';p.write_text(t)
# Retain the archive prerequisite adaptation omitted by the isolated G22 delta.
git=['git','--git-dir='+x['object_repository_git_dir']];before=next(q for q in x['resolved_joins'] if q['packet']=='G30')['tree_after_join'];name='crates/ginux-vfs/src/lib.rs';old=subprocess.check_output(git+['show',before+':'+name]).decode();new=(s/name).read_text();a='    pub fn overlay_entry(';b='    pub fn overlay_files(';adapted=old[:old.index(a)]+new[new.index(a):new.index(b)]+old[old.index(b):];(r/'G22-archive-prerequisite-join.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),adapted.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
for correction in x['candidate_corrections_needed']:
 if correction['packet']=='G12':correction['status']='assigned to corrected G12 '+cor['head']+'; source/strict replay static,92 units and ordinary mapping/storage pass; full FD/security remains unrun'
 if correction['packet']=='G22':correction['status']='reviewed G22 head/base already has correct helpers; explicit required archive prerequisite join saved as G22-archive-prerequisite-join.patch for future extraction; union validated'
x['status']='37-patch per-process union static/routine/actual transport/archive checks pass in source and clean replay; F02 partial pending thread/security and remaining consumers';x['next']='Review remaining ordinary actual consumer requirements and current Recipe code; retain G07 and DaybreakBlue holds; F03 closure not yet claimed';x['final_clean_tree_paths']=189;x['selected_unit_tests']=102;x['full_unit_tests_not_run']=3;x['candidate_updates']={'G12':cor['head']};x['final_runner_revalidation']=['functional-tasks-receipt.json','clean-functional-tasks-receipt.json'];(r/'state.json').write_text(json.dumps(x,indent=2)+'\n')
# Copy only evidence, not raw mode0600 workload result files or private TLS material.
art=root/'.artifacts/ginux-contribution-preparation/F02';art.mkdir(parents=True,exist_ok=True)
for p in r.iterdir():
 if p.is_file() and (p.name=='index' or p.suffix in ['.log','.index','.txt','.patch'] or p.name in ['state.json','source-preservation.json','unit-receipt.json','clean-unit-receipt.json'] or p.name.endswith(('-receipt.json','-provenance.json'))):shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-f02-*.py'):shutil.copyfile(p,art/p.name)
for p in [Path('/tmp/ginux-record-f02-composed.py'),Path('/tmp/ginux-f02-coexist.py')]:shutil.copyfile(p,art/p.name)
art12=root/'.artifacts/ginux-contribution-preparation/G12'
for p in g12.iterdir():
 if p.is_file() and ('correction' in p.name or p.name.startswith(('corrected-','before-f02-'))):shutil.copyfile(p,art12/p.name)
for p in Path('/tmp').glob('ginux-g12-correction*.py'):shutil.copyfile(p,art12/p.name)
(docs/'f02-review.md').write_text(f'''# F02 — combined per-process source (partial)

All37 prepared patches are joined in `/tmp/ginux-contribution-preparation/F02/source`.
Local unreferenced snapshot `{x['combined_head']}`, tree `{x['working_tree']}`,
is based on recorded main `{x['recorded_main']}`. This is a local integration
snapshot, not a proposed PR or a fresh remote-main check. The temporary index
is `/tmp/ginux-contribution-preparation/F02/index`; state.json records exact patch
order, conflict resolutions, source snapshots, findings and receipts. Real branch,
index, checkout and stash state is preserved; nothing was published.

## Source joins and fixes

- Existing behavior owners retain cwd, executable/mapping transactions, locks,
  readiness and teardown. Mapping transactions remain before ordinary dispatch.
- Dynamic memfd/namespace backing retains aliases, directory/link states,
  accounting and mapping identity. Restore/export/checkpoints share correct
  canonical metadata and backing reads. The G22 extraction depended on a base
  that already adapted archive helpers; compilation exposed that missing join.
  `G22-archive-prerequisite-join.patch` explicitly retains it for future extraction.
- Private signal/control poll uses a1ms timeout only for finite/external guest
  readiness waits. wait4(WNOHANG) remains the task-status owner.
- One canonical IoVectors helper serves files, pipes, packets and TCP. Packets
  retain duplex direction, message boundaries, short-read discard and zero-size
  messages. FIONBIO retains its copy helper after the vector port.
- Object references place TCP after64 file+32 channel+64 device slots (start160,
  total176). Network-specific ENOTSOCK guards preserve local packet send/receive
  through the channel owner. Socket stats include link/timestamp fields.
- G26 retains typed per-process identity queries; G27 configured uname moves to
  the task entry after ABI/private transaction handling. Native core is unchanged.
- Descriptor futimens-null and fchownat-empty routing coexist. Default fixture,
  Make and CI coverage are retained together; stale combined docs are corrected.
- Mixed task selections initially accepted ordinary-resources without calling
  its resource cases. The runner now invokes those cases whenever selected and
  removes this runner-only name before fixture dispatch; source/clean reruns pass.
- G12's stale FD mapping assertion is assigned to corrected candidate
  `{cor['head']}`. Its source/strict replay passes92 units,178 paths and ordinary
  mapping/storage. Full FD/security remains enabled and unrun. The first edit's
  duplicate variable failed compilation and was corrected before validation.

## Exact ordinary evidence

Source and strict recorded-main-plus-combined-patch replay pass make check,
all five Rust build binaries and all12 configured-launch fixture build targets.
All189 tracked paths match, and both binaries hash
`{x['source_binary_sha256']}`. The final snapshot only changes the Python task
selection after the first full build/replay; exact final-tree equality is checked,
and the affected source/clean task/resource/lock scenarios rerun successfully.
All compiled Rust/fixture bytes and the binary remain unchanged.

Seven unit packages pass102 selected tests in each export. The three new TCP
policy/security tests remain enabled but locally unrun, so this is not a full
make test-unit/CI pass. Source checks preserve all65 original named unit tests,
all7 package commands, required CI, exact native core/process fixtures/cgroup
module and five native protected-copy caller bodies. No security acceptance is
claimed by source comparison.

Eleven ordinary integration groups pass in source/clean: channels (including
vectors), polling, storage/mapping/link/namespace/positioned/vector/large-I/O/
timestamp/ownership/export, directories/cwd/cross paths, owned ELF, scripts,
resources/identity, locks/process lifecycle, TCP, checkpoints and full restore.
Restore covers5,000 nonempty files, archive link identity and the complete payload
above2 GiB. The corrected mixed resource selection has a separate final receipt.
A focused valid regression holds TCP alongside64 null devices, fourteen pipes,
packet vectors and owned storage, proving the joined ranges/functionality.

Actual trusted cpio extracts all8229 bytes plus hardlink/symlink/root metadata.
Actual curl IPv4/IPv6 HTTP and verified local TLS pass; actual Git ls-remote now
passes controlled HTTP and TLS through the real helper subprocess. All actual
consumer checks pass in source and clean replay. The earlier G29-only Git getcwd
failure is resolved by the configured cwd owner here, without a native core grant.
No external service, negative TLS or hostile-input scenario ran.

## Remaining work and limits

G07 threads/shared arguments remains unready and excluded. G01/G02 native policy
and G25 native clamp remain excluded. [DaybreakBlue](daybreakblue-handoff.md)
owns written adversarial validation; no agent was dispatched and no security
criterion is passed. Policy/full default/remote platform CI/current-main standalone
acceptance remain pending. Actual compiler, SQLite/Cargo and APK/RPM package
consumer closure plus the fresh complete applicable Recipe suite remain open.
This combined proof does not replace candidate-specific independence or reviews.

Evidence and helpers are retained in .artifacts/ginux-contribution-preparation/F02;
G12 correction evidence remains under its own directory. Private TLS keys and raw
mode0600 result files are excluded from evidence copies. Initial formatting,
compile/merge-helper failures and the transient shared Git config observation
remain recorded. No shared config repair was made by this task.

Exact next action: review remaining ordinary consumer requirements/current Recipe
code against this per-process composition; keep G07/security/policy and every
unperformed criterion explicit. F03 complete acceptance and F04 user inspection
remain open. No branch/ref creation, push, PR or maintainer message is authorized.
''')
p=docs/'daybreakblue-handoff.md';t=p.read_text();t+=f'''
## F02 — combined per-process snapshot (security unverified)

Combined `{x['combined_head']}` excludes G07 threads/shared arguments, native
clock/poll policy and the native read clamp. Ordinary source/clean build,102
selected units, channels/storage/cwd/locks/TCP/control/restore and actual
curl/Git/cpio checks pass. These results do not validate hostile cross-owner
inputs, private-FD/mapping transactions, shared argument races, control/task
cancellation faults or rollback/authority/confinement under adversarial input.
Carry all earlier packet handoffs into the combined review, including packet/
TCP dispatch, dynamic references, archive canonical metadata and typed resource
queries. Three default-enabled TCP policy/security units and full security
fixtures remain locally unrun. G07 remains unready; no cloud dispatch occurred.

G12 corrected `{cor['head']}` preserves full FD security cases while replacing
its obsolete read-only mapping denial assertion with valid data/unmap checks.
Only ordinary mapping scenarios ran; the full protected/private-FD fixture is
still for monitored review. No security acceptance or green full CI is claimed.
''';p.write_text(t)
p=root/'docs/ginux-contribution-task-list.md';t=p.read_text();a=t.index('F02 composition is active:');b=t.index('\nActive skill:',a);t=t[:a]+f'''F02's37-patch per-process union is retained at `{x['combined_head']}`:
[review/evidence](ginux-contributions/f02-review.md). Source/clean replay matches189
paths and identical binary; make check/build,102 selected units and eleven ordinary
integration groups pass, including complete>2GiB/5000-file restore. Actual curl
IPv4/IPv6 HTTP/TLS, Git HTTP/TLS and cpio pass in both. Backend coexistence, packet
vectors and the corrected mixed task/resource selection pass. All65 original
unit names/required CI/native source remain. Three security/policy unit tests,
full default fixtures and remote CI remain unrun. This is partial F02, not green
full CI or full compiler/Recipe acceptance.

G12 fixture correction is assigned to `{cor['head']}` with92 units/178-path strict
replay and ordinary mapping/storage passes; earlier candidate evidence remains
historical. G22's reviewed base already contained the archive alias/metadata join;
it is explicitly retained for future extraction rather than silently assumed.
Every original policy/security/current-main independence hold remains. No
publication occurred.

Exact next action: **review remaining actual consumer requirements and current
Recipe code** against the frozen combined source. Keep G07 unready thread/shared
argument work with DaybreakBlue, plus G01/G02 native policy and G25 native clamp
excluded. Actual compiler, SQLite/Cargo, APK/RPM package and fresh complete
applicable Recipe acceptance remain F02/F03 work; do not reuse historical suite
passes as new closure. F04 remains user inspection before any publication. No
branches/refs/pushes/PRs/maintainer messages are authorized.
''' +t[b:];p.write_text(t)
print('recorded final combined',x['combined_head'],'G12',cor['head'],'still partial, no publication')
