from pathlib import Path
import re,json,subprocess,py_compile
s=Path('/tmp/ginux-contribution-preparation/F02/source');x=json.loads((s.parent/'state.json').read_text());assert x['pending_packet']=='G30'
for f in x['conflicts']:
 p=s/f;t=p.read_text();n=0
 def merge(m):
  global n
  a,b=m[1],m[2];i=n;n+=1
  if f=='README.md':return a+'\n'+b
  if f.endswith('descriptors.rs'):return a.replace('| 91 | 217','| 91 | 93 | 217') if i==0 else a.replace('258 | 262','258 | 260 | 262')
  if f.endswith('fs_hooks.rs'):
   if i==0:return a.replace('        if r.orig_rax == 280 && r.rsi == 0 {','''        // Empty-path ownership likewise belongs to the descriptor owner.
        if (r.orig_rax == 280 && r.rsi == 0)
            || (r.orig_rax == 260 && read_path(pid, r.rsi)?.is_empty()) {''')
   if i==1:return b.replace('262 =>','262 | 280 =>')
   return a+b
  if f.endswith('test-launch-storage.py'):return a.replace("'positioned',", "'positioned', 'ownership', 'ordinary-ownership',") if i==0 else a+b
  if f.endswith('launch-storage-fixture.c'):return a+'    return 0;\n}\n'+b if i==0 else a+b
  raise AssertionError((f,i))
 p.write_text(re.sub(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',merge,t,flags=re.S))
py_compile.compile(str(s/'scripts/test-launch-storage.py'),doraise=True);subprocess.run(['cc','-fsyntax-only',str(s/'tests/fixtures/launch-storage-fixture.c')],check=True)
