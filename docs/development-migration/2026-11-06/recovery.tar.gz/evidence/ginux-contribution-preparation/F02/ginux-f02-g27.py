from pathlib import Path
import re,json,py_compile,subprocess
s=Path('/tmp/ginux-contribution-preparation/F02/source');x=json.loads((s.parent/'state.json').read_text());assert x['pending_packet']=='G27'
for f in x['conflicts']:
 p=s/f;t=p.read_text()
 def merge(m):
  a,b=m[1],m[2]
  if f=='README.md':return a.replace('Optional `[storage]',b[b.index('Configured `uname`'):]+ '\nOptional `[storage]',1)
  if f.endswith('launch.rs'):return a
  if f.endswith('launch-fixture.c'):return a+'        return 0;\n    }\n'+b
  if f.endswith('test-launch.py'):
   af=a[:a.index('        if sys.argv[3:]')];bf=b[:b.index('        if sys.argv[3:]')]
   return af+bf+'''        if sys.argv[3:]:
            selected={'ordinary-resources':resource_cases, 'ordinary-uname':identity_cases}
            if any(mode not in selected for mode in sys.argv[3:]):
                sys.exit('unknown selected launch scenario')
            for mode in sys.argv[3:]:
                selected[mode]()
            return
        resource_cases()
        identity_cases()
'''
  raise AssertionError(f)
 p.write_text(re.sub(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',merge,t,flags=re.S))
p=s/'crates/ginux-init/src/launch_tasks.rs';t=p.read_text();anchor='        let id = self.task(index).id;\n';assert t.count(anchor)==1
hook='''        if r.orig_rax == ginux_core::SYS_UNAME {
            let identity = ginux_kernel_views::IdentityView {
                hostname: domain.config().id.as_bytes(),
                machine_id: b"",
                boot_id: b"",
            };
            let mut bytes = [0u8; 390];
            let result = identity
                .uname(b"x86_64", &mut bytes)
                .map_err(|_| -5)
                .and_then(|_| crate::supervisor::write_tracee_bytes_strict(
                    self.task(index).host, r.rdi as usize, &bytes))
                .map(|_| 0)
                .unwrap_or_else(|error| error);
            self.emulate(index, r, result, domain);
            return;
        }
'''
assert 'ginux_core::SYS_UNAME' not in t;p.write_text(t.replace(anchor,anchor+hook));x['extra_resolved_files']=['crates/ginux-init/src/launch_tasks.rs'];(s.parent/'state.json').write_text(json.dumps(x,indent=2)+'\n')
py_compile.compile(str(s/'scripts/test-launch.py'),doraise=True);subprocess.run(['cc','-fsyntax-only',str(s/'tests/fixtures/launch-fixture.c')],check=True)
