from pathlib import Path
import json,re
r=Path('/tmp/ginux-contribution-preparation/F02');x=json.loads((r/'state.json').read_text());assert x['conflicts'] and set(x['conflicts'])<={'.github/workflows/check.yml','Makefile'};s=Path(x['source'])
for name in x['conflicts']:
 p=s/name;t=p.read_text()
 while '<<<<<<< ours\n' in t:
  a=t.index('<<<<<<< ours\n');b=t.index('=======\n',a);c=t.index('>>>>>>> theirs\n',b);ours=t[a+len('<<<<<<< ours\n'):b];theirs=t[b+len('=======\n'):c]
  if name=='Makefile':
   assert ours.startswith('.PHONY: ') and theirs.startswith('.PHONY: '),(ours,theirs)
   ot=set(re.findall(r'^([\w-]+):',ours,re.M));tt=set(re.findall(r'^([\w-]+):',theirs,re.M));assert ot and tt and not (ot&tt),(ot,tt);merged=ours.rstrip()+'\n\n'+theirs
  else:
   ol=ours.splitlines();tl=theirs.splitlines();assert all(l.startswith('      - run: ') for l in ol+tl)
   ob=[l for l in ol if l.startswith('      - run: make build ')];tb=[l for l in tl if l.startswith('      - run: make build ')]
   if ob and tb:
    assert len(ob)==len(tb)==1 and ol==ob and tl==tb,(ol,tl);prefix='      - run: ';tokens=list(dict.fromkeys((ob[0][len(prefix):]+' '+tb[0][len(prefix):]).split()));assert tokens[:2]==['make','build'];merged=prefix+' '.join(tokens)+'\n'
   else:merged='\n'.join(dict.fromkeys(ol+tl))+'\n'
  t=t[:a]+merged+t[c+len('>>>>>>> theirs\n'):]
 p.write_text(t)
ci=(s/'.github/workflows/check.yml').read_text();assert '      - run: make test-unit\n' in ci
print('merged distinct fixture/build/CI entries, preserved static-and-unit')
