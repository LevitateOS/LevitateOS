from pathlib import Path
import subprocess,tarfile,io,json,os,hashlib
r=Path('/tmp/ginux-contribution-preparation/F02');s=r/'source';d=r/'verified-head';assert not d.exists();d.mkdir();m=json.loads((r/'state.json').read_text());git=['git','--git-dir='+m['object_repository_git_dir']]
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(git+['archive',m['recorded_main']]))) as t:t.extractall(d,filter='data')
subprocess.run(['git','apply','--whitespace=error',str(r/'combined.patch')],cwd=d,check=True);names=subprocess.check_output(git+['ls-tree','-r','--name-only',m['combined_head']]).decode().splitlines()
for name in names:
 a=s/name;b=d/name;assert a.is_symlink()==b.is_symlink(),name;assert (os.readlink(a)==os.readlink(b) if a.is_symlink() else a.read_bytes()==b.read_bytes()),name
cmd=['make','check','build','build-launch-fixture','build-launch-storage-fixture','build-launch-device-fixture','build-launch-pipe-fixture','build-launch-fd-fixture','build-launch-task-fixture','build-launch-exec-fixture','build-launch-poll-fixture','build-launch-directory-fixture','build-launch-owned-exec-fixture','build-launch-script-fixture','build-launch-network-fixture']
with (r/'clean-static-build.log').open('w') as f:p=subprocess.run(cmd,cwd=d,stdout=f,stderr=subprocess.STDOUT)
record={'command':cmd,'exit_code':p.returncode,'base':m['recorded_main'],'combined_head':m['combined_head'],'matched_paths':len(names),'binary_sha256':hashlib.sha256((d/'target/x86_64-unknown-linux-gnu/release/ginux').read_bytes()).hexdigest() if p.returncode==0 else None};(r/'clean-static-receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);assert p.returncode==0;assert record['binary_sha256']==m['source_binary_sha256']
