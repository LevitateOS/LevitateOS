from pathlib import Path
import re,json,subprocess
s=Path('/tmp/ginux-contribution-preparation/F02/source');x=json.loads((s.parent/'state.json').read_text());assert x['pending_packet']=='G21'
for f in x['conflicts']:
 p=s/f;t=p.read_text();n=0
 def merge(m):
  global n
  a,b=m[1],m[2];i=n;n+=1
  if f in ['Makefile','.github/workflows/check.yml']:return a.rstrip()+'\n\n'+b if f=='Makefile' else a+b
  if f=='README.md':
   text=a.replace('retained storage, startup restoration, symlink or hardlink archive support.','retained storage, symlink or hardlink archive support.').replace('Guest polling, shared\nthread capture and startup restore remain separate capabilities.','Finite guest readiness waits also use a bounded timer tick; shared-thread\ncapture remains a separate capability.')
   rest=b[b.index('`--restore-file'):].replace('The current32-slot namespace (including prepared assignment\nparents), configured byte capacity and2 GiB archive payload bound all apply.','Configured namespace capacity (including prepared assignment parents),\nbyte capacity and the2 GiB archive payload bound all apply.')
   return text+'\n'+rest
  if f.endswith('fs_hooks.rs'):
   return 'pub(crate) const OBJECTS: usize = 32;\n'+a if i==0 else a+'    }\n\n'+b
  if f.endswith('launch.rs'):
   if i==0:return '    Launch(*const u8, *const u8, *const u8, *const u8, Option<usize>, *const u8),\n'
   if i in (1,2,3,4):return a+b
   return a.replace('[--control-fd <inherited socket>]','[--control-fd <inherited socket>] [--restore-file <snapshot tar>]')
  if f.endswith('main.rs'):
   return '''        Some(Command::Launch(config_path, root_path, result_path, export_path, control_fd, restore_path)) => {
            launch_main(config_path, root_path, result_path, export_path, control_fd, restore_path)
'''
  if f.endswith('launch-storage-fixture.c'):return a+'}\n'+b if i==0 else a+b
  raise AssertionError(f)
 t=re.sub(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',merge,t,flags=re.S);p.write_text(t)
subprocess.run(['cc','-fsyntax-only','-Wall','-Wextra',str(s/'tests/fixtures/launch-storage-fixture.c')],check=True)
