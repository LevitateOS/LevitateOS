from pathlib import Path
import re,json
s=Path('/tmp/ginux-contribution-preparation/F02/source');x=json.loads((s.parent/'state.json').read_text());assert x['pending_packet']=='G23'
for f in x['conflicts']:
 p=s/f;t=p.read_text();n=0
 def merge(m):
  global n
  a,b=m[1],m[2];i=n;n+=1
  if f.endswith('descriptors.rs'):return a.replace('44 | 45 | 74','44 | 45 | 73 | 74')
  if f.endswith('fs_hooks.rs'):
   if i==0:return a+'    }\n\n'+b
   return a[:a.index('            3 =>')]+b[b.index('            3 =>'):]
  if f.endswith('launch_tasks.rs'):return b+a
  if f.endswith('main.rs'):return a+b
  raise AssertionError(f)
 p.write_text(re.sub(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',merge,t,flags=re.S))
