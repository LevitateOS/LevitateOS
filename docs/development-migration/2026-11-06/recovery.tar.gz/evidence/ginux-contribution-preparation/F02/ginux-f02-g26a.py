from pathlib import Path
import re,json,py_compile
s=Path('/tmp/ginux-contribution-preparation/F02/source');x=json.loads((s.parent/'state.json').read_text());assert x['pending_packet']=='G26a'
for f in x['conflicts']:
 p=s/f;t=p.read_text();n=0
 def merge(m):
  global n
  a,b=m[1],m[2];i=n;n+=1
  if f=='README.md':return b+a[a.index('Optional `[storage]'):]
  if f.endswith('launch.rs'):
   if i==0:return a.replace('launch_tracee(root_path, descriptors.capacity());','launch_tracee(root_path, &config, descriptors.capacity());')
   return b.replace('fn launch_tracee(root_path: *const u8, config: &DomainConfig) -> ! {','fn launch_tracee(root_path: *const u8, config: &DomainConfig, descriptor_limit: usize) -> ! {')
  if f.endswith('test-launch.py'):
   if i==0:return a.replace('cloexec_stdin=False','cloexec_stdin=False, preexec=None')
   return '''                                  timeout=20, pass_fds=pass_fds,
                                  preexec_fn=child_setup if (preexec or cloexec_stdin) else None)
'''
  raise AssertionError((f,i))
 t=re.sub(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',merge,t,flags=re.S)
 if f.endswith('test-launch.py'):
  at='            proc = subprocess.run('
  assert at in t
  t=t.replace(at,'''            def child_setup():
                if preexec:
                    preexec()
                if cloexec_stdin:
                    fcntl.fcntl(0, fcntl.F_SETFD, fcntl.FD_CLOEXEC)
            proc = subprocess.run(''',1)
 p.write_text(t)
py_compile.compile(str(s/'scripts/test-launch.py'),doraise=True)
