from pathlib import Path
import subprocess,re,shutil,hashlib,json,sys
r=Path('/tmp/ginux-contribution-preparation/F02');s=r/(sys.argv[1] if len(sys.argv)>1 else 'source');prefix='' if s.name=='source' else 'clean-';root=r/'sqlite-root';(root/'bin').mkdir(parents=True,exist_ok=True);(root/'work').mkdir(exist_ok=True)
source=r/'sqlite-consumer.c';source.write_text(r'''
typedef struct sqlite3 sqlite3;
extern int sqlite3_open_v2(const char*,sqlite3**,int,const char*);
extern int sqlite3_exec(sqlite3*,const char*,int(*)(void*,int,char**,char**),void*,char**);
extern int sqlite3_close(sqlite3*);
extern const char *sqlite3_libversion(void);
extern int pipe(int*),fork(void),waitpid(int,int*,int),close(int);
extern long read(int,void*,unsigned long),write(int,const void*,unsigned long);
extern void _exit(int);
#define CHECK(x,n) do{if(!(x)){write(2,"sqlite check failed\n",20);return n;}}while(0)
static int open_db(sqlite3 **db){return sqlite3_open_v2("/work/cache.db",db,2|4,0);}
static int value;
static int collect(void *p,int n,char **v,char **names){(void)p;(void)names;if(n!=1 || !v[0])return 1;value=0;for(char*c=v[0];*c;c++)value=value*10+*c-'0';return 0;}
int main(void){
 sqlite3 *db=0;CHECK(sqlite3_libversion()!=0,10);CHECK(open_db(&db)==0,11);
 CHECK(sqlite3_exec(db,"PRAGMA journal_mode=DELETE; CREATE TABLE items(v INTEGER);",0,0,0)==0,12);
 CHECK(sqlite3_close(db)==0,13);
 int go[2],ready[2];CHECK(pipe(go)==0 && pipe(ready)==0,14);int child=fork();CHECK(child>=0,15);
 if(child==0){
  close(go[1]);close(ready[0]);char marker=0;CHECK(read(go[0],&marker,1)==1,16);
  CHECK(open_db(&db)==0,17);CHECK(sqlite3_exec(db,"BEGIN IMMEDIATE;",0,0,0)==5,18);
  CHECK(write(ready[1],"B",1)==1 && read(go[0],&marker,1)==1,19);
  CHECK(sqlite3_exec(db,"BEGIN IMMEDIATE; INSERT INTO items VALUES(22); COMMIT;",0,0,0)==0,20);
  CHECK(sqlite3_close(db)==0,21);_exit(0);
 }
 close(go[0]);close(ready[1]);CHECK(open_db(&db)==0,22);
 CHECK(sqlite3_exec(db,"BEGIN IMMEDIATE; INSERT INTO items VALUES(11);",0,0,0)==0,23);
 CHECK(write(go[1],"G",1)==1,24);char marker=0;CHECK(read(ready[0],&marker,1)==1 && marker=='B',25);
 CHECK(sqlite3_exec(db,"COMMIT;",0,0,0)==0 && sqlite3_close(db)==0,26);
 CHECK(write(go[1],"G",1)==1,27);int status=-1;CHECK(waitpid(child,&status,0)==child && status==0,28);
 CHECK(open_db(&db)==0 && sqlite3_exec(db,"SELECT sum(v) FROM items;",collect,0,0)==0 && value==33,29);
 CHECK(sqlite3_exec(db,"PRAGMA integrity_check;",0,0,0)==0 && sqlite3_close(db)==0,30);
 CHECK(close(go[1])==0 && close(ready[0])==0,31);write(1,"sqlite-locks: PASS\n",19);return 0;
}
''')
program=root/'bin/sqlite-consumer';subprocess.run(['cc','-O2','-Wall','-Wextra','-Werror',str(source),'/lib64/libsqlite3.so.0','-o',str(program)],check=True);files=re.findall(r'(?:=>\s+|^\s+)(/[^\s]+)',subprocess.check_output(['ldd',str(program)]).decode(),re.M);provenance=[]
for name in dict.fromkeys(files):
 p=Path(name);dest=root/name.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);dest.chmod(0o755);provenance.append({'source':name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
(r/'sqlite-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n');config=(s/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/sqlite-consumer"').replace('[storage]\nassignments = []','[storage]\nassignments = ["memory:/work"]').replace('[devices]\nassignments = []','[devices]\nassignments = ["null"]');path=r/(prefix+'sqlite.toml');path.write_text(config);result=r/(prefix+'sqlite-result.json');result.unlink(missing_ok=True);cmd=[str(s/'target/x86_64-unknown-linux-gnu/release/ginux'),'launch',str(path),str(root),'--result-file',str(result)];p=subprocess.run(cmd,capture_output=True,timeout=20);(r/(prefix+'sqlite.audit')).write_bytes(p.stderr);(r/(prefix+'sqlite.stdout')).write_bytes(p.stdout);receipt={'command':cmd,'exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'result':json.loads(result.read_text()) if result.exists() else None,'consumer_sha256':hashlib.sha256(program.read_bytes()).hexdigest(),'scope':'actual host SQLite shared library, two real forked clients, SQLite_BUSY while lock held, commit/release then successful second transaction, sum and integrity check; no disabled lock option'};(r/(prefix+'sqlite-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print('sqlite',p.returncode,repr(p.stdout),flush=True)
if p.returncode or p.stdout!=b'sqlite-locks: PASS\n':print(p.stderr[-4500:].decode(errors='replace'),flush=True)
assert p.returncode==0 and p.stdout==b'sqlite-locks: PASS\n'
