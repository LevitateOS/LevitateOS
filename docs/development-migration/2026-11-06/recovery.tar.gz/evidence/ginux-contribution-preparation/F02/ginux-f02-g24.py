from pathlib import Path
import re,json,py_compile
s=Path('/tmp/ginux-contribution-preparation/F02/source');x=json.loads((s.parent/'state.json').read_text());assert x['pending_packet']=='G24'
for f in x['conflicts']:
 p=s/f;t=p.read_text();n=0
 def merge(m):
  global n
  a,b=m[1],m[2];i=n;n+=1
  if f.endswith('fs_hooks.rs'):return a+'    }\n\n'+b if i==1 else a+b
  if i==0:return a.replace("'positioned',", "'positioned', 'timestamps', 'ordinary-times',")
  return ''.join(l+'\n' for l in b.splitlines() if "['namespace']" not in l)
 p.write_text(re.sub(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',merge,t,flags=re.S))
py_compile.compile(str(s/'scripts/test-launch-storage.py'),doraise=True)
