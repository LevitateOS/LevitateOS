from pathlib import Path
import subprocess,json,sys
r=Path('/tmp/ginux-contribution-preparation/F02');clean='--clean' in sys.argv;sys.argv=[x for x in sys.argv if x!='--clean'];s=r/('verified-head' if clean else 'source');prefix='clean-' if clean else '';records=[]
cases=[
('channels','pipes','pipe',['ordinary-packet','ordinary-fionbio','ordinary-streams','ordinary-vectors']),
('poll','poll','poll',['ordinary','read','write','hup','ordinary-timer']),
('storage','storage','storage',['growth','bounds','quota','ordinary-mapping','ordinary-unlinked-mapping','ordinary-symlinks','namespace','positioned','ordinary-vectors','ordinary-large-io','ordinary-times','ordinary-ownership','flush','export','export-wait','child-export']),
('directories','directories','directory',['functional','cwd','ordinary-owned-cwd','ordinary-cwd-budget','ordinary-hardlinks','ordinary-hardlink-quota','ordinary-cross','ordinary-cross-exec','ordinary-image-dir-exec']),
('owned-exec','owned-exec','owned-exec',['ordinary-path','ordinary-fd','ordinary-unlinked','ordinary-relative','ordinary-child','ordinary-reexec','ordinary-hardlinked','ordinary-fd-hardlinked']),
('scripts','scripts','script',['ordinary-plain','ordinary-option','ordinary-nested','ordinary-relative','ordinary-at','ordinary-fd','ordinary-unlinked','ordinary-dir','ordinary-renamed','ordinary-fork','ordinary-vfork','ordinary-owned','ordinary-chain','ordinary-joined','ordinary-script-link','ordinary-interpreter-link','ordinary-cross','ordinary-cross-nested','ordinary-cross-relative','ordinary-cross-cwd','ordinary-cross-plain']),
('resources-identity','','',['ordinary-resources','ordinary-uname']),
('tasks','tasks','task',['OrdinaryLocks','ExecLocks','fork','vfork','clone','shared-vfork','libc-fork','handler-return','inherit','orphan','adopted-zombie','ordinary-resources']),
('network','network','network',['io','nonblock','timeout','ordinary-hold','budget']),
('checkpoints','checkpoints','storage',['ordinary']),
('restore','restore','storage',['ordinary'])]
selected=sys.argv[1:]
for name,script,fixture,modes in cases:
 if selected and name not in selected:continue
 if name=='resources-identity':script='test-launch.py';fixture='launch-fixture'
 else:script='test-launch-'+script+'.py';fixture='launch-'+fixture+'-fixture'
 cmd=['sudo','-n','python3','scripts/'+script,'target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/'+fixture,*modes]
 log=r/(prefix+'functional-'+name+'.log')
 with log.open('w') as f:p=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':cmd,'exit_code':p.returncode});(r/(prefix+'functional-'+('-'.join(selected) if selected else 'all')+'-receipt.json')).write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:print(log.read_text()[-4500:],flush=True);break
