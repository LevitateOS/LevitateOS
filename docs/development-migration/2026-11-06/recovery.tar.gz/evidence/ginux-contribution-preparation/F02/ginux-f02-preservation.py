from pathlib import Path
import subprocess,json,re,collections,hashlib
r=Path('/tmp/ginux-contribution-preparation/F02');s=r/'source';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base=json.loads((r/'state.json').read_text())['recorded_main'];git=['git','-C',repo,'--work-tree='+repo];packages=['ginux-core','ginux-domain','ginux-devices','ginux-runtime','ginux-process','ginux-vfs','ginux-kernel-views']
def show(f):return subprocess.check_output(git+['show',base+':'+f]).decode()
pattern=r'#\[test\](?:\s*#\[[^\]]*\])*\s*(?:unsafe\s+)?fn\s+(\w+)';files=subprocess.check_output(git+['ls-tree','-r','--name-only',base]).decode().splitlines();paths=[f for f in files if f.endswith('.rs') and any(f.startswith('crates/'+p+'/src/') for p in packages)];names={f:collections.Counter(re.findall(pattern,show(f))) for f in paths};missing={f:dict(v-collections.Counter(re.findall(pattern,(s/f).read_text()))) for f,v in names.items()};missing={f:v for f,v in missing.items() if v};assert not missing,missing
exactfiles=['crates/ginux-core/src/lib.rs','scripts/test-process-native.py','tests/fixtures/process-review-fixture.c','crates/ginux-kernel-views/src/cgroup.rs'];exact={f:(s/f).read_text()==show(f) for f in exactfiles};assert all(exact.values()),exact
make=(s/'Makefile').read_text();unit=make[make.index('test-unit:\n'):].split('\n\n',1)[0];assert all('cargo test -p '+p in unit for p in packages);assert '      - run: make test-unit\n' in (s/'.github/workflows/check.yml').read_text()
def func(t,name):
 at=t.index('fn '+name+'(');at=t.index('{',at);depth=0
 for end in range(at,len(t)):
  if t[end]=='{':depth+=1
  elif t[end]=='}':
   depth-=1
   if depth==0:return t[at:end+1]
 raise AssertionError(name)
f='crates/ginux-init/src/main.rs';a=show(f);b=(s/f).read_text();bodies={n:func(a,n)==func(b,n) for n in ['read_tracee_pipefds','store_wait_results','store_tracee_status','store_tracee_tid','write_wait_fault']};assert all(bodies.values()),bodies
assert (s/'crates/ginux-init/src/tracee_io.rs').read_text().count('pub struct IoVectors {')==1
record={'base':base,'original_named_tests_preserved':sum(sum(v.values()) for v in names.values()),'missing_named_tests':missing,'exact_original_files':exact,'original_native_copy_bodies':bodies,'unit_packages':packages,'required_unit_ci':True,'canonical_iovectors_owners':1,'public_backend_reference_slots':{'vfs':64,'channels':32,'devices':64,'tcp':16,'tcp_start':160,'total':176},'scope':'source preservation only; no security/full CI claim'};(r/'source-preservation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
