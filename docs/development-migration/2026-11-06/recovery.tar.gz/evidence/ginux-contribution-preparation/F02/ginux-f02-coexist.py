from pathlib import Path
import subprocess,json,importlib.util,sys
r=Path('/tmp/ginux-contribution-preparation/F02');s=r/'source';t=(s/'tests/fixtures/launch-network-fixture.c').read_text();anchor='    CHECK(DO(72,fd,1,0)==1,12);';assert t.count(anchor)==1
join='''
    /* All backend ranges coexist with the live TCP object. */
    int pair[2], pipes[14][2]; long nulls[64];
    CHECK(call(53,1,5|04000,0,(word)pair,0,0)==0,100);
    struct {const char *base;word length;} message[3]={{"ab",2},{"",0},{"cdef",4}};
    CHECK(DO(20,pair[0],message,3)==6,101);
    struct {char *base;word length;} receive[2]={{buffer,2},{buffer+2,1}};
    CHECK(DO(19,pair[1],receive,2)==3 && buffer[0]=='a' && buffer[2]=='c',102);
    CHECK(call(45,pair[1],(word)buffer,1,0,0,0)==-11,103);
    CHECK(DO(20,pair[0],message,0)==0 && DO(19,pair[1],receive,2)==0,104);
    for(int n=0;n<14;++n){CHECK(DO(22,pipes[n],0,0)==0,105);CHECK(DO(1,pipes[n][1],"P",1)==1,106);}
    for(int n=0;n<64;++n){nulls[n]=DO(2,"/dev/null",2,0);CHECK(nulls[n]>=3,107);}
    long memory=DO(2,"/work/file",0102,0600);CHECK(memory>=3 && DO(1,memory,"M",1)==1,108);
    for(int n=0;n<64;++n)CHECK(DO(1,nulls[n],"N",1)==1 && DO(3,nulls[n],0,0)==0,109);
    for(int n=0;n<14;++n)CHECK(DO(0,pipes[n][0],buffer,1)==1 && buffer[0]=='P' && DO(3,pipes[n][0],0,0)==0 && DO(3,pipes[n][1],0,0)==0,110);
    CHECK(call(44,pair[1],(word)"Q",1,0,0,0)==1 && DO(0,pair[0],buffer,1)==1 && buffer[0]=='Q',111);
    CHECK(DO(3,pair[0],0,0)==0 && DO(3,pair[1],0,0)==0 && DO(3,memory,0,0)==0,112);
''';src=r/'coexist-fixture.c';src.write_text(t.replace(anchor,anchor+join));binary=r/'coexist-fixture';subprocess.run(['cc','-nostdlib','-static','-fno-stack-protector','-fno-builtin','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(binary)],check=True)
# Use the existing runner; extend only its local valid template with assignments.
p=s/'scripts/test-launch-network.py';spec=importlib.util.spec_from_file_location('coexist_runner',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);read=Path.read_text
original=str(s/'config/domain-gate5.toml')
def assigned(path,*args,**kwargs):
 text=read(path,*args,**kwargs)
 return text.replace('[storage]\nassignments = []','[storage]\nassignments = ["memory:/work"]').replace('[devices]\nassignments = []','[devices]\nassignments = ["null"]') if str(path)==original else text
Path.read_text=assigned
sys.argv=[str(p),str(s/'target/x86_64-unknown-linux-gnu/release/ginux'),str(binary),'io','nonblock']
module.main()
(r/'coexist-receipt.json').write_text(json.dumps({'modes':['io','nonblock'],'exit_code':0,'scope':'live TCP plus 64 null devices, 14 pipes, duplex packet vectors and owned storage; no fault/hostile probes'},indent=2)+'\n')
