from pathlib import Path
import re,json
s=Path('/tmp/ginux-contribution-preparation/F02/source');x=json.loads((s.parent/'state.json').read_text());assert x['pending_packet']=='G29'
for f in x['conflicts']:
 p=s/f;t=p.read_text();n=0
 def merge(m):
  global n
  a,b=m[1],m[2];i=n;n+=1
  if f=='Makefile':return a.rstrip()+'\n\n'+b
  if f=='.github/workflows/check.yml':return a.rstrip()+' build-launch-network-fixture\n' if i==0 else a+b
  if f.endswith('ginux-domain/src/lib.rs'):return a+'    }\n\n    #[test]\n'+b if i==1 else a+b
  if f.endswith('descriptors.rs'):
   if i in (0,1):return a.replace('128 + crate::channel_hooks::FDS','128 + crate::channel_hooks::FDS + crate::network_hooks::FDS')
   if i==2:return '''        if crate::network_hooks::LaunchNetwork::owns(handle) {
            128 + crate::channel_hooks::FDS + (handle - crate::network_hooks::FD_BASE) as usize
        } else '''+a[len('        '):]
   if i==3:return b.replace('22 | 293','22 | 53 | 293')
   if i==4:return b.replace('| 75 |','| 73 | 75 |')
   if i==5:return a[:a.index('        Ok(match decision')]+b.replace('Ok(match backends.claim(pid, r)','Ok(match decision')
  raise AssertionError((f,i))
 t=re.sub(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',merge,t,flags=re.S)
 if f.endswith('descriptors.rs'):
  old='''        if matches!(r.orig_rax, 42 | 44 | 45 | 48 | 51 | 52 | 54 | 55) && !network {'''
  assert old in t;t=t.replace(old,'''        let packet = matches!(entry.handle, Handle::Owned(h) if backends.channels.is_socket(h));
        if matches!(r.orig_rax, 42 | 44 | 45 | 48 | 51 | 52 | 54 | 55)
            && !network && !(packet && matches!(r.orig_rax, 44 | 45)) {''')
 p.write_text(t)
p=s/'crates/ginux-init/src/channel_hooks.rs';t=p.read_text();anchor='    fn entry(&self, slot: usize) -> Result<PipeFd, i64> {';assert t.count(anchor)==1
p.write_text(t.replace(anchor,'''    pub fn is_socket(&self, handle: u32) -> bool {
        handle.checked_sub(PIPE_FD_BASE)
            .and_then(|slot| self.descriptors.get(slot as usize))
            .and_then(|entry| *entry)
            .is_some_and(|entry| entry.peer.is_some())
    }

'''+anchor))
p=s/'crates/ginux-init/src/network_hooks.rs';t=p.read_text();anchor='                Stat {\n';assert t.count(anchor)==1;p.write_text(t.replace(anchor,anchor+'''                    links: 1,
                    accessed: ginux_vfs::Timestamp::ZERO,
                    modified: ginux_vfs::Timestamp::ZERO,
'''))
x['extra_resolved_files']=['crates/ginux-init/src/channel_hooks.rs','crates/ginux-init/src/network_hooks.rs'];(s.parent/'state.json').write_text(json.dumps(x,indent=2)+'\n')
