Configured storage and devices currently expose backend handle ranges. Add one bounded public descriptor table for image files, memory files, devices and anonymous pipes, with shared alias lifetime, per-slot close-on-exec flags and argument restoration. Reserve slots before create/truncate/open so exhaustion cannot mutate data.

Keep pipe bytes in supervisor memory and cover atomic writes, partial copies, EOF, SIGPIPE, blocking termination, aliases, native FD reuse, failed opens and lower inherited limits. Static checks,77 unit tests and all applicable Linux launch/storage/device/pipe/FD/native/process/setup suites pass locally, including a clean patch replay; macOS CI is pending.

This still supports one configured task. Pipe readiness, peer scheduling, process inheritance and exec-time close-on-exec need later work. Polling/clock policy is unchanged.
