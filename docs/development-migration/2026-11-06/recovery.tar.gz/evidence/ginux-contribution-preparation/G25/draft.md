Support bounded vectors and chunked writes on owned files

Add readv/writev for owned files and pipes using at most 16 iovecs and a 4 KiB
transfer bound. Process regular writes/pwrites in 4 KiB chunks up to 1 MiB,
returning committed progress and preserving positioned-write offsets. Pipe
atomicity uses the full vector length; native transfer policy is unchanged.

Local static/build checks, 89 units and selected ordinary large-file, vector,
quota, alias/offset, pipe and directory checks pass in source and clean replay.
Adversarial validation, actual package-manager acceptance, full runtime/remote
CI and prerequisite merges remain pending. Not ready to submit.
