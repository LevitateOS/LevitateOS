from pathlib import Path
import tempfile,subprocess,json,shutil,hashlib
r=Path('/tmp/ginux-contribution-preparation/G25');s=r/'source';binary=Path('/tmp/ginux-contribution-preparation/G17a/verified-head/target/x86_64-unknown-linux-gnu/release/ginux');receipts=[]
for mode,fixture,code in [('ordinary-vectors','launch-storage-fixture',181),('ordinary-large-io','launch-storage-fixture',197),('vectors','launch-pipe-fixture',91)]:
 with tempfile.TemporaryDirectory(prefix='ginux-g25-baseline-') as name:
  w=Path(name);root=w/'root';(root/'bin').mkdir(parents=True);(root/'work').mkdir();shutil.copyfile(s/'.artifacts/launch'/fixture,root/'bin/fixture');(root/'bin/fixture').chmod(0o755)
  config=(s/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/fixture"').replace('args = []','args = '+json.dumps([mode])).replace('[storage]\nassignments = []','[storage]\nassignments = ["memory:/work", "memory:/out"]')
  path=w/'config.toml';path.write_text(config);result=w/'result.json';cmd=[str(binary),'launch',str(path),str(root),'--result-file',str(result)];proc=subprocess.run(cmd,capture_output=True,timeout=20);record=json.loads(result.read_text());(r/f'baseline-{mode}.log').write_bytes(proc.stderr);assert proc.returncode==code and record['code']==code and record['outcome']=='exited',(mode,proc.returncode,record)
  receipts.append({'base':'94baebbec5e887ae659718c3f6162d08ca267b99','command':cmd,'mode':mode,'fixture':fixture,'exit_code':proc.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()});print('baseline',mode,'expected capability failure',code,flush=True)
(r/'baseline-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n')
