from pathlib import Path
import json,hashlib,shutil,subprocess
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G25');art=root/'.artifacts/ginux-contribution-preparation/G25';m=json.loads((temp/'manifest.json').read_text());assert not (docs/'g25-review.md').exists()
static=[json.loads((temp/(prefix+'static-receipt.json')).read_text()) for prefix in ['final-','clean-']]
assert all(r['exit_code']==0 and r['matched_paths']==171 and r['head']==m['head'] for r in static)
assert static[0]['binary_sha256']==static[1]['binary_sha256'] and static[0]['fixture_sha256']==static[1]['fixture_sha256']
for prefix in ['', 'clean-']:
 rs=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(rs)==3 and all(r['exit_code']==0 for r in rs)
assert [r['exit_code'] for r in json.loads((temp/'baseline-receipt.json').read_text())]==[181,197,91]
m.update(status='ordinary source/clean preparation and separate self-review retained; full G25 partial: actual APK/RPM, security, native clamping policy, full CI and upstream independence pending',unit_tests=89,vfs_tests=31,clean_matched_paths=171,review='separate whole-diff self-review; no independent or adversarial acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=static[0]['binary_sha256'],clean_binary_sha256=static[1]['binary_sha256'],fixture_sha256=static[0]['fixture_sha256'],held_dependencies=['G07 shared-argument security'],consumer_acceptance='actual APK/RPM on final combined capabilities required at F02/F03; this packet remains partial',native_policy='74835089 descriptors/fd fixture hunks excluded and held under #178/#163; no native clamp imported')
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.patch','.diff','.txt']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g25*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G25.patch')
(art/'draft.md').write_text('''Support bounded vectors and chunked writes on owned files

Add readv/writev for owned files and pipes using at most 16 iovecs and a 4 KiB
transfer bound. Process regular writes/pwrites in 4 KiB chunks up to 1 MiB,
returning committed progress and preserving positioned-write offsets. Pipe
atomicity uses the full vector length; native transfer policy is unchanged.

Local static/build checks, 89 units and selected ordinary large-file, vector,
quota, alias/offset, pipe and directory checks pass in source and clean replay.
Adversarial validation, actual package-manager acceptance, full runtime/remote
CI and prerequisite merges remain pending. Not ready to submit.
''')
assert not any(x in (art/'draft.md').read_text() for x in ['LevitateOS','Recipe','Daybreak'])
(docs/'g25-review.md').write_text(f'''# G25 — bounded owned vectors and chunked regular writes

Head `{m['head']}`, tree `{m['tree']}`, directly on G17a
`{m['base']}`. [Patch](patches/G25.patch):8 files,+253/-25.
Ordinary source preparation is retained. **The full packet remains partial**:
actual APK/RPM, security, full CI and current-main independence are pending.

Readv/writev use a single snapshot of up to16 x86-64 iovecs with checked aggregate
length bounded by isize::MAX. Existing strict process_vm copies perform scatter/
gather, reporting only the transferred prefix. Owned vectors and scalar reads
retain the4 KiB per-call limit. Regular writes/pwrites process up to1 MiB in4 KiB
scratch chunks; later errors return progress already committed. Positioned writes
restore the original shared offset, including after a partial quota result.
Pipes retain their4 KiB transfers and use the entire vector length for small-write
atomicity, nonblocking capacity checks, partial consumption and EOF.

The capability base is G17a (including G09/G05), without G17b, mappings, archives,
timestamps, locks, threads or socket channels. Existing public FD translation,
VFS quota/offset owners, strict copy and pipe ring-buffer ownership remain in
place. Core native policy, descriptors.rs, launch/task dispatch, storage backend,
VFS implementation and all other tracked paths are unchanged. The74835089 native
read clamp and its native FD fixture are held separately under #178/#163; no
consent or native-policy resolution is inferred from owned-file checks.

Separate whole-diff self-review covered all eight changed paths and their VFS
read/write/seek, shared-offset, permission/quota, public descriptor, pipe claim/
park/retry and tracee-copy callers. This is self-review, not an independent reviewer
or security acceptance.

- **Length validation correction:** reject aggregate iovec lengths above the
  signed transfer-result range as well as arithmetic overflow. Bounds follow
  the declared16-vector contract; hostile overflow/protected-buffer probes were
  not executed.
- **Verification correction:** first draft of the large-read fixture passed a
  request larger than its destination array, relying on this adapter's short
  read bound. The final fixture allocates the entire requested span, clears it
  after writing, then verifies every returned byte. Prior49988e22 is labelled
  before-buffer-fixture-fix and is not the final candidate.
- **Build correction:** removed the obsolete channel copy_memory import after
  routing through the shared vector helper. Initial failed static output remains.
- **Coverage preserved:** existing storage/pipe default runners execute the new
  cases alongside all old cases; Make/workflow already call those runners.
  Selected local modes avoid protected buffers and prior adversarial scenarios.

Final source and strict clean base-plus-patch replay pass make check test-unit
build and storage/pipe/directory fixture builds:89 units,31 VFS,171 tracked paths
byte-matched. Ginux and all three fixture hashes match. Both copies pass:

- zero/empty iovecs,16 entries, rejected17-entry request, vector-boundary short
  transfers, EOF and duplicate descriptors sharing offsets;
- complete2 MiB+37 regular-file payload written using short1 MiB calls, reread
  using short4 KiB calls and checked byte-for-byte, plus large positioned writes
  preserving duplicate offsets and content;
- regular write quota exhaustion after one committed chunk, correct size/offset
  and next-call ENOSPC, plus existing positioned/growth/bounds/quota controls;
- vector pipe atomicity at capacity, nonblocking short transfer, scatter/gather,
  duplicated writer lifetime and EOF, plus directory/cwd controls.

The same final fixtures fail on exact G17a: file vectors exit181, large write197,
pipe vectors91. Baseline receipts name the exact binary hash. The earlier plain
source logs predate the fixture correction; functional receipts and final/clean
static receipts identify final evidence. Native read clamp remains untested here.

[DaybreakBlue](daybreakblue-handoff.md) owns protected/mutable iovec and payload
validation, partial faults, overflow/authority/FD reuse and thread/park races.
No cloud dispatch occurred. Full/default Linux runtime suites, independent review,
macOS/remote CI and fresh upstream standalone extraction remain unrun. Actual
APK/RPM on the full combined capabilities and G08 socket integration belong to
F02/F03; fixtures do not substitute for package-manager acceptance. Preserve G23
SQLite/Cargo and G24 native-time policy/security holds as well.

Patch, generic draft, commands, receipts, hashes, helpers and diagnostic logs live
under .artifacts/ginux-contribution-preparation/G25/. Real Ginux branches,
checkouts/indexes/refs and remote human text remain untouched. No publication or
maintainer message before the F04 user inspection boundary.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G25');row.update(m);row.update(evidence='g25-review.md',source_patch='patches/G25.patch');p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'p04-dependencies.md';t=p.read_text();t+='''\nG25 ordinary extraction uses only G17a94baebbe (includes G09/G05) as capability
base: owned vectors and regular write chunks need no mapping/private-budget,
archive/time/lock/thread/socket owner. Exact owned candidate9afd60cc and clean
replay pass89 units and ordinary vectors/large-file/offset/quota/pipe controls.
74835089 native descriptor clamping stays held under #178/#163, with its FD
fixture hunks, rather than being hidden in this packet. G08 channel adaptation,
G07 security and actual APK/RPM closure still require F02/F03; G25 remains partial.
''';p.write_text(t)
p=docs/'daybreakblue-handoff.md';t=p.read_text();t+=f'''\n## G25 — vectors and chunked regular I/O (partial)

Exact retained ordinary head `{m['head']}` on G17a `{m['base']}`.
89 routine units and selected ordinary source/clean vectors, complete2 MiB+37
payload, offset/alias, quota-prefix and nonblocking pipe atomicity/EOF checks pass.
Native scalar clamp74835089 remains policy-held and absent; actual APK/RPM is
still F02/F03 consumer work, not established by these small fixtures.

DaybreakBlue must validate protected/mutable iovec metadata and payloads, faults
inside and between vector/chunk boundaries, short-copy/error prefix accounting,
aggregate/address overflow, read-only destinations, FD/inode authority and reused
slots, cancellation and blocked retry with changing layouts, shared-buffer/thread
races, append/offset/close ordering and failure rollback. Preserve existing full
pointer/copy tests and required CI; no adversarial probes were run here and no
cloud agent was dispatched. G07's shared-argument hold remains. Source self-review
is not security acceptance; [review/evidence](g25-review.md).
''';p.write_text(t)
p=root/'docs/ginux-contribution-task-list.md';t=p.read_text();a=t.index('Exact next task: **G25');b=t.index('\nActive skill:',a);t=t[:a]+f'''G25 owned-vector/chunk source preparation is retained at `{m['head'][:8]}` directly
on G17a{m['base'][:8]}. [Review/evidence](ginux-contributions/g25-review.md) records89
units,171-path strict replay and vectors/short transfers/alias offsets, complete
2 MiB+37 byte-checked payload, positioned writes, quota prefixes and pipe atomicity/
EOF plus existing controls passing in source/clean. Final large-read fixture
allocates its entire request. Native descriptor clamp74835089 is excluded and
policy-held under #178/#163. The full task remains partial: actual APK/RPM,
G07/security, G08 channels, full CI and upstream independence remain F02/F03 or
publication prerequisites; fixtures do not replace application acceptance.

Exact next task: **G26 — explicit inherited process resource limits**.
Inspect0c571cbb against current config validation, native child setup and existing
task lifecycle. Separate useful per-process limits from held thread/policy scope;
state virtual AS and allowed CPU subset accurately, without aggregate RSS/time
claims. Use only ordinary bounded allocation/affinity/inheritance checks locally.
Record boundary/authority/hostile exhaustion/race probes for DaybreakBlue. Preserve
all pending G23–G25/F02/F03 acceptance. No publication or maintainer messages before F04.
''' +t[b:];p.write_text(t)
print('recorded G25',m['head'])
