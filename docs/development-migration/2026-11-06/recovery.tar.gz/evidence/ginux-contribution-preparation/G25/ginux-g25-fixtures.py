from pathlib import Path
s=Path('/tmp/ginux-contribution-preparation/G25/source')
p=s/'tests/fixtures/launch-storage-fixture.c';t=p.read_text();idx=t.index('long storage_main(');t=t[:idx]+'''/* Valid, stable buffers exercise owned I/O without relying on native transfers. */
static char large_io[2*1024*1024+37];
static long ordinary_vectors(void) {
    long fd=DO(2,"/out/vectors",0102,0600); CHECK(fd>=3,180);
    word vectors[32]={0};
    CHECK(DO(20,fd,vectors,0)==0 && DO(19,fd,vectors,0)==0,181);
    vectors[0]=(word)"ab";vectors[1]=2;vectors[2]=0;vectors[3]=0;
    vectors[4]=(word)"cde";vectors[5]=3;
    CHECK(DO(20,fd,vectors,3)==5 && DO(8,fd,0,1)==5,182);
    long alias=DO(32,fd,0,0);CHECK(alias>=3 && DO(8,alias,0,0)==0,183);
    vectors[0]=(word)output;vectors[1]=1;vectors[4]=(word)(output+1);vectors[5]=8;
    CHECK(DO(19,alias,vectors,3)==5 && DO(8,fd,0,1)==5,184);
    CHECK(output[0]=='a' && output[1]=='b' && output[4]=='e' && DO(19,fd,vectors,3)==0,185);
    for(word i=0;i<16;++i) { data[i]=(char)('A'+i);vectors[2*i]=(word)(data+i);vectors[2*i+1]=1; }
    CHECK(DO(20,fd,vectors,16)==16 && DO(8,fd,5,0)==5,186);
    for(word i=0;i<16;++i) vectors[2*i]=(word)(output+i);
    CHECK(DO(19,fd,vectors,16)==16,187);
    for(word i=0;i<16;++i) CHECK(output[i]==data[i],188);
    CHECK(DO(20,fd,vectors,17)==-22 && DO(8,fd,0,1)==21,189);
    for(word i=0;i<8192;++i) data[i]=(char)(i%251);
    vectors[0]=(word)data;vectors[1]=4090;vectors[2]=(word)(data+4090);vectors[3]=4102;
    CHECK(DO(77,fd,0,0)==0 && DO(8,fd,0,0)==0 && DO(20,fd,vectors,2)==4096,190);
    CHECK(DO(5,fd,meta,0)==0 && *(word *)(meta+48)==4096 && DO(8,alias,0,1)==4096,191);
    CHECK(DO(8,fd,0,0)==0,192);
    vectors[0]=(word)output;vectors[1]=4090;vectors[2]=(word)(output+4090);vectors[3]=4102;
    CHECK(DO(19,alias,vectors,2)==4096 && DO(8,fd,0,1)==4096,193);
    for(word i=0;i<4096;++i) CHECK(output[i]==data[i],194);
    CHECK(DO(3,fd,0,0)==0 && DO(3,alias,0,0)==0,195);
    return 0;
}
static long ordinary_large_io(void) {
    const word mib=1024*1024;
    for(word i=0;i<sizeof large_io;++i) large_io[i]=(char)(i%251);
    long fd=DO(2,"/out/large-io",0102,0600);CHECK(fd>=3,196);
    CHECK(DO(1,fd,large_io,sizeof large_io)==mib && DO(8,fd,0,1)==mib,197);
    CHECK(DO(1,fd,large_io+mib,sizeof large_io-mib)==mib,198);
    CHECK(DO(1,fd,large_io+2*mib,37)==37 && DO(5,fd,meta,0)==0,199);
    CHECK(*(word *)(meta+48)==sizeof large_io && DO(8,fd,0,0)==0,200);
    word done=0;
    while(done<sizeof large_io) {
        long n=DO(0,fd,output,sizeof large_io-done);
        CHECK(n>0 && n<=4096,201);
        for(long i=0;i<n;++i) CHECK(output[i]==(char)((done+i)%251),202);
        done+=(word)n;
    }
    CHECK(DO(0,fd,output,sizeof output)==0,203);
    long alias=DO(32,fd,0,0);CHECK(alias>=3 && DO(8,fd,17,0)==17,204);
    CHECK(call(18,alias,(word)large_io,sizeof large_io,3*mib,0,0)==mib && DO(8,fd,0,1)==17,205);
    CHECK(call(17,fd,(word)output,4096,4*mib-4096,0,0)==4096 && DO(8,alias,0,1)==17,206);
    for(word i=0;i<4096;++i) CHECK(output[i]==large_io[mib-4096+i],207);
    CHECK(DO(3,fd,0,0)==0 && DO(3,alias,0,0)==0,208);
    return 0;
}
''' +t[idx:];t=t.replace('if(argc>1 && equal(argv[1],"positioned"))', 'if(argc>1 && equal(argv[1],"ordinary-vectors")) return ordinary_vectors();\n    if(argc>1 && equal(argv[1],"ordinary-large-io")) return ordinary_large_io();\n    if(argc>1 && equal(argv[1],"positioned"))');p.write_text(t)
p=s/'scripts/test-launch-storage.py';t=p.read_text().replace("'positioned', 'view-probes'", "'positioned', 'ordinary-vectors', 'ordinary-large-io', 'view-probes'");t=t.replace("        invoke([], ['no-storage'])", "        for mode in ['ordinary-vectors', 'ordinary-large-io']:\n            invoke(['memory:/work', 'memory:/work/build', 'memory:/out'], [mode])\n        invoke([], ['no-storage'])");p.write_text(t)
p=s/'tests/fixtures/launch-pipe-fixture.c';t=p.read_text();idx=t.index('long pipe_main(');t=t[:idx]+'''static long ordinary_vectors(void) {
    int pair[2];word vectors[32]={0};
    CHECK(DO(293,pair,04000,0)==0,90);
    CHECK(DO(19,pair[0],vectors,0)==0 && DO(20,pair[1],vectors,0)==0,91);
    vectors[0]=(word)"ab";vectors[1]=2;vectors[4]=(word)"cde";vectors[5]=3;
    CHECK(DO(20,pair[1],vectors,3)==5,92);
    vectors[0]=(word)buffer;vectors[1]=1;vectors[4]=(word)(buffer+1);vectors[5]=8;
    CHECK(DO(19,pair[0],vectors,3)==5 && buffer[0]=='a' && buffer[4]=='e',93);
    for(word i=0;i<16;++i) { data[i]=(char)('A'+i);vectors[2*i]=(word)(data+i);vectors[2*i+1]=1; }
    CHECK(DO(20,pair[1],vectors,16)==16 && DO(20,pair[1],vectors,17)==-22,94);
    for(word i=0;i<16;++i) vectors[2*i]=(word)(buffer+i);
    CHECK(DO(19,pair[0],vectors,16)==16,95);
    for(word i=0;i<16;++i) CHECK(buffer[i]==data[i],96);
    for(word i=0;i<65536;++i) data[i]=(char)(i%251);
    for(word i=0;i<65536-4096;i+=4096) CHECK(DO(1,pair[1],data+i,4096)==4096,97);
    CHECK(DO(1,pair[1],data,4095)==4095,98);
    vectors[0]=(word)"x";vectors[1]=1;vectors[2]=(word)"y";vectors[3]=1;
    CHECK(DO(20,pair[1],vectors,2)==-11 && DO(0,pair[0],buffer,1)==1,99);
    CHECK(DO(20,pair[1],vectors,2)==2,100);
    for(word i=0;i<65536;i+=4096) CHECK(DO(0,pair[0],buffer,4096)==4096,101);
    vectors[0]=(word)data;vectors[1]=4090;vectors[2]=(word)(data+4090);vectors[3]=4102;
    CHECK(DO(20,pair[1],vectors,2)==4096,102);
    vectors[0]=(word)buffer;vectors[1]=4090;vectors[2]=(word)(buffer+4090);vectors[3]=4102;
    CHECK(DO(19,pair[0],vectors,2)==4096,103);
    for(word i=0;i<4096;++i) CHECK(buffer[i]==data[i],104);
    CHECK(DO(0,pair[0],buffer,1)==-11,105);
    long alias=DO(32,pair[1],0,0);CHECK(alias>=3 && DO(3,pair[1],0,0)==0,106);
    vectors[0]=(word)"bye";vectors[1]=3;
    CHECK(DO(20,alias,vectors,1)==3 && DO(3,alias,0,0)==0,107);
    vectors[0]=(word)buffer;vectors[1]=16;
    CHECK(DO(19,pair[0],vectors,1)==3 && buffer[0]=='b' && buffer[2]=='e',108);
    CHECK(DO(19,pair[0],vectors,1)==0 && DO(3,pair[0],0,0)==0,109);
    DO(1,1,"owned-pipes: PASS\\n",18);
    return 0;
}
''' +t[idx:];t=t.replace('    int pair[2];\n    if (argc', '    int pair[2];\n    if (argc>1 && argv[1][0]==\'v\') return ordinary_vectors();\n    if (argc',1);p.write_text(t)
p=s/'scripts/test-launch-pipes.py';t=p.read_text().replace('if len(sys.argv) != 3','if len(sys.argv) < 3').replace("for p in sys.argv[1:]]", "for p in sys.argv[1:3]]");t=t.replace('        invoke()\n        invoke(assigned=True)', '''        if sys.argv[3:]:
            if sys.argv[3:] != ['ordinary-vectors']:
                sys.exit('unknown selected pipe scenario')
            invoke(['vectors'])
            print('PASS launch pipes: ordinary vectors')
            return
        invoke(['vectors'])
        invoke()
        invoke(assigned=True)''');p.write_text(t)
print('ordinary vector/large I/O fixtures added to existing runners and default CI paths')
