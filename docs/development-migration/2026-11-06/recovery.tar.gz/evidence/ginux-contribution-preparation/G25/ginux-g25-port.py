from pathlib import Path
import subprocess
s=Path('/tmp/ginux-contribution-preparation/G25/source');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a]).decode()
p=s/'crates/ginux-init/src/tracee_io.rs';t=p.read_text();donor=git('show','88fa4749:crates/ginux-init/src/tracee_io.rs');addition=donor[donor.index('/// Bounded scatter/gather'):];addition=addition.replace('output.length = output.length.checked_add(length).ok_or(-22)?;', 'output.length = output.length.checked_add(length).ok_or(-22)?;\n            if output.length > isize::MAX as usize {\n                return Err(-22);\n            }');p.write_text(t+'\n'+addition)
p=s/'crates/ginux-init/src/fs_hooks.rs';t=p.read_text();t=t.replace('1 => self.write(pid, fd, r.rsi, r.rdx, None),','1 => self.write(pid, fd, r.rsi, r.rdx, None),\n            19 | 20 => self.vector_io(pid, fd, r),');donor=git('show','7d556b4e:crates/ginux-init/src/fs_hooks.rs');a=donor.index('    fn vector_io(');b=donor.index('    fn getdents(',a);t=t[:t.index('    fn write(')]+donor[a:b]+t[t.index('    fn getdents('):];p.write_text(t)
p=s/'crates/ginux-init/src/channel_hooks.rs';t=p.read_text().replace('if matches!(r.orig_rax, 0 | 1) {','if matches!(r.orig_rax, 0 | 1 | 19 | 20) {');t=t.replace('let writing = r.orig_rax == 1;', '''let writing = matches!(r.orig_rax, 1 | 20);
        let vectors = if matches!(r.orig_rax, 19 | 20) {
            crate::tracee_io::IoVectors::read(pid, r.rsi, r.rdx)?
        } else {
            crate::tracee_io::IoVectors::single(r.rsi, r.rdx)
        };
        let requested = vectors.length;''').replace('if r.rdx == 0 {','if requested == 0 {').replace('let atomic = r.rdx <= IO_SIZE as u64;','let atomic = requested <= IO_SIZE;').replace('available < r.rdx as usize','available < requested').replace('r.rdx.min(IO_SIZE as u64).min(available as u64) as usize','requested.min(IO_SIZE).min(available)').replace('r.rdx.min(IO_SIZE as u64).min(p.len as u64) as usize','requested.min(IO_SIZE).min(p.len)').replace('copy_memory(pid, r.rsi, &mut buffer[..count], false)? as usize','vectors.copy(pid, &mut buffer[..count], false)?').replace('copy_memory(pid, r.rsi, &mut buffer[..count], true)? as usize','vectors.copy(pid, &mut buffer[..count], true)?');p.write_text(t)
p=s/'README.md';t=p.read_text();old='storage adapter, not a complete unified image/overlay filesystem. IO is bounded\nto 4096 bytes per call.';assert old in t;t=t.replace(old,'''storage adapter, not a complete unified image/overlay filesystem. Regular writes
and pwrites process at most 1 MiB per call in 4 KiB scratch chunks, returning
only committed bytes after a short transfer or error. Reads and readv/writev
remain bounded to 4096 bytes per call; callers must handle short transfers.
Owned files and pipes accept at most 16 iovecs, including empty entries, with a
combined length no greater than the signed transfer-result range. Pipe writes
use the combined vector length for atomicity and retain their existing bounds.
Native image/console transfer policy is unchanged.''');p.write_text(t)
print('owned file/vector/chunk and pipe changes ported; native descriptors unchanged')
