from pathlib import Path
import subprocess,json,sys
root=Path('/tmp/ginux-contribution-preparation/G25');src=root/(sys.argv[1] if len(sys.argv)>1 else 'source');prefix='clean-' if src.name!='source' else ''
commands=[['sudo','-n','python3','scripts/test-launch-storage.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-storage-fixture','ordinary-vectors','ordinary-large-io','positioned','growth','bounds','quota'],['sudo','-n','python3','scripts/test-launch-pipes.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-pipe-fixture','ordinary-vectors'],['sudo','-n','python3','scripts/test-launch-directories.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-directory-fixture','functional','cwd']]
receipts=[]
for i,cmd in enumerate(commands):
 with (root/f'{prefix}functional-{i}.log').open('w') as log:r=subprocess.run(cmd,cwd=src,stdout=log,stderr=subprocess.STDOUT)
 receipts.append({'command':cmd,'exit_code':r.returncode});(root/f'{prefix}functional-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n');print(prefix+'functional',i,r.returncode,flush=True);assert r.returncode==0
