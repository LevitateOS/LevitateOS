from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G25');src=root/'source';base=json.loads((root/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['README.md','crates/ginux-init/src/channel_hooks.rs','crates/ginux-init/src/fs_hooks.rs','crates/ginux-init/src/tracee_io.rs','scripts/test-launch-storage.py','scripts/test-launch-pipes.py','tests/fixtures/launch-storage-fixture.c','tests/fixtures/launch-pipe-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g25-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(src/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',base,input=('feat(init): support bounded owned vectors and chunked writes\n\nUse one bounded iovec snapshot for owned files and pipes, retaining pipe\natomicity and strict tracee copies. Process regular writes and pwrites in\n4 KiB scratch chunks up to 1 MiB and report only committed progress.\nKeep native transfer policy unchanged.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert not any(x in patch for x in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in git('ls-tree','-r','--name-only',base).decode().splitlines():
 if name in files:continue
 p=src/name
 expected=git('show',base+':'+name)
 actual=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
 assert actual==expected,name
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G25','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':['G17a'],'standalone':False,'status':'ordinary source checks pass; final self-review/clean replay pending; security/application/native policy/full CI held','patch_sha256':hashlib.sha256(patch).hexdigest(),'deferred_joins':['G08 sockets/G07 threads','actual APK/RPM at F02/F03'],'held_source':['74835089 native scalar clamping under #178/#163']};(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
