Retain explicit inode timestamps and archive mtime

Keep access/modified times with owned inode identity, project them through
stat/statx and support utimensat/futimens updates. Preserve whole-second USTAR
mtime across restore and verify matching hardlink metadata. Runtime nanoseconds
and access time are explicitly not persisted; reads/writes do not set them.

Local build/static checks and 100 units pass in source and clean replay, as do
ordinary explicit/OMIT/NOW/null-times, aliases, descriptor updates, contained symlink
metadata and archive restart/scale/large-payload checks. Native realtime
policy, adversarial validation and full runtime/remote CI remain pending.
Not ready to submit.
