from pathlib import Path
r=Path('/tmp/ginux-contribution-preparation/G24/source')
p=r/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();at=s.index('long storage_main(');s=s[:at]+'''static long timestamp_data(int ordinary) {
    long fd=DO(2,"/work/time",0102,0600); CHECK(fd==3,70);
    CHECK(DO(86,"/work/time","/work/time-alias",0)==0 && DO(88,"time","/work/time-link",0)==0,71);
    long times[4]={11,123,123456789,987654321};
    CHECK(call(280,fd,0,(word)times,0,0,0)==0 && DO(5,fd,meta,0)==0,72);
    CHECK(*(long *)(meta+72)==11 && *(long *)(meta+80)==123 && *(long *)(meta+88)==123456789 && *(long *)(meta+96)==987654321,73);
    CHECK(DO(4,"/work/time-alias",meta,0)==0 && *(long *)(meta+88)==123456789,74);
    CHECK(call(332,-100,(word)"/work/time",0,0x7ff,(word)meta,0)==0 && *(long *)(meta+112)==123456789 && *(unsigned *)(meta+120)==987654321,75);
    times[0]=99; times[1]=1073741822; times[3]=555;
    CHECK(call(280,fd,0,(word)times,0,0,0)==0 && DO(5,fd,meta,0)==0 && *(long *)(meta+72)==11 && *(long *)(meta+80)==123 && *(long *)(meta+96)==555,76);
    if(!ordinary) {
        times[3]=1000000000;
        CHECK(call(280,fd,0,(word)times,0,0,0)==-22 && call(280,fd,0,1,0,0,0)==-14,77);
        times[3]=1073741823;
        CHECK(call(280,fd,0,(word)times,0,0,0)==0 && DO(5,fd,meta,0)==0 && *(long *)(meta+72)==11 && *(long *)(meta+88)>1000000000,78);
    }
    times[0]=11; times[1]=123; times[2]=123456789; times[3]=987654321;
    CHECK(call(280,-100,(word)"/work/time-alias",(word)times,0,0,0)==0,79);
    times[2]=222; times[3]=333;
    CHECK(call(280,-100,(word)"/work/time-link",(word)times,0x100,0,0)==0,80);
    CHECK(DO(6,"/work/time-link",meta,0)==0 && *(long *)(meta+88)==222 && DO(5,fd,meta,0)==0 && *(long *)(meta+88)==123456789,81);
    CHECK(DO(87,"/work/time",0,0)==0,82);
    times[0]=13; times[1]=456; times[2]=123456789; times[3]=987654321;
    CHECK(call(280,fd,0,(word)times,0,0,0)==0 && DO(4,"/work/time-alias",meta,0)==0 && *(long *)(meta+72)==13,83);
    CHECK(DO(3,fd,0,0)==0,84); return 0;
}
'''+s[at:];needle='    char **argv = (char **)(stack + 1);';s=s.replace(needle,needle+'''
    if(argc>1 && equal(argv[1],"timestamps")) return timestamp_data(0);
    if(argc>1 && equal(argv[1],"ordinary-times")) return timestamp_data(1);''',1)
needle='''        CHECK(DO(86,"/out/temporary","/out/surviving",0)==0 && DO(87,"/out/temporary",0,0)==0,237);''';assert needle in s;s=s.replace(needle,needle+'''
        long times[4]={11,123,123456789,987654321};
        CHECK(call(280,-100,(word)"/out/product",(word)times,0,0,0)==0,85);
        times[2]=222; times[3]=333;
        CHECK(call(280,-100,(word)"/out/product-link",(word)times,0x100,0,0)==0,86);''',1)
s=s.replace('''        long status=restore_data(0); CHECK(status==0,status);''','''        CHECK(DO(4,"/out/product",meta,0)==0 && *(long *)(meta+72)==0 && *(long *)(meta+88)==123456789 && *(long *)(meta+96)==0,87);
        CHECK(DO(6,"/out/product-link",meta,0)==0 && *(long *)(meta+88)==222 && *(long *)(meta+96)==0,88);
        long status=restore_data(0); CHECK(status==0,status);''',1);p.write_text(s)
p=r/'scripts/test-launch-storage.py';s=p.read_text();needle='''                        assert 'out/deleted' not in names''';assert needle in s;s=s.replace(needle,'''                        if args in (['timestamps'], ['ordinary-times']):
                            assert tar.getmember('work/time-alias').mtime == 123456789
                            assert tar.getmember('work/time-link').mtime == 222
                            return
'''+needle,1).replace("'quota', 'namespace'","'quota', 'timestamps', 'ordinary-times', 'namespace'",1).replace("'child-export', 'invalid-export-config'))","'child-export', 'invalid-export-config', 'timestamps', 'ordinary-times'))",1)
s=s.replace("        invoke(['memory:/work', 'memory:/out'], ['symlinks'])", "        invoke(['memory:/work', 'memory:/out'], ['timestamps'], export=True)\n        invoke(['memory:/work', 'memory:/out'], ['symlinks'])",1);compile(s,str(p),'exec');p.write_text(s)
p=r/'scripts/test-launch-restore.py';s=p.read_text().replace("            assert tar.getmember('out/product-alias').linkname == 'out/product'", "            assert tar.getmember('out/product-alias').linkname == 'out/product'\n            assert tar.getmember('out/product').mtime == 123456789\n            assert tar.getmember('out/product-alias').mtime == 123456789\n            assert tar.getmember('out/product-link').mtime == 222",1)
s=s.replace("('hardlink-mode', 'out/source', tarfile.REGTYPE, 0o700)):","('hardlink-mode', 'out/source', tarfile.REGTYPE, 0o700),\n                    ('hardlink-mtime', 'out/source', tarfile.REGTYPE, None)):",1).replace("                    entry.type, entry.linkname, entry.mode = tarfile.LNKTYPE, target, extra or 0o600", "                    entry.type, entry.linkname, entry.mode = tarfile.LNKTYPE, target, extra or 0o600\n                    if name == 'hardlink-mtime': entry.mtime = 1",1);compile(s,str(p),'exec');p.write_text(s)
print('G24 ordinary explicit/OMIT/alias/FD times and whole-second linked archive restart; full negative/NOW defaults retained')
