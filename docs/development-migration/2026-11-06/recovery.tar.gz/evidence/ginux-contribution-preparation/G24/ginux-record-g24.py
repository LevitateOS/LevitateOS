from pathlib import Path
import json,hashlib,shutil
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G24');art=root/'.artifacts/ginux-contribution-preparation/G24';m=json.loads((temp/'manifest.json').read_text())
for prefix in ['', 'clean-']:
    rs=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(rs)==4 and all(r['exit_code']==0 for r in rs)
static=[json.loads((temp/(prefix+'static-receipt.json')).read_text()) for prefix in ['final-','clean-']]
assert all(r['exit_code']==0 and r['matched_paths']==181 and r['head']==m['head'] for r in static)
assert static[0]['binary_sha256']==static[1]['binary_sha256']
fixtures={}
for name in ['launch-storage-fixture','launch-directory-fixture','launch-script-fixture','launch-owned-exec-fixture','launch-fd-fixture']:
    a=(temp/'source/.artifacts/launch'/name).read_bytes();b=(temp/'verified-head/.artifacts/launch'/name).read_bytes();assert a==b;fixtures[name]=hashlib.sha256(a).hexdigest()
m.update(status='source separately self-reviewed; selected ordinary source-clean checks including NOW pass; security/policy/full CI/upstream independence pending',unit_tests=100,vfs_tests=41,clean_matched_paths=181,review='separate self-review; no independent reviewer/security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',held_dependencies=['G07 shared-argument security'],policy_disposition='UTIME_NOW reads native supervisor realtime; recorded #179 policy needs refresh/disposition before publication; no core clock rule changed',unrun_clock_modes=[],native_now_validation='ordinary UTIME_NOW and null-times use current realtime; null-times sets both fields from one capture; clock-boundary/failure injection remains unrun',deferred_owner_hunks=[{'source':'d21d26c879ad53b96652b2f9677c928e7ac2183c','path':'crates/ginux-init/src/network_hooks.rs','owner':'G29','reason':'network stat encoder does not exist in this candidate; initialize new timestamp fields when introduced'}],source_binary_sha256=static[0]['binary_sha256'],clean_binary_sha256=static[1]['binary_sha256'],fixture_sha256=fixtures)
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
    if p.is_file() and p.suffix in ['.json','.log','.patch','.diff','.txt']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g24*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G24.patch')
(art/'draft.md').write_text('''Retain explicit inode timestamps and archive mtime

Keep access/modified times with owned inode identity, project them through
stat/statx and support utimensat/futimens updates. Preserve whole-second USTAR
mtime across restore and verify matching hardlink metadata. Runtime nanoseconds
and access time are explicitly not persisted; reads/writes do not set them.

Local build/static checks and 100 units pass in source and clean replay, as do
ordinary explicit/OMIT/NOW/null-times, aliases, descriptor updates, contained symlink
metadata and archive restart/scale/large-payload checks. Native realtime
policy, adversarial validation and full runtime/remote CI remain pending.
Not ready to submit.
''')
assert not any(s in (art/'draft.md').read_text() for s in ['LevitateOS','Recipe','Daybreak'])
(docs/'g24-review.md').write_text(f'''# G24 — inode timestamps and archive mtime

Head `{m['head']}`, tree `{m['tree']}`, on G22
`{m['base']}` (includes G15 inode identity). [Patch](patches/G24.patch):12 files,
+261/-8. Source/ordinary preparation is retained; clock policy/security,
full CI and refreshed upstream independence remain pending.

Access/modified timestamps live with the canonical owned inode, shared across
hardlink names and retained descriptors. New owned objects and VFS index metadata
start at zero. Explicit setters validate both nanosecond values before mutation;
reads/writes do not automatically update timestamps. Existing stat/statx encoders
project the fields at their x86-64 ABI offsets, with zero values for current
pipe/device metadata. The existing VFS component walker and assignment owner are
reused. Core syscall policy, configuration/index format, process ownership and
backing code are unchanged.

Archive export encodes representable nonnegative whole-second mtime; import
restores it with zero nanoseconds and checks a hardlink's mtime agrees with its
prior regular entry. Atime/runtime nanoseconds are intentionally not persisted.
Existing private staging, no-overwrite publication and failed-startup cleanup
remain. UTIME_NOW/implicit NOW uses supervisor CLOCK_REALTIME; this is documented,
not advertised as virtual time or upstream policy consent. It does not enable
workload clock syscalls. Ordinary NOW/null-times checks pass; policy disposition
remains pending.

Separate final self-review read the entire diff and current alias/object/FD
lifetime, stat serializers, shared path/device dispatch, public descriptor
translation, creation/reset, dynamic metadata charging, archive timestamp fields,
matching alias import and failure/teardown callers. This is self-review, not
independent or adversarial review.

- **High, reproduced valid-call failure fixed:** the initial adapter returned
  EFAULT for a valid futimens descriptor/null-path call. Device dispatch consults
  shared request_path before filesystem dispatch, which tried to read that null
  pathname. The shared resolver now returns no path for this descriptor form;
  existing descriptor translation and filesystem FD validation still own it.
  The same ordinary fixture passes. Earlier failure logs remain labelled before
  the null-path correction; exact G22 separately returns unsupported and exits72.
- **Current owner adaptation:** legacy patch rejects are reconciled with current
  metadata constructors and descriptor transactions. No old lexical normalizer,
  G23 lock owner, G20 control or held thread/poll policy is imported. The donor
  network Stat initialization is explicitly assigned to G29, where that absent
  backend will be introduced.
- **Contract limits:** only existing owned objects support these setters. Public
  nanosecond values are retained at runtime; USTAR persistence remains seconds
  only. Negative/unrepresentable export times fail rather than silently changing.
  Clock-boundary/failure behavior and invalid fields/authority/races remain unverified.
- **Coverage:** existing storage and restore targets/CI invocations include the
  new cases. Full invalid-pointer and mismatched-hardlink-mtime fixtures are
  retained in default runs. Local ordinary selection excludes those cases.

Final source and strict clean prerequisite-plus-patch replay pass make check
test-unit build and storage/directory/script/owned-exec/FD fixture builds:
100 units,41 VFS,181 matching tracked paths. Ginux and all five fixture binaries
match. Ordinary checks in both copies cover explicit nanoseconds, stat/statx,
UTIME_OMIT preserving one field, ordinary UTIME_NOW and null-times single-capture
updates, path and descriptor setters, alias and retained
FD updates after removing the original name, and a valid no-follow update to a
contained owned symlink. Linked archive restart preserves mtime seconds, resets
nanoseconds/atime as documented, and retains shared identity after mutation.
Existing5,000-file and complete2 GiB+1 archive checks with streaming payload digest,
seven flush/export/config, two mapping, ordinary symlink, six ELF,14 script and
growth/bounds/quota controls also pass.

Clock-boundary/failure cases, invalid flags/fields, protected or mutable time structs,
no-follow/assignment bypass, timestamp overflow/export failures, conflicting
alias metadata and races remain with [DaybreakBlue](daybreakblue-handoff.md).
No such probes or cloud dispatch occurred. Independent review, full/default Linux
suite, macOS/remote CI, current native-realtime policy resolution and fresh-main standalone
acceptance are unrun. G20/G23/remaining filesystem interaction and actual consumer
closure remain F02/F03; G23's SQLite/Cargo acceptance is still partial.

Patch, generic draft, commands, receipts, hashes, helpers and failure/reject logs
are retained under .artifacts/ginux-contribution-preparation/G24/. No real Ginux
branch, checkout/index/ref, remote human text or maintainer message changed.
Publication remains stopped at the F04 user inspection boundary.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G24');row.update(m);row.update(evidence='g24-review.md',source_patch='patches/G24.patch');p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'p04-dependencies.md';s=p.read_text().replace('Metadata follows inode identity; export and restore must agree. Seconds-only persistence must be stated.','Metadata follows inode identity; export and restore must agree. Seconds-only persistence and explicit-only updates must be stated. UTIME_NOW reads native supervisor realtime; its recorded #179 policy disposition and clock-boundary validation remain pending. The later network Stat initializer belongs with G29.');s=s.replace('clock-mode validation', 'clock-boundary validation');p.write_text(s)
p=docs/'daybreakblue-handoff.md';prior=p.read_text().replace('G24 exact retained revision: 2dbbcb02731350c6b12a4225829f5d012845f85c','G24 initial retained revision before ordinary NOW coverage: 2dbbcb02731350c6b12a4225829f5d012845f85c');prior=prior.replace('its ordinary clock/implicit-time\ncoverage and #179 policy disposition remain separate from explicit-time proof.', 'ordinary NOW/implicit-time calls now have functional coverage. #179 policy\nand clock-boundary/failure validation remain pending.');p.write_text(prior+f'''\nG24 exact retained revision: {m['head']} on G22 {m['base']}.
100 routine units and selected ordinary explicit/OMIT, alias/descriptor/stat,
contained symlink metadata and whole-second archive restart plus existing
large/scale/storage/exec controls pass in source/clean. A valid futimens null-path
adapter failure was reproduced and corrected in the shared resolver. Ordinary
NOW/null-times checks also pass. Clock-boundary/failure and invalid/protected/
mutable inputs, authority/races, unrepresentable archive times
and conflicting alias timestamps remain unrun. No cloud dispatch or security
acceptance; [review/evidence](g24-review.md).\n''')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text();a=s.index('G24 explicit-time source/ordinary preparation');b=s.index('\nActive skill:',a)
s=s[:a]+f'''G24 explicit-time source/ordinary preparation is retained at `{m['head'][:8]}` on
G22{m['base'][:8]}. [Review/evidence](ginux-contributions/g24-review.md) records100
units,181-path strict replay, nanosecond/stat/statx/OMIT and alias/descriptor
updates, contained symlink metadata, whole-second archive restart and existing
large/scale/storage/exec controls passing in source/clean. A valid futimens
null-path adapter failure is fixed at the shared path owner. Atime/nanoseconds
are not persisted and IO does not update times implicitly. Ordinary NOW/null-times
calls also pass; native-realtime/#179 policy, security/full CI and upstream independence remain pending; no consent is inferred.
The absent network Stat field join is assigned to G29. G23's actual application/
thread closure remains pending for F02/F03; nothing was published.

Exact next task: **G25 — vectored and chunked regular I/O**.
Inspect88fa4749/7d556b4e/74835089 against current public descriptor, tracee-copy and
owned regular-file/channel owners. Separate useful owned vector/chunk handling
from native scalar clamping policy held by #178/#163; do not import that policy
or treat pipe semantics as regular-file behavior. Include ordinary real vectors,
short transfers/offsets and large regular I/O, then actual APK/RPM consumer paths
when their dependencies permit. Record protected/mutable iovecs/buffers, partial
faults, authority and races for DaybreakBlue. Preserve all pending G23/G24/F02/F03
requirements. No publication or maintainer messages before F04.
''' +s[b:];p.write_text(s);print('retained',m['head'])
