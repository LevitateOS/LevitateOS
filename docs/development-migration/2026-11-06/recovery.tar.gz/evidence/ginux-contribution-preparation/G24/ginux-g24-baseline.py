from pathlib import Path
import tempfile,subprocess,json,shutil
r=Path('/tmp/ginux-contribution-preparation/G24');s=r/'source';binary='/tmp/ginux-contribution-preparation/G22/verified-head/target/x86_64-unknown-linux-gnu/release/ginux'
with tempfile.TemporaryDirectory(prefix='ginux-time-baseline-') as name:
    w=Path(name);root=w/'root';(root/'bin').mkdir(parents=True);(root/'work').mkdir();shutil.copyfile(s/'.artifacts/launch/launch-storage-fixture',root/'bin/fixture');(root/'bin/fixture').chmod(0o755)
    config=(s/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/fixture"').replace('args = []','args = ["ordinary-times"]').replace('[storage]\nassignments = []','[storage]\nassignments = ["memory:/work"]')
    p=w/'config.toml';p.write_text(config);result=w/'result.json';archive=w/'export.tar';cmd=[binary,'launch',str(p),str(root),'--result-file',str(result),'--export-file',str(archive)]
    proc=subprocess.run(cmd,capture_output=True,timeout=10);(r/'baseline-times.log').write_bytes(proc.stderr);record=json.loads(result.read_text())
    assert proc.returncode==72 and record['code']==72 and record['outcome']=='exited',proc.stderr.decode()
    assert not archive.exists() and not list(w.glob('.ginux-export-*'))
    (r/'baseline-receipt.json').write_text(json.dumps({'base':'7b2adc4f75acca26f2b356fbf9a47a9644c39bc8','command':cmd,'exit_code':proc.returncode,'behavior':'valid explicit descriptor timestamp unsupported; workload exits72 and no archive publishes'},indent=2)+'\n')
print('exact G22 prerequisite fails valid explicit-time fixture')
