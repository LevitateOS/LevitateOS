from pathlib import Path
import subprocess
r=Path('/tmp/ginux-contribution-preparation/G24');s=r/'source';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def get(n):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'show','d21d26c8:'+n]).decode()
n='crates/ginux-vfs/src/lib.rs';p=s/n;t=p.read_text();d=get(n);a=d.index('/// Explicit domain inode timestamps');b=d.index('/// Metadata from',a);t=t.replace('/// Image/overlay metadata',d[a:b]+'/// Image/overlay metadata',1).replace('pub struct FileMetadata {','pub struct FileMetadata {\n    pub accessed: Timestamp,\n    pub modified: Timestamp,',1)
t=t.replace('''        Ok(FileMetadata {
            links: 1,''','''        Ok(FileMetadata {
            accessed: Timestamp::ZERO,
            modified: Timestamp::ZERO,
            links: 1,''',1).replace('''            Ok(FileMetadata {
                links: self.link_count(state.object),''','''            Ok(FileMetadata {
                accessed: file.accessed,
                modified: file.modified,
                links: self.link_count(state.object),''',1).replace('''            Ok(FileMetadata {
                links: 1,''','''            Ok(FileMetadata {
                accessed: Timestamp::ZERO,
                modified: Timestamp::ZERO,
                links: 1,''',1)
a=d.index('    pub fn set_times(');b=d.index('    pub fn fchmod(',a);t=t.replace('    pub fn fchmod(',d[a:b]+'    pub fn fchmod(',1);p.write_text(t)
n='crates/ginux-init/src/channel_hooks.rs';p=s/n;t=p.read_text().replace('''            Stat {
''','''            Stat {
                accessed: ginux_vfs::Timestamp::ZERO,
                modified: ginux_vfs::Timestamp::ZERO,
''',1);p.write_text(t)
n='crates/ginux-init/src/fs_hooks.rs';p=s/n;t=p.read_text().replace('    pub hardlink: bool,','    pub hardlink: bool,\n    pub modified: u64,',1).replace('''            hardlink,
        } = entry;''','''            hardlink,
            modified,
        } = entry;''',1).replace('''                || metadata.mode != mode
''','''                || metadata.mode != mode
                || metadata.modified.seconds != modified as i64
''',1)
t=t.replace('''        // Track exact names rather than canonical inodes, since aliases share data.''','''        self.fs.set_times(path, false, None, Some(ginux_vfs::Timestamp {
            seconds: modified as i64, nanoseconds: 0,
        })).map_err(|_| b"restore timestamp failed".as_slice())?;
        // Track exact names rather than canonical inodes, since aliases share data.''',1)
t=t.replace('''            262 => (1, r.rsi, r.rdi, r.r10 & 0x100 == 0, false),''','''            262 | 280 => (1, r.rsi, r.rdi, r.r10 & 0x100 == 0, false),''',1)
needle='''        let fd = r.rdi as i32;
        if matches!(''';assert needle in t;t=t.replace(needle,'''        let fd = r.rdi as i32;
        if r.orig_rax == 280 && r.rsi == 0 {
            return Some(if (FD_BASE as i32..FD_BASE as i32 + 64).contains(&fd) {
                self.descriptor_call(pid, r, fd - FD_BASE as i32 + 3)
            } else { -9 });
        }
        if matches!(''',1)
t=t.replace('''            4 | 6 => self.stat(pid, path.as_bytes(), r.rsi, false),''','''            4 | 6 => self.stat(pid, path.as_bytes(), r.rsi, false),
            280 => self.timestamps(pid, r).and_then(|times| {
                self.fs.set_times(path.as_bytes(), false, times[0], times[1]).map(|_| 0).map_err(errno)
            }),''',1)
needle='''            72 => self''';assert needle in t;t=t.replace(needle,'''            280 if r.r10 == 0 => self.timestamps(pid, r).and_then(|times| {
                self.fs.fset_times(fd, times[0], times[1]).map(|_| 0).map_err(errno)
            }),
            280 => Err(-22),
'''+needle,1)
d=get(n);a=d.index('    fn timestamps(');b=d.index('    fn flock(',a);t=t.replace('    fn read(',d[a:b]+'    fn read(',1).replace('''        crate::tracee_io::Stat {
''','''        crate::tracee_io::Stat {
            accessed: metadata.accessed,
            modified: metadata.modified,
''',1);p.write_text(t)
n='crates/ginux-init/src/descriptors.rs';p=s/n;t=p.read_text().replace('''            72 => {
''','''            280 if r.rsi == 0 => {
                self.save(r);
                self.get(r.rdi).and_then(|d| self.descriptor(pid, r, d, backends))
            }
            72 => {
''',1).replace('258 | 262 | 263 | 267 | 268 | 269 | 332 | 439','258 | 262 | 263 | 267 | 268 | 269 | 280 | 332 | 439',1);p.write_text(t)
for name in ['crates/ginux-init/src/channel_hooks.rs.rej','crates/ginux-vfs/src/lib.rs.rej']:
 p=s/name; (r/(p.name+'.txt')).write_bytes(p.read_bytes());p.unlink()
p=s/'README.md';t=p.read_text();t+='''
Owned inode access and modification timestamps can be set explicitly through
`utimensat` and descriptor `futimens`, including no-follow, nanoseconds and
`UTIME_OMIT`/`UTIME_NOW`. Aliases share times; stat/statx return them. New objects
and image metadata start at zero; reads/writes do not update times automatically.
`UTIME_NOW` uses the supervisor's native realtime clock, without allowing new
workload clock syscalls. These operations require existing owned objects.
Archives retain only whole-second nonnegative USTAR mtime. Access time and runtime
nanoseconds are not persisted; unrepresentable mtimes fail export explicitly.
''';p.write_text(t)
print('G24 timestamp, current descriptor/path and archive owners ported; no locks/network policy imported')
