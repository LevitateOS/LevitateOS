from pathlib import Path
import subprocess,tarfile,io,json
r=Path('/tmp/ginux-contribution-preparation/G24');r.mkdir(exist_ok=True);s=r/'source';assert not s.exists();s.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='7b2adc4f75acca26f2b356fbf9a47a9644c39bc8'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(s,filter='data')
(r/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G22 metadata/link/archive owner (includes G15)'],'source':['d21d26c879ad53b96652b2f9677c928e7ac2183c'],'held_joins':['G02/#179 native realtime policy at UTIME_NOW; no consent inferred','G07 shared-argument security','G20 checkpoint and G23 locks at F02'],'excluded':['network stat encoder until G28/G29 exists','public clock/sleep/poll policy','unrelated G23/thread ownership']},indent=2)+'\n')
files=['crates/ginux-vfs/src/lib.rs','crates/ginux-init/src/tracee_io.rs','crates/ginux-init/src/channel_hooks.rs','crates/ginux-init/src/device_hooks.rs','crates/ginux-init/src/storage_export.rs','crates/ginux-init/src/storage_restore.rs']
patch=git('diff','d21d26c8^','d21d26c8','--',*files);(r/'donor-initial.patch').write_bytes(patch)
p=subprocess.run(['git','apply','--reject',str(r/'donor-initial.patch')],cwd=s,capture_output=True);(r/'initial-apply.log').write_bytes(p.stdout+p.stderr);print('donor field/encoder/archive apply exit',p.returncode);print(p.stderr.decode())
