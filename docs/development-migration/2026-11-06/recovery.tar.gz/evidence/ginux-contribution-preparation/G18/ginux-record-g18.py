from pathlib import Path
import json,shutil,hashlib
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G18');art=root/'.artifacts/ginux-contribution-preparation/G18'
m=json.loads((temp/'manifest.json').read_text());m.update(status='source separately self-reviewed; static/unit/build and selected ordinary scale/runtime pass in source/clean replay; security/full CI/current-main independence pending',unit_tests=91,vfs_tests=32,clean_matched_paths=171,review='separate self-review; no independent reviewer/security acceptance claimed',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=json.loads((temp/'final-static-receipt.json').read_text())['binary_sha256'],clean_binary_sha256=json.loads((temp/'clean-static-receipt.json').read_text())['binary_sha256'],final_clean_export='verified-head',default_max_objects=32,scale_nonempty_files=5000,scale_configured_objects=5003)
assert m['source_binary_sha256']==m['clean_binary_sha256'];fixtures={}
for name in ['launch-directory-fixture','launch-storage-fixture']:
 a=(temp/'source/.artifacts/launch'/name).read_bytes();b=(temp/'verified-head/.artifacts/launch'/name).read_bytes();assert a==b,name;fixtures[name]=hashlib.sha256(a).hexdigest()
m['fixture_sha256']=fixtures
for prefix in ['', 'clean-']:
 rs=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(rs)==2 and all(r['exit_code']==0 for r in rs)
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.patch','.diff']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g18*.py'):shutil.copyfile(p,art/p.name)
shutil.copytree(temp/'baseline-harness',art/'baseline-harness',dirs_exist_ok=True)
(art/'draft.md').write_text('''Configure bounded owned namespace and data capacity

Add storage.max_objects and optional positive storage.max_bytes. Keep the current
32-object default and inline VFS constructors. Runtime namespace/backing metadata
use bounded supervisor allocations, charged before data against memory_mib.

Local validation:91 units and a5000 nonempty-file scenario with readback, exhaustion
and final-close slot reclamation pass in source and clean replay, alongside
storage/directory controls. Security/full runtime coverage, remote CI, combined
feature validation and prerequisite merges remain pending; not ready to submit.
''');assert not any(s in (art/'draft.md').read_text() for s in ['LevitateOS','Recipe','Daybreak'])
shutil.copyfile(temp/'candidate.patch',docs/'patches/G18.patch')
(docs/'g18-review.md').write_text(f'''# G18 — configurable bounded namespace; security acceptance pending

Head `{m['head']}`, tree `{m['tree']}`, sole local prerequisite
G09d `{m['base']}`. [Retained patch](patches/G18.patch). Seven files,+324/-37.
Source/ordinary preparation is retained. Security/full CI/current-main independence
remain pending. G10–G16/thread/archive ancestry is not required by this feature.

## Implementation and separate self-review

Add DomainConfig storage_max_objects/max_bytes, parsed as storage.max_objects and
storage.max_bytes. Preserve the current32-object default rather than importing the
donor's unrelated16384 default increase. Explicit object capacities accept1–1000000;
positive max_bytes is optional. Normalization emits max_objects and emits max_bytes
when configured; the zero internal sentinel means the remaining memory budget.
Public DomainConfig gains fields: this is an upstream configuration/API extension,
not a claim that every consumer's literal construction has already been checked.

The VFS gains a default InlineNamespace generic and with_namespace constructor;
new and with_storage retain their inline behavior and shared descriptor positions.
OverlayFile becomes public with private fields and an empty constructor. Custom
namespace and storage owners must service matching capacities. Runtime supplies
both from one checked object count. Enumeration, teardown and rename iteration use
actual namespace length instead of the old compile-time FILES bound. A focused
unit uses a three-slot dynamic namespace with FILES0, checks all slots/enumeration,
exhaustion, unlinked-open lifetime and final-close reuse. No abstraction-only PR is
intended; these changes travel with the configured runtime consumer.

MappedArray initializes each element before exposing slices, rejects unsuitable
alignment/zero or unrepresentable byte lengths, and unmaps its pages on Drop.
Page-rounded namespace plus backing metadata bytes are calculated with checked
arithmetic before either allocation. They are subtracted from memory_mib; explicit
max_bytes must fit the remainder. Runtime anonymous data growth is unchanged and
continues charging rounded capacities, not logical file sizes. This accounts for
owned namespace/backing bytes, not aggregate process RSS or every supervisor object.
A positive data budget below one page can hold empty names but cannot allocate a
file page. Seeded directories and removed names with live descriptions count slots.

A separate final self-review read the full final diff and current configuration
parse/validate/normalize, VFS constructors/offsets/open/allocation/whiteout/rename/
enumeration/teardown, anonymous growth and runtime setup/cleanup callers. This is
self-review, not independent reviewer or security acceptance. Core/process/native
supervisor, descriptor/task/device/dispatch owners remain identical to G09d.

- **High, current position ownership:** port the donor constructor with the current
  shared positions array. The initial static check caught its missing initializer;
  it was corrected without removing/suppressing tests or warnings. Existing shared
  dup offsets remain covered by all current VFS tests.
- **High, allocation bounds:** reject over-aligned or isize-unrepresentable mapped
  arrays before pointer/slice construction; checked conversions/product/addition/
  subtraction precede allocation. Default32 is preserved. Adversarial size/failure
  confirmation is handed off, not inferred from source review.
- **High, actual capacity and lifetime:** enumerate/clear the supplied namespace,
  preserve unlinked-open slots until final close, and test actual nonempty files.
  With5003 configured slots and three seeded directories,5000 four-byte files are
  written and individually read back. The next create fails ENOSPC; an unlinked
  still-open file keeps the namespace full until close permits a replacement.
- **Moderate, byte-budget fixture precision:** the existing16 MiB data-quota scenario
  now explicitly sets max_bytes16 MiB inside memory_mib32, accounting for metadata
  separately. It still exercises the same data ceiling/reclamation, rather than
  quietly weakening quota assertions. Default quota/growth behavior is retained.
- **Scope reconciliation:** donor restore seen-table/capacity loops stay with
  G21/G22; no archive/restore consumer exists in this base. Donor hardlink byte
  sharing assertions stay with G15/F02; importing them would create a false G15
  prerequisite. G14 cwd/G10 exec/G12 mapping accounting joins need F02 validation.
- **Blocking for publication:** adversarial arithmetic/allocator/initialization/
  namespace authority and later alias/pin interaction validation remain in the
  [DaybreakBlue handoff](daybreakblue-handoff.md). The broader security holds and
  combined feature prerequisites are not satisfied by these ordinary checks.

## Exact evidence

Source and strict clean prerequisite-plus-patch export both pass `make check
 test-unit build build-launch-directory-fixture build-launch-storage-fixture`:
91 units,32 VFS,171 matching tracked paths. The Ginux binary and both compiled
fixtures match byte-for-byte. Clean apply uses --whitespace=error. New configuration
unit checks explicit normalized round-trip and ordinary rejected bounds/duplicates;
all earlier units/default fixture/CI routes remain intact.

The5000-file namespace scenario passes on both exports, alongside growth, explicit
16 MiB data bounds, old default namespace quota and directory functional/native-cwd
controls. Directory harness modes repeat twice each. Exact G09d, using the same
compiled fixture but a temporary harness omitting unsupported max_objects, fails
open with ENOSPC(-28) and workload160 at its old32-slot bound. This measures the
runtime limit rather than merely rejecting a new config field. Baseline harness,
commands, logs and receipts are retained.

Protected/view-probes and adversarial allocation/authority checks, independent
review, full Linux runtime suite, macOS Actions/remote CI and refreshed standalone
validation remain unrun. Linux-local success is not green remote CI. Intermediate
adaptation helpers/failures are retained; candidate.patch/manifest identify final
source. No real Ginux source/index/branch/ref, remote or human text was changed.

Patch, draft, manifests, helpers, hashes and logs live under
.artifacts/ginux-contribution-preparation/G18/. F04 remains the inspection stop
before publication. G18 correctly precedes G17; no PR has been created.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G18');row.update(m);row.update(evidence='g18-review.md',source_patch='patches/G18.patch');p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''

### G18 exact retained revision

Candidate {m['head']} on G09d {m['base']} has91 routine units and5000 nonempty
files with individual readback, configured exhaustion and unlinked-FD final-close
reclamation passing in source/clean exports. [Review/evidence](g18-review.md) records
checked metadata charging and explicit byte quota. Malicious configuration sizes,
allocation failure/cleanup, unsafe pointer/alignment/initialization and future
alias/cwd/executable/map interactions remain pending for security validation.
Routine API/error units do not constitute that adversarial acceptance. No cloud
agent was dispatched or security probes performed.
''')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text();a=s.index('Exact next task: **G18');b=s.index('\nActive skill:',a)
s=s[:a]+f'''G18 source/ordinary preparation is retained at `{m['head'][:8]}` on G09d{m['base'][:8]}.
[Review/evidence](ginux-contributions/g18-review.md) records91 units,171-path strict
replay and5000 actual nonempty files with readback, namespace exhaustion and last-
close reclamation, plus storage/directory controls in source/clean exports. Default
capacity32 is retained; explicit object/data limits charge rounded metadata before
data. The exact old runtime fails the same scale fixture at its32-slot bound.
Restore/archive and G10–G16 combined joins remain assigned to their owners/F02;
security/full CI/current-main independence remain pending. Nothing was published.

Exact next task: **G17 — private backing descriptors, public FD budgets and
positioned writes**, now that G18 is prepared. Inspect53a2c9cc/d5357101 and split
only by actual capability ownership as P04 requires. Compose the minimum mapping/
storage/namespace prerequisites in a disposable export, preserving current typed
process APIs, public descriptor aliases, dynamic metadata/data charging and exact
checks. Keep private-FD authority/protected-copy/race probes with DaybreakBlue;
perform ordinary low-limit/lifetime/pwrite checks locally. No publication before
F04; all security and standalone prerequisite holds remain explicit.
''' +s[b:];p.write_text(s)
print('Retained G18',m['head'])
