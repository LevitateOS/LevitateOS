from pathlib import Path
import subprocess,shutil,json
root=Path('/tmp/ginux-contribution-preparation/G18');dest=root/'baseline-harness';(dest/'scripts').mkdir(parents=True,exist_ok=True);(dest/'config').mkdir(exist_ok=True)
s=(root/'source/scripts/test-launch-storage.py').read_text();s=s.replace("            if args == ['namespace']:\n                config = config.replace('[storage]\\n', '[storage]\\nmax_objects = 5003\\n')\n",'')
assert 'max_objects' not in s
(dest/'scripts/test-launch-storage.py').write_text(s);shutil.copyfile(root/'source/config/domain-gate5.toml',dest/'config/domain-gate5.toml')
cmd=['sudo','-n','python3',str(dest/'scripts/test-launch-storage.py'),'/tmp/ginux-contribution-preparation/G09d/clean-apply/target/x86_64-unknown-linux-gnu/release/ginux',str(root/'source/.artifacts/launch/launch-storage-fixture'),'namespace']
with (root/'baseline-namespace.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
s=(root/'baseline-namespace.log').read_text();assert r.returncode!=0 and 'workload-exit-code=160' in s and 'result=-28' in s,s[-1000:]
(root/'baseline-receipt.json').write_text(json.dumps({'base':'85b53fe15a64041f451ec7e7aa1e77d08cb2c18a','command':cmd,'harness_change':'omit unsupported max_objects field to exercise exact old32-slot runtime limit','exit_code':r.returncode,'workload_code':160,'open_failure':-28},indent=2)+'\n');print('G09d default capacity fails new nonempty-file fixture as expected')
