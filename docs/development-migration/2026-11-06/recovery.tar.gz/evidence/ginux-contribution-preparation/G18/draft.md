Configure bounded owned namespace and data capacity

Add storage.max_objects and optional positive storage.max_bytes. Keep the current
32-object default and inline VFS constructors. Runtime namespace/backing metadata
use bounded supervisor allocations, charged before data against memory_mib.

Local validation:91 units and a5000 nonempty-file scenario with readback, exhaustion
and final-close slot reclamation pass in source and clean replay, alongside
storage/directory controls. Security/full runtime coverage, remote CI, combined
feature validation and prerequisite merges remain pending; not ready to submit.
