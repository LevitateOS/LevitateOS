from pathlib import Path
import subprocess,tarfile,io,json
root=Path('/tmp/ginux-contribution-preparation/G18');root.mkdir(exist_ok=True);src=root/'source';assert not src.exists();src.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='85b53fe15a64041f451ec7e7aa1e77d08cb2c18a'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(src,filter='data')
(root/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G09d'],'excluded':['G10/G11 exec','G12 mappings','G13 links','G14 cwd','G15 hardlinks','G16 traversal','G07 threads'],'deferred':['G15 alias/exec/cwd combined accounting at F02','G19/G21/G22 export/restore capacity joins'],'source':'38fa14fd9b14f1d62f1c4a9ba2e9b38e11303eca','default_max_objects':32},indent=2)+'\n')
p=src/'crates/ginux-domain/src/lib.rs';s=p.read_text();patch=git('show','38fa14fd','--format=','--','crates/ginux-domain/src/lib.rs');r=subprocess.run(['git','apply','--whitespace=error','-'],cwd=src,input=patch,capture_output=True);assert r.returncode==0,r.stderr.decode();s=p.read_text().replace('storage_max_objects: 16384,','storage_max_objects: 32,');p.write_text(s)
p=src/'crates/ginux-vfs/src/lib.rs';s=p.read_text().replace('#![no_std]','#![no_std]\n\nuse core::ops::{Deref, DerefMut};',1).replace('struct OverlayFile {','pub struct OverlayFile {',1);a=s.index('impl OverlayFile {');b=s.index('\n}',a);s=s[:a]+s[a:b].replace('    const fn empty()','    pub const fn empty()')+s[b:]
s=s.replace('/// Slots are owned by VirtualFs and are always below its FILES bound.','/// Slots are owned by VirtualFs and are below its namespace capacity.\n/// A custom namespace and storage must provide matching slot capacities.')
donor=git('show','38fa14fd:crates/ginux-vfs/src/lib.rs').decode();a=donor.index('/// Inline names');b=donor.index('pub struct VirtualFs<',a);at=s.index('pub struct VirtualFs<');s=s[:at]+donor[a:b]+s[at:]
s=s.replace('    S = InlineStorage<FILES, FILE_SIZE>,\n','    S = InlineStorage<FILES, FILE_SIZE>,\n    N = InlineNamespace<FILES>,\n',1).replace('    overlay: [OverlayFile; FILES],','    overlay: N,',1).replace('            overlay: [OverlayFile::empty(); FILES],','            overlay: InlineNamespace([OverlayFile::empty(); FILES]),',1)
a=donor.index('impl<',donor.index('pub fn with_storage'));b=donor.index('    /// Readable regular-file backing',a);block=donor[a:b];at=s.index('    fn descriptor(') if False else s.index('    pub fn open(')
# Split the existing storage constructor from generic operations at its closing brace.
a=s.index('    pub fn with_storage(');at=s.index('\n    pub fn ',s.index('\n    }',a)+6);s=s[:at]+'\n}\n\n'+block+s[at:]
s=s.replace('self.index.len() + FILES','self.index.len() + self.overlay.len()').replace('for slot in 0..FILES','for slot in 0..self.overlay.len()').replace('for entry in &self.overlay','for entry in self.overlay.iter()').replace('for entry in &mut self.overlay','for entry in self.overlay.iter_mut()')
s=s.replace('    pub fn with_namespace(', '    /// Storage must service every slot in the supplied empty namespace.\n    pub fn with_namespace(',1);p.write_text(s)
p=src/'crates/ginux-init/src/storage_memory.rs';s=p.read_text().replace('    capacity: usize,\n}','    capacity: usize,\n}\nimpl Mapping { const EMPTY: Self = Self { address: 0, capacity: 0 }; }',1)
a=donor.index('not present') if False else 0
donor_memory=git('show','38fa14fd:crates/ginux-init/src/storage_memory.rs').decode();a=donor_memory.index('/// Supervisor allocation');b=donor_memory.index('pub struct MemoryStorage',a);block=donor_memory[a:b]
block=block.replace('        length\n            .checked_mul', '''        if core::mem::align_of::<T>() > PAGE { return Err(VfsError::OverlayLimit); }
        length
            .checked_mul''').replace('            .filter(|n| *n != 0)','            .filter(|n| *n != 0 && *n <= isize::MAX as usize)')
a=s.index('pub struct MemoryStorage');s=s[:a]+block+s[a:];s=s.replace('pub struct MemoryStorage<const FILES: usize> {\n    files: [Mapping; FILES],','pub struct MemoryStorage {\n    files: MappedArray<Mapping>,',1).replace('impl<const FILES: usize> MemoryStorage<FILES> {','impl MemoryStorage {',1)
a=s.index('    pub const fn new(');b=s.index('    pub fn allocated_bytes',a);da=donor_memory.index('    pub fn metadata_bytes(');db=donor_memory.index('    pub fn allocated_bytes',da);s=s[:a]+donor_memory[da:db]+s[b:];s=s.replace('impl<const FILES: usize> OverlayStorage for MemoryStorage<FILES>','impl OverlayStorage for MemoryStorage');p.write_text(s)
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text().replace('use crate::storage_memory::MemoryStorage;','use crate::storage_memory::{MappedArray, MemoryStorage};',1).replace('const OBJECTS: usize = 32;\ntype MemoryFs = VirtualFs<\'static, EmptyReader, OBJECTS, 0, 64, MemoryStorage<OBJECTS>>;',"type MemoryFs = VirtualFs<'static, EmptyReader, 0, 0, 64, MemoryStorage, MappedArray<ginux_vfs::OverlayFile>>;")
a=s.index('        let mut fs = MemoryFs::with_storage(');b=s.index('        for prefix in &prefixes[..count]',a)
s=s[:a]+'''        let objects = usize::try_from(config.storage_max_objects)
            .map_err(|_| b"storage object capacity exceeds address space".as_slice())?;
        let metadata = MappedArray::<ginux_vfs::OverlayFile>::bytes_for(objects)
            .and_then(|n| MemoryStorage::metadata_bytes(objects)
                .and_then(|m| n.checked_add(m).ok_or(VfsError::OverlayLimit)))
            .map_err(|_| b"storage metadata size overflow".as_slice())?;
        let memory = usize::try_from(config.memory_mib).ok()
            .and_then(|mib| mib.checked_mul(1024 * 1024))
            .ok_or(b"memory storage capacity exceeds address space".as_slice())?;
        let available = memory.checked_sub(metadata)
            .ok_or(b"storage metadata exceeds memory bound".as_slice())?;
        let limit = if config.storage_max_bytes == 0 { available } else {
            let limit = usize::try_from(config.storage_max_bytes)
                .map_err(|_| b"storage data capacity exceeds address space".as_slice())?;
            if limit > available { return Err(b"storage data and metadata exceed memory bound"); }
            limit
        };
        let namespace = MappedArray::new(objects, ginux_vfs::OverlayFile::empty())
            .map_err(|_| b"storage namespace allocation failed".as_slice())?;
        let mut fs = MemoryFs::with_namespace(
            Index::new(index_bytes).map_err(|_| b"invalid storage root index".as_slice())?,
            EmptyReader,
            MemoryStorage::new(limit, objects)
                .map_err(|_| b"storage metadata allocation failed".as_slice())?,
            namespace,
        );
'''+s[b:];p.write_text(s)
print('G18 port on G09d; default32; restore/export and alias joins deferred')
