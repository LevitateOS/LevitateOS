from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G18/source')
p=src/'crates/ginux-vfs/src/lib.rs';s=p.read_text().replace('            overlay: namespace,\n            descriptors: [Descriptor::empty(); FDS],','            overlay: namespace,\n            descriptors: [Descriptor::empty(); FDS],\n            positions: [0; FDS],',1)
a=s.index('    #[test]',s.index('mod tests {'));s=s[:a]+'''    #[test]
    fn supplied_namespace_controls_capacity_without_changing_inline_defaults() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 0, 16, 4, InlineStorage<3, 16>, std::vec::Vec<OverlayFile>> =
            VirtualFs::with_namespace(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"),
                InlineStorage::default(), std::vec![OverlayFile::empty(); 3]);
        assert_eq!(fs.namespace_capacity(), 3);
        for name in [b"/one".as_slice(), b"/two", b"/three"] {
            let fd = fs.open(name, O_CREATE | O_READ | O_WRITE).unwrap();
            fs.write(fd, b"data").unwrap();
            fs.close(fd).unwrap();
        }
        assert_eq!(fs.open(b"/four", O_CREATE | O_WRITE), Err(VfsError::OverlayLimit));
        let fd = fs.open(b"/three", O_READ).unwrap();
        fs.unlink(b"/three").unwrap();
        assert_eq!(fs.open(b"/four", O_CREATE | O_WRITE), Err(VfsError::OverlayLimit));
        let mut data = [0;4];
        assert_eq!(fs.read(fd, &mut data), Ok(4));
        assert_eq!(&data, b"data");
        fs.close(fd).unwrap();
        let fd = fs.open(b"/four", O_CREATE | O_WRITE).unwrap();
        fs.close(fd).unwrap();
        fs.teardown();
        assert_eq!(fs.overlay_files(), 0);
    }

'''+s[a:];p.write_text(s)
p=src/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();a=s.index('long storage_main(');s=s[:a]+'''static int equal(const char *a, const char *b) {
    while (*a && *a==*b) { ++a; ++b; } return *a==*b;
}
static void numbered(char *path, word n) {
    for(int digit=3;digit>=0;--digit) { path[10+digit]='0'+n%10; n/=10; }
}
static long namespace_scale(void) {
    char path[]="/out/file-0000";
    for(word n=0;n<5000;++n) {
        numbered(path,n);
        long fd=DO(2,path,0102,0600); CHECK(fd>=3,160);
        CHECK(DO(1,fd,path+10,4)==4 && DO(3,fd,0,0)==0,161);
    }
    CHECK(DO(2,"/out/overflow",0102,0600)==-28,162);
    for(word n=0;n<5000;++n) {
        numbered(path,n);
        long fd=DO(2,path,0,0); CHECK(fd>=3,163);
        CHECK(DO(0,fd,output,4)==4,164);
        for(word k=0;k<4;++k) CHECK(output[k]==path[10+k],165);
        CHECK(DO(3,fd,0,0)==0,166);
    }
    numbered(path,4999);
    long held=DO(2,path,0,0); CHECK(held>=3 && DO(87,path,0,0)==0,167);
    CHECK(DO(2,"/out/replacement",0102,0600)==-28,168);
    CHECK(DO(3,held,0,0)==0,169);
    long fd=DO(2,"/out/replacement",0102,0600); CHECK(fd>=3 && DO(1,fd,"new",3)==3 && DO(3,fd,0,0)==0,170);
    return 0;
}
'''+s[a:];s=s.replace('    char **argv = (char **)(stack + 1);','    char **argv = (char **)(stack + 1);\n    if(argc>1 && equal(argv[1],"namespace")) return namespace_scale();',1);p.write_text(s)
p=src/'scripts/test-launch-storage.py';s=p.read_text().replace('[growth|bounds|quota|view-probes ...]','[growth|bounds|quota|namespace|view-probes ...]')
s=s.replace("            config = config.replace('id =", "            if args == ['namespace']:\n                config = config.replace('[storage]\\n', '[storage]\\nmax_objects = 5003\\n')\n            if args == ['bounds']:\n                config = config.replace('[storage]\\n', '[storage]\\nmax_bytes = 16777216\\n')\n            config = config.replace('id =",1)
s=s.replace("('growth', 'bounds', 'quota', 'view-probes')","('growth', 'bounds', 'quota', 'namespace', 'view-probes')").replace("memory=16 if mode == 'bounds' else 256","memory=32 if mode == 'bounds' else (64 if mode == 'namespace' else 256)").replace("['bounds'], memory=16","['bounds'], memory=32")
s=s.replace("        invoke([], ['no-storage'])","        invoke(['memory:/work', 'memory:/work/build', 'memory:/out'], ['namespace'], memory=64)\n        invoke([], ['no-storage'])");p.write_text(s)
p=src/'README.md';s=p.read_text().replace('Metadata capacity remains 32 objects (including seeded\ndirectories) and 64 independently opened files.','Metadata defaults to 32 objects (including seeded directories) and 64 independently\nopened files. `[storage].max_objects` permits 1–1000000 namespace slots. Bounded\nsupervisor allocations hold namespace and backing metadata; their page-rounded\nbytes are charged before file data. Optional positive `[storage].max_bytes` caps\nfile-data capacity. Data plus metadata must fit `[resources].memory_mib`; without\nmax_bytes, data uses the remainder. Removed names with live descriptions retain\ntheir slots until final close.');p.write_text(s)
print('G18 dynamic namespace unit and5000 nonempty-file scenario')
