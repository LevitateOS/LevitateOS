Configured launches currently reject writable storage assignments. Add explicit `memory:/path` namespaces whose bytes, metadata and descriptors stay in supervisor memory. Image links preserve assignment precedence; unassigned writes remain denied.

Keep existing CI and add real storage coverage for data/metadata, hidden image files, bad buffers, protected pages, path components, descriptor/object/file bounds and fresh launches. Local static checks,77 unit tests and all required Linux launch/storage/native/process/setup suites pass, including a clean patch replay. macOS CI is pending.

This bounded backend has no persistence, generated exec, directory FDs or owned symlinks. Native canonical paths require temporary writable scratch below the stopped task's stack.
