from pathlib import Path
import tempfile,subprocess,json,shutil
r=Path('/tmp/ginux-contribution-preparation/G22');s=r/'source';binary=str(r/'restore-join/target/x86_64-unknown-linux-gnu/release/ginux')
with tempfile.TemporaryDirectory(prefix='ginux-archive-baseline-') as name:
    w=Path(name);root=w/'root';(root/'bin').mkdir(parents=True);shutil.copyfile(s/'.artifacts/launch/launch-storage-fixture',root/'bin/fixture');(root/'bin/fixture').chmod(0o755)
    config=(s/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/fixture"').replace('args = []','args = ["archive-create"]').replace('[storage]\nassignments = []','[storage]\nassignments = ["memory:/out"]')
    p=w/'config.toml';p.write_text(config);archive=w/'valid.tar';result=w/'result.json'
    cmd=[binary,'launch',str(p),str(root),'--result-file',str(result),'--export-file',str(archive)];proc=subprocess.run(cmd,capture_output=True,timeout=10)
    (r/'baseline-archive.log').write_bytes(proc.stderr);assert proc.returncode==1 and b'hardlink archive identity is not implemented' in proc.stderr,proc.stderr.decode()
    assert not archive.exists() and not list(w.glob('.ginux-export-*'))
    assert json.loads(result.read_text())['outcome']=='supervisor-error'
    (r/'baseline-receipt.json').write_text(json.dumps({'base':json.loads((r/'composition.json').read_text())['base'],'command':cmd,'exit_code':proc.returncode,'behavior':'valid linked-file workload completes; prerequisite refuses identity-losing export and cleans staging'},indent=2)+'\n')
print('exact prerequisite refuses linked archive without partial publication')
