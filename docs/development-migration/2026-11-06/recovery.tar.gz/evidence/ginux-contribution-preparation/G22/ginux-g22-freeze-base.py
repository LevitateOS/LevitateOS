from pathlib import Path
import subprocess,os,tempfile,json,tarfile,io
r=Path('/tmp/ginux-contribution-preparation/G22');s=r/'restore-join';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';preview=(r/'restore-merge-preview.txt').read_text().splitlines()[0];parents=[json.loads((r/'prerequisite-step1.json').read_text())['head'],'33bf08a746bd64306e0375f8d419af4744d31064']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
entries=git('ls-tree','-r',preview).decode().splitlines();changed=[]
with tempfile.TemporaryDirectory(prefix='ginux-g22-base-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',preview,env=env)
 for line in entries:
  left,name=line.split('\t');mode,kind,old=left.split();p=s/name;data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
  assert b'<<<<<<< ' not in data,name
  blob=git('hash-object','-w','--stdin',input=data).decode().strip()
  if blob!=old:git('update-index','--cacheinfo',mode,blob,name,env=env);changed.append(name)
 tree=git('write-tree',env=env).decode().strip();base=git('commit-tree',tree,'-p',parents[0],'-p',parents[1],input=b'Join reviewed link, bounded storage and startup restore prerequisites\n').decode().strip()
git('diff','--check',parents[0],base)
m={'base':base,'base_tree':tree,'parents':parents,'dependencies':['G13','G15','G18','G17b','G21'],'source':['e33745930acdbf35e4a0671a5d7de034d8fd1ef2'],'resolved_paths':changed,'excluded':['G20 control/event wait','G07 thread groups','G14 cwd','G16 image traversal','G17a pwrite','G01/G02/G08 policy'],'retained_joins':['G19 enumeration/read-overlay uses G15 inode identity','G19 export visits dynamic namespace, rejects hardlink identity until G22','G21 keeps bounded32-entry restore pending G22 dynamic seen/format join'],'unpublished':True}
(r/'composition.json').write_text(json.dumps(m,indent=2)+'\n');dest=r/'source';assert not dest.exists();dest.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(dest,filter='data')
print(json.dumps(m,indent=2))
