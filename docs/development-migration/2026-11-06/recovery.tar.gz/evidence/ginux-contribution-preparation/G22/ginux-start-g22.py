from pathlib import Path
import subprocess
r=Path('/tmp/ginux-contribution-preparation/G22');src=r/'source';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def get(ref,n):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'show',ref+':'+n]).decode()
n='crates/ginux-init/src/fs_hooks.rs';p=src/n;s=p.read_text();d=get('e3374593',n)
s=s.replace('pub(crate) const OBJECTS: usize = 32;\n','',1)
a=d.index('pub struct RestoreEntry');b=d.index('pub struct LaunchFs',a);s=s.replace('pub struct LaunchFs',d[a:b]+'pub struct LaunchFs',1)
s=s.replace('    fs: MemoryFs,','    fs: MemoryFs,\n    byte_limit: usize,',1).replace('        Ok(Self {\n            fs,','        Ok(Self {\n            fs,\n            byte_limit: limit,',1)
a=s.index('    pub fn restore_entry(');b=s.index('    pub fn export(',a);da=d.index('    pub fn byte_limit(');db=d.index('    pub fn enabled(',da);methods=d[da:db];da=d.index('    pub fn restore_entry(');db=d.index('    pub fn export(',da);restore=d[da:db]
a1=restore.index('        let canonical =');b1=restore.index('        {\n            return Err(b"restore path',a1)
restore=restore[:a1]+'''        // The archive parser has already validated absolute path components.
        if !self.owns_path(path)
            && !(directory && self.prefixes[..self.count].iter().any(|p| within(p.as_bytes(), path)))
'''+restore[b1:]
restore=restore.replace('''        // This launch view has a one-entry immutable root; live owned inode
        // numbers are stable slot+2 for the duration of startup import.
''','''        // Track exact names rather than canonical inodes, since aliases share data.
''')
s=s[:a]+methods+restore+s[b:]
a=s.index('    pub fn export(');b=s.index('    pub fn teardown(',a);da=d.index('    fn write_archive(');db=d.index('    pub fn teardown(',da)
s=s[:a]+'''    pub fn export(&self) -> Result<(), &'static [u8]> {
        crate::storage_export::finish(|archive| self.write_archive(archive))
    }

'''+d[da:db]+s[b:];p.write_text(s)
n='crates/ginux-init/src/storage_export.rs';p=src/n;s=p.read_text();d=get('e3374593',n);a=s.index('    pub fn entry(');b=s.index('\nfn octal(',a);da=d.index('    pub fn entry(');db=d.index('\nfn octal(',da);s=s[:a]+d[da:db]+s[b:];p.write_text(s)
n='crates/ginux-init/src/storage_restore.rs';s=get('e3374593',n).replace('            0x80000 | 0x20000,','            // Reject non-regular sources without blocking before fstat.\n            0x80000 | 0x20000 | 0x800,',1);(src/n).write_text(s)
n='crates/ginux-vfs/src/lib.rs';p=src/n;s=p.read_text();d=get('e3374593',n);a=d.index('    /// Exact live namespace identity');b=d.index('    /// Enumerate live writable',a);at=s.index('    /// Enumerate live writable');s=s[:at]+d[a:b]+s[at:];p.write_text(s)
n='README.md';p=src/n;s=p.read_text().replace('retained storage, live checkpoint control, symlink or hardlink archive support.','retained storage or live checkpoint control.',1)
a=s.index('`--restore-file <snapshot tar>`');s=s[:a]+'''`--restore-file <snapshot tar>` reconstructs the owned filesystem before workload
startup. Regular files, directories, symlinks, modes and GNU long names/targets
are supported. Regular hardlinks export one payload followed by zero-size aliases
to an earlier name; restore preserves shared bytes and inode identity. Symbolic
link targets are stored as data and are never followed during import.

Import uses the configured namespace and data budgets, including prepared
assignment parents. Archive bytes are bounded by the data budget plus 3072 bytes
per namespace slot and a 1024-byte terminator. There is no fixed 2 GiB payload
ceiling; ustar octal size fields limit each file to below 8 GiB. Hardlink aliases
consume namespace capacity and share the original data charge. Invalid paths,
forward hardlinks, conflicting alias modes, symlink parents, duplicate entries,
metadata, checksums, truncation or trailing data fail launch. The source must be
a bounded regular file opened without following a symlink; it remains unchanged.
Failure discards the new memory view. The host must verify the chosen snapshot
and matching runtime state: process memory and live handles are not restored,
and no checkpoint control socket is required.
''';p.write_text(s)
print('G22 bounded dynamic/link archive source ported; G19 atomic export/G21 cleanup retained')
