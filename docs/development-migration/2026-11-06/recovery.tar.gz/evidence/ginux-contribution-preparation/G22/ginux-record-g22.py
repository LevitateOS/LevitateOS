from pathlib import Path
import json,hashlib,shutil
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G22');art=root/'.artifacts/ginux-contribution-preparation/G22';m=json.loads((temp/'manifest.json').read_text())
for prefix in ['', 'clean-']:
    rs=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(rs)==4 and all(r['exit_code']==0 for r in rs)
static=[json.loads((temp/(prefix+'static-receipt.json')).read_text()) for prefix in ['final-','clean-']]
assert all(r['exit_code']==0 and r['matched_paths']==181 and r['head']==m['head'] for r in static)
assert static[0]['binary_sha256']==static[1]['binary_sha256']
fixtures={}
for name in ['launch-storage-fixture','launch-directory-fixture','launch-script-fixture','launch-owned-exec-fixture','launch-fd-fixture']:
    a=(temp/'source/.artifacts/launch'/name).read_bytes();b=(temp/'verified-head/.artifacts/launch'/name).read_bytes();assert a==b;fixtures[name]=hashlib.sha256(a).hexdigest()
m.update(status='source separately self-reviewed; selected ordinary source/clean checks pass; security/full CI/upstream independence pending',unit_tests=100,vfs_tests=41,clean_matched_paths=181,review='separate self-review; no independent reviewer or security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',held_dependencies=['inherited G07 shared-argument security; no thread code imported'],source_binary_sha256=static[0]['binary_sha256'],clean_binary_sha256=static[1]['binary_sha256'],fixture_sha256=fixtures,prerequisite_patch_sha256=hashlib.sha256((temp/'prerequisite.patch').read_bytes()).hexdigest(),large_payload_bytes=2147483649,large_payload_integrity='complete restored/re-exported payload compared with expected streaming SHA256 in source/clean',nonempty_namespace_files=5000)
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
    if p.is_file() and p.suffix in ['.json','.log','.patch','.diff','.txt']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g22*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G22.patch')
(art/'draft.md').write_text('''Preserve filesystem link identity across bounded archives

Export one regular-file payload with hardlink aliases and roundtrip symlinks,
long names and long targets. Restore exact entry identities within configured
namespace/data budgets, without the fixed 2 GiB ceiling. Retain atomic export
publication and startup cleanup; reject unsupported symlink permission modes.

Local build/static checks and 100 units pass in source and clean replay. Ordinary
checks roundtrip links, 5,000 nonempty files and a complete 2 GiB+1 payload with
streaming integrity comparison. Security validation, full runtime/remote CI and
upstream prerequisite merges remain pending; not ready to submit.
''')
assert not any(s in (art/'draft.md').read_text() for s in ['LevitateOS','Recipe','Daybreak'])
(docs/'g22-review.md').write_text(f'''# G22 — bounded archives and link identity

Head `{m['head']}`, tree `{m['tree']}`, on local composition
`{m['base']}`. [Patch](patches/G22.patch): seven files, +401/-77.
Source and selected ordinary verification are retained. Security, full CI and
upstream independence remain pending; no PR stack is ready for publication.

Prerequisites are reviewed G13/G15 link identity, G18 dynamic namespace, G17b
private backing budget and G21 startup restore (including G19 final export).
G17b is required by this memfd composition's 5,000-file check, not by archive
syntax alone. The local join preserves generic namespace iteration, both mapping
and link fixtures, current alias-aware metadata/read APIs, checked FD reservations
and startup teardown. Until G22, export refuses identity-losing hardlinks and
restore retains its older fixed entry bound. The exact prerequisite passes its
100-unit/build and ordinary G21 restore checks; its valid linked workload then
fails export explicitly and leaves no final/staging output.

G22 writes one regular payload and earlier-name hardlink aliases, retaining shared
inode/mode/data identity. GNU name/target records carry long links; symlink targets
remain data during import. Exact named slots replace inode arithmetic for duplicate
tracking because aliases share inodes. Dynamic bounded seen storage follows current
namespace capacity. Total archive bytes are checked against the configured data
budget plus 3072 bytes per slot and terminator; data/target bytes and actual storage
allocations retain their existing quota owner. The old fixed 2 GiB cap is removed;
ustar's supported file-size encoding still bounds each output file below 8 GiB.

Separate final self-review read the whole diff and existing archive write/sync/
close/publication, startup/config/completion teardown, VFS alias/data/metadata/
slot lifetime, shared component walker, namespace capacity, backing reservation
and restored file/parent callers. This is self-review, not independent review.

- **Metadata correction:** donor restore accepted arbitrary low symlink mode
  bits, while VFS creation always installs0777. Reject another mode explicitly
  rather than silently changing requested metadata. The default symlink-target
  rejection fixture now uses its supported mode. Adversarial metadata validation
  is written down for DaybreakBlue, not claimed from ordinary results.
- **Identity:** export picks a prior live name for each shared inode. The first
  surviving alias becomes payload when its original name was unlinked. Restore
  accepts only prior exact regular names with matching mode and assignment;
  parents must be actual directories. No new inode or path owner is introduced.
- **Retained lifecycle:** G19 private staging/no-overwrite publication and G21
  pre-workload restore cleanup are unchanged. Control/event wait, thread groups,
  cwd/traversal extensions and held guest/network policy are not imported. Core,
  process, native supervisor, descriptors, mapping and backing source are unchanged
  from the explicit prerequisite. The shared VFS walker is unchanged.
- **Coverage:** extend G21's existing restore target and its existing Linux CI
  invocation; no deferred G31 wiring is needed. Existing static-and-unit tests,
  mapping/link fixtures and full negative defaults are retained.

Final source and strict clean prerequisite-plus-patch replay pass make check
test-unit build and storage/directory/script/owned-exec/FD fixture builds:100 units,
41 VFS,181 matching tracked paths. Ginux and all five fixture binaries match.
Ordinary checks pass in both copies: regular startup reconstruction/restart,
permissions, empty/binary/multi-chunk files, parent ordering, link/inode/nlink
coherence after mutation, long hardlink/symlink targets, and an unlinked original
with its surviving alias. A 5,000-nonempty-file archive restores and verifies data
under its configured namespace. A complete2 GiB+1 source payload is restored and
re-exported under an explicit4 GiB memory budget; length, boundary bytes and a
streaming SHA256 over every exported payload byte match the expected content.
Seven flush/export/config cases, two mapping, ordinary symlink, six ELF,14 script
and growth/bounds/quota controls also pass. Earlier results before metadata review
and before the final digest fixture are labelled separately from the final head.

Full negative/private-FD/hostile archive/path/alias/race/failure validation remains
with [DaybreakBlue](daybreakblue-handoff.md); no cloud dispatch or security
acceptance occurred. Independent review, full Linux suite, macOS/remote CI and
fresh-main standalone validation are unrun. G07 shared-argument security and
G20/G14/G16 cross-candidate joins remain F02 work. Linux-local success is not green CI.

Patch, concise draft, commands, hashes, helpers, logs and a complete prerequisite
reconstruction patch from recorded main3f2fe7df are retained under
.artifacts/ginux-contribution-preparation/G22/. No real Ginux branch, index,
checkout/ref, remote human text or maintainer message changed. F04 remains the
user inspection stop before publication.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G22');row.update(m);row.update(evidence='g22-review.md',source_patch='patches/G22.patch');p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'p04-dependencies.md';s=p.read_text();s=s.replace('Requires hardlink identities, symlinks, dynamic capacity and matching export/import.','Requires hardlink identities, symlinks, dynamic capacity and matching export/import. The selected memfd composition also needs G17b private backing reservations for 5,000 live files.');p.write_text(s)
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\nG22 exact retained revision: {m['head']} on composition {m['base']}.
100 routine units and selected ordinary link/alias/long-target,5000-file and
complete2 GiB+1 restore/export with full streaming digest pass in source/clean.
Unsupported symlink modes now reject rather than silently becoming0777, based on
source review; that adversarial rejection remains unrun. Validate archive/alias/
assignment authority, malformed and oversized input, conflicting metadata,
hostile source changes, failure injection and races independently. No security
acceptance or cloud dispatch; [review/evidence](g22-review.md).\n''')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text().replace('| G13, G15, G18, G21 | Export/restore','| G13, G15, G18, G17b (memfd scale), G21 | Export/restore',1);a=s.index('Exact next task: **G22');b=s.index('\nActive skill:',a)
s=s[:a]+f'''G22 source/ordinary preparation is retained at `{m['head'][:8]}` on reviewed
G13/G15/G18/G17b/G21 composition `{m['base'][:8]}`. [Review/evidence](ginux-contributions/g22-review.md)
records100 units,181-path strict replay and link/alias/long-target identity,
5000 nonempty files and a complete2 GiB+1 restore/export with every payload byte
compared by streaming digest, plus existing controls, passing in source/clean.
G17b supplies this memfd composition's required private FD budget; no G20/thread/
held policy code is imported. Source review fixed silent symlink-mode changes.
G19 atomic export and G21 startup cleanup remain. Existing restore CI wiring
covers the new fixtures. Security/full CI/upstream independence and remaining
F02 interactions are pending; nothing was published.

Exact next task: **G23 — owned file locks**.
Inspect26784843 against current descriptor/process identities and shared G15 inode
ownership. Distinguish process record locks from open-description flock lifetime;
retain blocking/cancellation/close/exit behavior without importing held threads
or readiness policy. Run ordinary real simultaneous clients and the existing
SQLite/Cargo consumer scenarios where dependencies permit. Record adversarial
FD/lock ownership, copy and race probes for DaybreakBlue. No publication or
maintainer messages before F04.
''' +s[b:];p.write_text(s);print('retained',m['head'])
