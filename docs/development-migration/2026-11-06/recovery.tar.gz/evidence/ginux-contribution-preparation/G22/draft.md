Preserve filesystem link identity across bounded archives

Export one regular-file payload with hardlink aliases and roundtrip symlinks,
long names and long targets. Restore exact entry identities within configured
namespace/data budgets, without the fixed 2 GiB ceiling. Retain atomic export
publication and startup cleanup; reject unsupported symlink permission modes.

Local build/static checks and 100 units pass in source and clean replay. Ordinary
checks roundtrip links, 5,000 nonempty files and a complete 2 GiB+1 payload with
streaming integrity comparison. Security validation, full runtime/remote CI and
upstream prerequisite merges remain pending; not ready to submit.
