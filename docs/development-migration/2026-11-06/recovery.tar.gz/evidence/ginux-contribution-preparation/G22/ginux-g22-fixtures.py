from pathlib import Path
import subprocess
r=Path('/tmp/ginux-contribution-preparation/G22');src=r/'source'
p=src/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();a=s.index('long storage_main(')
s=s[:a]+'''static long archive_links(int restore) {
    char path[208]="/out/";
    for(word i=5;i<125;++i) path[i]='a';
    path[125]='/';
    for(word i=126;i<206;++i) path[i]='b';
    path[206]=0;
    if(!restore) {
        long status=export_data("export"); CHECK(status==0,status);
        CHECK(DO(86,"/out/product","/out/product-alias",0)==0 && DO(86,path,"/out/long-alias",0)==0,234);
        CHECK(DO(88,"product","/out/product-link",0)==0 && DO(88,path,"/out/long-link",0)==0,235);
        CHECK(DO(2,"/out/temporary",0101,0600)==3 && DO(1,3,"orphan",6)==6 && DO(3,3,0,0)==0,236);
        CHECK(DO(86,"/out/temporary","/out/surviving",0)==0 && DO(87,"/out/temporary",0,0)==0,237);
    } else {
        long status=restore_data(0); CHECK(status==0,status);
        CHECK(DO(4,"/out/product",meta,0)==0 && *(word *)(meta+16)==2,238);
        word inode=*(word *)(meta+8);
        CHECK(DO(4,"/out/product-alias",meta,0)==0 && *(word *)(meta+8)==inode && *(word *)(meta+16)==2,239);
        CHECK(DO(2,"/out/product-alias",0,0)==3 && DO(0,3,output,7)==7 && output[0]=='c' && DO(3,3,0,0)==0,240);
        CHECK(DO(2,"/out/product-link",0,0)==3 && DO(0,3,output,7)==7 && output[0]=='c' && DO(3,3,0,0)==0,241);
        CHECK(DO(2,"/out/long-alias",0,0)==3 && DO(0,3,output,4)==4 && output[0]=='l' && DO(3,3,0,0)==0,242);
        CHECK(DO(2,"/out/long-link",0,0)==3 && DO(0,3,output,4)==4 && output[0]=='l' && DO(3,3,0,0)==0,243);
        CHECK(DO(2,"/out/surviving",0,0)==3 && DO(0,3,output,6)==6 && output[0]=='o' && DO(3,3,0,0)==0,244);
    }
    return 0;
}
static long restore_namespace(void) {
    char path[]="/out/file-0000";
    for(word n=0;n<4999;++n) {
        numbered(path,n); long fd=DO(2,path,0,0); CHECK(fd==3,245);
        CHECK(DO(0,fd,output,4)==4,246);
        for(word i=0;i<4;++i) CHECK(output[i]==path[10+i],247);
        CHECK(DO(3,fd,0,0)==0,248);
    }
    CHECK(DO(2,"/out/replacement",0,0)==3 && DO(0,3,output,3)==3 && output[0]=='n' && DO(3,3,0,0)==0,249);
    CHECK(DO(1,1,"restored: PASS\\n",15)==15,250); return 0;
}
static long restore_big(void) {
    long fd=DO(2,"/out/big",0,0); CHECK(fd==3 && DO(5,fd,meta,0)==0 && *(word *)(meta+48)==2147483649UL,251);
    CHECK(DO(0,fd,output,1)==1 && output[0]==0,252);
    CHECK(DO(8,fd,2147483647UL,0)==2147483647UL && DO(0,fd,output,2)==2 && output[0]==0 && output[1]=='Z',253);
    CHECK(DO(3,fd,0,0)==0 && DO(1,1,"restored: PASS\\n",15)==15,254); return 0;
}
'''+s[a:];needle='    char **argv = (char **)(stack + 1);';s=s.replace(needle,needle+'''
    if(argc>1 && equal(argv[1],"archive-create")) return archive_links(0);
    if(argc>1 && equal(argv[1],"restore-links")) return archive_links(1);
    if(argc>1 && equal(argv[1],"restore-namespace")) return restore_namespace();
    if(argc>1 && equal(argv[1],"restore-big")) return restore_big();''',1);p.write_text(s)
p=src/'scripts/test-launch-restore.py';s=p.read_text().replace("def launch(mode, archive=None, exported=None, failure=False, assignments='memory:/out'):","def launch(mode, archive=None, exported=None, failure=False, assignments='memory:/out', objects=None, memory=256):",1)
s=s.replace("            config_path.write_text(config.replace('args = []', 'args = ' + json.dumps([mode])).replace('memory:/out', assignments))", """            effective = config.replace('args = []', 'args = ' + json.dumps([mode])).replace('memory:/out', assignments)
            effective = effective.replace('memory_mib = 256', 'memory_mib = ' + str(memory))
            if objects is not None:
                effective = effective.replace('[storage]\\n', '[storage]\\nmax_objects = ' + str(objects) + '\\n')
            config_path.write_text(effective)""",1).replace('capture_output=True, timeout=10','capture_output=True, timeout=120',1)
a=s.index('        if not ordinary:')
s=s[:a]+'''        linked = work/'links.tar'
        launch('archive-create', exported=linked)
        linked_original = linked.read_bytes()
        with tarfile.open(linked) as tar:
            assert tar.getmember('out/product-alias').islnk()
            assert tar.getmember('out/product-alias').linkname == 'out/product'
            assert tar.getmember('out/long-alias').linkname == 'out/' + 'a'*120 + '/' + 'b'*80
            assert tar.getmember('out/product-link').issym()
            assert tar.getmember('out/product-link').linkname == 'product'
            assert tar.getmember('out/long-link').linkname == '/out/' + 'a'*120 + '/' + 'b'*80
            assert tar.extractfile('out/surviving').read() == b'orphan'
            assert 'out/temporary' not in tar.getnames()
        updated = work/'links-updated.tar'
        launch('restore-links', linked, updated)
        assert linked.read_bytes() == linked_original
        with tarfile.open(updated) as tar:
            assert tar.extractfile('out/product-alias').read() == b'changed'
            assert tar.getmember('out/product-alias').islnk()

        namespace = work/'namespace.tar'
        launch('namespace', exported=namespace, objects=5001, memory=64)
        with tarfile.open(namespace) as tar:
            assert sum(member.isfile() for member in tar.getmembers()) == 5000
        launch('restore-namespace', namespace, objects=5001, memory=64)

        # A complete valid payload crosses the old2 GiB ceiling. Sparse host
        # construction avoids writing the source's zero bytes twice.
        big, big_export = work/'big.tar', work/'big-export.tar'
        entry = tarfile.TarInfo('out/big')
        entry.mode, entry.size = 0o600, 2*1024*1024*1024+1
        with big.open('wb') as stream:
            stream.write(entry.tobuf(format=tarfile.USTAR_FORMAT))
            stream.seek(512+entry.size-1)
            stream.write(b'Z')
            stream.write(bytes((-entry.size)%512+1024))
        launch('restore-big', big, big_export, memory=4096)
        with tarfile.open(big_export) as tar:
            member = tar.getmember('out/big')
            assert member.size == entry.size
            contents = tar.extractfile(member)
            assert contents.read(1) == b'\\0'
            contents.seek(entry.size-2)
            assert contents.read(2) == b'\\0Z'
        big.unlink(); big_export.unlink()

'''+s[a:]
# Retain the donor's hardlink rejection cases without requiring control transport.
a=s.index("            link = work / 'snapshot-link.tar'")
s=s[:a]+'''            for name, target, target_type, extra in (
                    ('forward-hardlink', 'out/future', None, None),
                    ('absolute-hardlink', '/out/product', None, None),
                    ('traversing-hardlink', 'out/../product', None, None),
                    ('directory-hardlink', 'out/dir', tarfile.DIRTYPE, None),
                    ('symlink-hardlink', 'out/sym', tarfile.SYMTYPE, None),
                    ('hardlink-mode', 'out/source', tarfile.REGTYPE, 0o700)):
                archive = work/(name+'.tar')
                with tarfile.open(archive, 'w', format=tarfile.USTAR_FORMAT) as tar:
                    if target_type is not None:
                        entry = tarfile.TarInfo(target)
                        entry.type, entry.mode = target_type, 0o600
                        if target_type == tarfile.SYMTYPE:
                            entry.linkname = '/out/source'
                        tar.addfile(entry)
                    entry = tarfile.TarInfo('out/bad-alias')
                    entry.type, entry.linkname, entry.mode = tarfile.LNKTYPE, target, extra or 0o600
                    tar.addfile(entry)
                launch('restore', archive, failure=True)
'''+s[a:]
s=s.replace('ordinary roundtrip, data, modes, long paths, restart and parent ordering','ordinary roundtrip, links,5000 nonempty files and complete >2 GiB payload');compile(s,str(p),'exec');p.write_text(s)
print('G22 ordinary link, namespace and complete >2 GiB roundtrips; full negative defaults retained')
