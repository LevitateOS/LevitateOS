from pathlib import Path
import subprocess,os,tempfile,json,re
r=Path('/tmp/ginux-contribution-preparation/G22');s=r/'prerequisite';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';preview='8c7b6f5a1325ce40f75718967110cf3cc34643cf'
pattern=re.compile(r'^<<<<<<< [^\n]*\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]*\n',re.M|re.S)
p=s/'crates/ginux-vfs/src/lib.rs';v=p.read_text();v,n=pattern.subn(lambda m:m[2].replace('&self.overlay','self.overlay.iter()').replace('&mut self.overlay','self.overlay.iter_mut()'),v);assert n==2;p.write_text(v)
p=s/'scripts/test-launch-storage.py';v=p.read_text();matches=list(pattern.finditer(v));assert len(matches)==2
for i,m in reversed(list(enumerate(matches))):
 text=m[1].replace("'ordinary-unlinked-mapping')","'ordinary-unlinked-mapping', 'symlinks', 'ordinary-symlinks')") if i==0 else m[1]+''.join(line+'\n' for line in m[2].splitlines() if "['symlinks']" in line or "['ordinary-symlinks']" in line)
 v=v[:m.start()]+text+v[m.end():]
p.write_text(v)
p=s/'tests/fixtures/launch-storage-fixture.c';v=p.read_text();matches=list(pattern.finditer(v));assert len(matches)==2
for i,m in reversed(list(enumerate(matches))):
 text=m[1]+('    return 0;\n}\n' if i==0 else '        return 0;\n    }\n')+m[2]
 v=v[:m.start()]+text+v[m.end():]
p.write_text(v)
for p in s.rglob('*'):
 if p.is_file() and not p.is_symlink():assert b'<<<<<<< ' not in p.read_bytes(),p
print('resolved G17b/G15 generic namespace, link states and both fixture sets')
