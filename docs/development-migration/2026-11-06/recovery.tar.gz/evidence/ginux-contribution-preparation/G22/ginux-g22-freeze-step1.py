from pathlib import Path
import subprocess,os,tempfile,json,tarfile,io
r=Path('/tmp/ginux-contribution-preparation/G22');s=r/'prerequisite';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';parents=['6fcdd6183703768a2f4ed1cc48380eaa50da547c','8ab24d4b47adeb9897623627060846070d41219d']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['crates/ginux-vfs/src/lib.rs','scripts/test-launch-storage.py','tests/fixtures/launch-storage-fixture.c']
for name in files:assert b'<<<<<<< ' not in (s/name).read_bytes(),name
with tempfile.TemporaryDirectory(prefix='ginux-g22-index-') as t:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(t)/'index')};git('read-tree','8c7b6f5a1325ce40f75718967110cf3cc34643cf',env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(s/name).read_bytes()).decode().strip();git('update-index','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();head=git('commit-tree',tree,'-p',parents[0],'-p',parents[1],input=b'Join reviewed storage capacity, backing and link owners\n').decode().strip()
(r/'prerequisite-step1.json').write_text(json.dumps({'parents':parents,'head':head,'tree':tree},indent=2)+'\n')
p=subprocess.run(['git','-C',repo,'--work-tree='+repo,'merge-tree','--write-tree',head,'33bf08a746bd64306e0375f8d419af4744d31064'],capture_output=True);(r/'restore-merge-preview.txt').write_bytes(p.stdout+p.stderr);assert p.returncode in (0,1);print('first composition',head);print(p.stdout.decode())
d=r/'restore-join';assert not d.exists();d.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive',p.stdout.decode().splitlines()[0]))) as t:t.extractall(d,filter='data')
