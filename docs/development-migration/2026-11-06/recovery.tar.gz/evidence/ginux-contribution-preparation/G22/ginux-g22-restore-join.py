from pathlib import Path
import subprocess,re
r=Path('/tmp/ginux-contribution-preparation/G22');src=r/'restore-join';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a]).decode()
pat=re.compile(r'^<<<<<<< [^\n]*\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]*\n',re.M|re.S)
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();s,n=pat.subn(lambda m:'pub(crate) const OBJECTS: usize = 32;\n'+m[1],s);assert n==1
s=s.replace('for slot in 0..OBJECTS {','for slot in 0..self.fs.namespace_capacity() {',1).replace('''                if let Some((path, metadata)) = self.fs.overlay_entry(slot) {
                    archive.entry''','''                if let Some((path, metadata)) = self.fs.overlay_entry(slot) {
                    if metadata.links > 1 { return Err(b"hardlink archive identity is not implemented"); }
                    archive.entry''',1);p.write_text(s)
p=src/'scripts/test-launch-storage.py';s=p.read_text();ms=list(pat.finditer(s));assert len(ms)==2
for i,m in reversed(list(enumerate(ms))):
 t=m[2].replace("'quota', 'flush'","'quota', 'namespace', 'symlinks', 'ordinary-symlinks', 'flush'").replace("memory=16 if mode == 'bounds' else 256","memory=32 if mode == 'bounds' else (64 if mode == 'namespace' else 256)") if i==0 else m[1]+m[2]
 s=s[:m.start()]+t+s[m.end():]
p.write_text(s)
p=src/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();ms=list(pat.finditer(s));assert len(ms)==2
for i,m in reversed(list(enumerate(ms))):s=s[:m.start()]+m[1]+('}\n' if i==0 else '')+m[2]+s[m.end():]
p.write_text(s)
p=src/'crates/ginux-vfs/src/lib.rs';s=p.read_text();d=git('show','9e2a39e8:crates/ginux-vfs/src/lib.rs');a=d.index('    pub fn overlay_entry(');b=d.index('    fn overlay_metadata(',a);at=s.index('    pub fn overlay_entry(');bt=s.index('    /// Read a live writable regular file',at);s=s[:at]+d[a:b]+s[bt:]
a=d.index('    pub fn read_overlay(');b=d.index('    pub fn overlay_files(',a);at=s.index('    pub fn read_overlay(');bt=s.index('    pub fn overlay_files(',at);s=s[:at]+d[a:b]+s[bt:]
s=s.replace('for entry in &self.overlay {','for entry in self.overlay.iter() {').replace('for entry in &mut self.overlay {','for entry in self.overlay.iter_mut() {');p.write_text(s)
for p in src.rglob('*'):
 if p.is_file() and not p.is_symlink():assert b'<<<<<<< ' not in p.read_bytes(),p
print('joined current storage/mapping, links and startup restore; archive identity/scale remains G22')
