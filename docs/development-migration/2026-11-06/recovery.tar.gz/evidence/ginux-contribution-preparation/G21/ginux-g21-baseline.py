from pathlib import Path
import tempfile, subprocess, json, shutil, tarfile
r=Path('/tmp/ginux-contribution-preparation/G21');s=r/'source';binary='/tmp/ginux-contribution-preparation/G19/verified-head/target/x86_64-unknown-linux-gnu/release/ginux'
with tempfile.TemporaryDirectory(prefix='ginux-restore-baseline-') as name:
    w=Path(name);root=w/'root';(root/'bin').mkdir(parents=True);shutil.copyfile(s/'.artifacts/launch/launch-storage-fixture',root/'bin/fixture');(root/'bin/fixture').chmod(0o755)
    config=(s/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/fixture"').replace('args = []','args = ["export"]').replace('[storage]\nassignments = []','[storage]\nassignments = ["memory:/out"]')
    p=w/'config.toml';p.write_text(config);archive=w/'valid.tar'
    export=[binary,'launch',str(p),str(root),'--export-file',str(archive)];a=subprocess.run(export,capture_output=True,timeout=10);assert a.returncode==0,a.stderr.decode()
    with tarfile.open(archive) as t:assert t.extractfile('out/product').read()==b'result\0data'
    p.write_text(config.replace('args = ["export"]','args = ["restore"]'));result=w/'result.json'
    cmd=[binary,'launch',str(p),str(root),'--restore-file',str(archive),'--result-file',str(result)];b=subprocess.run(cmd,capture_output=True,timeout=10)
    (r/'baseline-restore.log').write_bytes(b.stderr);assert b.returncode==2 and b'launch usage:' in b.stderr and not result.exists()
    (r/'baseline-receipt.json').write_text(json.dumps({'base':'a36e76441b5a7c1a30b3461c9537bb3c6aee9d8e','valid_export_exit_code':a.returncode,'command':cmd,'exit_code':b.returncode,'behavior':'valid G19-produced archive; restore option rejected before startup'},indent=2)+'\n')
print('G19 produced valid archive but rejects startup restore as expected')
