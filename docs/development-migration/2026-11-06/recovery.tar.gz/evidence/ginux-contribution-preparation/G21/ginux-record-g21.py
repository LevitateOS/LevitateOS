from pathlib import Path
import json,hashlib,shutil
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G21');art=root/'.artifacts/ginux-contribution-preparation/G21'
m=json.loads((temp/'manifest.json').read_text())
for prefix in ['', 'clean-']:
    rs=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(rs)==4 and all(r['exit_code']==0 for r in rs)
static=[json.loads((temp/(prefix+'static-receipt.json')).read_text()) for prefix in ['final-','clean-']]
assert all(r['exit_code']==0 and r['matched_paths']==181 and r['head']==m['head'] for r in static)
assert static[0]['binary_sha256']==static[1]['binary_sha256']
fixtures={}
for name in ['launch-storage-fixture','launch-directory-fixture','launch-script-fixture','launch-owned-exec-fixture']:
    a=(temp/'source/.artifacts/launch'/name).read_bytes();b=(temp/'verified-head/.artifacts/launch'/name).read_bytes();assert a==b;fixtures[name]=hashlib.sha256(a).hexdigest()
m.update(status='source separately self-reviewed; selected ordinary source/clean checks pass; security/full CI/upstream independence pending',unit_tests=92,vfs_tests=34,clean_matched_paths=181,review='separate self-review; no independent reviewer/security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=static[0]['binary_sha256'],clean_binary_sha256=static[1]['binary_sha256'],fixture_sha256=fixtures)
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
    if p.is_file() and p.suffix in ['.json','.log','.patch','.diff']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g21*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G21.patch')
(art/'draft.md').write_text('''Restore filesystem snapshots before workload startup

Add --restore-file to reconstruct regular files, directories, modes and long
names in a fresh owned memory view before starting a workload. Bound archive
bytes/entries and configured capacity; preserve the input and discard failed
imports. Use existing storage ownership without a control-socket prerequisite.

Local build/static checks, 92 units, ordinary restore/restart/parent-order checks
and existing storage/mapping/exec controls pass in source and clean replay.
Adversarial archive validation, remote CI and upstream prerequisite merges are
pending. Not ready to submit.
''')
assert not any(s in (art/'draft.md').read_text() for s in ['LevitateOS','Recipe','Daybreak'])
(docs/'g21-review.md').write_text(f'''# G21 — startup filesystem restore

Head `{m['head']}`, tree `{m['tree']}`, on G19
`{m['base']}`. [Patch](patches/G21.patch): nine files, +482/-7.
Source and selected ordinary checks are retained; security, full CI and actual
upstream independence remain pending. G20 is not a dependency.

`--restore-file` reconstructs a fresh owned memory view before domain creation,
fork or workload startup. The donor bounded parser restores regular files,
directories, modes and GNU long names. It checks headers, total bytes, entry count,
canonical components and configured storage assignments. Existing VFS creation,
quota, write, chmod and close own the imported resources. Failure tears down the
new view and common completion cancels pending final export. The source is read
only and closed before workload execution. No existing filesystem is merged or
restored in place; exact two-block termination is the documented format.

Separate final self-review read the entire diff and current argv, startup/config,
completion/export, assignment, VFS inode/create/truncate/close/teardown callers.
This is self-review, not independent or security review.

- **False dependency removed:** donor restore checks were embedded in checkpoint
  tests. A focused restore runner now consumes ordinary G19 final export directly;
  no G20 CLI, control transport, event wait or guest channel is imported.
- **Owner adaptation:** donor lexical normalize is absent from the reviewed
  component-walker base. The parser already rejects noncanonical archive paths;
  restore uses the existing VFS owner without adding a parallel normalizer.
  The initial unresolved-import build failure is retained. The source retains
  the current 32-slot namespace, including assignment parents, rather than the
  donor's unrelated 4096-object change. G18/G22 scale joins remain explicit.
- **Cleanup:** restore errors explicitly tear down storage before startup failure.
  The read-only input has scoped close ownership. Adding O_NONBLOCK prevents a
  non-regular source blocking before fstat; no hostile FIFO/device probe ran.
- **Ordinary regression corrected:** the larger-data fixture initially assumed
  one read returns 8193 bytes and failed at the existing 4096-byte limit. It now
  loops over valid short reads and verifies EOF and all bytes. G25 remains separate.
  C indentation warnings were also fixed; initial failure logs are preserved.
- **Coverage:** the feature adds its Make target and Linux CI invocation while
  retaining static-and-unit and the existing fixture build. Donor rejection checks
  for corruption, traversal, links, duplicate entries, outside assignments and
  symlink input remain in the default runner; they were not executed locally.

Source and strict clean prerequisite-plus-patch replay pass make check test-unit
build and storage/directory/script/owned-exec fixture builds: 92 units, 34 VFS,
181 matching tracked paths. Ginux and all four fixture binaries match. Ordinary
checks reconstruct binary/empty files, modes and long paths; repeat fresh starts,
modify and re-export without changing the source, and restore 8193 bytes with a
child appearing before its parent directory. Existing seven flush/export/config,
two mapping, six ELF, 14 script and growth/bounds/quota controls pass in both copies.
Exact G19 produces the valid archive, but rejects --restore-file with usage exit2.
An initial baseline invocation lacked sudo and failed before chroot; the recorded
successful baseline rerun uses the required privilege.

Archive/path/collision/FD authority, hostile replacement, oversized input, quotas,
I/O/close failures and concurrent mutation require [DaybreakBlue](daybreakblue-handoff.md).
No such probes or cloud dispatch occurred. Independent review, full Linux suite,
macOS/remote CI and refreshed standalone validation are unrun. Symlink/hardlink,
dynamic namespace and combined checkpoint joins remain G22/F02; G07's inherited
shared-argument security limitation remains unresolved. Do not publish the local
prerequisite composition as a stack. F04 remains the user's review stop.

Patch, generic draft, commands, receipts, hashes and helpers live under
.artifacts/ginux-contribution-preparation/G21/. No real Ginux checkout, branch,
index/ref, remote text or maintainer message changed.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G21');row.update(m);row.update(evidence='g21-review.md',source_patch='patches/G21.patch')
row=next(x for x in plan['packets'] if x['packet']=='G31');row['restore_wiring']='Folded into G21 introducing packet; full/default/remote runtime unrun. G20 checkpoint wiring retained separately; combined join remains F02.'
p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\nG21 exact retained revision: {m['head']} on G19 {m['base']}.
92 routine units and selected ordinary restore/restart/data/mode/parent-order plus
export/mapping/exec/storage controls pass in source and clean replay. Default
malformed/traversal/duplicate/authority fixtures remain unrun. Independently
validate archive and assignment bounds, hostile input/replacement, resource and
close/read failures and shared-mutation behavior. No cloud dispatch or security
acceptance; [review/evidence](g21-review.md).\n''')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text();a=s.index('Exact next task: **G21');b=s.index('\nActive skill:',a);s=s[:a]+f'''G21 source/ordinary preparation is retained at `{m['head'][:8]}` directly on
G19{m['base'][:8]}, without a G20 dependency. [Review/evidence](ginux-contributions/g21-review.md)
records 92 units, 181-path strict replay and valid startup reconstruction, repeated
fresh launches, binary/empty/multi-chunk data, modes, long paths and child-before-
parent ordering, plus export/mapping/exec/storage controls, in source/clean copies.
The fixture now respects existing short reads; no G25 behavior is imported.
Essential G31 restore wiring is folded into its introducing packet. Exact G19
exports the archive but rejects restore. Security/full CI/upstream independence
and G18/G13/G15/G20 combined joins remain pending; no publication occurred.

Exact next task: **G22 — bounded archives with link identity**.
Inspect e3374593 and join only the reviewed G13/G15/G18/G21 storage/archive owners
in a disposable composition. Preserve G19 staging/publication and G21 startup
cleanup, without importing G20 or held thread/policy capabilities accidentally.
Review alias/symlink identity and dynamic capacity in the shared owners; run
ordinary archive roundtrips/scale as resources permit. Record hostile paths,
forward aliases, conflicting metadata, oversized/malformed input and races for
DaybreakBlue instead of executing security probes. No publication or maintainer
messages before F04.
''' +s[b:];p.write_text(s);print('retained',m['head'])
