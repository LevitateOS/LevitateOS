from pathlib import Path
root=Path('/tmp/ginux-contribution-preparation/G21/source')
p=root/'crates/ginux-init/src/storage_restore.rs';s=p.read_text().replace('            0x80000 | 0x20000,','            // O_NONBLOCK prevents a non-regular source blocking before fstat.\n            0x80000 | 0x20000 | 0x800,',1);p.write_text(s)
p=root/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();a=s.index('long storage_main(');s=s[:a]+'''static long restore_data(int large) {
    if(large) {
        long fd=DO(2,"/out/nested/data",0,0); CHECK(fd==3,220);
        CHECK(DO(0,fd,output,sizeof output)==8193,221);
        for(word i=0;i<8193;++i) CHECK(output[i]==(char)(i%251),222);
        CHECK(DO(3,fd,0,0)==0,223);
        CHECK(DO(4,"/out/nested",meta,0)==0 && (*(word *)(meta+24)&0777)==0700,224);
    } else {
        long fd=DO(2,"/out/product",0,0); CHECK(fd==3,225);
        CHECK(DO(0,fd,output,sizeof output)==11,226);
        const char expected[]="result\\0data";
        for(word i=0;i<11;++i) CHECK(output[i]==expected[i],227);
        CHECK(DO(5,fd,meta,0)==0 && (*(word *)(meta+24)&0777)==0700 && DO(3,fd,0,0)==0,228);
        CHECK(DO(4,"/out/empty",meta,0)==0 && (*(word *)(meta+24)&0170000)==0040000,229);
        CHECK(DO(2,"/out/empty-file",0,0)==3 && DO(0,3,output,1)==0 && DO(3,3,0,0)==0,230);
        char path[208]="/out/";
        for(word i=5;i<125;++i) path[i]='a'; path[125]='/';
        for(word i=126;i<206;++i) path[i]='b'; path[206]=0;
        CHECK(DO(2,path,0,0)==3 && DO(0,3,output,4)==4 && output[0]=='l' && DO(3,3,0,0)==0,231);
        CHECK(DO(2,"/out/product",01001,0600)==3 && DO(1,3,"changed",7)==7 && DO(3,3,0,0)==0,232);
    }
    CHECK(DO(1,1,"restored: PASS\\n",15)==15,233); return 0;
}
'''+s[a:];needle='    char **argv = (char **)(stack + 1);';s=s.replace(needle,needle+'\n    if(argc>1 && equal(argv[1],"restore")) return restore_data(0);\n    if(argc>1 && equal(argv[1],"restore-large")) return restore_data(1);',1);p.write_text(s)
p=root/'Makefile';s=p.read_text();s+='\n.PHONY: test-launch-restore\ntest-launch-restore:\n\tpython3 scripts/test-launch-restore.py $(GINUX) .artifacts/launch/launch-storage-fixture\n';p.write_text(s)
p=root/'.github/workflows/check.yml';s=p.read_text().replace('      - run: sudo make test-launch-storage','      - run: sudo make test-launch-storage\n      - run: sudo make test-launch-restore',1);p.write_text(s)
p=root/'README.md';s=p.read_text().replace('retained storage, checkpoint/restore, symlink or hardlink archive support.','retained storage, live checkpoint control, symlink or hardlink archive support.');s+='''
`--restore-file <snapshot tar>` imports owned files before workload startup. It
restores regular files, directories, permission bits and GNU long names into the
new memory view. The current32-slot namespace (including prepared assignment
parents), configured byte capacity and2 GiB archive payload bound all apply.
The input must be a bounded regular file opened without following a symlink;
import never changes it. Invalid paths, duplicate entries, links, invalid metadata,
checksums/terminators and truncated data fail launch and discard the new view.
The archive must have exactly two zero terminator blocks and no trailing data.
This is filesystem reconstruction, without process memory, handles or matching
runtime state; the host must select and verify the intended snapshot. It does
not require a checkpoint control socket.
''';p.write_text(s)
print('G21 restore workload, Make/CI wiring and bounded-contract docs added')
