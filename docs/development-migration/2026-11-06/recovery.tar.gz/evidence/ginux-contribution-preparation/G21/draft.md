Restore filesystem snapshots before workload startup

Add --restore-file to reconstruct regular files, directories, modes and long
names in a fresh owned memory view before starting a workload. Bound archive
bytes/entries and configured capacity; preserve the input and discard failed
imports. Use existing storage ownership without a control-socket prerequisite.

Local build/static checks, 92 units, ordinary restore/restart/parent-order checks
and existing storage/mapping/exec controls pass in source and clean replay.
Adversarial archive validation, remote CI and upstream prerequisite merges are
pending. Not ready to submit.
