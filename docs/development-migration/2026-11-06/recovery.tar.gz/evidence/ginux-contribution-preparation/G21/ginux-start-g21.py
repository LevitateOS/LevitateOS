from pathlib import Path
import subprocess,tarfile,io,json
root=Path('/tmp/ginux-contribution-preparation/G21');root.mkdir(exist_ok=True);src=root/'source';assert not src.exists();src.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='a36e76441b5a7c1a30b3461c9537bb3c6aee9d8e'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(src,filter='data')
(root/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G19 export/storage owner'],'source':['1d9e00e05627791b0da193240319342bc4932b8b'],'excluded':['G20 control transport','G07 thread groups','G18 dynamic namespace','G13/G15/G22 link archive support']},indent=2)+'\n')
p=src/'crates/ginux-init/src/storage_restore.rs';s=git('show','1d9e00e0:crates/ginux-init/src/storage_restore.rs').decode();p.write_text(s)
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text().replace('const OBJECTS: usize = 32;','pub(crate) const OBJECTS: usize = 32;',1);d=git('show','1d9e00e0:crates/ginux-init/src/fs_hooks.rs').decode();a=d.index('    pub fn restore_entry(');b=d.index('    pub fn export(',a);s=s.replace('    pub fn export(',d[a:b]+'    pub fn export(',1);s=s.replace('    BaseReader, Entry, Executable,','    normalize, BaseReader, Entry, Executable,',1);p.write_text(s)
p=src/'crates/ginux-init/src/launch.rs';s=p.read_text().replace('Launch(*const u8, *const u8, *const u8, *const u8),','Launch(*const u8, *const u8, *const u8, *const u8, *const u8),',1).replace('        let mut export_path: *const u8 = core::ptr::null();','        let mut export_path: *const u8 = core::ptr::null();\n        let mut restore_path: *const u8 = core::ptr::null();',1)
s=s.replace('''            } else {
                return Some(Command::LaunchUsage);
            }
            i += 2;''','''            } else if c_string_equals(option, b"--restore-file") && restore_path.is_null() {
                restore_path = value;
            } else {
                return Some(Command::LaunchUsage);
            }
            i += 2;''',1).replace('            export_path,\n        ))','            export_path,\n            restore_path,\n        ))',1).replace('    export_path: *const u8,\n) -> ! {','    export_path: *const u8,\n    restore_path: *const u8,\n) -> ! {',1)
needle='''    let mut channels = crate::channel_hooks::LaunchChannels::new();'''
s=s.replace(needle,'''    if let Err(reason) = crate::storage_restore::restore(restore_path, &mut filesystem) {
        filesystem.teardown();
        launch_startup_fail(reason);
    }
'''+needle,1).replace('[--export-file <fresh tar path>]"','[--export-file <fresh tar path>] [--restore-file <snapshot tar>]"');p.write_text(s)
p=src/'crates/ginux-init/src/main.rs';s=p.read_text().replace('mod storage_memory;','mod storage_memory;\nmod storage_restore;',1).replace('Some(Command::Launch(config_path, root_path, result_path, export_path))','Some(Command::Launch(config_path, root_path, result_path, export_path, restore_path))',1).replace('launch_main(config_path, root_path, result_path, export_path)','launch_main(config_path, root_path, result_path, export_path, restore_path)',1);p.write_text(s)
print('G21 startup restore port directly on G19; no control dependency')
