Poll owned descriptors through their registered owners

Resolve up to16 configured-launch public descriptors using pipe, assigned file/
null and inherited console owners. Park for object progress or bounded deadlines,
snapshot the layout across retries and use checked internal monotonic time.
Shared native syscall and guest clock policy stay unchanged.

Local static/build checks and82 units pass in source and clean prerequisite
replay, plus ordinary mixed descriptors, pipe wakeups, aliases, EOF and timers.
Full/default runtime, thread integration, readiness policy and remote CI remain
pending. Not ready to submit.
