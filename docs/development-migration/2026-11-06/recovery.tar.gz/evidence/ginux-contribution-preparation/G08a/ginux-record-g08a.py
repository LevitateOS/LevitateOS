from pathlib import Path
import subprocess,json,shutil
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G08a');art=root/'.artifacts/ginux-contribution-preparation/G08a';assert not (docs/'g08a-review.md').exists();m=json.loads((temp/'manifest.json').read_text());stats=[json.loads((temp/(p+'static-receipt.json')).read_text()) for p in ['final-','clean-']];assert all(x['exit_code']==0 and x['head']==m['head'] and x['matched_paths']==170 and x['unit_tests']==82 for x in stats);assert stats[0]['binary_sha256']==stats[1]['binary_sha256'] and stats[0]['fixture_sha256']==stats[1]['fixture_sha256']
for prefix in ['', 'clean-']:assert json.loads((temp/(prefix+'functional-receipt.json')).read_text())['exit_code']==0
assert json.loads((temp/'baseline-receipt.json').read_text())['exit_code']==71
m.update(status='minimal per-process readiness source/clean preparation and separate self-review retained; G08 full task partial: socketpairs/FIONBIO/thread join, policy/security/full CI pending',unit_tests=82,clean_matched_paths=170,review='separate whole-diff self-review; no independent or adversarial acceptance',source_binary_sha256=stats[0]['binary_sha256'],clean_binary_sha256=stats[1]['binary_sha256'],fixture_sha256=stats[0]['fixture_sha256'],security_handoff='daybreakblue-handoff.md',remote_ci='not run',evidence='g08a-review.md',source_patch='patches/G08a.patch')
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.patch','.diff','.txt']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g08a*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G08a.patch')
(art/'draft.md').write_text('''Poll owned descriptors through their registered owners

Resolve up to16 configured-launch public descriptors using pipe, assigned file/
null and inherited console owners. Park for object progress or bounded deadlines,
snapshot the layout across retries and use checked internal monotonic time.
Shared native syscall and guest clock policy stay unchanged.

Local static/build checks and82 units pass in source and clean prerequisite
replay, plus ordinary mixed descriptors, pipe wakeups, aliases, EOF and timers.
Full/default runtime, thread integration, readiness policy and remote CI remain
pending. Not ready to submit.
''')
(docs/'g08a-review.md').write_text(f'''# G08a — minimal per-process public readiness prerequisite

Head `{m['head']}`, tree `{m['tree']}`, on G06b `{m['base']}`.
[Patch](patches/G08a.patch):12 files,+434/-10. Extracted from210a8cca while tracing
G29's actual readiness dependency. This is partial G08 preparation, not a new PR
or completion of socket-pair/thread/readiness policy acceptance.

Existing descriptor/backends own all queries. A bounded128-byte poll layout holds
up to16 entries and snapshots once across parked retries. Pipes supply live
buffer/peer status, assigned files/null immediate readiness, console aliases only
the inherited0–2 OFDs. Image FDs are unsupported rather than applied to matching
host numbers. Error/HUP bits ignore the requested mask; output writes only revents.
Timeout0–300000 ms and negative infinite waits use checked internal monotonic
arithmetic; finite/console waits use the donor's1 ms nonbusy sleep tick. Other
owned waits wake on actual object/death progress. General nonfatal signal
interruption/restart is explicitly unfinished.

The current G06b table is per-process, so poll state belongs there without G07's
shared-FD/thread transaction architecture. Fork initializes fresh call state;
finish/death clears it. Typed death accounting remains the owner if a stopped
caller disappears during retry/resume. No guest clock/core-native rule, socket
pair, FIONBIO, G28/TCP or unrelated filesystem/mapping behavior is imported.
G07 shared-table pinning/call ownership and G20 event-wait composition remain F02
joins. #179/#207 policy is unchanged and still holds publication.

Separate full-diff self-review read all12 changed files and the current public
FD alias/fork/close/finish owners, inherited console assumptions, backend readiness,
strict copies, timer/death/wake paths, complete fixture/default cases and CI.
This is self-review, not independent or adversarial review.

- **Dependency correction:** G29 needs readiness, not every G07/thread or G08
  socket-pair ancestor. This coherent prerequisite is retained separately on
  the existing G06b owner; no public stack is proposed.
- **Snapshot correction:** parked queries retain the initial descriptor/event
  layout instead of rereading mutable guest arrays on every retry. Race/fault
  validation remains with DaybreakBlue; no adversarial reproducer ran here.
- **Arithmetic correction:** internal nanosecond conversion/addition is checked,
  without changing global release overflow policy or granting guest clocks.
- **Coverage preserved:** donor full/default invalid-pointer/authority/kill cases
  remain in the new poll target; existing tests/targets are untouched. Essential
  fixture build/run wiring is included in Linux CI. Local mode selection reports
  only the ordinary scenarios actually run.

Source and strict clean base-plus-patch replay pass make check test-unit build
build-launch-poll-fixture:82 units,170 tracked paths matched, identical Ginux/
fixture hashes. Five ordinary modes in both copies cover live pipe/memory/null/
console-alias mixed queries, preserved input fields, duplicate writer lifetime,
buffered data with HUP, EOF, blocked read/write peer wakeups and60 ms timers.
Real fork/wait/death paths are exercised by those peer cases. Exact G06b fails
first ordinary pipe readiness and exits71. No protected arrays, foreign FD probes,
proc/FD inspection or hostile races ran in these selected checks.

[DaybreakBlue](daybreakblue-handoff.md) owns protected/mutable arrays, partial
copyout, unknown/native authority, layout/FD reuse and shared-thread races,
cancellation/interruption/rollback and failure/clock boundary probes. Full/default
Linux runtime, macOS/remote CI, independent review, thread/event-owner joins,
#179/#207 disposition and current-main independence remain pending. G08's original
socket-pair/FIONBIO/nested compiler streams and G29 network/HTTP/TLS/Git acceptance
remain open. No cloud dispatch occurred.

Patch/draft/commands/receipts/hashes/helpers live in
.artifacts/ginux-contribution-preparation/G08a/. Real Ginux branches/indexes/refs/
checkouts and remote human text remain intact. Nothing published; F04 remains the
user inspection boundary.
''')
# Retain source-only G29 findings without claiming implementation or validation.
pre=docs/'g29-review.md';assert not pre.exists();pre.write_text(f'''# G29 — configured TCP integration (in progress)

Source reviewed so far:66de28808afd59808d6c0180a376629e41478a9c. No G29 candidate
has been extracted or runtime-validated yet. G08a `{m['head']}` supplies the
minimal per-process public readiness owner; G28 `0a3cf5f5` supplies the TCP backend.
Next compose those exact prerequisites, preserving their own source/CI/tests.
This needs no G07/thread, G02 guest clocks, G26 resources, archive or scalar native
clamp ancestry. Full source review, fixes and all G29 acceptance remain open.

Initial source findings to fix during extraction (no adversarial probes run):

- **High — receive ownership/copyout:** network_hooks.rs preflights receive buffers
  with copyin and writeback, consumes/charges a backend read, then copies to the
  guest without retaining undelivered bytes. It unnecessarily reads/touches the
  destination before I/O and can lose received data if final copyout fails/shortens.
  Reuse the canonical bounded vector/copy owner and retain a bounded per-socket
  received prefix until successfully delivered. EOF/zero transfers must avoid
  needless destination access; staged data must also participate in readiness.
- **High — asynchronous connection state:** SO_ERROR reads consume the native
  error, but the donor does not retain failed connection state. A later connect
  retry may see zero and incorrectly commit connected. Centralize completion and
  retain failure separately from the consumable getsockopt error result.
- **Review needed — vector/SIGPIPE semantics:** donor network vector parsing is
  separate from the later G25 helper and clamps lengths without its aggregate
  validation. Reuse that owner without importing regular-file/pwrite ancestry.
  Check guest SIGPIPE for writes without MSG_NOSIGNAL while keeping the supervisor
  protected; read/write partial effects, timeout and error mapping remain open.

Carry G24's later network Stat nlink/timestamp initialization at F02 if those fields
are absent from the minimal base; do not pull the entire archive/time stack solely
for them. Resolve shared config/FD/task/readiness joins and preserve all default
security fixtures/CI. Ordinary controlled HTTP/TLS/Git and all final consumer
closure remain unrun. #179/network policy and [DaybreakBlue](daybreakblue-handoff.md)
security acceptance remain held. No publication or maintainer messages.
''')
g29temp=Path('/tmp/ginux-contribution-preparation/G29');g29temp.mkdir(exist_ok=True);g29art=root/'.artifacts/ginux-contribution-preparation/G29';g29art.mkdir(parents=True,exist_ok=True);source=subprocess.check_output(['git','-C','/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux','show','66de2880:crates/ginux-init/src/network_hooks.rs']);(g29temp/'network_hooks-donor.rs').write_bytes(source);shutil.copyfile(g29temp/'network_hooks-donor.rs',g29art/'network_hooks-donor.rs');shutil.copyfile(pre,g29art/'preflight.md')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G08');row.update(status='partial source prep: G08a per-process readiness retained for G29; original socketpairs/FIONBIO/thread and policy/security/full CI still pending',subpackets=['G08a'],evidence='g08a-review.md');assert not any(x['packet']=='G08a' for x in plan['packets']);plan['packets'].append({**m,'purpose':'Minimal per-process public poll readiness','source_commits':['210a8cca92265385b5f59081d053ecaf6eef1e77'],'artifact_directory':'.artifacts/ginux-contribution-preparation/G08a','acceptance':'See original G08 plus split scope/evidence and pending checks in g08a-review.md'})
row=next(x for x in plan['packets'] if x['packet']=='G29');row.update(status='in progress: traced minimal G08a/G28 prerequisites and recorded source receive/connection-state findings; no G29 candidate/runtime yet',dependencies=['G08a','G28'],evidence='g29-review.md',deferred_joins=['G07 shared-table/thread ownership and security','G24 socket Stat nlink/times at F02','actual combined consumers at F02/F03']);p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'p04-dependencies.md';p.write_text(p.read_text()+f'''\nG29 tracing requires the G08 readiness owner but not its full thread/socketpair
ancestry. G08a `{m['head'][:8]}` is now prepared on G06b only:82 units and ordinary
source/clean poll/peer/timer checks pass; socketpairs/FIONBIO/thread/policy/security
and full CI stay open. G29's next local composition is G08a+G28. Its receive-copy,
SO_ERROR state and vector/SIGPIPE review findings remain unfixed source findings;
[readiness review](g08a-review.md), [G29 progress](g29-review.md).
''')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\n## G08a readiness prerequisite and G29 source findings

G08a `{m['head']}` on G06b `{m['base']}` passes82 units and
five ordinary source/clean poll modes (live/mixed/aliases, read/write/HUP peers,
EOF and timer). Poll input is now snapshotted across retries with checked internal
time arithmetic. Default protected-array/authority/kill cases remain enabled but
unrun; no proc/FD inspection or hostile probes were executed locally.
DaybreakBlue must validate protected/mutable poll buffers and partial output,
unknown/native/closed/reused FD authority, thread/call snapshots, interruption/
cancellation/death races, rollback and clock/bounds failures. #179/#207 and full
runtime/remote CI remain pending; no cloud dispatch.

G29 has source-only receive ownership/copyout and consumed SO_ERROR/state findings,
plus vector/SIGPIPE review work, in [G29 progress](g29-review.md). No G29 extraction
or runtime evidence exists yet. During later validation, route hostile endpoint,
buffer, FD/assignment bypass and network/race/failure probes here. Ordinary local
HTTP/TLS/Git remains authorized. [G08a evidence](g08a-review.md).
''')
p=root/'docs/ginux-contribution-task-list.md';t=p.read_text();a=t.index('Exact next task: **G29');b=t.index('\nActive skill:',a);t=t[:a]+f'''G29 tracing exposed its actual G08 readiness prerequisite. Minimal G08a
`{m['head'][:8]}` on G06b is now source-prepared separately: [review/evidence](ginux-contributions/g08a-review.md)
records82 units,170-path strict replay and five ordinary poll/peer/alias/EOF/timer
modes passing in source/clean. Poll layouts are snapshotted and internal arithmetic
checked. No thread/socketpair/FIONBIO, guest clock or shared native poll policy is
imported. G08's remaining scope/security/#179/#207/full CI remain open.
[G29 progress](ginux-contributions/g29-review.md) records unfixed source receive
copyout/retained-data and consumed-SO_ERROR state findings. G29 itself has no
candidate or runtime validation yet; it is not complete.

Exact next task: **continue G29 — compose G08a+G28 and extract TCP integration**.
Use G08a `{m['head']}` plus G28 `0a3cf5f5ab7e77080eb9491cb6bffd5ba642cb68`;
retain prerequisite test/CI ownership in an unreferenced local composition. Port
66de2880 config/device/FD/network joins against those per-process owners. Reuse
G25's bounded IoVectors helper without regular-file/pwrite ancestry; fix receive
staging/partial copyout and async connect/error state before runtime validation.
Review SIGPIPE/timeout/alias cleanup. Carry G24 Stat fields when their owner joins
at F02 rather than importing archives now. Keep policy/security holds, preserve
all negative/default fixtures, and use only trusted local ordinary HTTP/TLS/Git
checks. Preserve G08 and G23–G28/F02/F03 acceptance. No publication or maintainer
messages before F04.
''' +t[b:];p.write_text(t);print('saved readiness prerequisite',m['head'],'G29 still in progress')
