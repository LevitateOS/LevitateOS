from pathlib import Path
s=Path('/tmp/ginux-contribution-preparation/G08a/source')
p=s/'crates/ginux-init/src/descriptors.rs';t=p.read_text();t=t.replace('    poll_deadline: Option<u64>,','    poll_deadline: Option<u64>,\n    poll_input: [u8; 128],');t=t.replace('            poll_deadline: None,','            poll_deadline: None,\n            poll_input: [0; 128],');old='''        if copy_memory(pid, r.rdi, &mut bytes[..length], false)? != length as i64 {
            return Err(-14);
        }''';assert old in t;t=t.replace(old,'''        if self.poll_wait {
            bytes = self.poll_input;
        } else {
            if copy_memory(pid, r.rdi, &mut bytes[..length], false)? != length as i64 {
                return Err(-14);
            }
            self.poll_input = bytes;
        }''',1);p.write_text(t)
p=s/'tests/fixtures/launch-poll-fixture.c';t=p.read_text();old="    if (mode=='t') {";assert old in t;t=t.replace(old,'''    if (mode=='o') {
        if(argv[1][8]=='-') {
            CHECK(DO(7,0,0,60)==0,70);
        } else {
            CHECK(query(pipe[0],1,0) && query(pipe[1],4,4),71);
            long moved=DO(32,1,0,0);CHECK(moved>=3 && query(moved,4,4),72);
            long file=DO(2,"/work/data",0102,0600), null=DO(2,"/dev/null",2,0);
            CHECK(file>=3 && null>=3 && query(file,0x145,0x145) && query(null,0x145,0x145),73);
            struct pollfd mixed[3]={{pipe[0],1,99},{(int)moved,4,99},{(int)file,1,99}};
            CHECK(DO(7,mixed,3,0)==2 && mixed[0].revents==0 && mixed[1].revents==4 && mixed[2].revents==1,74);
            long writer=DO(32,pipe[1],0,0);CHECK(writer>=3 && DO(3,pipe[1],0,0)==0,75);
            CHECK(DO(1,writer,"X",1)==1 && query(pipe[0],1,1),76);
            CHECK(DO(3,writer,0,0)==0 && query(pipe[0],1,17),77);
            CHECK(DO(0,pipe[0],buffer,1)==1 && buffer[0]=='X' && query(pipe[0],1,16),78);
            CHECK(DO(3,pipe[0],0,0)==0 && DO(3,moved,0,0)==0 && DO(3,file,0,0)==0 && DO(3,null,0,0)==0,79);
        }
    } else if (mode=='t') {''');p.write_text(t)
p=s/'scripts/test-launch-poll.py';t=p.read_text().replace('if len(sys.argv) != 3','if len(sys.argv) < 3').replace('for p in sys.argv[1:]]','for p in sys.argv[1:3]]');old="        for mode in ('all', 'read', 'write', 'hup', 'deadline', 'timer', 'console', 'kill', 'infinite-kill', 'all-again'):";assert old in t;t=t.replace(old,"""        selected = sys.argv[3:]
        if selected and any(mode not in ('ordinary', 'read', 'write', 'hup', 'ordinary-timer') for mode in selected):
            sys.exit('unknown selected poll scenario')
        for mode in selected or ('all', 'read', 'write', 'hup', 'deadline', 'timer', 'console', 'kill', 'infinite-kill', 'all-again', 'ordinary', 'ordinary-timer'):""");t=t.replace("            if mode == 'timer':", "            if mode in ('timer', 'ordinary-timer'):");p.write_text(t)
print('trusted ordinary poll selection and stable parked-array snapshot added')
