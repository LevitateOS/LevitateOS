from pathlib import Path
import subprocess,json
r=Path('/tmp/ginux-contribution-preparation/G08a')
for directory,prefix in [('source',''),('verified-head','clean-')]:
 s=r/directory;cmd=['sudo','-n','python3','scripts/test-launch-poll.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-poll-fixture','ordinary','read','write','hup','ordinary-timer']
 with (r/(prefix+'functional.log')).open('w') as f:p=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
 (r/(prefix+'functional-receipt.json')).write_text(json.dumps({'command':cmd,'exit_code':p.returncode},indent=2)+'\n');print(directory,p.returncode,flush=True);assert p.returncode==0
