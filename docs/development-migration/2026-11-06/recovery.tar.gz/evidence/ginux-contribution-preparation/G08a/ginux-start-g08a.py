from pathlib import Path
import subprocess,tarfile,io,json
r=Path('/tmp/ginux-contribution-preparation/G08a');r.mkdir(exist_ok=True);s=r/'source';assert not s.exists();s.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='8c783e717b839b0e511820e89d29840cae0f3c0c'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(s,filter='data')
(r/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G06b'],'source':['210a8cca92265385b5f59081d053ecaf6eef1e77'],'reason':'G29 requires public readiness and timed/external wakeups; extract minimal existing G08 owner first','excluded':['G07 thread/shared FD table','G08 socket pairs/FIONBIO','G02 guest clocks','G01 shared native poll policy','network backend/TCP'],'policy':'#179/#207 configured polling contract remains held; local preparation only'},indent=2)+'\n')
# Readiness is provided by existing owning backends.
for file,start,end,needle in [
 ('channel_hooks.rs','    /// Current readiness','    fn entry(', '    fn entry('),
 ('device_hooks.rs','    pub fn readiness(', '    pub fn prepare(', '    pub fn prepare('),
 ('fs_hooks.rs','    pub fn readiness(', '    fn owns_path(', '    fn owns_path(')]:
 p=s/'crates/ginux-init/src'/file;t=p.read_text();donor=git('show','210a8cca:crates/ginux-init/src/'+file).decode();a=donor.index(start);b=donor.index(end,a);assert needle in t;t=t.replace(needle,donor[a:b]+needle,1);p.write_text(t)
p=s/'crates/ginux-init/src/descriptors.rs';t=p.read_text().replace('use crate::supervisor::{syscall3, syscall4, UserRegs};','use crate::supervisor::{syscall2, syscall3, syscall4, UserRegs};');t=t.replace('    saved_args: Option<[u64; 7]>,\n}', '    saved_args: Option<[u64; 7]>,\n    poll_wait: bool,\n    poll_tick: bool,\n    poll_deadline: Option<u64>,\n}');t=t.replace('            saved_args: None,','            saved_args: None,\n            poll_wait: false,\n            poll_tick: false,\n            poll_deadline: None,');t=t.replace('        self.saved_args = None;','        self.saved_args = None;\n        self.poll_wait = false;\n        self.poll_tick = false;\n        self.poll_deadline = None;');t=t.replace('        let mut changed = false;','        self.poll_wait = false;\n        self.poll_tick = false;\n        self.poll_deadline = None;\n        let mut changed = false;',1);idx=t.index('    pub fn fork_copy(');t=t[:idx]+'''    pub fn needs_poll_tick(&self) -> bool {
        self.poll_tick
    }

''' +t[idx:];needle='            _ => Ok(backends.claim(pid, r)),';assert needle in t;t=t.replace(needle,'            7 => self.poll(pid, r, backends),\n'+needle,1);donor=git('show','210a8cca:crates/ginux-init/src/descriptors.rs').decode();a=donor.index('    fn poll(');b=donor.index('\nfn ready(',a);body=donor[a:b];a2=body.index('\n}\n\n#[derive(Clone, Copy)]');method=body[:a2];extras=body[a2+3:];method=method.replace('        &self,','        &mut self,',1).replace('        call: &mut DescriptorCall,\n','').replace('call.poll_', 'self.poll_');method=method.replace('Some(now + timeout as u64 * 1_000_000)', 'Some(now.checked_add(timeout as u64 * 1_000_000).ok_or(-22)?)');extras=extras.replace('    Ok(time[0] * 1_000_000_000 + time[1])','    time[0].checked_mul(1_000_000_000)\n        .and_then(|seconds| seconds.checked_add(time[1]))\n        .ok_or(-5)');idx=t.index('\n}\n\nfn ready(');t=t[:idx]+'\n'+method+t[idx:];idx=t.index('\nfn ready(');t=t[:idx]+'\n'+extras+t[idx:];p.write_text(t)
p=s/'crates/ginux-init/src/dispatch.rs';t=p.read_text().replace('    Park { fd: u32 },','    Park { fd: u32 },\n    /// A public-descriptor query waits for object readiness or a deadline.\n    ParkPoll,');p.write_text(t)
p=s/'crates/ginux-init/src/main.rs';t=p.read_text().replace('NativeDecision::Park { .. } => {','NativeDecision::Park { .. } | NativeDecision::ParkPoll => {');p.write_text(t)
p=s/'crates/ginux-init/src/launch_tasks.rs';t=p.read_text();donor=git('show','210a8cca:crates/ginux-init/src/launch_tasks.rs').decode();a=donor.index('    let mut poll_tick = 0;');b=donor.index('        s.wake(domain);',a);prefix=donor[a:b].replace('t.call.needs_poll_tick()','t.descriptors.needs_poll_tick()');needle='    loop {\n        s.wake(domain);';assert needle in t;t=t.replace(needle,prefix+'        s.wake(domain);',1).replace('                WALL,\n                0,','                WALL | usize::from(polling),\n                0,',1);a=donor.index('        if host == 0 {',b);b=donor.index('        if host < 0 {',a);needle='        if host < 0 {\n            s.fail(domain, b"launch task wait failed")';assert needle in t;t=t.replace(needle,donor[a:b]+needle,1)
for start,end in [('    fn resume(', '    fn emulate(')]:
 a=donor.index(start);b=donor.index(end,a);old_a=t.index(start);old_b=t.index(end,old_a);t=t[:old_a]+donor[a:b]+t[old_b:]
t=t.replace('            NativeDecision::Park { fd } => {','            NativeDecision::ParkPoll => {\n                self.task_mut(index).blocked = Some(original);\n                audit_write(b"park surface=owned-poll\\n");\n            }\n            NativeDecision::Park { fd } => {',1);t=t.replace('// Only object operations and observed deaths can satisfy these waits.\n        // Other tasks\' register/signal/fork stops do not change readiness.','// Object operations, observed deaths and readiness ticks retry parked calls.');p.write_text(t)
for name in ['scripts/test-launch-poll.py','tests/fixtures/launch-poll-fixture.c']:(s/name).write_bytes(git('show','210a8cca:'+name))
p=s/'Makefile';t=p.read_text();donor=git('show','210a8cca:Makefile').decode();t+='\n'+donor[donor.index('.PHONY: build-launch-poll-fixture'):];p.write_text(t)
p=s/'.github/workflows/check.yml';t=p.read_text().replace(' build-gate1-fixture\n',' build-gate1-fixture build-launch-poll-fixture\n');t+='      - run: sudo make test-launch-poll\n';p.write_text(t)
p=s/'README.md';t=p.read_text();t+='''
Configured `poll` resolves at most16 public descriptors through their existing
owners: pipes, assigned memory files/null and inherited console aliases. Negative
descriptors are ignored; closed descriptors report POLLNVAL. Image files remain
unsupported for this operation. Error/hangup bits are reported independently of
the requested mask. Zero through300000 ms and negative infinite waits are
supported. Queries park and wake on object progress; finite/console waits also
use a1 ms supervisor tick. Internal monotonic time does not enable guest clocks.
General nonfatal signal interruption/restart remains unfinished. The shared
native syscall contract is unchanged; this is configured-launch readiness.
''';p.write_text(t)
print('G08a minimal per-process readiness owner prepared on G06b')
