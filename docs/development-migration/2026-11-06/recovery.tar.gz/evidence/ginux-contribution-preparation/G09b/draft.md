Title: Grow configured memory files within a shared allocation bound

Replace fixed 64 KiB file arrays with anonymous supervisor mappings. Files share
a mapped-capacity bound from resources.memory_mib; truncate/final close reclaim
pages, sparse/regrown bytes are zero, and exhausted allocations preserve state.
Keep the existing object/descriptor limits. Include the reviewed VFS storage
owner in this feature rather than proposing an abstraction without its consumer.

Validation: 85 units, static checks/build and three selected real storage
scenarios pass in source and clean replay. Growth fails on the exact prerequisite
binary. Full runtime/security checks and macOS Actions remain pending. Publication
waits for upstream prerequisites and user inspection.
