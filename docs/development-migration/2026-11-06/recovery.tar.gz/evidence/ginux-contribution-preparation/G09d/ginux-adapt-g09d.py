from pathlib import Path
import subprocess,re
root=Path('/tmp/ginux-contribution-preparation/G09d/source');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def donor(commit,file):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'show',commit+':'+file]).decode()
def function(text,name):
 m=re.search(r'^    (?:pub(?:\([^)]*\))? )?fn '+name+r'\b',text,re.M);assert m,name
 a=text.index('{',m.start());depth=1;i=a+1
 while depth:
  depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[m.start():i]+'\n'
p=root/'crates/ginux-init/src/descriptors.rs';s=p.read_text();old=function(s,'path_descriptor');new=function(donor('9ba6a1d4','crates/ginux-init/src/descriptors.rs'),'path_descriptor');new=new.replace('''    ) -> Result<NativeDecision, i64> {''','''    ) -> Result<NativeDecision, i64> {''');s=s.replace(old,new+'\n'+function(donor('9ba6a1d4','crates/ginux-init/src/descriptors.rs'),'path_handle')+'\n'+function(donor('9ba6a1d4','crates/ginux-init/src/descriptors.rs'),'rename_paths'))
s=s.replace('''            258 | 262 | 263 | 268 | 269 | 332 | 439 => {''','''            264 | 316 => {
                self.save(r);
                self.rename_paths(pid, r, backends)
            }
            258 | 262 | 263 | 267 | 268 | 269 | 332 | 439 => {''');p.write_text(s)
p=root/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();s=s.replace('O_EXCLUSIVE, O_READ,','O_EXCLUSIVE, O_NONBLOCK, O_READ,');s=s.replace('    cwd: Path,\n','').replace('''            cwd: Path::from_bytes(config.workdir.as_bytes())
                .map_err(|_| b"storage workdir exceeds bound".as_slice())?,
''','')
old='''        if !absolute && dirfd as i32 != -100 {
            return Err(if dirfd as i32 >= FD_BASE as i32 {
                -20
            } else {
                -9
            });
        }
        let mut bytes = [0; MAX_PATH];
        let base = if absolute {
            b"".as_slice()
        } else {
            self.cwd.as_bytes()
        };'''
new='''        let cwd;
        let base = if absolute {
            b"".as_slice()
        } else if dirfd as i32 == -100 {
            cwd = crate::tracee_io::image_cwd(pid)?;
            cwd.as_bytes()
        } else {
            let fd = (dirfd as u32).checked_sub(FD_BASE as u32)
                .filter(|slot| *slot < 64).ok_or(-9)?;
            self.fs.directory_path(fd as i32 + 3).map_err(errno)?
        };
        let mut bytes = [0; MAX_PATH];''';assert old in s;s=s.replace(old,new)
s=s.replace('''            6 | 87 | 89 =>''','''            6 | 84 | 87 | 89 =>''').replace('''            59 => (0, r.rdi''','''            80 => (0, r.rdi, (-100i64) as u64, true, false),
            59 => (0, r.rdi''').replace('''            263 => (1, r.rsi, r.rdi, false, false),''','''            263 | 267 => (1, r.rsi, r.rdi, false, false),''')
old='''        let path = self.path(pid, address, dirfd)?;
        self.resolve(pid, path.as_bytes(), follow, missing)
            .map(|p| Some((argument, p)))''';new='''        let path = self.path(pid, address, dirfd)?;
        if (r.orig_rax == 84 || r.orig_rax == 263 && r.rdx == 0x200) && dot_entry(path.as_bytes()) {
            return Err(-22);
        }
        let path = self.resolve(pid, path.as_bytes(), follow, missing)?;
        if dirfd as i32 != -100 && read_path(pid, address)?.as_bytes().first() != Some(&b'/')
            && !self.owns_path(path.as_bytes()) {
            return Err(-95);
        }
        Ok(Some((argument, path)))''';assert old in s;s=s.replace(old,new)
# Current image interpreter validation also needs the calling process cwd.
s=s.replace('''            let base = if name.first() == Some(&b'/') {''','''            let cwd;
            let base = if name.first() == Some(&b'/') {''').replace('''                self.cwd.as_bytes()''','''                cwd = crate::tracee_io::image_cwd(pid)?;
                cwd.as_bytes()''')
anchor='''    /// Image execution never reopens assigned paths''';assert anchor in s
s=s.replace(anchor,'''    pub fn image_chdir(&self, pid: usize, address: u64) -> Result<(), i64> {
        let path = self.path(pid, address, (-100i64) as u64)?;
        let path = self.resolve(pid, path.as_bytes(), true, false)?;
        if self.owns_path(path.as_bytes()) { return Err(-95); }
        if [b"/dev".as_slice(), b"/proc", b"/sys"].iter().any(|prefix| within(path.as_bytes(), prefix)) {
            return Err(-13);
        }
        Ok(())
    }

'''+anchor)
s=s.replace('''    pub fn claim(&mut self, pid: usize, r: &UserRegs) -> Option<i64> {
        let fd''','''    pub fn claim(&mut self, pid: usize, r: &UserRegs) -> Option<i64> {
        if matches!(r.orig_rax, 82 | 264 | 316) {
            return Some(self.rename(pid, r).unwrap_or_else(|error| error));
        }
        let fd''').replace('''| 77 | 91 | 292''','''| 77 | 91 | 217 | 292''').replace('''if matches!(r.orig_rax, 262 | 332) {''','''if matches!(r.orig_rax, 262 | 332 | 439) {''')
s=s.replace('''            4 | 6 => self.stat(pid, path.as_bytes(), r.rsi, false),''','''            4 | 6 => self.stat(pid, path.as_bytes(), r.rsi, false),
            21 | 269 | 439 => self.fs.metadata(path.as_bytes()).map_err(errno).and_then(|metadata| access(metadata, r)),
            89 | 267 => Err(-22),''')
s=s.replace('''            263 => {
                if r.rdx != 0 {''','''            84 => self.remove_directory(path.as_bytes()),
            263 => {
                if r.rdx == 0x200 {
                    self.remove_directory(path.as_bytes())
                } else if r.rdx != 0 {''')
old=function(s,'open');new=function(donor('9ba6a1d4','crates/ginux-init/src/fs_hooks.rs'),'open');new=new.replace('''            | 0o200
''','''            | 0o200
            | 0o400
''');s=s.replace(old,new)
d=donor('9ba6a1d4','crates/ginux-init/src/fs_hooks.rs');methods='\n'.join(function(d,x) for x in ['remove_directory','assignment_root','rename'])
old='''        if flags > 1 {''';methods=methods.replace(old,'''        if dot_entry(source.as_bytes()) || dot_entry(destination.as_bytes()) { return Err(-22); }
        let source = self.resolve(pid, source.as_bytes(), false, false)?;
        let destination = self.resolve(pid, destination.as_bytes(), false, true)?;
        if flags > 1 {''')
s=s.replace('''    fn stat(&self,''',methods+'\n    fn stat(&self,',1)
s=s.replace('''            77 => Err(-22),''','''            77 => Err(-22),
            217 => self.getdents(pid, fd, r.rsi, r.rdx),
            439 => {
                if r.r10 & 0x1000 == 0 { Err(-2) }
                else { self.fs.fstat(fd).map_err(errno).and_then(|metadata| access(metadata, r)) }
            }''')
# Add directory copyout to the existing filesystem owner, before impl closure.
m=re.search(r'^fn within\(',s,re.M);assert m;end=s.rfind('\n}',0,m.start());s=s[:end]+'\n'+function(d,'getdents')+s[end:]
s=s.replace('''        VfsError::IsDirectory => -21,''','''        VfsError::IsDirectory => -21,
        VfsError::DirectoryNotEmpty => -39,''')
a=donor('adc79f0a','crates/ginux-init/src/fs_hooks.rs');i=a.index('fn access(');j=a.index('\nfn within(',i);s=s.replace('fn within(',a[i:j]+'''\nfn dot_entry(path: &[u8]) -> bool {
    path.rsplit(|byte| *byte == b'/').find(|component| !component.is_empty())
        .is_some_and(|component| matches!(component, b"." | b".."))
}

fn within(''',1)
s=s.replace('//! Retained storage, directory descriptors, mappings and generated-file exec\n//! are not provided.','//! Retained storage, mappings and generated-file exec are not provided.');assert 'self.cwd' not in s;p.write_text(s)
p=root/'crates/ginux-init/src/tracee_io.rs';s=p.read_text();d=donor('d9490772','crates/ginux-init/src/tracee_io.rs');i=d.index('/// Kernel-owned image cwd');j=d.index('/// Linux file type bits',i);helper=d[i:j];helper=helper.replace('''    let relative = cwd[..cwd_len].strip_prefix(&root[..root_len]).ok_or(-13)?;''','''    let relative = if &root[..root_len] == b"/" { &cwd[..cwd_len] }
        else { cwd[..cwd_len].strip_prefix(&root[..root_len]).ok_or(-13)? };''');s=s.replace('/// Linux file type bits',helper+'/// Linux file type bits',1);p.write_text(s)
p=root/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text();anchor='''        match r.orig_rax {
            59 | 322 =>''';assert anchor in s
s=s.replace(anchor,'''        match r.orig_rax {
            79 => {
                audit_write(b"mediate surface=image-cwd\\n");
                self.run(index, r, domain);
                return;
            }
            80 => {
                let host = self.task(index).host;
                let result = self.objects.filesystem.image_chdir(host, r.rdi)
                    .and_then(|_| crate::path_hooks::Rewrite::prepare(self.objects.filesystem, host, r));
                match result {
                    Ok(rewrite) => {
                        self.task_mut(index).path_rewrite = rewrite;
                        audit_write(b"mediate surface=image-cwd\\n");
                        self.run(index, r, domain);
                    }
                    Err(-5) => self.fail(domain, b"chdir path scratch restoration failed"),
                    Err(error) => self.emulate(index, r, error, domain),
                }
                return;
            }
            59 | 322 =>''',1);p.write_text(s)
# Reuse existing fixture target and required integration job.
p=root/'Makefile';s=p.read_text();s+='''\n.PHONY: build-launch-directory-fixture test-launch-directories
build-launch-directory-fixture:
\tmkdir -p .artifacts/launch
\t$(CC) -nostdlib -static -fno-stack-protector -fno-builtin -O2 -Wall -Wextra -Werror tests/fixtures/launch-directory-fixture.c -o .artifacts/launch/launch-directory-fixture

test-launch-directories:
\tpython3 scripts/test-launch-directories.py $(GINUX) .artifacts/launch/launch-directory-fixture
''';p.write_text(s)
p=root/'.github/workflows/check.yml';s=p.read_text().replace('build-launch-exec-fixture','build-launch-exec-fixture build-launch-directory-fixture');s=s.replace('      - run: sudo make test-launch-exec','      - run: sudo make test-launch-directories\n      - run: sudo make test-launch-exec');p.write_text(s)
print('Adapted current path/FD/cwd owners; no thread, exec-backing or polling imports.')
