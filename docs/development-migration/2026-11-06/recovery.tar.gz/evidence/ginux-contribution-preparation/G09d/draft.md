Title: Support configured owned directory and image cwd operations

Resolve public owned directory descriptors through their existing VFS owner for
enumeration, relative operations, rename and removal. Preserve inode/cursor state
across fork and rename; resolve image-relative paths/exec from each process cwd.
Include the reviewed directory-library owner and required errno join together.

Validation: 89 unit tests, static checks/build, clean patch replay, selected real
directory/cwd scenarios and storage growth/bounds/quota checks pass. Older G09b
binary fails the new directory/cwd capability checks. Access/readlink, protected
buffer and confinement validation remain pending; full Linux
runtime and macOS Actions are unrun. Publication requires upstream prerequisites
and user inspection. No stack is proposed.
