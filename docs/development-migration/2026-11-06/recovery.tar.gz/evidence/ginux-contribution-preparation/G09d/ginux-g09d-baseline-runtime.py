from pathlib import Path
import subprocess,json
root=Path('/tmp/ginux-contribution-preparation/G09d');src=root/'source';base=Path('/tmp/ginux-contribution-preparation/G09b/source/target/x86_64-unknown-linux-gnu/release/ginux');results=[]
for mode,expected in [('functional',12),('cwd',94)]:
 command=['sudo','-n','python3',str(src/'scripts/test-launch-directories.py'),str(base),str(src/'.artifacts/launch/launch-directory-fixture'),mode]
 r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(root/f'baseline-{mode}.log').write_bytes(r.stdout)
 assert r.returncode!=0 and ('AssertionError: ('+str(expected)+',').encode() in r.stdout,(mode,r.returncode,r.stdout[-300:])
 results.append({'binary_revision':'297ad8dde26e02ca32d6becd60d654c1fd67ecd0','scenario':mode,'workload_code':expected,'harness_exit':r.returncode})
(root/'baseline-runtime-receipt.json').write_text(json.dumps(results,indent=2)+'\n');print(results)
