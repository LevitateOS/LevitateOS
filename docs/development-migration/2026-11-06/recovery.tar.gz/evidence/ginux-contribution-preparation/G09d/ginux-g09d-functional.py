from pathlib import Path
import subprocess,json
root=Path('/tmp/ginux-contribution-preparation/G09d');src=root/'source';results=[]
commands=[['sudo','-n','python3','scripts/test-launch-directories.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-directory-fixture','functional','cwd'],['sudo','-n','python3','scripts/test-launch-storage.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-storage-fixture','growth','bounds','quota']]
for i,command in enumerate(commands):
 with (root/f'functional-runtime-{i}.log').open('w') as log:r=subprocess.run(command,cwd=src,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':command,'exit_code':r.returncode});(root/'functional-runtime-receipt.json').write_text(json.dumps(results,indent=2)+'\n');print('functional scenario group',i,'exit',r.returncode)
 if r.returncode:break
assert all(x['exit_code']==0 for x in results),results
