from pathlib import Path
root=Path('/tmp/ginux-contribution-preparation/G09d/source');p=root/'tests/fixtures/launch-directory-fixture.c';s=p.read_text();s=s.replace('long directory_main(void)\n{','''long directory_main(word *stack)
{
    char **argv=(char **)(stack+1);
    int functional=stack[0]>1 && equal(argv[1],"functional");
    if(stack[0]>1 && equal(argv[1],"cwd-child")) {
        CHECK(DO(79,buffer,sizeof buffer,0)==11 && equal(buffer,"/image-dir"),90);
        long fd=DO(2,"input",0,0);
        CHECK(fd>=3 && DO(0,fd,buffer,11)==11 && buffer[0]=='i',91);
        CHECK(DO(3,fd,0,0)==0 && create("/work/after-exec","ok")==0,92);
        CHECK(DO(1,1,"owned-directories: PASS\\n",24)==24,93);
        return 0;
    }
    if(stack[0]>1 && equal(argv[1],"cwd")) {
        CHECK(DO(80,"/image-dir",0,0)==0,94);
        CHECK(DO(79,buffer,sizeof buffer,0)==11 && equal(buffer,"/image-dir"),95);
        long child=DO(57,0,0,0);
        if(child==0) {
            long code=DO(80,"/",0,0)==0 && create("work/child","ok")==0 ? 17:1;
            DO(60,code,0,0); __builtin_unreachable();
        }
        int status=0;
        CHECK(child>1 && DO(61,child,&status,0)==child && status==(17<<8),96);
        CHECK(DO(79,buffer,sizeof buffer,0)==11 && equal(buffer,"/image-dir"),97);
        long fd=DO(2,"../work/child",0,0);
        CHECK(fd>=3 && DO(0,fd,buffer,2)==2 && buffer[0]=='o',98);
        CHECK(DO(3,fd,0,0)==0,99);
        char *args[]={"fixture","cwd-child",0},*env[]={0};
        DO(59,"fixture",args,env);
        return 100;
    }''')
a=s.index('    CHECK(DO(217,dir,1,sizeof buffer)');b=s.index('    CHECK(DO(217,dir,buffer,24)',a);s=s[:a]+'    if(!functional) {\n'+s[a:b]+'    }\n'+s[b:]
s=s.replace('''CHECK(names==15 && DO(217,dir,1,4096)==0,33);''','''CHECK(names==15 && DO(217,dir,buffer,4096)==0,33);
    if(!functional) CHECK(DO(217,dir,1,4096)==0,33);''')
s=s.replace('''CHECK(DO(257,file,"child",0)==-20 && DO(257,1048576,"file",0)==-9,37);
    CHECK(DO(257,dir,"../../image",0)==-95,38);''','''CHECK(DO(257,file,"child",0)==-20,37);
    if(!functional) {
        CHECK(DO(257,1048576,"file",0)==-9,37);
        CHECK(DO(257,dir,"../../image",0)==-95,38);
    }''')
s=s.replace('''CHECK(DO(82,"/work/moved","/work/target",0)==-20 && DO(82,1,"/work/no-effect",0)==-14,63);''','''CHECK(DO(82,"/work/moved","/work/target",0)==-20,63);
    if(!functional) CHECK(DO(82,1,"/work/no-effect",0)==-14,63);''')
s=s.replace('''    CHECK(DO(82,"/work/moved","/image",0)==-18 && DO(82,"/work","/work-other",0)==-18,72);''','''    if(!functional) CHECK(DO(82,"/work/moved","/image",0)==-18 && DO(82,"/work","/work-other",0)==-18,72);''')
s=s.replace('''_start:\\nandq $-16,%rsp''','''_start:\\nmov %rsp,%rdi\\nandq $-16,%rsp''');p.write_text(s)
p=root/'scripts/test-launch-directories.py';s=p.read_text().replace('len(sys.argv)!=3','len(sys.argv)<3').replace('<directory-fixture>\'','<directory-fixture> [all|functional|cwd ...]\'').replace('for p in sys.argv[1:]]','for p in sys.argv[1:3]]');s=s.replace('''        (root/'work').mkdir()''','''        (root/'work').mkdir()
        (root/'image-dir').mkdir()
        shutil.copyfile(fixture,root/'image-dir/fixture')
        (root/'image-dir/fixture').chmod(0o755)
        (root/'image-dir/input').write_bytes(b'image-child')''')
a=s.index("        (work/'launch.toml').write_text(config)");b=s.index("        print('test-launch-directories:",a);block=s[a:b];block=block[block.index('        for i in range(2):'):];block='\n'.join('    '+line if line else line for line in block.splitlines())+'\n';block=block.replace("assert list((root/'work').iterdir())==[]","assert list((root/'work').iterdir())==[]")
new='''        for mode in (sys.argv[3:] or ['all', 'cwd']):
            if mode not in ('all', 'functional', 'cwd'):
                sys.exit('unknown directory scenario')
            # Every launch gets a new image; image cwd remains kernel-owned.
            (work/'launch.toml').write_text(config.replace('args = []', 'args = ' + json.dumps([] if mode == 'all' else [mode])))
'''+block+'''            print(f'PASS launch directories: {mode}')
''';s=s[:a]+new+s[b:];p.write_text(s)
# Add ordinary access/noctty/readlink semantics without importing /dev/fd reopen
# or mappings, neither of which is available in this extraction yet.
p=root/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();anchor="    if (argc > 1 && argv[1][0] == 'g') {";assert anchor in s
s=s.replace(anchor,'''    if (argc > 1 && argv[1][0] == 'v') {
        long fd=DO(2,"/work/probe",0102|0400,0600);
        CHECK(fd>=3 && DO(1,fd,"ok",2)==2,145);
        CHECK(DO(21,"/work/probe",0,0)==0 && DO(21,"/work/probe",6,0)==0,146);
        CHECK(DO(21,"/work/probe",1,0)==-13,147);
        CHECK(DO(269,-100,"/work/probe",4)==0,148);
        CHECK(call(439,fd,(word)"",4,0x1000,0,0)==0,149);
        CHECK(DO(91,fd,0700,0)==0 && DO(21,"/work/probe",1,0)==0,150);
        CHECK(DO(89,"/work/probe",output,16)==-22,151);
        CHECK(call(267,-100,(word)"/work/probe",(word)output,16,0,0)==-22,152);
        long reader=DO(2,"/work/probe",0400,0);
        CHECK(reader>=3 && DO(0,reader,output,2)==2 && output[0]=='o',153);
        CHECK(DO(3,reader,0,0)==0 && DO(3,fd,0,0)==0,154);
        return 0;
    }
'''+anchor);p.write_text(s)
p=root/'scripts/test-launch-storage.py';s=p.read_text().replace("('growth', 'bounds', 'quota')","('growth', 'bounds', 'quota', 'view-probes')").replace('[growth|bounds|quota ...]','[growth|bounds|quota|view-probes ...]');s=s.replace("        invoke(['memory:/work', 'memory:/work/build', 'memory:/out'], ['growth'])","        invoke(['memory:/work'], ['view-probes'])\n        invoke(['memory:/work', 'memory:/work/build', 'memory:/out'], ['growth'])");p.write_text(s)
print('Added selected functional scenarios; default full directory/security coverage retained.')
