from pathlib import Path
import subprocess,tarfile,io,json,os,hashlib,re
root=Path('/tmp/ginux-contribution-preparation/G23');src=root/'source';dest=root/'verified-head';assert not dest.exists();dest.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';m=json.loads((root/'manifest.json').read_text())
def git(*args):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*args])
with tarfile.open(fileobj=io.BytesIO(git('archive',m['base']))) as t:t.extractall(dest,filter='data')
subprocess.run(['git','apply','--whitespace=error',str(root/'candidate.patch')],cwd=dest,check=True)
names=git('ls-tree','-r','--name-only',m['head']).decode().splitlines()
for name in names:
 a=src/name;b=dest/name;assert a.is_symlink()==b.is_symlink(),name
 assert (os.readlink(a)==os.readlink(b) if a.is_symlink() else a.read_bytes()==b.read_bytes()),name
cmd=['make','check','test-unit','build','build-launch-script-fixture','build-launch-owned-exec-fixture','build-launch-directory-fixture','build-launch-storage-fixture','build-launch-task-fixture']
for path,prefix in [(src,'final-'),(dest,'clean-')]:
 with (root/(prefix+'static-build.log')).open('w') as log:r=subprocess.run(cmd,cwd=path,stdout=log,stderr=subprocess.STDOUT)
 receipt={'command':cmd,'exit_code':r.returncode,'matched_paths':len(names),'head':m['head'],'binary_sha256':hashlib.sha256((path/'target/x86_64-unknown-linux-gnu/release/ginux').read_bytes()).hexdigest()};(root/(prefix+'static-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(prefix,'static',r.returncode,'tracked paths',len(names),flush=True);assert r.returncode==0
 print('unit total',sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', (root/(prefix+'static-build.log')).read_text())),flush=True)
