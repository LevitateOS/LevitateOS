from pathlib import Path
r=Path('/tmp/ginux-contribution-preparation/G23/source')
p=r/'tests/fixtures/launch-task-fixture.c';s=p.read_text();needle='''        CHECK(DO(73,fd,6,0)==0 && DO(73,fd,16,0)==-22 && DO(3,fd,0,0)==0,150);''';assert needle in s;s=s.replace(needle,'''        CHECK(DO(73,fd,6,0)==0 && DO(73,fd,16,0)==-22,150);
        if(ordinary_locks) {
            child=DO(57,0,0,0); CHECK(child>=0,172);
            if(!child) {
                CHECK(DO(1,pipes[1],"K",1)==1,173);
                lock.kind=1; lock.start=0; lock.len=0;
                DO(72,fd,7,&lock); return 174;
            }
            CHECK(DO(0,pipes[0],buffer,1)==1 && buffer[0]=='K',175);
            CHECK(DO(1,1,"cancel-ready\\n",13)==13 && DO(0,0,buffer,1)==1,176);
            CHECK(DO(62,child,9,0)==0 && DO(61,child,&status,0)==child && status==9,177);
        }
        CHECK(DO(3,fd,0,0)==0,150);''',1);p.write_text(s)
p=r/'scripts/test-launch-tasks.py';s=p.read_text().replace("for syscall, ready in ((72,b'record-release-ready\\n'),(73,b'flock-release-ready\\n')):","for syscall, owner, ready in ((72,2,b'record-release-ready\\n'),(73,3,b'flock-release-ready\\n'),(72,4,b'cancel-ready\\n')):",1).replace("f'syscall={syscall} virtual-pid='.encode()", "f'syscall={syscall} virtual-pid={owner} '.encode()",1);compile(s,str(p),'exec');p.write_text(s)
print('ordinary cancellation observes blocked lock entry before supported SIGKILL/reap')
