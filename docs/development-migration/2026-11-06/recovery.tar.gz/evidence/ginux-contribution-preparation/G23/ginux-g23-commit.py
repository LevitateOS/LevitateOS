from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G23');src=root/'source';base=json.loads((root/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['README.md','crates/ginux-init/src/file_locks.rs','crates/ginux-init/src/descriptors.rs','crates/ginux-init/src/fs_hooks.rs','crates/ginux-init/src/launch_tasks.rs','crates/ginux-init/src/main.rs','scripts/test-launch-tasks.py','tests/fixtures/launch-task-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g23-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(src/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',base,input=('feat(storage): mediate file locks with virtual ownership\n\nSupport bounded POSIX record locks on owned regular-file inodes and flock\nlocks on owned open descriptions. Keep process and description lifetime\ndistinct across aliases, fork, exec and death; park conflicting blocking\nrequests in the existing supervisor and retain native lock denial.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert not any(x in patch for x in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in ['crates/ginux-init/src/supervisor.rs','crates/ginux-core/src/lib.rs','crates/ginux-process/src/lib.rs','crates/ginux-init/src/exec_script.rs','crates/ginux-init/src/storage_memory.rs','crates/ginux-init/src/tracee_io.rs','crates/ginux-vfs/src/lib.rs']:assert (src/name).read_bytes()==git('show',base+':'+name)
def walker(s):return s[s.index('fn resolve_components('):s.index('pub trait BaseReader')]
assert walker((src/'crates/ginux-vfs/src/lib.rs').read_text())==walker(git('show',base+':crates/ginux-vfs/src/lib.rs').decode())
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G23','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':['G15'],'standalone':False,'status':'source/ordinary checks pass; final self-review/clean replay pending; security/full CI held','patch_sha256':hashlib.sha256(patch).hexdigest(),'deferred_joins':['G07 thread/process-group locks and shared-argument security','actual SQLite/Cargo consumer closure at F02/F03']};(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
