from pathlib import Path
import subprocess,tarfile,io,json
r=Path('/tmp/ginux-contribution-preparation/G23');r.mkdir(exist_ok=True);src=r/'source';assert not src.exists();src.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='8ab24d4b47adeb9897623627060846070d41219d'
def get(ref,n):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'show',ref+':'+n]).decode()
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'archive',base]))) as t:t.extractall(src,filter='data')
(r/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G15 per-process inode and description ownership'],'source':['26784843bea2eacdfb4e661bf47a40d2b94a7a8f'],'held_joins':['G07 process-group/thread lock lifetime and shared arguments','actual SQLite/Cargo use with required filesystem consumer capabilities at F02/F03'],'excluded':['G17/G18 capacity, mapping and positioned writes','G19-G22 archives/control/restore','G14/G16 cwd/traversal','G01/G02/G08 policy']},indent=2)+'\n')
n='crates/ginux-init/src/file_locks.rs';s=get('26784843',n).replace('//! Owners are virtual process groups: forks do not inherit locks, threads do.','//! Owners are virtual processes; forks do not inherit record locks.');(src/n).write_text(s)
n='crates/ginux-init/src/main.rs';p=src/n;s=p.read_text().replace('mod exec_script;','mod exec_script;\nmod file_locks;',1);p.write_text(s)
n='crates/ginux-init/src/fs_hooks.rs';p=src/n;s=p.read_text().replace('    null: bool,','    null: bool,\n    process: u32,\n    locks: crate::file_locks::Locks,\n    flocks: crate::file_locks::Locks,',1).replace('        Ok(Self {\n            fs,','        Ok(Self {\n            process: 1,\n            locks: crate::file_locks::Locks::new(),\n            flocks: crate::file_locks::Locks::new(),\n            fs,',1);d=get('26784843',n);a=d.index('    pub fn select_process(');b=d.index('    pub fn select_cwd(',a);at=s.index('    pub fn teardown(');s=s[:at]+d[a:b]+s[at:]
s=s.replace('                | 72\n','                | 72\n                | 73\n',1).replace('''            3 => self.fs.close(fd).map(|_| 0).map_err(errno),''','''            3 => {
                self.flocks.release((fd - 3) as u32, None);
                self.fs.close(fd).map(|_| 0).map_err(errno)
            }''',1)
needle='''            72 => self''';assert needle in s;s=s.replace(needle,'''            73 => self.flock(fd, r.rsi),
            72 if matches!(r.rsi, 5..=7) => self.file_lock(pid, fd, r.rsi, r.rdx),
'''+needle,1)
a=d.index('    fn flock(');b=d.index('    fn read(',a);at=s.index('    fn read(');s=s[:at]+d[a:b]+s[at:];p.write_text(s)
n='crates/ginux-init/src/descriptors.rs';p=src/n;s=p.read_text().replace('''                    backends.release(handle)?;''','''                    backends.filesystem.close_locks(handle);
                    backends.release(handle)?;''',1).replace('0 | 1 | 5 | 8 | 16 | 17 | 18 | 19 | 20 | 74','0 | 1 | 5 | 8 | 16 | 17 | 18 | 19 | 20 | 73 | 74',1)
s=s.replace('''        Ok(match backends.claim(pid, r) {''','''        let decision = match backends.claim(pid, r) {
            NativeDecision::Hooked { result: -11, .. }
                if (r.orig_rax == 72 && r.rsi == 7) || (r.orig_rax == 73 && r.rsi & 4 == 0) => {
                NativeDecision::Park { fd: public_fd }
            }
            decision => decision,
        };
        Ok(match decision {''',1).replace('''        let entry = self.entries[slot].take().ok_or(-9)?;
        if let Handle::Owned(handle) = entry.handle {''','''        let entry = self.entries[slot].take().ok_or(-9)?;
        if let Handle::Owned(handle) = entry.handle {
            backends.filesystem.close_locks(handle);''',1);p.write_text(s)
n='crates/ginux-init/src/launch_tasks.rs';p=src/n;s=p.read_text().replace('''    fn entry(&mut self, index: usize, r: &mut UserRegs, domain: &mut Domain) {
''','''    fn entry(&mut self, index: usize, r: &mut UserRegs, domain: &mut Domain) {
        self.objects.filesystem.select_process(self.task(index).id.pid);
''',1).replace('''    fn exec_completed(&mut self, index: usize, domain: &mut Domain) {
''','''    fn exec_completed(&mut self, index: usize, domain: &mut Domain) {
        self.objects.filesystem.select_process(self.task(index).id.pid);
''',1).replace('''        self.task_mut(index).alive = false;''','''        self.objects.filesystem.release_process_locks(self.task(index).id.pid);
        self.task_mut(index).alive = false;''',1);p.write_text(s)
n='README.md';p=src/n;s=p.read_text();needle='Native locks, leases and signal ownership are denied.';assert needle in s;s=s.replace(needle,'''Owned regular files support POSIX byte-range locks
(`F_GETLK`, `F_SETLK`, `F_SETLKW`) with virtual process ownership. Fork does not
inherit record locks; closing any descriptor for the inode releases that
process's record locks. Owned file/directory `flock` locks follow the open
description across dup/fork and release on its final close. Each table holds at
most 64 ranges; exhaustion returns `ENOLCK` without a partial update. Conflicting
blocking calls wait in the supervisor; deadlock detection and thread sharing
remain unsupported. Native image locks, leases and signal ownership stay denied.''',1);p.write_text(s)
n='tests/fixtures/launch-task-fixture.c';p=src/n;s=p.read_text();d=get('26784843',n);a=d.index("    if (mode=='L')");b=d.index("    else if (mode=='a')",a);block=d[a:b].replace('''        CHECK(DO(72,fd,6,1)==-14 && DO(73,fd,6,0)==0,142);''','''        if(!ordinary_locks) CHECK(DO(72,fd,6,1)==-14,142);
        CHECK(DO(73,fd,6,0)==0,142);''')
s=s.replace("    CHECK(DO(39,0,0,0)","    int ordinary_locks=mode=='O';\n    if(ordinary_locks) mode='L';\n    CHECK(DO(39,0,0,0)",1).replace("    if (mode=='a')",block+"    else if (mode=='a')",1);p.write_text(s)
n='scripts/test-launch-tasks.py';p=src/n;s=p.read_text().replace('    if len(sys.argv) != 3','    if len(sys.argv) < 3',1).replace('<task-fixture>\'','<task-fixture> [scenario ...]\'',1).replace('for p in sys.argv[1:]]','for p in sys.argv[1:3]]',1).replace("        for mode in ('qfault',", "        modes = ('Locks', 'qfault',",1).replace("'rollback', 'inherit'):","'rollback', 'inherit')\n        if sys.argv[3:]:\n            allowed=set(modes) | {'OrdinaryLocks'}\n            if any(mode not in allowed for mode in sys.argv[3:]): sys.exit('unknown task selection')\n            modes=sys.argv[3:]\n        for mode in modes:",1).replace('''        # No descendant may survive''','''        if sys.argv[3:]: return
        # No descendant may survive''',1);compile(s,str(p),'exec');p.write_text(s)
print('G23 bounded process locks ported on G15; thread and consumer joins retained separately')
