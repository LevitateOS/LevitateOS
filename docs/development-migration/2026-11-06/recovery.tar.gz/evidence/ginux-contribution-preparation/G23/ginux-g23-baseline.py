from pathlib import Path
import tempfile,subprocess,json,shutil
r=Path('/tmp/ginux-contribution-preparation/G23');s=r/'source';binary='/tmp/ginux-contribution-preparation/G15/verified-head/target/x86_64-unknown-linux-gnu/release/ginux'
with tempfile.TemporaryDirectory(prefix='ginux-lock-baseline-') as name:
    w=Path(name);root=w/'root';(root/'bin').mkdir(parents=True);(root/'work').mkdir();shutil.copyfile(s/'.artifacts/launch/launch-task-fixture',root/'bin/fixture');(root/'bin/fixture').chmod(0o755)
    config=(s/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/fixture"').replace('args = []','args = ["OrdinaryLocks"]').replace('[storage]\nassignments = []','[storage]\nassignments = ["memory:/work"]')
    p=w/'config.toml';p.write_text(config);result=w/'result.json';cmd=[binary,'launch',str(p),str(root),'--result-file',str(result)]
    proc=subprocess.run(cmd,input=b'GGG',capture_output=True,timeout=10);(r/'baseline-locks.log').write_bytes(proc.stderr)
    record=json.loads(result.read_text());assert proc.returncode==126 and record['code']==126 and record['outcome']=='exited',proc.stderr.decode()
    (r/'baseline-receipt.json').write_text(json.dumps({'base':'8ab24d4b47adeb9897623627060846070d41219d','command':cmd,'exit_code':proc.returncode,'behavior':'valid F_SETLK is unsupported; ordinary fixture exits126 before any blocking handshake'},indent=2)+'\n')
print('exact G15 prerequisite fails supported-lock fixture at F_SETLK')
