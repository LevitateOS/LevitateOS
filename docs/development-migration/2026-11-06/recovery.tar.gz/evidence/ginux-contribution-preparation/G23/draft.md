Mediate owned file locks with virtual ownership

Support bounded POSIX byte-range locks on owned regular-file inodes and flock
locks on owned open descriptions. Preserve their distinct alias/fork/exec/close/
exit lifetimes and wait on conflicting blocking requests in the supervisor.
Keep native image locks denied; document unsupported deadlock/thread behavior.

Local build/static checks, 98 units, synchronized competing-process lock checks,
exec/CLOEXEC/final-close, supported cancellation and existing regressions pass in
source and clean replay. Thread/security validation, actual SQLite/Cargo consumer
closure, full runtime/remote CI and prerequisite merges remain pending.
Not ready to submit.
