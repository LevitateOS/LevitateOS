from pathlib import Path
r=Path('/tmp/ginux-contribution-preparation/G23/source')
p=r/'tests/fixtures/launch-task-fixture.c';s=p.read_text();definition='struct flock {short kind,whence;int padding;long start,len;int pid,padding2;};';assert definition in s;s=s.replace('        '+definition+'\n','',1);s=s.replace('long task_main(word *stack)',definition+'''
static long lock_exec(void) {
    long fd=DO(2,"/work/exec-lock",0102,0600); CHECK(fd==3 && DO(32,fd,0,0)==4 && DO(72,4,2,1)==0,151);
    int ready[2], go[2]; CHECK(DO(22,ready,0,0)==0 && ready[1]==6 && DO(22,go,0,0)==0 && go[0]==7,152);
    long child=DO(57,0,0,0); CHECK(child>=0,153);
    if(!child) {
        struct flock lock={1,0,0,0,0,0,0};
        CHECK(DO(72,3,6,&lock)==0 && DO(73,3,6,0)==0 && DO(1,ready[1],"R",1)==1,154);
        CHECK(DO(0,go[0],buffer,1)==1,155);
        char *args[]={"/bin/fixture","CheckLocks",0}; char *environment[]={0};
        DO(59,args[0],args,environment); return 156;
    }
    CHECK(DO(0,ready[0],buffer,1)==1 && buffer[0]=='R',157);
    long independent=DO(2,"/work/exec-lock",2,0); CHECK(independent==9,158);
    struct flock lock={1,0,0,0,0,0,0};
    CHECK(DO(72,independent,5,&lock)==0 && lock.kind==1 && lock.pid==(int)child,159);
    CHECK(DO(3,3,0,0)==0 && DO(3,4,0,0)==0,160);
    lock.kind=1; CHECK(DO(72,independent,5,&lock)==0 && lock.kind==1,161);
    CHECK(DO(1,go[1],"G",1)==1 && DO(0,ready[0],buffer,1)==1 && buffer[0]=='E',162);
    lock.kind=1; CHECK(DO(72,independent,5,&lock)==0 && lock.kind==2,163);
    CHECK(DO(73,independent,6,0)==-11 && DO(1,go[1],"G",1)==1,164);
    int status=-1; CHECK(DO(61,child,&status,0)==child && status==0,165);
    CHECK(DO(73,independent,6,0)==0 && DO(3,independent,0,0)==0,166);
    for(int n=5;n<=8;++n) CHECK(DO(3,n,0,0)==0,167);
    return 0;
}
long task_main(word *stack)''',1)
s=s.replace("    int ordinary_locks=mode=='O';",'''    if(mode=='C') {
        CHECK(DO(39,0,0,0)==2 && DO(72,3,1,0)==0 && DO(72,4,1,0)==-9,168);
        CHECK(DO(1,6,"E",1)==1 && DO(0,7,buffer,1)==1,169); return 0;
    }
    int ordinary_locks=mode=='O';''',1)
s=s.replace("    if (mode=='L') {",'''    if(mode=='E') {
        long status=lock_exec(); CHECK(status==0,status);
    } else if (mode=='L') {''',1)
s=s.replace('''        CHECK(DO(3,alias,0,0)==0,138);''','''        if(ordinary_locks) {
            CHECK(DO(1,1,"record-release-ready\\n",21)==21 && DO(0,0,buffer,1)==1,170);
        }
        CHECK(DO(3,alias,0,0)==0,138);''',1)
s=s.replace('''        CHECK(DO(73,fd,8,0)==0 && DO(61,child,&status,0)==child && status==(29<<8),149);''','''        if(ordinary_locks) {
            CHECK(DO(1,1,"flock-release-ready\\n",20)==20 && DO(0,0,buffer,1)==1,171);
        }
        CHECK(DO(73,fd,8,0)==0 && DO(61,child,&status,0)==child && status==(29<<8),149);''',1);p.write_text(s)
p=r/'scripts/test-launch-tasks.py';s=p.read_text().replace("modes = ('Locks',", "modes = ('Locks', 'OrdinaryLocks', 'ExecLocks',",1);needle="            if mode == 'adopted-zombie':";assert needle in s
s=s.replace(needle,'''            if mode == 'OrdinaryLocks':
                audit=work/'ordinary-locks.audit'
                with audit.open('wb') as errors:
                    proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
                    try:
                        for syscall, ready in ((72,b'record-release-ready\\n'),(73,b'flock-release-ready\\n')):
                            assert select.select([proc.stdout],[],[],5)[0], 'lock readiness missing'
                            assert proc.stdout.readline()==ready
                            deadline=time.monotonic()+5
                            while not any(f'syscall={syscall} virtual-pid='.encode() in line and b'action=park' in line for line in audit.read_bytes().splitlines()):
                                assert proc.poll() is None and time.monotonic()<deadline, audit.read_text()
                                time.sleep(.01)
                            proc.stdin.write(b'G'); proc.stdin.flush()
                        stdout,_=proc.communicate(timeout=5)
                    finally:
                        if proc.poll() is None: proc.kill(); proc.communicate(timeout=5)
                proc.stdout,proc.stderr=stdout,audit.read_bytes()
            elif mode == 'adopted-zombie':''',1);compile(s,str(p),'exec');p.write_text(s)
print('ordinary lock waits observed before release; exec/fork/dup/final-close lifecycle covered')
