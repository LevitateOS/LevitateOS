from pathlib import Path
import json,hashlib,shutil
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G23');art=root/'.artifacts/ginux-contribution-preparation/G23';m=json.loads((temp/'manifest.json').read_text())
for prefix in ['', 'clean-']:
    rs=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(rs)==5 and all(r['exit_code']==0 for r in rs)
static=[json.loads((temp/(prefix+'static-receipt.json')).read_text()) for prefix in ['final-','clean-']]
assert all(r['exit_code']==0 and r['matched_paths']==178 and r['head']==m['head'] for r in static)
assert static[0]['binary_sha256']==static[1]['binary_sha256']
fixtures={}
for name in ['launch-task-fixture','launch-storage-fixture','launch-directory-fixture','launch-script-fixture','launch-owned-exec-fixture']:
    a=(temp/'source/.artifacts/launch'/name).read_bytes();b=(temp/'verified-head/.artifacts/launch'/name).read_bytes();assert a==b;fixtures[name]=hashlib.sha256(a).hexdigest()
m.update(status='partial: per-process source separately self-reviewed and selected ordinary source/clean checks pass; thread/security/SQLite-Cargo/full CI/upstream independence pending',unit_tests=98,vfs_tests=40,clean_matched_paths=178,review='separate self-review; no independent reviewer or security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',held_dependencies=['G07 process-group/thread lifetime and shared-argument security'],consumer_validation='actual SQLite/Cargo not rerun on this prepared head; required combined consumer closure remains F02/F03',source_binary_sha256=static[0]['binary_sha256'],clean_binary_sha256=static[1]['binary_sha256'],fixture_sha256=fixtures)
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
    if p.is_file() and p.suffix in ['.json','.log','.patch','.diff']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g23*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G23.patch')
(art/'draft.md').write_text('''Mediate owned file locks with virtual ownership

Support bounded POSIX byte-range locks on owned regular-file inodes and flock
locks on owned open descriptions. Preserve their distinct alias/fork/exec/close/
exit lifetimes and wait on conflicting blocking requests in the supervisor.
Keep native image locks denied; document unsupported deadlock/thread behavior.

Local build/static checks, 98 units, synchronized competing-process lock checks,
exec/CLOEXEC/final-close, supported cancellation and existing regressions pass in
source and clean replay. Thread/security validation, actual SQLite/Cargo consumer
closure, full runtime/remote CI and prerequisite merges remain pending.
Not ready to submit.
''')
assert not any(s in (art/'draft.md').read_text() for s in ['LevitateOS','Recipe','Daybreak'])
(docs/'g23-review.md').write_text(f'''# G23 — process and open-description file locks

Head `{m['head']}`, tree `{m['tree']}`, directly on G15
`{m['base']}`. [Patch](patches/G23.patch): eight files, +389/-10.
Per-process source and selected ordinary validation are retained. The full G23
packet is **partial**: thread/security, actual SQLite/Cargo, full CI and refreshed
upstream independence remain pending. Ordinary fixtures do not substitute for
actual application acceptance.

The source uses existing G15 inode/description identity and G06 task/descriptor
ownership. G17 capacity/pwrite, mappings, archives, control, cwd/traversal and held
readiness policy are not code dependencies. Actual applications need their other
filesystem/process capabilities; that combined proof remains mandatory at F02/F03.
G07's thread/process-group join is held and is not inferred from per-process tests.

`F_GETLK`/`F_SETLK`/`F_SETLKW` use virtual process owners and bounded signed byte
ranges, including end-relative/current offsets, negative lengths and EOF ranges.
Records split/coalesce in a replacement table before committing, with64 ranges
and ENOLCK on exhaustion. Closing any public owned descriptor for the inode drops
that process's record locks, including dup2 retirement and committed CLOEXEC.
Death releases the process owner directly. Fork copies descriptions without
copying record ownership. A separate flock table follows each existing open
description across dup/fork and retires on its final backend close. Existing
supervisor retry/wakeup handles blocking conflicts; configured cancellation uses
the existing supported SIGKILL path. Deadlock detection, other signal interruption
and thread sharing are not newly provided. Native image locks remain denied.

Separate final self-review covered the entire diff and current descriptor refs,
close/dup2, exec transaction, death/duplicate-reap, parking/wakeup, fstat/flags/
offset, alias inode lifetime, dispatch and pointer-copy callers. This is self-
review, not independent or adversarial review. No remaining blocking source
finding was identified within the supported per-process scope; full scope is
still held as described above.

- **Owner adaptation:** donor thread-group selection is replaced by the reviewed
  per-process task ID. Entry/retry and committed exec explicitly select that
  owner; death releases by explicit ID. No donor thread transactions or pinned-
  descriptor machinery is imported into a base that has separate process tables.
- **Blocking proof strengthened:** the ordinary fixture pauses the releasing
  process until its own audit confirms the competing record/flock call parked.
  It also observes a parked child before supported SIGKILL/reap. This avoids
  treating an uncontended interleaving as blocking-lock evidence.
- **Lifecycle proof:** a child holds record/flock locks through dup and fork.
  Parent alias closes preserve the child's records; successful exec closes one
  CLOEXEC alias and removes its records while another description reference
  retains flock. Final child exit then releases flock for an independent opener.
  Split holes, virtual conflicting PID, negative lengths and child-death release
  use trusted buffers and real simultaneous child processes.
- **Coverage retained:** extend the existing task runner/fixture, already built
  and executed by Make/CI. Default full pointer/child/teardown cases remain.
  Explicit ordinary selections permit local checks without executing those
  adversarial cases; no static-and-unit coverage is removed.

Exact G15 returns unsupported for the first valid F_SETLK, causing fixture exit126.
Final source and strict clean prerequisite-plus-patch replay pass make check
 test-unit build and task/storage/directory/script/owned-exec fixture builds:
98 units,40 VFS,178 matching tracked paths. Ginux and all five fixture binaries
match. Ordinary lock/exec checks and ten existing process scenarios pass in both
copies. Four storage cases,16 scripts,eight ELF/hardlink modes and four directory/
alias/quota controls also pass. No application locks were disabled to get these
results; no new SQLite/Cargo result is claimed from older integrated logs.

Protected/mutable structs, FD/owner races, table-exhaustion rollback, authority,
thread groups and interruption require [DaybreakBlue](daybreakblue-handoff.md).
No such probes or cloud dispatch occurred. Independent review, full/default Linux
suite, macOS/remote CI, thread join, actual simultaneous SQLite/Cargo and fresh-
main standalone checks are unrun. Actual application proof remains an explicit
F02/F03 completion requirement; G24's independent timestamp/archive work may proceed.

Patch, generic draft, commands, receipts, hashes and helpers are retained under
.artifacts/ginux-contribution-preparation/G23/. No real Ginux branch, index,
checkout/ref, remote human text or maintainer message changed. F04 remains the
user inspection stop before publication.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G23');row.update(m);row.update(evidence='g23-review.md',source_patch='patches/G23.patch');p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'p04-dependencies.md';s=p.read_text().replace('Lock identity includes hardlink aliases; process/description lock semantics must be distinguished. Real concurrent Cargo/SQLite scenario supplements syscall fixtures.','Lock identity includes hardlink aliases; process/description lock semantics must be distinguished. The per-process port needs G15, not G17 capacity/pwrite or G07 thread machinery; the thread join and actual concurrent Cargo/SQLite acceptance remain required with their combined consumer capabilities at F02/F03.');p.write_text(s)
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\nG23 exact retained per-process revision: {m['head']} on G15 {m['base']}.
98 routine units and selected ordinary real record/flock contenders, audit-
confirmed blocking/wakeup, supported SIGKILL cancellation, exec/CLOEXEC/final-close
and existing controls pass in source/clean. Full pointer/authority/race/capacity
and thread acceptance remain unrun; actual SQLite/Cargo closure is still F02/F03
work. No cloud dispatch or security acceptance; [review/evidence](g23-review.md).\n''')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text().replace('| G06, G07, G15, G17 | Real simultaneous SQLite/Cargo','| G06, G15; G07 thread join and consumer capabilities at F02/F03 | Real simultaneous SQLite/Cargo',1);a=s.index('Exact next task: **G23');b=s.index('\nActive skill:',a)
s=s[:a]+f'''G23 per-process source/ordinary preparation is retained at `{m['head'][:8]}` directly
on G15{m['base'][:8]}. [Review/evidence](ginux-contributions/g23-review.md) records98
units,178-path strict replay and real record/flock contenders, audit-confirmed
blocking/wakeup, supported SIGKILL cancellation, exec/CLOEXEC/final-close lifetime
and existing process/storage/exec controls passing in source/clean. Code uses
existing G15 ownership without G17 or G07 machinery. The full packet remains
partial: G07 thread/security, actual simultaneous SQLite/Cargo with their combined
consumer prerequisites at F02/F03, full CI and upstream independence are pending.
Do not substitute these fixtures or historical integrated logs for that consumer
acceptance. Existing Make/CI wiring includes the new cases; no publication.

Exact next task: **G24 — inode timestamps and archive mtime**.
Inspect d21d26c8 on the reviewed G15/G22 metadata/archive owners, preserving shared
inode identity and matching export/import fields. Keep seconds-only persistence
explicit and avoid importing unrelated process/network/readiness policy. Run
ordinary explicit times across aliases and archive restart; record malformed,
no-follow/authority and clock-boundary security checks for DaybreakBlue. Preserve
G23's still-pending application/thread joins for F02/F03. No publication or
maintainer messages before F04.
''' +s[b:];p.write_text(s);print('retained',m['head'])
