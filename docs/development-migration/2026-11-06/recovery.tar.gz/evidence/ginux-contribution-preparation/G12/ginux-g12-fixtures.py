from pathlib import Path
import subprocess
src=Path('/tmp/ginux-contribution-preparation/G12/source');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def show(path):return subprocess.check_output(['git','-C',repo,'show','868862bc:'+path]).decode()
p=src/'crates/ginux-init/src/storage_memory.rs';s=p.read_text().replace('b"ginux-storage\\0"','c"ginux-storage"');p.write_text(s)
p=src/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();d=show('tests/fixtures/launch-storage-fixture.c');a=d.index("    if (argc > 1 && argv[1][0] == 'm') {");b=d.index("    if (argc > 1 && argv[1][0] == 'n')",a);s=s.replace("    if (argc > 1 && argv[1][0] == 'n')",d[a:b]+"    if (argc > 1 && argv[1][0] == 'n')",1)
pos=s.index('long storage_main(');s=s[:pos]+'''/* Ordinary data/coherence checks use only valid mappings and trusted buffers. */
static long ordinary_mapping(int unlink_mode) {
    long fd=DO(2,"/work/mapped",0102,0600);
    CHECK(fd==3 && DO(77,fd,8192,0)==0,150);
    CHECK(DO(1,fd,"old",3)==3 && DO(8,fd,4096,0)==4096 && DO(1,fd,"second",6)==6,151);
    long mapped=call(9,0,8192,3,2,fd,0);
    CHECK(mapped>0,152);
    volatile char *bytes=(volatile char *)mapped;
    CHECK(bytes[0]=='o' && bytes[4096]=='s' && bytes[8191]==0 && DO(8,fd,0,1)==4102,153);
    long shared=call(9,0,4096,1,1,fd,4096);
    CHECK(shared>0 && *(volatile char *)shared=='s',154);
    CHECK(DO(8,fd,0,0)==0 && DO(1,fd,"new",3)==3 && bytes[0]=='n',155);
    bytes[0]='C';
    CHECK(DO(8,fd,0,0)==0 && DO(0,fd,output,3)==3 && output[0]=='n',156);
    long child=DO(57,0,0,0); CHECK(child>=0,157);
    if(!child) {
        CHECK(DO(8,fd,4096,0)==4096 && DO(1,fd,"fresh",5)==5,158);
        DO(60,0,0,0); __builtin_unreachable();
    }
    int status=-1; CHECK(DO(61,child,&status,0)==child && status==0 && bytes[4096]=='f' && *(volatile char *)shared=='f',159);
    CHECK(DO(11,mapped,8192,0)==0 && DO(11,shared,4096,0)==0,160);
    CHECK(DO(77,fd,0,0)==0 && DO(77,fd,8192,0)==0 && DO(8,fd,0,0)==0 && DO(1,fd,"kept",4)==4,161);
    mapped=call(9,0,4096,1,2,fd,0); CHECK(mapped>0 && *(volatile char *)mapped=='k',162);
    if(unlink_mode) {
        CHECK(DO(87,"/work/mapped",0,0)==0 && DO(3,fd,0,0)==0,163);
        fd=DO(2,"/work/mapped",0102,0600); CHECK(fd==3 && DO(1,fd,"other",5)==5 && *(volatile char *)mapped=='k',164);
    }
    CHECK(DO(11,mapped,4096,0)==0 && DO(3,fd,0,0)==0,165);
    return 0;
}
'''+s[pos:]
s=s.replace("    if (argc > 1 && argv[1][0] == 'm') {", "    if (argc > 1 && equal(argv[1],\"ordinary-mapping\")) return ordinary_mapping(0);\n    if (argc > 1 && equal(argv[1],\"ordinary-unlinked-mapping\")) return ordinary_mapping(1);\n    if (argc > 1 && argv[1][0] == 'm') {",1)
# Existing fixture uses same helper under a different name? Add only if absent.
if 'static int equal(' not in s:
 pos=s.index('/* Ordinary data/coherence');s=s[:pos]+'''static int equal(const char *a, const char *b) {
    while(*a && *a==*b) { ++a; ++b; } return *a==*b;
}
'''+s[pos:]
p.write_text(s)
p=src/'scripts/test-launch-storage.py';s=p.read_text();s=s.replace('import shutil\n','import shutil\nimport select\n',1);d=show('scripts/test-launch-storage.py');a=d.index('            command =');b=d.index('            record =',a);s=s.replace("            proc = subprocess.run([binary, 'launch', str(path), str(root), '--result-file', str(result)],\n                                  capture_output=True, timeout=20)\n",d[a:b],1);s=s.replace("('growth', 'bounds', 'quota', 'view-probes')","('growth', 'bounds', 'quota', 'view-probes', 'mapping', 'ordinary-mapping', 'ordinary-unlinked-mapping')");s=s.replace("        invoke([], ['no-storage'])", "        invoke(['memory:/work', 'memory:/out'], ['mapping'])\n        invoke(['memory:/work', 'memory:/out'], ['ordinary-mapping'])\n        invoke(['memory:/work', 'memory:/out'], ['ordinary-unlinked-mapping'])\n        invoke([], ['no-storage'])",1);p.write_text(s)
print('retained full mapping default with unrun protected/SIGBUS/private-FD cases; added two valid ordinary modes')
