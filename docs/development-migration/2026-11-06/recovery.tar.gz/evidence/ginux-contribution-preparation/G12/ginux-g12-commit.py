from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G12');src=root/'source';base=json.loads((root/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['README.md','crates/ginux-init/src/descriptors.rs','crates/ginux-init/src/file_mapping.rs','crates/ginux-init/src/fs_hooks.rs','crates/ginux-init/src/launch_tasks.rs','crates/ginux-init/src/main.rs','crates/ginux-init/src/storage_memory.rs','crates/ginux-vfs/src/lib.rs','scripts/test-launch-storage.py','tests/fixtures/launch-storage-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g12-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(src/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',base,input=('feat(storage): map owned files through read-only backing references\n\nRetain anonymous file identity across mediated writes and resizing.\nJoin private/read-only shared mapping to the current per-process task\ntransaction, retiring temporary descriptors and scratch before return.\nKeep existing storage charging and native mapping behavior.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert not any(x in patch for x in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in ['crates/ginux-init/src/supervisor.rs','crates/ginux-core/src/lib.rs','crates/ginux-process/src/lib.rs','crates/ginux-init/src/exec_script.rs']:assert (src/name).read_bytes()==git('show',base+':'+name)
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G12','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':['G11'],'held_dependencies':['G07 nonleader/thread ownership and shared-argument security acceptance'],'standalone':False,'status':'per-process source/ordinary mapping checks pass; final self-review/clean replay pending; thread join/security/full CI pending','patch_sha256':hashlib.sha256(patch).hexdigest()};(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
(root/'held-thread-join.patch').write_bytes(git('diff','680d5081^','680d5081','--','scripts/test-launch-threads.py','tests/fixtures/launch-thread-fixture.c'))
print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
