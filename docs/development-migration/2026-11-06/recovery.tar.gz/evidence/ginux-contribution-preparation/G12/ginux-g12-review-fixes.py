from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G12/source')
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text().replace('//! Executable references share the VFS owner; retained storage and guest file\n//! mappings use a private read-only backing transfer; retained storage is not provided.', '//! Executable references share the VFS owner. File mappings use a private\n//! read-only backing transfer; retained storage is not provided.');p.write_text(s)
p=src/'README.md';s=p.read_text().replace('owned ELF dynamic loaders, guest file mappings and owned cwd remain unsupported.','owned ELF dynamic loaders and owned cwd remain unsupported.');pos=s.index('The configured `/dev` view is')
s=s[:pos]+'''Owned regular files support private mappings and read-only shared mappings.
Mediated writes/truncation use the same anonymous file backing; private writes
remain copy-on-write, and unlink/recreation preserves existing mapping identity.
Writable shared mappings are unsupported. A temporary read-only descriptor
transfer requires host pidfd_open/pidfd_getfd and ptrace access. Temporary native
descriptors and stack scratch retire before the original mmap returns. Fixed
maps cannot replace the replay instruction or scratch region. Transfer failure,
signal interruption or death stops the domain if cleanup cannot complete safely.
Threads remain unsupported in configured launch; nonleader mapping integration
is not provided here. File capacity charging remains unchanged, but guest mappings,
private COW pages and mappings retained after unlink are not aggregate RAM-accounted.
No retention, mapping budget or wider Linux compatibility is promised.

'''+s[pos:];p.write_text(s)
p=src/'scripts/test-launch-storage.py';s=p.read_text().replace('[growth|bounds|quota|view-probes ...]','[scenario ...]');p.write_text(s)
print('source/docs explicitly retain per-process mapping scope and memory limits')
