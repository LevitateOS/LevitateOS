from pathlib import Path
import subprocess,tarfile,io,json,os,hashlib,re
r=Path('/tmp/ginux-contribution-preparation/G12');s=r/'corrected-head';d=r/'correction-verified-head';assert not d.exists();d.mkdir();m=json.loads((r/'correction-manifest.json').read_text());git=['git','--git-dir=/home/vince/Projects/LevitateOS/.git/modules/tools/ginux/worktrees/ginux']
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(git+['archive',m['base']]))) as t:t.extractall(d,filter='data')
subprocess.run(['git','apply','--whitespace=error',str(r/'corrected-candidate.patch')],cwd=d,check=True);names=subprocess.check_output(git+['ls-tree','-r','--name-only',m['head']]).decode().splitlines()
for name in names:
 a=s/name;b=d/name;assert a.is_symlink()==b.is_symlink(),name;assert (os.readlink(a)==os.readlink(b) if a.is_symlink() else a.read_bytes()==b.read_bytes()),name
cmd=['make','check','test-unit','build','build-launch-fd-fixture','build-launch-storage-fixture']
with (r/'correction-clean-static-build.log').open('w') as f:p=subprocess.run(cmd,cwd=d,stdout=f,stderr=subprocess.STDOUT)
m['clean_static_build']={'command':cmd,'exit_code':p.returncode,'matched_paths':len(names)};m['clean_unit_tests']=sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',(r/'correction-clean-static-build.log').read_text()));m['clean_binary_sha256']=hashlib.sha256((d/'target/x86_64-unknown-linux-gnu/release/ginux').read_bytes()).hexdigest() if p.returncode==0 else None;(r/'correction-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('corrected clean G12',p.returncode,len(names),m['clean_unit_tests'],flush=True);assert p.returncode==0;assert m['source_binary_sha256']==m['clean_binary_sha256']
