Map configured owned files through read-only backing references

Preserve anonymous file identity across writes and resizing, then use the current
process transaction for private and read-only shared mappings. Retire temporary
mapping descriptors and scratch before returning to the workload.

Local validation:92 units, two ordinary mapping scenarios and storage/ELF/script
controls pass in source and clean replay. Thread integration, full security/runtime
coverage, remote CI and prerequisite merges remain pending; not ready to submit.
