from pathlib import Path
import subprocess,os,json
root=Path('/tmp/ginux-contribution-preparation/G13');src=root/'source';p=src/'crates/ginux-vfs/src/lib.rs';s=p.read_text();a=s.index('    fn dangling_image_link_whiteout_stays_reserved');b=s.index('    #[test]',a);chunk=s[a:b].replace('        fs.close(fd).unwrap();','''        fs.close(fd).unwrap();
        fs.teardown();
        fs.unlink(b"/bin").unwrap();
        fs.mkdir(b"/bin", 0o755).unwrap();
        assert_eq!(fs.metadata_no_follow(b"/bin").unwrap().kind, NodeKind::Directory);''');s=s[:a]+chunk+s[b:];p.write_text(s)
cmd=['cargo','test','-p','ginux-vfs','dangling_image_link_whiteout_stays_reserved_and_can_be_replaced'];env={**os.environ,'RUSTFLAGS':'','CARGO_TARGET_DIR':str(root/'review-unit-target')}
with (root/'review-before-mkdir-fix.log').open('w') as log:r=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==101
old='''        let slot = self.allocate_overlay()?;
        self.storage.clear(slot);
        self.overlay[slot].state = 3;
        self.overlay[slot].path = path;
        self.overlay[slot].mode = mode & 0o777;
        self.overlay[slot].len = 0;''';assert old in s;s=s.replace(old,'''        let slot = self.create_overlay(path, mode & 0o777)?;
        self.overlay[slot].state = 3;''',1);p.write_text(s)
with (root/'review-after-mkdir-fix.log').open('w') as log:fixed=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
assert fixed.returncode==0;(root/'review-mkdir-receipt.json').write_text(json.dumps({'before_exit':r.returncode,'after_exit':fixed.returncode},indent=2)+'\n')
for name in ['candidate.patch','candidate.diff','manifest.json','clean-static-build.log','clean-static-receipt.json','final-static-build.log','final-static-receipt.json']:
 q=root/name
 if q.exists():q.rename(root/('pre-mkdir-fix-'+name))
print('bounded replacement regression: donor mkdir fails101; restored create_overlay passes')
