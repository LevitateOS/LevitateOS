from pathlib import Path
import subprocess,os,json
root=Path('/tmp/ginux-contribution-preparation/G13');src=root/'source';p=src/'crates/ginux-vfs/src/lib.rs';saved=p.read_text();old='self.index.lookup_exact(entry.path.as_bytes())';assert old in saved
cmd=['cargo','test','-p','ginux-vfs','dangling_image_link_whiteout_stays_reserved_and_can_be_replaced'];env={**os.environ,'RUSTFLAGS':'','CARGO_TARGET_DIR':str(root/'review-unit-target')};receipts=[]
try:
 p.write_text(saved.replace(old,'self.index.resolve(entry.path.as_bytes())',1))
 with (root/'review-before-whiteout-fix.log').open('w') as log:r=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append({'case':'old followed-target recycling','exit_code':r.returncode});assert r.returncode==101
finally:p.write_text(saved)
with (root/'review-after-whiteout-fix.log').open('w') as log:r=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
receipts.append({'case':'actual candidate exact-entry recycling','exit_code':r.returncode});assert r.returncode==0
(root/'review-whiteout-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipts))
