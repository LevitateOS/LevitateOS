from pathlib import Path
import subprocess
src=Path('/tmp/ginux-contribution-preparation/G13/source');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def show(ref,path):return subprocess.check_output(['git','-C',repo,'show',ref+':'+path]).decode()
p=src/'crates/ginux-vfs/src/lib.rs';s=p.read_text();a=s.index('    pub fn symlink(');b=s.index('    pub fn read_link(',a);chunk=s[a:b].replace('        let slot = self.allocate_overlay()?;', '''        let slot = match self.find_overlay(path.as_bytes()) {
            Some(slot) if self.overlay[slot].state == 2 && self.overlay[slot].executions == 0 && !self.referenced(slot) => slot,
            _ => self.allocate_overlay()?,
        };''',1);s=s[:a]+chunk+s[b:]
pos=s.index('    #[test]\n    fn descriptors_never_equal');s=s[:pos]+'''    #[test]
    fn dangling_image_link_whiteout_stays_reserved_and_can_be_replaced() {
        let mut bytes = index_bytes();
        let mut entry = Index::new(&bytes).unwrap().entry(2).unwrap();
        entry.link = b"absent";
        let mut record = [0; RECORD_SIZE];
        encode_record(entry, &mut record).unwrap();
        bytes[HEADER_SIZE + 2 * RECORD_SIZE..HEADER_SIZE + 3 * RECORD_SIZE].copy_from_slice(&record);
        let mut fs: VirtualFs<'_, Reader, 1, 16, 2> = VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        fs.unlink(b"/bin").unwrap();
        assert_eq!(fs.open(b"/fresh", O_CREATE | O_WRITE), Err(VfsError::OverlayLimit));
        assert_eq!(fs.metadata_no_follow(b"/bin"), Err(VfsError::NotFound));
        assert_eq!(fs.symlink(b"target-beyond-backing-capacity", b"/bin"), Err(VfsError::FileTooLarge));
        assert_eq!(fs.metadata_no_follow(b"/bin"), Err(VfsError::NotFound));
        fs.symlink(b"base", b"/bin").unwrap();
        let fd = fs.open(b"/bin", O_READ).unwrap();
        let mut output = [0; 4];
        assert_eq!(fs.read(fd, &mut output), Ok(4));
        assert_eq!(&output, b"BASE");
        fs.close(fd).unwrap();
    }

'''+s[pos:];p.write_text(s)
# Retain the original full symlink fixture with its unrun security cases.
p=src/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();d=show('8b14578c','tests/fixtures/launch-storage-fixture.c');a=d.index("    if (argc > 1 && argv[1][0] == 's') {");b=d.index("    if (argc > 1 && argv[1][0] == 'l')",a);s=s.replace("    if (argc > 1 && argv[1][0] == 'n')",d[a:b]+"    if (argc > 1 && argv[1][0] == 'n')",1)
pos=s.index('long storage_main(');s=s[:pos]+'''static int named(const char *a, const char *b) { while(*a && *a==*b) { ++a; ++b; } return *a==*b; }
static long ordinary_symlinks(void) {
    CHECK(DO(83,"/work/dir",0755,0)==0 && DO(88,"dir","/work/link",0)==0,200);
    CHECK(DO(2,"/work/link/file",0102,0600)==3 && DO(1,3,"data",4)==4 && DO(3,3,0,0)==0,201);
    CHECK(DO(2,"/work/dir/file",0,0)==3 && DO(0,3,output,4)==4 && output[0]=='d' && DO(3,3,0,0)==0,202);
    CHECK(DO(6,"/work/link",meta,0)==0 && (*(word *)(meta+24)&0170000)==0120000 && *(word *)(meta+48)==3,203);
    CHECK(DO(4,"/work/link",meta,0)==0 && (*(word *)(meta+24)&0170000)==0040000,204);
    CHECK(DO(88,"../link","/work/dir/chain",0)==0,205);
    CHECK(DO(2,"/work/dir/chain/../fresh",0101,0600)==3 && DO(3,3,0,0)==0 && DO(4,"/work/fresh",meta,0)==0,206);
    CHECK(DO(88,"/work/dir/file","/work/absolute",0)==0 && DO(2,"/work/absolute",0,0)==3 && DO(0,3,output,4)==4 && output[0]=='d' && DO(3,3,0,0)==0,207);
    CHECK(DO(88,"created","/work/dangling",0)==0 && DO(2,"/work/dangling",0102,0600)==3 && DO(1,3,"new",3)==3 && DO(3,3,0,0)==0,208);
    CHECK(DO(2,"/work/created",0,0)==3 && DO(0,3,output,3)==3 && output[0]=='n' && DO(3,3,0,0)==0,209);
    CHECK(DO(2,"/work/dir",0200000,0)==3 && DO(266,"file",3,"relative")==0,210);
    CHECK(DO(257,3,"relative",0)==4 && DO(0,4,output,4)==4 && output[0]=='d' && DO(3,4,0,0)==0 && DO(3,3,0,0)==0,211);
    CHECK(DO(82,"/work/link","/work/renamed",0)==0 && DO(87,"/work/renamed",0,0)==0 && DO(4,"/work/dir/file",meta,0)==0,212);
    return 0;
}
'''+s[pos:];s=s.replace("    if (argc > 1 && argv[1][0] == 's') {",'    if (argc > 1 && named(argv[1],"ordinary-symlinks")) return ordinary_symlinks();\n'+"    if (argc > 1 && argv[1][0] == 's') {",1);p.write_text(s)
p=src/'scripts/test-launch-storage.py';s=p.read_text().replace("('growth', 'bounds', 'quota', 'view-probes')","('growth', 'bounds', 'quota', 'view-probes', 'symlinks', 'ordinary-symlinks')").replace("        invoke([], ['no-storage'])","        invoke(['memory:/work', 'memory:/out'], ['symlinks'])\n        invoke(['memory:/work', 'memory:/out'], ['ordinary-symlinks'])\n        invoke([], ['no-storage'])",1);p.write_text(s)
# Normal script-name preservation through a link and an owned interpreter alias.
p=src/'tests/fixtures/launch-script-fixture.c';s=p.read_text().replace('int owned=chain || equal(mode,"ordinary-owned");','int owned=chain || equal(mode,"ordinary-owned") || equal(mode,"ordinary-interpreter-link");');s=s.replace('owned?"/work/interpreter":"/bin/interpreter"','owned?(equal(mode,"ordinary-interpreter-link")?"/work/interpreter-link":"/work/interpreter"):"/bin/interpreter"');s=s.replace('equal(mode,"ordinary-relative")?"work/program":"/work/program"','equal(mode,"ordinary-relative")?"work/program":(equal(mode,"ordinary-script-link")?"/work/alias":"/work/program")')
s=s.replace('(owned?"#!/work/interpreter option with spaces\\nbody\\n":','(owned?(equal(mode,"ordinary-interpreter-link")?"#!/work/interpreter-link option with spaces\\nbody\\n":"#!/work/interpreter option with spaces\\nbody\\n"):');s=s.replace('    if(chain) CHECK(publish','    if(equal(mode,"ordinary-script-link")) CHECK(DO(88,"program","/work/alias",0)==0,96);\n    if(equal(mode,"ordinary-interpreter-link")) CHECK(DO(88,"interpreter","/work/interpreter-link",0)==0,97);\n    if(chain) CHECK(publish',1);s=s.replace('else DO(59,equal(mode,"ordinary-relative")?"work/program":"/work/program",next,next_env);','else DO(59,equal(mode,"ordinary-relative")?"work/program":(equal(mode,"ordinary-script-link")?"/work/alias":"/work/program"),next,next_env);',1);p.write_text(s)
p=src/'scripts/test-launch-scripts.py';s=p.read_text().replace("'ordinary-chain', 'ordinary-joined')","'ordinary-chain', 'ordinary-joined', 'ordinary-script-link', 'ordinary-interpreter-link')");p.write_text(s)
print('ordinary aliases and full deferred fixture retained; whiteout lifetime regression added')
