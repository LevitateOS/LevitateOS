from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G13');src=root/'source';base=json.loads((root/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['README.md','crates/ginux-init/src/descriptors.rs','crates/ginux-init/src/fs_hooks.rs','crates/ginux-vfs/src/lib.rs','scripts/test-launch-storage.py','tests/fixtures/launch-storage-fixture.c','scripts/test-launch-scripts.py','tests/fixtures/launch-script-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g13-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(src/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',base,input=('feat(storage): support owned symbolic link operations\n\nUse the existing component walker for owned symlink traversal, link\nmetadata and target bytes. Preserve final namespace entries during\nmutation, independent descriptor positions and pinned/whiteout identity.\nJoin configured symlink calls and keep owned traversal within assigned\nstorage until image/owned traversal is supported.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert not any(x in patch for x in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in ['crates/ginux-init/src/supervisor.rs','crates/ginux-core/src/lib.rs','crates/ginux-process/src/lib.rs','crates/ginux-init/src/exec_script.rs','crates/ginux-init/src/launch_tasks.rs','crates/ginux-init/src/storage_memory.rs']:assert (src/name).read_bytes()==git('show',base+':'+name)
# Preserve the upstream-derived component walker byte-for-byte.
def walker(s):return s[s.index('fn resolve_components('):s.index('pub trait BaseReader')]
assert walker((src/'crates/ginux-vfs/src/lib.rs').read_text())==walker(git('show',base+':crates/ginux-vfs/src/lib.rs').decode())
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G13','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':['G11'],'standalone':False,'status':'source/ordinary checks pass; final self-review and clean replay pending; security/full CI held','patch_sha256':hashlib.sha256(patch).hexdigest(),'excluded_joins':['G12 mapping unrelated','G19/G21/G22 archive, restore and checkpoint joins deferred']};(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
(root/'deferred-archive-joins.patch').write_bytes(git('diff','aa8becf2^','aa8becf2','--','crates/ginux-init/src/storage_export.rs','crates/ginux-init/src/storage_restore.rs','scripts/test-launch-checkpoints.py'))
print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
