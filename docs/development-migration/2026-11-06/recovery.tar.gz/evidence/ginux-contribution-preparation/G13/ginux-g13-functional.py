from pathlib import Path
import subprocess,json,sys
root=Path('/tmp/ginux-contribution-preparation/G13');src=root/(sys.argv[1] if len(sys.argv)>1 else 'source');prefix='clean-' if src.name!='source' else ''
commands=[['sudo','-n','python3','scripts/test-launch-storage.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-storage-fixture','ordinary-symlinks','growth','bounds','quota'],['sudo','-n','python3','scripts/test-launch-scripts.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-script-fixture','ordinary-plain','ordinary-option','ordinary-nested','ordinary-relative','ordinary-at','ordinary-fd','ordinary-unlinked','ordinary-dir','ordinary-renamed','ordinary-fork','ordinary-vfork','ordinary-owned','ordinary-chain','ordinary-joined','ordinary-script-link','ordinary-interpreter-link'],['sudo','-n','python3','scripts/test-launch-owned-exec.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-owned-exec-fixture','ordinary-path','ordinary-fd','ordinary-unlinked','ordinary-relative','ordinary-child','ordinary-reexec'],['sudo','-n','python3','scripts/test-launch-directories.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-directory-fixture','functional','cwd']]
receipts=[]
for i,cmd in enumerate(commands):
 with (root/f'{prefix}functional-{i}.log').open('w') as log:r=subprocess.run(cmd,cwd=src,stdout=log,stderr=subprocess.STDOUT)
 receipts.append({'command':cmd,'exit_code':r.returncode});(root/f'{prefix}functional-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n');print(prefix+'functional',i,r.returncode,flush=True);assert r.returncode==0
if not prefix:
 cmd=['sudo','-n','python3','scripts/test-launch-storage.py','/tmp/ginux-contribution-preparation/G11/verified-head/target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-storage-fixture','ordinary-symlinks']
 with (root/'baseline-ordinary-symlinks.log').open('w') as log:r=subprocess.run(cmd,cwd=src,stdout=log,stderr=subprocess.STDOUT)
 (root/'baseline-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'base':'0798d991ab2d652e54682750acb4fdd9f1e6d9ac'},indent=2)+'\n');print('G11 baseline expected failure',r.returncode,flush=True);assert r.returncode!=0
