from pathlib import Path
import subprocess,tarfile,io,json
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G13');src=root/'source';base='0798d991ab2d652e54682750acb4fdd9f1e6d9ac'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
def show(ref,path):return git('show',ref+':'+path).decode()
def method(s,signature):
 a=s.index(signature);b=s.index('{',a);depth=1;i=b+1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
assert not src.exists();src.mkdir(parents=True);tarfile.open(fileobj=io.BytesIO(git('archive',base))).extractall(src,filter='data');(root/'composition.json').write_text(json.dumps({'base':base,'donors':['909399b4','aa8becf2','8b14578c','d7f628cc'],'excluded':'G12 unrelated; archive/export/restore joins retained for G19/G21/G22'},indent=2)+'\n')
p=src/'crates/ginux-vfs/src/lib.rs';s=p.read_text();d=show('8b14578c','crates/ginux-vfs/src/lib.rs')
# Retain upstream component walker, shared positions, pins and corrected mutation guards.
for sig in ['    fn resolved_path(']:s=s.replace(method(s,sig),method(d,sig))
s=s.replace('matches!(entry.state, 1 | 3)', 'matches!(entry.state, 1 | 3 | 4)')
s=s.replace('kind: if entry.state == 3 {\n                            NodeKind::Directory\n                        } else {\n                            NodeKind::File\n                        },','kind: match entry.state { 3 => NodeKind::Directory, 4 => NodeKind::Symlink, _ => NodeKind::File },')
s=s.replace('kind: if file.state == 3 {\n                    NodeKind::Directory\n                } else {\n                    NodeKind::File\n                },','kind: match file.state { 3 => NodeKind::Directory, 4 => NodeKind::Symlink, _ => NodeKind::File },')
s=s.replace('Some(index) if self.overlay[index].state == 3 => return Err(VfsError::IsDirectory),','Some(index) if self.overlay[index].state == 3 => return Err(VfsError::IsDirectory),\n            Some(index) if self.overlay[index].state == 4 => return Err(VfsError::SymlinkLoop),',1)
new=''
for sig in ['    pub fn canonical_path(', '    pub fn canonical_namespace_path(', '    fn namespace_path(', '    pub fn symlink(', '    pub fn read_link(', '    pub fn metadata_no_follow(']:
 new+=method(d,sig).replace('metadata_exact(', 'metadata_at(')+'\n\n'
s=s.replace('    /// Follow image links in component order',new+'    /// Follow image links in component order',1)
s=s.replace('size: entry.size,\n        })\n    }\n\n    pub fn fstat', 'size: if entry.kind == NodeKind::Symlink { entry.link.len() as u64 } else { entry.size },\n        })\n    }\n\n    pub fn fstat',1)
for sig in ['    pub fn unlink(', '    pub fn remove_directory(']:
 old=method(s,sig);s=s.replace(old,old.replace('self.resolved_path(path, false, false)?','self.namespace_path(path, false)?'))
s=s.replace(method(s,'    pub fn mkdir('),method(d,'    pub fn mkdir(').replace('metadata_no_follow(', 'metadata_at('))
a=method(s,'    pub fn rename(');b=a.replace('let source = self.resolved_path(source, false, false)?;\n        let destination = self.resolved_path(destination, false, true)?;', 'let directory_destination = destination.ends_with(b"/");\n        let source = self.namespace_path(source, false)?;\n        let destination = self.namespace_path(destination, true)?;').replace('        if source.as_bytes() == destination.as_bytes() {','        if directory_destination && metadata.kind != NodeKind::Directory { return Err(VfsError::NotDirectory); }\n        if source.as_bytes() == destination.as_bytes() {',1);s=s.replace(a,b)
# Whiteout recycling tests base entry identity, not followed target existence.
s=s.replace('self.index.resolve(entry.path.as_bytes()) == Err(VfsError::NotFound)','self.index.lookup_exact(entry.path.as_bytes()) == Err(VfsError::NotFound)')
for name in ['owned_links_resolve_components_and_preserve_namespace_operations','link_io_follows_targets_but_namespace_changes_do_not']:
 test=method(d,'    fn '+name+'(');s=s.replace('    #[test]\n    fn descriptors_never_equal', '    #[test]\n'+test+'\n\n    #[test]\n    fn descriptors_never_equal',1)
p.write_text(s)
# Current descriptor transactions, not donor DescriptorCall.
p=src/'crates/ginux-init/src/descriptors.rs';s=p.read_text();pos=s.index('            258 | 262 | 263 | 267 | 268 | 269 | 332 | 439 =>');s=s[:pos]+'''            266 => {
                self.save(r);
                self.path_handle(pid, r.rsi, r.rdx).map(|handle| {
                    r.rsi = handle;
                    backends.claim(pid, r)
                })
            }
'''+s[pos:];p.write_text(s)
# Current composed namespace owns resolution. Do not add donor lexical routing.
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();a=method(s,'    fn resolve(');b=a.replace('        let n = ginux_vfs::resolve_namespace(', '        let mut owned_link = false;\n        let mut crossed = false;\n        let n = ginux_vfs::resolve_namespace(')
b=b.replace('                return self.fs.metadata(path).map(|m| (m.kind, 0));', '''                let metadata = self.fs.metadata_no_follow(path)?;
                let n = if metadata.kind == NodeKind::Symlink {
                    owned_link = true;
                    self.fs.read_link(path, target)?
                } else { 0 };
                return Ok((metadata.kind, n));''')
b=b.replace('            if path == b"/dev" {','''            // Owned links remain in assigned storage until the image/owned
            // traversal join is supported. Image aliases into storage retain
            // their existing assignment precedence.
            if owned_link { crossed = true; return Err(VfsError::PermissionDenied); }
            if path == b"/dev" {''',1)
b=b.replace('        .map_err(errno)?;','        .map_err(|error| if crossed { -95 } else { errno(error) })?;',1)
b=b.replace('        Path::from_bytes(&output[..n])', '        if owned_link && !self.owns_path(&output[..n]) { return Err(-95); }\n        Path::from_bytes(&output[..n])',1);s=s.replace(a,b)
# Namespace mutations strip trailing separators only for final-entry lookup,
# preserving the actual directory requirement and original dot guards.
s=s.replace('            83 => (0, r.rdi, (-100i64) as u64, false, true),','            83 => (0, r.rdi, (-100i64) as u64, false, true),\n            88 => (1, r.rsi, (-100i64) as u64, false, true),\n            266 => (2, r.rdx, r.rsi, false, true),')
s=s.replace('        let path = self.resolve(pid, path.as_bytes(), follow, missing)?;\n        if dirfd', '''        if matches!(r.orig_rax, 88 | 266) && path.as_bytes().ends_with(b"/") { return Err(-2); }
        let path = if matches!(r.orig_rax, 83 | 84 | 87 | 258 | 263) {
            self.mutation_path(pid, path.as_bytes(), missing)?
        } else { self.resolve(pid, path.as_bytes(), follow, missing)? };
        if dirfd''',1)
pos=s.index('    pub(crate) fn request_path(');s=s[:pos]+'''    fn mutation_path(&self, pid: usize, path: &[u8], missing: bool) -> Result<Path, i64> {
        let mut end = path.len();
        while end > 1 && path[end - 1] == b'/' { end -= 1; }
        let resolved = self.resolve(pid, &path[..end], false, missing)?;
        if end != path.len() {
            let kind = if self.owns_path(resolved.as_bytes()) {
                self.fs.metadata_no_follow(resolved.as_bytes()).map(|m| m.kind)
            } else {
                crate::path_hooks::ImageRoot::new(pid)?.lookup(resolved.as_bytes(), &mut [0; MAX_PATH]).map(|m| m.0)
            };
            match kind {
                Ok(NodeKind::Directory) => {},
                Err(VfsError::NotFound) if missing => {},
                Err(error) => return Err(errno(error)),
                _ => return Err(-20),
            }
        }
        Ok(resolved)
    }

'''+s[pos:]
s=s.replace('    pub fn native_path(&self, pid: usize, r: &UserRegs) -> Result<Option<(u8, Path)>, i64> {','    pub fn native_path(&self, pid: usize, r: &UserRegs) -> Result<Option<(u8, Path)>, i64> {\n        if matches!(r.orig_rax, 88 | 266) { return Ok(None); }',1)
s=s.replace('            89 | 267 => Err(-22),','''            88 | 266 => read_path(pid, r.rdi).and_then(|target| {
                self.fs.symlink(target.as_bytes(), path.as_bytes()).map(|_| 0).map_err(errno)
            }),
            89 | 267 => {
                let (address, length) = if r.orig_rax == 89 { (r.rsi, r.rdx) } else { (r.rdx, r.r10) };
                if length == 0 { Err(-22) } else {
                    let mut target = [0; MAX_PATH];
                    let count = (length as usize).min(target.len());
                    self.fs.read_link(path.as_bytes(), &mut target[..count]).map_err(errno).and_then(|n| {
                        if copy_memory(pid, address, &mut target[..n], true) != Ok(n as i64) { return Err(-14); }
                        Ok(n as i64)
                    })
                }
            },''',1)
# Paths already followed/no-followed by request_path. Never re-follow lstat/access.
s=s.replace('                .metadata(path.as_bytes())\n                .map_err(errno)\n                .and_then(|metadata| access(metadata, r)),','                .metadata_no_follow(path.as_bytes())\n                .map_err(errno)\n                .and_then(|metadata| access(metadata, r)),',1)
s=s.replace('self.fs.metadata(path).map_err(errno)?,','self.fs.metadata_no_follow(path).map_err(errno)?,',1)
s=s.replace('        // NOFOLLOW is valid because this backend has no symlinks. Unsupported\n        // directory/path-only behavior never falls through to native storage.', '        // Unsupported directory/path-only behavior never falls through to native storage.')
pos=s.index('        let metadata = self.fs.metadata(path);',s.index('    fn open('));s=s[:pos]+'''        let entry = self.fs.metadata_no_follow(path);
        if flags & (0o100 | 0o200) == (0o100 | 0o200) && entry.is_ok() { return Err(-17); }
        if flags & 0o400000 != 0 && entry.is_ok_and(|m| m.kind == NodeKind::Symlink) { return Err(-40); }
'''+s[pos:]
# Final trailing slash must not cause rename to follow a directory link.
s=s.replace('        let source = self.resolve(pid, source.as_bytes(), false, false)?;\n        let destination = self.resolve(pid, destination.as_bytes(), false, true)?;', '''        let directory_destination = destination.as_bytes().ends_with(b"/");
        let source = self.mutation_path(pid, source.as_bytes(), false)?;
        let destination = self.mutation_path(pid, destination.as_bytes(), true)?;''',1)
s=s.replace('        if self.prefixes[..self.count].iter().any(|prefix| {\n            self.assignment_root(prefix.as_bytes())', '''        if directory_destination && self.fs.metadata_no_follow(source.as_bytes()).map_err(errno)?.kind != NodeKind::Directory { return Err(-20); }
        if self.prefixes[..self.count].iter().any(|prefix| {
            self.assignment_root(prefix.as_bytes())''',1)
s=s.replace('mode: metadata.mode\n                | if metadata.kind == NodeKind::Directory {\n                    0o40000\n                } else {\n                    0o100000\n                },','mode: metadata.mode | match metadata.kind { NodeKind::Directory => 0o40000, NodeKind::Symlink => 0o120000, _ => 0o100000 },',1)
p.write_text(s)
print('G13 adapted without G12, archive/restore or old component walker')
