Support owned symbolic link operations

Use the existing component walker for owned links, nofollow metadata and link
target bytes. Preserve the final link during namespace mutations and keep
whiteout/pinned identity when names are removed or replaced.

Local validation:95 units and ordinary link/script/ELF/storage/directory checks
pass in source and clean replay. Security/full runtime coverage, remote CI and
prerequisite merges remain pending; not ready to submit.
