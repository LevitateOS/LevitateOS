Title: Support owned directory descriptions and namespace operations

Keep directory cookies and inode identity with open descriptions across aliases,
rename and removal. Validate replacement/type/descendant paths before mutation,
retain open replaced objects, and preserve upstream component-order lookup.
Pair this VFS owner with the configured-runtime adapter for a useful proposal.

Validation: 84 units (31 VFS), make check/build and clean patch replay pass.
An initial dot-entry mutation regression fails before correction and passes
now. Runtime adapter, full CI/security checks and standalone refresh are pending.
