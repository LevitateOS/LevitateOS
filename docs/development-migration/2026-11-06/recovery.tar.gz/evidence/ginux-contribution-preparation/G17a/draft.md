Support positioned writes on owned regular files

Route pwrite through the current bounded write path and preserve the shared
open-description offset on success and failure. Keep sparse growth and Linux
append behavior. Local89-unit checks and ordinary positioned/quota/directory
scenarios pass in source and clean replay. Security/full runtime coverage, remote
CI and prerequisite merges remain pending; not ready to submit.
