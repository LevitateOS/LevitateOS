from pathlib import Path
import json,hashlib,shutil
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G17a');art=root/'.artifacts/ginux-contribution-preparation/G17a';art.mkdir(parents=True,exist_ok=True)
m=json.loads((temp/'manifest.json').read_text());m.update(status='pwrite source separately self-reviewed; selected ordinary source/clean checks pass; G17b and security/full CI/upstream independence pending',unit_tests=89,vfs_tests=31,clean_matched_paths=171,review='separate self-review; no independent reviewer/security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md')
for label,prefix in [('source','final-'),('clean','clean-')]:
 r=json.loads((temp/(prefix+'static-receipt.json')).read_text());assert r['exit_code']==0;m[label+'_binary_sha256']=r['binary_sha256']
assert m['source_binary_sha256']==m['clean_binary_sha256']
for prefix in ['', 'clean-']:assert all(r['exit_code']==0 for r in json.loads((temp/(prefix+'functional-receipt.json')).read_text()))
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for p in temp.iterdir():
 if p.is_file() and p.suffix in ['.json','.patch','.diff','.log']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g17a*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G17a.patch')
(art/'draft.md').write_text('''Support positioned writes on owned regular files

Route pwrite through the current bounded write path and preserve the shared
open-description offset on success and failure. Keep sparse growth and Linux
append behavior. Local89-unit checks and ordinary positioned/quota/directory
scenarios pass in source and clean replay. Security/full runtime coverage, remote
CI and prerequisite merges remain pending; not ready to submit.
''')
(docs/'g17a-review.md').write_text(f'''# G17a — owned positioned writes

Head `{m['head']}` on G09d `{m['base']}`, tree `{m['tree']}`.
[Patch](patches/G17a.patch): four files,+49/-8. This focused part of53a2c9cc has no
namespace/mapping dependency; private backing budgets remain G17b. It is locally
prepared, with security/full CI and actual upstream independence pending.

The current descriptor table already routes syscall18 and restores its public
arguments. Add its owned-file write claim and an optional positioned offset to
the existing bounded write owner. Copy occurs before seeking; failed seek does
not mutate position. Successful or failed writes restore the previous shared
offset. VFS append semantics remain Linux-compatible. Pipes retain ESPIPE and
native descriptors retain their existing contract. No public config/VFS APIs or
process/descriptor ownership change.

A separate final self-review read the whole diff and existing dispatch/descriptor
translation, pipe errno, copy, VFS seek/write/resize/shared positions and cleanup.
This is self-review, not independent/security acceptance. Review found no new
blocking ordinary-functionality defect. The quota fixture now directly verifies
pwrite ENOSPC preserves position, length and bytes; the selected valid fixture
checks duplicate offset sharing, negative offsets, sparse growth and append.
Protected/partial copies and concurrent/raced descriptor state remain with the
[DaybreakBlue handoff](daybreakblue-handoff.md).

Source and strict clean prerequisite-plus-patch replay pass make check test-unit
build build-launch-storage-fixture build-launch-directory-fixture:89 units,31 VFS,
171 matching tracked paths and identical Ginux binaries. Ordinary positioned,
growth, byte bounds, default quota and functional/native-cwd directory controls
pass in both exports. Exact G09d returns ENOTSUP(-95) for pwrite, producing
workload163 on the new valid fixture. Existing default tests/CI remain present;
no security mode was removed or run under another name.

Patch, concise draft, commands/logs/receipts and helpers are retained under
.artifacts/ginux-contribution-preparation/G17a/. Full runtime/security, macOS and
remote CI are unrun. Linux-local results are not green CI. G17 remains partial
until private backing/public-budget preparation. No branch/checkouts/indexes,
remote PR text or maintainer message changed. Publication waits for F04 inspection.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());assert not any(x['packet']=='G17a' for x in plan['packets']);plan['packets'].append({**m,'purpose':'Positioned writes on owned files','source_commits':['53a2c9cc6ee842e97d0ca8214cc1205547b0ab65'],'artifact_directory':'.artifacts/ginux-contribution-preparation/G17a','evidence':'g17a-review.md','source_patch':'patches/G17a.patch'});row=next(x for x in plan['packets'] if x['packet']=='G17');row.update(status='partial: G17a pwrite prepared; G17b private backing/public budgets next',subpackets=['G17a']);p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'\nG17a exact retained revision: {m["head"]} on {m["base"]}.89 routine units and\nordinary positioned/alias/sparse/append/quota checks pass in source/clean replay.\nProtected-copy/race acceptance remains pending; no cloud agent dispatched.\n')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text();a=s.index('Exact next task: **G17');b=s.index('\nActive skill:',a);s=s[:a]+f'''G17a pwrite is locally prepared at `{m['head'][:8]}` on G09d{m['base'][:8]}.
[Review/evidence](ginux-contributions/g17a-review.md) records89 units,171-path strict
replay and ordinary positioned/alias/sparse/append/quota/directory checks passing
in source/clean copies. Exact G09d rejects pwrite. This part has no G18/mapping
prerequisite. G17 remains partial; security/full CI/upstream holds remain.

Exact next task: **G17b — private backing descriptors and public FD budgets**.
Compose only the actual G12 memfd and G18 dynamic metadata prerequisites in a
disposable export; inspect53a2c9cc/d5357101. Capture the public limit before raising
the supervisor soft limit, never raise its hard limit, and bound the tracee by the
captured capacity. Verify ordinary low-limit storage and nonempty-file scaling.
Keep private-FD authority, protected-copy and race probes with DaybreakBlue.
Preserve all existing work; no publication before F04.
''' +s[b:];p.write_text(s);print('retained',m['head'])
