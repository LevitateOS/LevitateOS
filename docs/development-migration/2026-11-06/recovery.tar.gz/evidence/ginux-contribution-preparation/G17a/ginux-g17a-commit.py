from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G17a');src=root/'source';base=json.loads((root/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['README.md','crates/ginux-init/src/fs_hooks.rs','scripts/test-launch-storage.py','tests/fixtures/launch-storage-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g17a-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(src/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',base,input=('feat(storage): support positioned writes on owned files\n\nRoute pwrite through the existing owned write path, restoring the shared\nopen-description offset on success and failure. Retain bounded transfers,\nsparse growth, Linux append behavior and existing descriptor ownership.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert not any(x in patch for x in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in ['crates/ginux-init/src/supervisor.rs','crates/ginux-core/src/lib.rs','crates/ginux-process/src/lib.rs','crates/ginux-init/src/descriptors.rs','crates/ginux-init/src/launch_tasks.rs','crates/ginux-init/src/device_hooks.rs','crates/ginux-init/src/dispatch.rs']:assert (src/name).read_bytes()==git('show',base+':'+name),name
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G17a','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':['G09d'],'standalone':False,'status':'source/ordinary checks pass; final self-review/clean replay pending; security/full CI held','patch_sha256':hashlib.sha256(patch).hexdigest(),'deferred_joins':['G17b private backing budgets','G15 alias and G12 mapping composition','security protected-copy/race validation']};(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
