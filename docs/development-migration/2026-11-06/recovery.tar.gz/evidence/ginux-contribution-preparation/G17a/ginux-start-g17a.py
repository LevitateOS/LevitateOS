from pathlib import Path
import subprocess,tarfile,io,json
root=Path('/tmp/ginux-contribution-preparation/G17a');root.mkdir(exist_ok=True);src=root/'source';assert not src.exists();src.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='85b53fe15a64041f451ec7e7aa1e77d08cb2c18a'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(src,filter='data')
(root/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G09d'],'source':'53a2c9cc6ee842e97d0ca8214cc1205547b0ab65','scope':'pwrite only; private memfd budgets remain G17b'},indent=2)+'\n')
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text().replace('            1 => self.write(pid, fd, r.rsi, r.rdx),','            1 => self.write(pid, fd, r.rsi, r.rdx, None),\n            18 => self.write(pid, fd, r.rsi, r.rdx, Some(r.r10 as i64)),',1)
a=s.index('    fn write(&mut self,');b=s.index('    fn getdents(',a);donor=git('show','53a2c9cc:crates/ginux-init/src/fs_hooks.rs').decode();da=donor.index('    fn write(\n');db=donor.index('    fn getdents(',da);s=s[:a]+donor[da:db]+s[b:];p.write_text(s)
p=src/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();a=s.index('long storage_main(');s=s[:a]+'''static int equal(const char *a, const char *b) {
    while (*a && *a==*b) { ++a; ++b; } return *a==*b;
}
static long positioned(void) {
    long fd=DO(2,"/out/positioned",0102,0600); CHECK(fd>=3,160);
    CHECK(DO(1,fd,"ABC",3)==3 && DO(8,fd,1,0)==1,161);
    long alias=DO(32,fd,0,0); CHECK(alias>=3,162);
    CHECK(call(18,alias,(word)"Z",1,2,0,0)==1 && DO(8,fd,0,1)==1,163);
    CHECK(call(18,fd,(word)"x",1,-1,0,0)==-22 && DO(8,alias,0,1)==1,164);
    CHECK(DO(0,alias,output,2)==2 && output[0]=='B' && output[1]=='Z',165);
    CHECK(DO(8,fd,1,0)==1 && call(18,alias,(word)"Q",1,8192,0,0)==1 && DO(8,fd,0,1)==1,166);
    CHECK(call(17,fd,(word)output,2,8191,0,0)==2 && output[0]==0 && output[1]=='Q' && DO(8,alias,0,1)==1,167);
    CHECK(DO(3,fd,0,0)==0 && DO(3,alias,0,0)==0,168);
    fd=DO(2,"/out/positioned",02002,0); CHECK(fd>=3 && DO(8,fd,2,0)==2,169);
    CHECK(call(18,fd,(word)"!",1,0,0,0)==1 && DO(8,fd,0,1)==2,170);
    CHECK(DO(5,fd,meta,0)==0 && *(word *)(meta+48)==8194,171);
    CHECK(call(17,fd,(word)output,1,8193,0,0)==1 && output[0]=='!' && DO(3,fd,0,0)==0,172);
    return 0;
}
'''+s[a:];s=s.replace('    char **argv = (char **)(stack + 1);','    char **argv = (char **)(stack + 1);\n    if(argc>1 && equal(argv[1],"positioned")) return positioned();',1);p.write_text(s)
p=src/'scripts/test-launch-storage.py';s=p.read_text().replace('[growth|bounds|quota|view-probes ...]','[growth|bounds|quota|positioned|view-probes ...]').replace("('growth', 'bounds', 'quota', 'view-probes')","('growth', 'bounds', 'quota', 'positioned', 'view-probes')");s=s.replace("        invoke([], ['no-storage'])","        invoke(['memory:/work', 'memory:/work/build', 'memory:/out'], ['positioned'])\n        invoke([], ['no-storage'])");p.write_text(s)
p=src/'README.md';s=p.read_text().replace('read/write/pread, ftruncate','read/write/pread/pwrite, ftruncate');p.write_text(s)
print('G17a pwrite port on G09d')
