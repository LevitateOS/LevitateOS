Capture owned filesystem snapshots over private host control

Add an optional inherited Unix stream control socket with bounded sequenced
requests and acknowledgments after complete archive publication. Reuse the
archive writer with distinct staging files for snapshots and final export.
Private signal/control readiness wakes the supervisor; wait4 owns task status.

Local92-unit/build checks and ordinary snapshots, fragmentation, peer cancellation,
task events and existing storage/mapping/exec checks pass in source/clean replay.
Full negative-frame/private-FD validation, thread support, remote CI and upstream
prerequisite merges remain pending. Not ready to submit.
