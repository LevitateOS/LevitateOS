from pathlib import Path
import subprocess,tempfile,socket,json,shutil
root=Path('/tmp/ginux-contribution-preparation/G20');src=root/'source';binary='/tmp/ginux-contribution-preparation/G19/verified-head/target/x86_64-unknown-linux-gnu/release/ginux'
with tempfile.TemporaryDirectory(prefix='ginux-control-baseline-') as folder:
 work=Path(folder);image=work/'root';(image/'bin').mkdir(parents=True);(image/'work').mkdir();shutil.copyfile(src/'.artifacts/launch/launch-storage-fixture',image/'bin/fixture');(image/'bin/fixture').chmod(0o755)
 config=(src/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/fixture"').replace('args = []','args = ["checkpoint"]').replace('[storage]\nassignments = []','[storage]\nassignments = ["memory:/work"]');(work/'config.toml').write_text(config)
 client,server=socket.socketpair()
 try:
  cmd=[binary,'launch',str(work/'config.toml'),str(image),'--result-file',str(work/'result.json'),'--control-fd',str(server.fileno())];r=subprocess.run(cmd,pass_fds=(server.fileno(),),capture_output=True,timeout=5);assert r.returncode==2 and b'launch usage:' in r.stderr and not (work/'result.json').exists()
  (root/'baseline-control.log').write_bytes(r.stdout+r.stderr);(root/'baseline-receipt.json').write_text(json.dumps({'base':'a36e76441b5a7c1a30b3461c9537bb3c6aee9d8e','command':cmd,'exit_code':r.returncode,'behavior':'unknown control option rejected before workload/result setup'},indent=2)+'\n');print('G19 lacks control option as expected')
 finally:client.close();server.close()
