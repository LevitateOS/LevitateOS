from pathlib import Path
import subprocess,tarfile,io,json
root=Path('/tmp/ginux-contribution-preparation/G20');root.mkdir(exist_ok=True);src=root/'source';assert not src.exists();src.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='a36e76441b5a7c1a30b3461c9537bb3c6aee9d8e'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(src,filter='data')
(root/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G19 per-process flush/export'],'source':['2b306eff66f5e650c5b33d256ce922e9a6989445','990fbb7a42f9481b63b80d8ccc41226cd568f10e'],'held_joins':['G07 thread/shared-argument security','G08 finite guest-readiness timer tick','G21 restore checks from later checkpoint harness'],'excluded':['G08 workload socket channels','downstream coordinator protocols']},indent=2)+'\n')
p=src/'crates/ginux-init/src/checkpoint_control.rs';s=git('show','990fbb7a:crates/ginux-init/src/checkpoint_control.rs').decode();s+='''
pub fn close() -> Result<(), Error> {
    let state = unsafe { &mut *core::ptr::addr_of_mut!(CONTROL) };
    let Some(fd) = state.fd.take() else { return Ok(()); };
    if unsafe { crate::supervisor::syscall1(3, fd) } != 0 { return Err(b"checkpoint control close failed"); }
    Ok(())
}
''';p.write_text(s)
p=src/'crates/ginux-init/src/launch.rs';s=p.read_text().replace('Launch(*const u8, *const u8, *const u8, *const u8),','Launch(*const u8, *const u8, *const u8, *const u8, Option<usize>),',1).replace('        let mut export_path: *const u8 = core::ptr::null();','        let mut export_path: *const u8 = core::ptr::null();\n        let mut control_fd = None;',1).replace('''            } else {
                return Some(Command::LaunchUsage);
            }
            i += 2;''','''            } else if c_string_equals(option, b"--control-fd") && control_fd.is_none() {
                control_fd = parse_control_fd(value);
                if control_fd.is_none() { return Some(Command::LaunchUsage); }
            } else {
                return Some(Command::LaunchUsage);
            }
            i += 2;''',1).replace('            export_path,\n        ))','            export_path,\n            control_fd,\n        ))',1)
d=git('show','2b306eff:crates/ginux-init/src/launch.rs').decode();a=d.index('fn parse_control_fd(');b=d.index('pub fn load_config(',a);s=s.replace('pub fn load_config(',d[a:b]+'pub fn load_config(',1)
s=s.replace('    export_path: *const u8,\n) -> ! {','    export_path: *const u8,\n    control_fd: Option<usize>,\n) -> ! {',1).replace('''    let config = launch_load_config(config_path);''','''    crate::checkpoint_control::prepare(control_fd).unwrap_or_else(|reason| launch_startup_fail(reason));
    let config = launch_load_config(config_path);''',1)
s=s.replace('[--export-file <fresh tar path>]"','[--export-file <fresh tar path>] [--control-fd <inherited socket>]"')
s=s.replace('''    let descriptor = unsafe { RESULT_FD };''','''    if crate::checkpoint_control::close().is_err() { line_stderr(b"ginux: checkpoint control close failed"); }
    let descriptor = unsafe { RESULT_FD };''',1);p.write_text(s)
p=src/'crates/ginux-init/src/main.rs';s=p.read_text().replace('mod channel_hooks;','mod channel_hooks;\nmod checkpoint_control;',1).replace('Some(Command::Launch(config_path, root_path, result_path, export_path))','Some(Command::Launch(config_path, root_path, result_path, export_path, control_fd))',1).replace('launch_main(config_path, root_path, result_path, export_path)','launch_main(config_path, root_path, result_path, export_path, control_fd)',1);p.write_text(s)
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();a=s.index('    pub fn export(&self)');b=s.index('    pub fn teardown(',a);d=git('show','2b306eff:crates/ginux-init/src/fs_hooks.rs').decode();da=d.index('    pub fn export(&self)');db=d.index('    pub fn teardown(',da);s=s[:a]+d[da:db]+s[b:];p.write_text(s)
p=src/'crates/ginux-init/src/storage_export.rs';s=p.read_text().replace('static mut EXPORT: Option<Export> = None;','static mut EXPORT: Option<Export> = None;\nstatic mut SERIAL: u64 = 0;',1)
a=s.index('pub fn prepare(');b=s.index('    let mut destination =',a);s=s[:a]+'''pub fn prepare(path: *const u8) -> Result<(), Error> {
    if path.is_null() { return Ok(()); }
    let state = create(path)?;
    unsafe { core::ptr::write(core::ptr::addr_of_mut!(EXPORT), Some(state)); }
    Ok(())
}

fn create(path: *const u8) -> Result<Export, Error> {
'''+s[b:]
a=s.index('    let mut digits = [0; 20];');b=s.index('    if temporary[..end]',a)
s=s[:a]+'''    let serial = unsafe { SERIAL.checked_add(1) }.ok_or(b"export staging identity exhausted".as_slice())?;
    unsafe { SERIAL = serial; }
    let mut suffix = [0; 41];
    let mut suffix_len = 0;
    for number in [pid as u64, serial] {
        if suffix_len != 0 { suffix[suffix_len] = b'-'; suffix_len += 1; }
        let mut digits = [0; 20];
        let mut count = 0;
        let mut number = number;
        loop {
            digits[count] = b'0' + (number % 10) as u8;
            count += 1;
            number /= 10;
            if number == 0 { break; }
        }
        for digit in digits[..count].iter().rev() { suffix[suffix_len] = *digit; suffix_len += 1; }
    }
    let prefix = b".ginux-export-";
    let end = parent.checked_add(prefix.len()).and_then(|n| n.checked_add(suffix_len))
        .filter(|n| *n < PATH_BYTES).ok_or(b"export staging path exceeds bound".as_slice())?;
    let mut temporary = [0; PATH_BYTES];
    temporary[..parent].copy_from_slice(&destination[..parent]);
    temporary[parent..parent+prefix.len()].copy_from_slice(prefix);
    temporary[parent+prefix.len()..end].copy_from_slice(&suffix[..suffix_len]);
'''+s[b:]
needle='''    unsafe {
        core::ptr::write(core::ptr::addr_of_mut!(EXPORT), Some(state));
    }
    Ok(())
}''';assert needle in s;s=s.replace(needle,'    Ok(state)\n}',1)
a=s.index('pub fn finish(');b=s.index('    let mut archive = Archive(state.fd);',a);s=s[:a]+'''pub fn finish(write: impl FnOnce(&mut Archive) -> Result<(), Error>) -> Result<(), Error> {
    let Some(state) = take() else { return Ok(()); };
    complete(state, write)
}

pub fn capture(path: *const u8, write: impl FnOnce(&mut Archive) -> Result<(), Error>) -> Result<(), Error> {
    complete(create(path)?, write)
}

fn complete(state: Export, write: impl FnOnce(&mut Archive) -> Result<(), Error>) -> Result<(), Error> {
'''+s[b:];p.write_text(s)
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text().replace('    tearing_down: bool,','    tearing_down: bool,\n    signal_fd: Option<usize>,',1).replace('        tearing_down: false,','        tearing_down: false,\n        signal_fd: None,',1)
d=git('show','990fbb7a:crates/ginux-init/src/launch_tasks.rs').decode();a=d.index('// Created only after');b=d.index('pub fn supervise(',a);event=d[a:b].replace('fn wait_events(signal_fd: usize, timer: bool)','fn wait_events(signal_fd: usize)').replace('''    // Owned finite polls need a millisecond tick; otherwise either descriptor
    // wakes us immediately, including control requests while all tasks sleep.
''','''    // Either private descriptor wakes us, including requests while tasks sleep.
''').replace('if timer { 1 } else { usize::MAX }','usize::MAX');s=s.replace('pub fn supervise(',event+'pub fn supervise(',1)
s=s.replace('    s.resume(0, 0, domain);','''    let signal_fd = task_events().unwrap_or_else(|reason| s.fail(domain, reason));
    s.signal_fd = Some(signal_fd);
    s.resume(0, 0, domain);''',1).replace('''        s.wake(domain);
        status = 0;''','''        s.wake(domain);
        // Only this owner mediates owned mutations; snapshot serialization
        // cannot interleave with another owned write.
        if let Err(reason) = crate::checkpoint_control::poll(s.objects.filesystem) { s.fail(domain, reason); }
        status = 0;''',1).replace('''                WALL,
                0,
            )
        };
        if host == -4''','''                WALL | 1,
                0,
            )
        };
        if host == 0 {
            if let Err(reason) = wait_events(signal_fd) { s.fail(domain, reason); }
            continue;
        }
        if host == -4''',1)
s=s.replace('''        let exported = if export {''','''        let control_closed = crate::checkpoint_control::close();
        let event_closed = if let Some(fd) = self.signal_fd.take() {
            if unsafe { syscall1(3, fd) } == 0 { Ok(()) } else { Err(b"task event close failed".as_slice()) }
        } else { Ok(()) };
        let settled = control_closed.and(event_closed);
        let exported = settled.and_then(|_| if export {''',1).replace('''            crate::storage_export::cancel()
        };
        self.objects.filesystem.teardown();''','''            crate::storage_export::cancel()
        });
        self.objects.filesystem.teardown();''',1);p.write_text(s)
print('G20 host control/event wait port, isolated repeated archive captures')
