from pathlib import Path
import json, hashlib, shutil
root=Path('/home/vince/Projects/LevitateOS'); docs=root/'docs/ginux-contributions'; temp=Path('/tmp/ginux-contribution-preparation/G20'); art=root/'.artifacts/ginux-contribution-preparation/G20'
m=json.loads((temp/'manifest.json').read_text())
for prefix in ['', 'clean-']:
    receipts=json.loads((temp/(prefix+'functional-receipt.json')).read_text())
    assert len(receipts)==4 and all(r['exit_code']==0 for r in receipts)
static=[json.loads((temp/(prefix+'static-receipt.json')).read_text()) for prefix in ['final-','clean-']]
assert all(r['exit_code']==0 and r['matched_paths']==181 and r['head']==m['head'] for r in static)
assert static[0]['binary_sha256']==static[1]['binary_sha256']
fixtures={}
for name in ['launch-storage-fixture','launch-directory-fixture','launch-script-fixture','launch-owned-exec-fixture']:
    a=(temp/'source/.artifacts/launch'/name).read_bytes(); b=(temp/'verified-head/.artifacts/launch'/name).read_bytes(); assert a==b
    fixtures[name]=hashlib.sha256(a).hexdigest()
m.update(status='per-process source separately self-reviewed; selected ordinary source/clean checks pass; security/thread/full CI/upstream independence pending',unit_tests=92,vfs_tests=34,clean_matched_paths=181,review='separate self-review; no independent reviewer or security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',held_dependencies=['G07 thread/shared-argument security'],source_binary_sha256=static[0]['binary_sha256'],clean_binary_sha256=static[1]['binary_sha256'],fixture_sha256=fixtures)
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n'); art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
    if p.is_file() and p.suffix in ['.json','.log','.patch','.diff']: shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g20*.py'): shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G20.patch')
(art/'draft.md').write_text('''Capture owned filesystem snapshots over private host control

Add an optional inherited Unix stream control socket with bounded sequenced
requests and acknowledgments after complete archive publication. Reuse the
archive writer with distinct staging files for snapshots and final export.
Private signal/control readiness wakes the supervisor; wait4 owns task status.

Local92-unit/build checks and ordinary snapshots, fragmentation, peer cancellation,
task events and existing storage/mapping/exec checks pass in source/clean replay.
Full negative-frame/private-FD validation, thread support, remote CI and upstream
prerequisite merges remain pending. Not ready to submit.
''')
assert not any(x in (art/'draft.md').read_text() for x in ['LevitateOS','Recipe','Daybreak'])
(docs/'g20-review.md').write_text(f'''# G20 — private checkpoint control and task-event waiting

Head `{m['head']}`, tree `{m['tree']}`, on G19
`{m['base']}`. [Patch](patches/G20.patch):11 files,+563/-36.
Per-process source and selected ordinary verification are retained. Security,
thread-sharing, full CI and current-main independence remain pending.

`--control-fd` accepts one inherited Unix stream socket. The existing donor
protocol uses bounded GXS1 frames, strictly increasing u64 sequences, a u16 path
length1–512 and non-NUL path bytes. GXA1 acknowledges only after snapshot write,
sync, close and no-overwrite publication. Partial reads/replies persist in the
single event-loop owner; invalid requests, capture failure and peer loss stop
launch. The workload's existing bootstrap closes inherited descriptors above
stdio. Runtime FD-authority validation is deliberately unrun here.

Separate whole-diff self-review covered current argv/config/completion callers,
bootstrap descriptor cleanup, task birth/wait/death/teardown, control buffering,
readiness and archive lifetime. This is self-review, not independent review.

- **Repeated capture ownership corrected:** the G19 PID-only staging name would
  collide with an already prepared final export. Checked PID/serial names now
  isolate each capture. Capture owns its staging locally, while final export
  retains its existing global owner. Both reuse one write/sync/close/publication
  implementation and the same filesystem archive visitor.
- **Cleanup retained:** common launch completion closes control idempotently,
  including config rejection. Task teardown closes control and signal descriptors
  independently before export and always tears down storage. Error completion
  cancels pending final output through the existing owner.
- **Event ownership preserved:** after the initial tracee exec stop, the supervisor
  blocks SIGCHLD, restores its default disposition and creates private signalfd.
  wait4(WNOHANG) alone consumes statuses; poll waits for signal/control readiness
  without a timer tick. The blocked signal bridges the check/wait interval.
  Existing typed child birth, wait and cleanup logic is unchanged. G08's finite
  guest-readiness timer is not imported and must join only with its own capability.
- **Scope:** core/process policy, native supervisor, public descriptors, tracee
  transfer/mapping/storage backing, VFS and its shared path walker are unchanged.
  G07 thread/shared-argument checks and G13/G15/G18/G21/G22 joins stay assigned to
  their existing owners. No guest socket channels or consumer protocol is added.
- **Coverage wiring:** the introducing packet adds its Make target and Linux CI
  invocation using the existing storage fixture build. Static-and-unit still runs
  make check and make test-unit. Full negative/private-FD defaults are preserved.

Exact G19 rejects the valid inherited-control invocation with usage exit2.
Source and strict clean prerequisite-plus-patch replay pass make check test-unit
build and storage/directory/script/owned-exec fixture builds:92 units,34 VFS,
181 matching tracked paths. Ginux and all four fixture binaries match. Ordinary
runtime checks pass in both copies: two valid fragmented captures, byte/content
isolation after mutation, child-produced data, final export in the same directory,
normal peer cancellation and10000 task syscalls with idle control off/on and
inherited ignored SIGCHLD. Seven final-export/config/flush cases, two valid mapping,
six ELF,14 script and growth/bounds/quota controls pass too. Timing output is a
smoke observation, not a performance guarantee or race proof.

Malformed/replayed/oversized frames, FD visibility and private authority, hostile
paths, injected failures, inherited signal-mask/race behavior and thread sharing
remain with [DaybreakBlue](daybreakblue-handoff.md), with no cloud dispatch.
Independent review, full Linux suite, macOS/remote CI and fresh-main standalone
validation remain unrun. The G19 prerequisite is local; do not publish this stack.
Patch, draft, commands, logs, hashes and helpers are retained under
.artifacts/ginux-contribution-preparation/G20/. No real Ginux branch, index,
checkout/ref, remote text or maintainer message changed. F04 remains the review stop.
''')
p=docs/'p05-package-plan.json'; plan=json.loads(p.read_text()); row=next(x for x in plan['packets'] if x['packet']=='G20'); row.update(m); row.update(evidence='g20-review.md',source_patch='patches/G20.patch')
row=next(x for x in plan['packets'] if x['packet']=='G31'); row['checkpoint_wiring']='Folded into G20 introducing packet; full/default runtime and remote CI unrun. Restore wiring remains with G21.'
p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'daybreakblue-handoff.md'; p.write_text(p.read_text()+f'''\nG20 exact retained revision: {m['head']} on G19 {m['base']}.
92 routine units and selected ordinary capture/fragmentation/final-export/peer-
closure/task-event plus existing storage/exec controls pass in source/clean replay.
No negative-frame, private-FD inspection, race or injected-failure run occurred.
Validate bounded framing/authority, bootstrap leakage, readiness/lost-stop races,
inherited signal masks and shared mutation independently. No cloud dispatch;
[review/evidence](g20-review.md).\n''')
p=root/'docs/ginux-contribution-task-list.md'; s=p.read_text(); a=s.index('Exact next task: **G20'); b=s.index('\nActive skill:',a)
s=s[:a]+f'''G20 per-process source/ordinary preparation is retained at `{m['head'][:8]}` on
G19{m['base'][:8]}. [Review/evidence](ginux-contributions/g20-review.md) records92
units,181-path strict replay, two valid fragmented captures plus final export,
normal peer cancellation and task events, plus export/mapping/exec/storage controls
passing in source/clean exports. Shared archive staging now has distinct capture
identities. Private signalfd/poll replaces blocking task wait while wait4 retains
status ownership. Essential G31 checkpoint CI wiring is folded into this packet;
full/default/remote runs, security, G07 threads and upstream independence remain
pending. Exact G19 rejects the new option. No publication occurred.

Exact next task: **G21 — validated startup restore**.
Inspect1d9e00e0 on the G19 export/storage owner. Keep restore independent of G20's
control transport and use the shared current filesystem/metadata/storage owners.
Run ordinary valid startup reconstruction before workload execution; write down
malformed/traversing/oversized archive, collision/authority and failure-injection
security acceptance for DaybreakBlue instead of executing it. Preserve full
fixtures and fold essential restore CI wiring into the feature. No publication
or maintainer messages before F04.
''' +s[b:]; p.write_text(s); print('retained',m['head'])
