from pathlib import Path
import subprocess
root=Path('/tmp/ginux-contribution-preparation/G20');src=root/'source';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a]).decode()
p=src/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();a=s.index('long storage_main(');s=s[:a]+'''static long checkpoint_data(void) {
    long fd=DO(2,"/work/checkpoint",0102,0600); CHECK(fd==3 && DO(1,fd,"first",5)==5,210);
    long child=DO(57,0,0,0); CHECK(child>=0,211);
    if(!child) {
        long data=DO(2,"/work/child",0101,0600);
        CHECK(data>=3 && DO(1,data,"child",5)==5 && DO(3,data,0,0)==0,212); return 0;
    }
    int status=-1; CHECK(DO(61,child,&status,0)==child && status==0,213);
    CHECK(DO(1,1,"checkpoint-ready\\n",17)==17 && DO(0,0,output,1)==1,214);
    CHECK(DO(8,fd,0,0)==0 && DO(1,fd,"second",6)==6,215);
    CHECK(DO(1,1,"checkpoint-ready\\n",17)==17 && DO(0,0,output,1)==1,216);
    CHECK(DO(74,fd,0,0)==0 && DO(75,fd,0,0)==0 && DO(3,fd,0,0)==0,217);
    return 0;
}
static long task_events_data(void) {
    for(word n=0;n<10000;++n) CHECK(DO(39,0,0,0)>0,218);
    CHECK(DO(1,1,"events: PASS\\n",13)==13,219); return 0;
}
'''+s[a:];needle='    char **argv = (char **)(stack + 1);';s=s.replace(needle,needle+'\n    if(argc>1 && equal(argv[1],"checkpoint")) return checkpoint_data();\n    if(argc>1 && equal(argv[1],"events")) return task_events_data();',1);p.write_text(s)
p=src/'scripts/test-launch-checkpoints.py';s=git('show','2b306eff:scripts/test-launch-checkpoints.py').replace('import shutil','import shutil\nimport signal\nimport time',1).replace('    if len(sys.argv) != 3 or os.geteuid() != 0:','    if len(sys.argv) not in (3,4) or os.geteuid() != 0:',1).replace('<storage-fixture>\')','<storage-fixture> [ordinary]\')',1).replace('    binary, fixture = [str(Path(p).resolve()) for p in sys.argv[1:]]','    binary, fixture = [str(Path(p).resolve()) for p in sys.argv[1:3]]\n    ordinary = len(sys.argv)==4\n    if ordinary and sys.argv[3]!=\'ordinary\': sys.exit(\'unknown checkpoint selection\')',1)
s=s.replace("        for failure in (None, 'replay', 'existing'):","        for failure in ((None,) if ordinary else (None, 'replay', 'existing')):",1)
s=s.replace("            result = work / f'result-{failure}.json'","            result = work / f'result-{failure}.json'\n            final = work / f'final-{failure}.tar'",1).replace("'--result-file', str(result), '--control-fd', str(server.fileno())]","'--result-file', str(result), '--export-file', str(final), '--control-fd', str(server.fileno())]",1)
a=s.index('                        children = Path(');b=s.index('                        archive = work /',a);s=s[:a]+'                        if not ordinary:\n'+''.join('    '+line for line in s[a:b].splitlines(keepends=True))+s[b:]
s=s.replace("                            break\n                        assert receive", "                            assert not final.exists()\n                            break\n                        assert receive",1).replace("                            assert tar.extractfile('work/checkpoint').read() == expected","                            assert tar.extractfile('work/checkpoint').read() == expected\n                            assert tar.extractfile('work/child').read() == b'child'",1)
s=s.replace("                        assert json.loads(result.read_text())['code'] == 0","                        assert json.loads(result.read_text())['code'] == 0\n                        with tarfile.open(final) as tar:\n                            assert tar.extractfile('work/checkpoint').read() == b'second'\n                        assert not list(work.glob('.ginux-export-*'))",1)
a=s.index("        print('test-launch-checkpoints:");s=s[:a]+'''        # A normally disconnected coordinator cancels a blocked workload.
        client, server = socket.socketpair()
        result, final = work/'closed.json', work/'closed.tar'
        with (work/'closed.audit').open('wb') as audit:
            proc = subprocess.Popen([binary,'launch',str(config_path),str(root),'--result-file',str(result),'--export-file',str(final),'--control-fd',str(server.fileno())],
                pass_fds=(server.fileno(),),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=audit)
            server.close()
            try:
                assert select.select([proc.stdout],[],[],5)[0]
                assert proc.stdout.readline()==b'checkpoint-ready\\n'
                client.close()
                assert proc.wait(timeout=5)==1
                stdout,_=proc.communicate(timeout=5)
                assert not stdout and json.loads(result.read_text())['outcome']=='supervisor-error'
                assert not final.exists() and not list(work.glob('.ginux-export-*'))
            finally:
                client.close()
                if proc.poll() is None: proc.kill(); proc.communicate(timeout=5)
        # Idle control must not force a polling tick per syscall. An inherited
        # ignored SIGCHLD must not prevent the supervisor's private task wait.
        config_path.write_text(config.replace('args = ["checkpoint"]','args = ["events"]'))
        for controlled in (False,True):
            client, server = socket.socketpair()
            try:
                command=[binary,'launch',str(config_path),str(root)]
                if controlled: command+=['--control-fd',str(server.fileno())]
                start=time.monotonic()
                proc=subprocess.run(command,pass_fds=(server.fileno(),) if controlled else (),
                    preexec_fn=lambda: signal.signal(signal.SIGCHLD,signal.SIG_IGN),capture_output=True,timeout=10)
                assert proc.returncode==0,proc.stderr.decode()
                assert proc.stdout==b'events: PASS\\n',proc.stdout
                print(f'10000 syscalls, control={controlled}: {time.monotonic()-start:.3f}s')
            finally:
                client.close(); server.close()
'''+s[a:];s=s.replace("print('test-launch-checkpoints: PASS (snapshots, isolation, private fds, partial frames, replay, freshness)')","print('test-launch-checkpoints: PASS (' + ('ordinary snapshots, fragmented valid frames, final export, cancellation and task events' if ordinary else 'snapshots, private fds, partial frames, replay, freshness, cancellation and task events') + ')')");compile(s,str(p),'exec');p.write_text(s)
p=src/'Makefile';s=p.read_text();assert 'test-launch-checkpoints:' not in s;s+='\n.PHONY: test-launch-checkpoints\ntest-launch-checkpoints:\n\tpython3 scripts/test-launch-checkpoints.py $(GINUX) .artifacts/launch/launch-storage-fixture\n';p.write_text(s)
p=src/'.github/workflows/check.yml';s=p.read_text().replace('      - run: sudo make test-launch-storage','      - run: sudo make test-launch-storage\n      - run: sudo make test-launch-checkpoints',1);p.write_text(s)
p=src/'README.md';s=p.read_text().replace('retained storage, checkpoint/restore, symlink or hardlink archive support.','retained storage, startup restoration, symlink or hardlink archive support.');s+='''
A host coordinator may pass `--control-fd <inherited Unix stream socket>` for
mid-run filesystem snapshots. The supervisor keeps the socket private. Requests
are GXS1, a little-endian u64 strictly increasing sequence, a little-endian u16
pathname length1–512, and non-NUL pathname bytes. Destinations must be fresh.
Only after complete archive write/sync/close and no-overwrite publication does
it reply GXA1, the matching little-endian u64 sequence and u64 zero status.
Valid partial frames are buffered within the fixed bound. Invalid requests,
peer loss and capture failure stop the domain. The host owns request deadlines,
directory durability, paired state and workload acknowledgment. Capture serializes
with mediated owned filesystem mutation; it does not save process memory or live
handles. Private signal/control readiness wakes the supervisor without a periodic
control tick; wait4 remains the sole task-status owner. Guest polling, shared
thread capture and startup restore remain separate capabilities.
''';p.write_text(s)
print('G20 existing checkpoint harness adapted; full security defaults retained')
