from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G17b/source')
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();a=s.index('        let namespace = MappedArray::new(');s=s[:a]+'''        if count != 0 {
            // One backing FD per possible object plus bounded supervisor work.
            // The launcher captures the public limit before this reservation.
            let required = objects.checked_add(128)
                .ok_or(b"storage descriptor budget overflow".as_slice())?;
            let mut limits = [0usize; 2];
            if unsafe { crate::supervisor::syscall4(302, 0, 7, 0, limits.as_mut_ptr() as usize) } != 0 {
                return Err(b"cannot inspect storage descriptor budget");
            }
            if limits[0] < required {
                if limits[1] < required {
                    return Err(b"storage descriptor budget exceeds host hard limit");
                }
                limits[0] = required;
                if unsafe { crate::supervisor::syscall4(302, 0, 7, limits.as_ptr() as usize, 0) } != 0 {
                    return Err(b"cannot reserve storage descriptor budget");
                }
            }
        }
'''+s[a:];p.write_text(s)
p=src/'crates/ginux-init/src/descriptors.rs';s=p.read_text().replace('    pub fn fork_copy(', '    pub fn capacity(&self) -> usize { self.capacity }\n\n    pub fn fork_copy(',1);p.write_text(s)
p=src/'crates/ginux-init/src/launch.rs';s=p.read_text();block='''    let descriptors = crate::descriptors::DescriptorTable::new()
        .unwrap_or_else(|reason| launch_startup_fail(reason));
''';assert s.count(block)==1;s=s.replace(block,'',1);a=s.index('    let mut filesystem = crate::fs_hooks::LaunchFs::prepare(&config)');s=s[:a]+'    // Capture the public operator limit before reserving private backing FDs.\n'+block+s[a:];s=s.replace('        launch_tracee(root_path);','        launch_tracee(root_path, descriptors.capacity());',1).replace('fn launch_tracee(root_path: *const u8) -> ! {','fn launch_tracee(root_path: *const u8, descriptor_limit: usize) -> ! {',1).replace('reserve_native_descriptors(crate::descriptors::LIMIT)','reserve_native_descriptors(descriptor_limit)',1);p.write_text(s)
p=src/'scripts/test-launch-storage.py';s=p.read_text().replace('import os','import os\nimport resource',1);needle='''                proc = subprocess.run(command, capture_output=True, timeout=20)''';assert needle in s;s=s.replace(needle,'''                def bounded_host_fds():
                    _, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
                    resource.setrlimit(resource.RLIMIT_NOFILE, (min(64, hard), hard))
                proc = subprocess.run(command, capture_output=True, timeout=20,
                                      preexec_fn=bounded_host_fds if args == ['namespace'] else None)''',1);p.write_text(s)
p=src/'tests/fixtures/launch-fd-fixture.c';s=p.read_text().replace('''        for(word i=3;i<8;++i)''','''        char path[]="/work/item-00";
        for(word n=0;n<20;++n) {
            path[11]='0'+n/10; path[12]='0'+n%10;
            long fd=DO(2,path,0102,0600); CHECK(fd==3,56);
            CHECK(DO(1,fd,"data",4)==4 && DO(3,fd,0,0)==0,57);
        }
        for(word i=3;i<8;++i)''',1);p.write_text(s)
p=src/'scripts/test-launch-fds.py';s=p.read_text().replace("    if len(sys.argv)!=3 or os.geteuid()!=0:","    if len(sys.argv) not in (3,4) or os.geteuid()!=0:").replace("<fd-fixture>')","<fd-fixture> [limits]')",1).replace("    binary,fixture=[str(Path(p).resolve()) for p in sys.argv[1:]]","    binary,fixture=[str(Path(p).resolve()) for p in sys.argv[1:3]]\n    only_limits = len(sys.argv)==4\n    if only_limits and sys.argv[3]!='limits': sys.exit('unknown fd scenario')")
a=s.index('        for i in range(2):');b=s.index('        # A lower operator limit',a);s=s[:a]+'        if not only_limits:\n'+''.join('    '+line if line.strip() else line for line in s[a:b].splitlines(keepends=True))+s[b:];s=s.replace('            resource.setrlimit(resource.RLIMIT_NOFILE,(8,8))','            _, hard = resource.getrlimit(resource.RLIMIT_NOFILE)\n            resource.setrlimit(resource.RLIMIT_NOFILE,(8,hard))',1)
a=s.index("        print('test-launch-fds:");s=s[:a]+'''        def insufficient_hard_limit():
            resource.setrlimit(resource.RLIMIT_NOFILE,(8,8))
        result=work/'hard.json'
        proc=subprocess.run([binary,'launch',str(work/'low.toml'),str(root),'--result-file',str(result)],capture_output=True,timeout=20,preexec_fn=insufficient_hard_limit)
        assert proc.returncode==2 and b'storage descriptor budget exceeds host hard limit' in proc.stderr,(proc.returncode,proc.stderr)
        assert json.loads(result.read_text())['outcome']=='supervisor-error'
'''+s[a:];p.write_text(s)
p=src/'README.md';s=p.read_text();needle='supervisor allocations hold namespace and backing metadata;';assert needle in s;s=s.replace(needle,'''supervisor allocations hold namespace and backing metadata. Before workload
startup, assigned storage reserves max_objects +128 private descriptors by raising
only the supervisor soft limit within its existing hard limit; insufficient hard
capacity rejects launch. The public descriptor capacity is captured beforehand
and applied to the tracee. Namespace/backing metadata's''',1).replace("Namespace/backing metadata's their page-rounded","Their page-rounded");p.write_text(s)
print('G17b reservation and public-limit preservation')
