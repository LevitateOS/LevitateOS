from pathlib import Path
import subprocess,json
root=Path('/tmp/ginux-contribution-preparation/G17b');src=root/'source';binary=str(root/'prerequisite/target/x86_64-unknown-linux-gnu/release/ginux')
commands=[['sudo','-n','python3','scripts/test-launch-fds.py',binary,'.artifacts/launch/launch-fd-fixture','limits'],['sudo','-n','python3','scripts/test-launch-storage.py',binary,'.artifacts/launch/launch-storage-fixture','namespace']]
rows=[]
for i,cmd in enumerate(commands):
 with (root/f'baseline-{i}.log').open('w') as f:r=subprocess.run(cmd,cwd=src,stdout=f,stderr=subprocess.STDOUT)
 s=(root/f'baseline-{i}.log').read_text();assert r.returncode!=0 and 'workload-exit-code=' in s,s[-1000:]
 rows.append({'base':json.loads((root/'composition.json').read_text())['base'],'command':cmd,'exit_code':r.returncode,'failure_tail':s[-500:]});print('baseline',i,'expected failure',r.returncode,flush=True)
(root/'baseline-receipt.json').write_text(json.dumps(rows,indent=2)+'\n')
