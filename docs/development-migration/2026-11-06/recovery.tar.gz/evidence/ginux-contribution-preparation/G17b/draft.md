Reserve private storage FDs without widening workload limits

Capture public descriptor capacity before reserving max_objects+128 supervisor
FDs. Raise only the supervisor soft limit within its existing hard limit and apply
the captured public capacity to the workload. Reject insufficient hard capacity
before workload startup.

Local94-unit/build checks and ordinary low-limit,5000-file, mapping, script and
ELF scenarios pass in source and clean replay. Security/full runtime coverage,
remote CI and prerequisite merges remain pending; not ready to submit.
