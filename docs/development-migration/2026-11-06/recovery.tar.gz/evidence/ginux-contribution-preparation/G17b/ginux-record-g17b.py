from pathlib import Path
import json,hashlib,shutil
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G17b');art=root/'.artifacts/ginux-contribution-preparation/G17b';art.mkdir(parents=True,exist_ok=True)
m=json.loads((temp/'manifest.json').read_text());m.update(status='source separately self-reviewed; ordinary source/clean static/unit/build/runtime checks pass; security/full CI/current-main independence pending',unit_tests=94,vfs_tests=35,clean_matched_paths=178,review='separate self-review; no independent reviewer/security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=json.loads((temp/'final-static-receipt.json').read_text())['binary_sha256'],clean_binary_sha256=json.loads((temp/'clean-static-receipt.json').read_text())['binary_sha256'])
assert m['source_binary_sha256']==m['clean_binary_sha256']
for prefix in ['', 'clean-']:
 rs=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(rs)==4 and all(r['exit_code']==0 for r in rs)
fixtures={}
for name in ['launch-storage-fixture','launch-directory-fixture','launch-script-fixture','launch-owned-exec-fixture','launch-fd-fixture']:
 a=(temp/'source/.artifacts/launch'/name).read_bytes();b=(temp/'verified-head/.artifacts/launch'/name).read_bytes();assert a==b;fixtures[name]=hashlib.sha256(a).hexdigest()
m['fixture_sha256']=fixtures;(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for p in temp.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.patch','.diff']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g17b*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G17b.patch')
(art/'draft.md').write_text('''Reserve private storage FDs without widening workload limits

Capture public descriptor capacity before reserving max_objects+128 supervisor
FDs. Raise only the supervisor soft limit within its existing hard limit and apply
the captured public capacity to the workload. Reject insufficient hard capacity
before workload startup.

Local94-unit/build checks and ordinary low-limit,5000-file, mapping, script and
ELF scenarios pass in source and clean replay. Security/full runtime coverage,
remote CI and prerequisite merges remain pending; not ready to submit.
''')
assert not any(s in (art/'draft.md').read_text() for s in ['LevitateOS','Recipe','Daybreak'])
(docs/'g17b-review.md').write_text(f'''# G17b — private backing budget and captured public limits

Head `{m['head']}`, tree `{m['tree']}`, on local composition
`{m['base']}` of G12 `83072ec3` and G18 `f58ba480`.
[Patch](patches/G17b.patch): seven files,+80/-27. G17a pwrite is deliberately
independent. Security/full CI and actual upstream independence remain pending.

Capture DescriptorTable capacity before preparing storage. Assigned storage
reserves max_objects+128 private descriptors after metadata/data validation,
raising only the supervisor soft limit when its existing hard limit permits it.
The tracee applies the captured capacity to both native soft/hard bounds, then
uses existing close_range cleanup; its public allocator keeps the same capacity.
No hard limit is raised, and no-storage launches skip reservation. No new public
configuration, process table or resource-control abstraction is introduced.

A separate final self-review read the entire delta and relevant constructor,
resource capture/validation, descriptor allocation/fork-copy, bootstrap cleanup,
memfd backing/clear, mapping and task lifetime callers. Source stays with current
owners. VFS, memory backing, typed process/native supervisor, mapping transactions
and tracee copy implementation are identical to the composed prerequisite. This
is self-review, not independent reviewer/security acceptance.

The composition retains G12 memfd identity and G18 checked/page-rounded metadata
allocation, shared positions and actual namespace length. Four merge conflicts
were resolved locally in the constructor/backing and fixture joins. An outdated
G12 FD fixture still expected owned mmap rejection; its valid readonly-map
assertion is corrected in the prerequisite, with writable-shared rejection retained.
That mapping-owned join and the full prerequisite diff are retained for F01/F02,
not hidden in this contribution's delta. An initial duplicate fixture helper was
caught by -Werror and removed; no warning/test was suppressed. No G07 thread or
G13–G16 ancestry is imported. Those interactions still require F02.

Source and strict clean prerequisite-plus-patch export pass make check test-unit
build and storage/directory/script/owned-exec/FD fixture builds:94 units,35 VFS,
178 matching tracked paths. Ginux and all five fixture binaries match. Clean apply
uses --whitespace=error. Existing default units and harness routes remain intact;
limits-only selection permits ordinary verification without running full authority
or width probes. Its output accurately names only the selected checks.

Ordinary source/clean checks demonstrate public soft/hard limit8, creation/write/
close of20 distinct nonempty owned files through public FD3, alias exhaustion at
public8, and startup rejection when the host hard limit8 cannot reserve backing.
The5000-file scenario starts with supervisor soft64, raises it within the existing
hard bound, reads every file and reclaims the last pinned namespace slot. Two
valid mapping modes, growth/bounds/quota, six owned-ELF and14 script controls pass.
The exact prerequisite fails the same low-limit fixture at workload43 (native
hard bound remains256 rather than8) and the scale fixture at workload160 with
EMFILE(-24). The new candidate passes both. Logs/commands/receipts are retained.

Private-FD authority/leakage, protected-copy, injected failure and raced ownership
remain with the [DaybreakBlue handoff](daybreakblue-handoff.md), including inherited
FD overhead assumptions in the fixed128 reserve. Full/default security modes,
independent review, macOS/remote CI and standalone-main refresh are unrun. These
Linux-local results are not green CI or security acceptance. No branch, real
checkout/index/ref, remote text or maintainer message changed. Patch, prerequisite
diff, generic draft, composition, hashes and helpers are retained under
.artifacts/ginux-contribution-preparation/G17b/. Publication remains after F04.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());assert not any(x['packet']=='G17b' for x in plan['packets']);plan['packets'].append({**m,'purpose':'Private backing descriptors without widening public limits','source_commits':['53a2c9cc6ee842e97d0ca8214cc1205547b0ab65','d5357101e9ce7b268235a9377a9366a33cd92813'],'artifact_directory':'.artifacts/ginux-contribution-preparation/G17b','evidence':'g17b-review.md','source_patch':'patches/G17b.patch'});row=next(x for x in plan['packets'] if x['packet']=='G17');row.update(status='G17a/G17b source and ordinary validation prepared; security/full CI/standalone independence pending',subpackets=['G17a','G17b']);row=next(x for x in plan['packets'] if x['packet']=='G12');row['composition_note']='G17b prerequisite f41ed1b0 corrects outdated full FD mapping fixture assertion using existing supported owned readonly mmap; preserve this mapping-owner join at F01/F02. Full fixture/security remains unrun.';p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\nG17b exact retained revision: {m['head']} on {m['base']} (G12+G18).
94 routine units and selected ordinary low-limit/20-file/5000-file/mapping/exec
checks pass in source and clean replay. Independently validate private FD leakage,
inherited FD overhead beyond the fixed128 allowance, bootstrap/transient state,
protected copy, failure injection and races. No cloud dispatch or security
acceptance is claimed. Full FD width/authority and mapping inspection modes remain.
''')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text();a=s.index('Exact next task: **G17b');b=s.index('\nActive skill:',a);s=s[:a]+f'''G17b is locally prepared at `{m['head'][:8]}` on composition `{m['base'][:8]}`
(G12/G18). [Review/evidence](ginux-contributions/g17b-review.md) records94 units,
178-path strict replay, public/native limit8 with20 private-backed files, rejected
insufficient hard capacity and5000 nonempty files launched under soft64, plus
mapping/script/ELF/storage controls in source/clean exports. Exact prerequisite
fails both new limit/scale fixtures. The outdated mapping fixture assertion is
corrected in its prerequisite owner and retained for F01/F02. G17a/G17b ordinary
preparation is retained; inherited security/full CI/upstream holds remain pending.

Exact next task: **G19 — flush and quiesced export**. Inspect53dec6b3/48b26f8d and
allocate c541a67f static fixes to actual owners. Trace the minimal storage/task
settlement prerequisites; keep held G07 threading/security joins explicit. Prepare
ordinary fsync/fdatasync and successful/failed workload/export behavior without
importing downstream protocols or unrelated archives/control. Do not run hostile
export/path/race probes here; record those for DaybreakBlue. Preserve tests,
current typed process cleanup and all existing work. No publication before F04.
''' +s[b:];p.write_text(s);print('retained',m['head'])
