from pathlib import Path
import subprocess,os,tempfile,json,tarfile,io
root=Path('/tmp/ginux-contribution-preparation/G17b');src=root/'prerequisite';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';m=json.loads((root/'composition.json').read_text())
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
with tempfile.TemporaryDirectory(prefix='ginux-g17b-base-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',m['parents'][0],env=env)
 for row in git('ls-tree','-r',m['preview_tree']).decode().splitlines():
  bits,name=row.split('\t');mode=bits.split()[0];p=src/name;data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes();blob=git('hash-object','-w','--stdin',input=data).decode().strip();git('update-index','--add','--cacheinfo',mode,blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();user=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',m['parents'][0],'-p',m['parents'][1],input=f'Compose file backing and bounded namespace metadata\n\nPreserve memfd mapping identity and current shared positions with runtime\nnamespace allocation. Keep the descriptor mapping fixture consistent with\nits existing supported readonly mapping contract.\n\nSigned-off-by: {user} <{email}>\n'.encode()).decode().strip()
git('diff','--check',m['parents'][0],head);m.update(base=head,tree=tree,mapping_fixture_join='G12 supported owned readonly mmap assertion from d5357101; not part of G17b delta');(root/'composition.json').write_text(json.dumps(m,indent=2)+'\n');dest=root/'source';assert not dest.exists();dest.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive',head))) as t:t.extractall(dest,filter='data')
print('local prerequisite',head,tree)
