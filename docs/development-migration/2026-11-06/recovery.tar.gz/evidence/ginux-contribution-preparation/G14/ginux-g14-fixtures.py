from pathlib import Path
import subprocess
src=Path('/tmp/ginux-contribution-preparation/G14/source')
p=src/'tests/fixtures/launch-directory-fixture.c';s=p.read_text();pos=s.index('long directory_main(')
s=s[:pos]+r'''static int copy_fixture(void) {
    long source=DO(2,"/bin/fixture",0,0), dest=DO(2,"program",0102,0600);
    if(source<0 || dest<0) return -1;
    long n; while((n=DO(0,source,buffer,sizeof buffer))>0) if(DO(1,dest,buffer,n)!=n) return -1;
    if(n<0 || DO(91,dest,0755,0) || DO(3,dest,0,0) || DO(3,source,0,0)) return -1;
    return 0;
}
static long owned_cwd(int functional) {
    CHECK(DO(83,"/work/cwd",0755,0)==0 && DO(83,"/work/cwd/nested",0755,0)==0,120);
    CHECK(DO(80,"/work/cwd",0,0)==0 && DO(79,buffer,sizeof buffer,0)==10 && equal(buffer,"/work/cwd"),121);
    if(!functional) CHECK(DO(79,buffer,9,0)==-34 && DO(79,buffer,0,0)==-22 && DO(79,1,4096,0)==-14,122);
    CHECK(create("relative","owned")==0 && DO(80,"relative",0,0)==-20,123);
    long cwd=DO(2,".",0200000,0); CHECK(cwd>=3,124);
    CHECK(DO(81,12345,0,0)==-9 && DO(80,"missing",0,0)==-2,125);
    long child=DO(57,0,0,0); CHECK(child>=0,126);
    if(!child) {
        CHECK(DO(80,"nested",0,0)==0 && create("child","child")==0,127);
        CHECK(DO(79,buffer,sizeof buffer,0)==17 && equal(buffer,"/work/cwd/nested"),128);
        return 0;
    }
    int status=-1; CHECK(DO(61,child,&status,0)==child && status==0,129);
    CHECK(DO(79,buffer,sizeof buffer,0)==10 && equal(buffer,"/work/cwd"),130);
    CHECK(DO(82,"/work/cwd","/work/cwd-moved",0)==0 && DO(79,buffer,sizeof buffer,0)==16 && equal(buffer,"/work/cwd-moved"),131);
    CHECK(DO(80,"/bin",0,0)==0 && DO(79,buffer,sizeof buffer,0)==5 && equal(buffer,"/bin"),132);
    CHECK(DO(81,cwd,0,0)==0 && DO(3,cwd,0,0)==0,133);
    CHECK(copy_fixture()==0 && create("script","#!program optional\n")==0 && DO(90,"script",0755,0)==0,134);
    for(int mode=0;mode<3;++mode) {
        child=DO(57,0,0,0); CHECK(child>=0,135);
        if(!child) {
            char *args[]={"fixture",mode==2?"owned-cwd-script-child":"owned-cwd-exec-child",0}, *env[]={0};
            DO(59,mode==0?"/bin/fixture":(mode==1?"program":"script"),args,env);
            return 136;
        }
        CHECK(DO(61,child,&status,0)==child && status==0,137);
    }
    CHECK(DO(4,"exec-output",meta,0)==0 && *(word *)(meta+48)==4,138);
    CHECK(DO(83,"empty",0755,0)==0 && DO(80,"empty",0,0)==0 && DO(84,"/work/cwd-moved/empty",0,0)==0,139);
    CHECK(DO(79,buffer,sizeof buffer,0)==-2 && create("missing-parent","bad")==-2,140);
    CHECK(DO(80,"/bin",0,0)==0,141);
    long bin=DO(2,"/bin",0200000,0); CHECK(bin>=3,142);
    CHECK(DO(80,"/work",0,0)==0 && DO(81,bin,0,0)==0 && DO(3,bin,0,0)==0,143);
    CHECK(DO(79,buffer,sizeof buffer,0)==5 && equal(buffer,"/bin"),144);
    CHECK(DO(1,1,"owned-directories: PASS\n",24)==24,145);
    return 0;
}
static long cwd_budget(void) {
    CHECK(DO(80,"/work",0,0)==0,150);
    long fds[64],n=0,fd;
    while((fd=DO(2,".",0200000,0))>=0) { CHECK(n<64,151); fds[n++]=fd; }
    CHECK(n==63 && fd==-24,152);
    for(int i=0;i<8;++i) CHECK(DO(57,0,0,0)==-24,153);
    CHECK(DO(3,fds[--n],0,0)==0,154);
    long child=DO(57,0,0,0); CHECK(child>=0,155);
    if(!child) return 0;
    int status=-1; CHECK(DO(61,child,&status,0)==child && status==0,156);
    while(n) CHECK(DO(3,fds[--n],0,0)==0,157);
    CHECK(DO(80,"/bin",0,0)==0 && create("/work/after-budget","ok")==0,158);
    DO(1,1,"owned-directories: PASS\n",24); return 0;
}
''' +s[pos:]
pos=s.index('    int functional=',s.index('long directory_main('));s=s[:pos]+r'''    if(stack[0]>1 && (equal(argv[stack[0]-1],"owned-cwd-exec-child") || equal(argv[stack[0]-1],"owned-cwd-script-child"))) {
        if(equal(argv[stack[0]-1],"owned-cwd-script-child")) CHECK(stack[0]==4 && equal(argv[0],"program") && equal(argv[1],"optional") && equal(argv[2],"script"),146);
        CHECK(DO(79,buffer,sizeof buffer,0)==16 && equal(buffer,"/work/cwd-moved") && create("exec-output","exec")==0,147);
        return 0;
    }
    if(stack[0]>1 && equal(argv[1],"ordinary-owned-cwd")) return owned_cwd(1);
    if(stack[0]>1 && equal(argv[1],"owned-cwd")) return owned_cwd(0);
    if(stack[0]>1 && equal(argv[1],"ordinary-cwd-budget")) return cwd_budget();
''' +s[pos:];p.write_text(s)
p=src/'scripts/test-launch-directories.py';s=p.read_text().replace("['all', 'cwd']","['all', 'cwd', 'owned-cwd', 'ordinary-owned-cwd', 'ordinary-cwd-budget']").replace("('all', 'functional', 'cwd')","('all', 'functional', 'cwd', 'owned-cwd', 'ordinary-owned-cwd', 'ordinary-cwd-budget')").replace('[all|functional|cwd ...]','[scenario ...]');p.write_text(s)
p=src/'README.md';s=p.read_text().replace('owned directories as cwd, relative image-directory FD access, hardlinks and\nguest file mappings remain unsupported.','relative image-directory FD access, hardlinks and guest file mappings remain\nunsupported. Owned chdir/fchdir/getcwd keep a private VFS directory reference per\nprocess. Fork copies that reference; exec keeps it; successful image chdir/fchdir\nreleases it. Rename updates the reported path, and a removed cwd reports ENOENT\nfor getcwd and relative operations until an absolute directory change. Private\ncwd references consume the existing 64-entry VFS open-description capacity.\nRelative owned scripts/interpreters use that cwd; relative fallback into the image\nand native kernel-selected relative interpreters from owned cwd remain unsupported.\nConfigured-launch threads and shared cwd groups remain unsupported.')
p.write_text(s)
print('G14 normal cwd/inheritance and capacity fixture retained; full protected getcwd and thread joins remain unrun')
