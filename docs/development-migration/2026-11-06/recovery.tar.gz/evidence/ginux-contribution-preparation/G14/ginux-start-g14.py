from pathlib import Path
import subprocess,tarfile,io,json
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G14');src=root/'source';base='5c3ae8e5068b5da21d2c37f9545c0f7b10eba147'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
def method(s,sig):
 a=s.index(sig);b=s.index('{',a);level=1;i=b+1
 while level:level+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
assert not src.exists();src.mkdir(parents=True);tarfile.open(fileobj=io.BytesIO(git('archive',base))).extractall(src,filter='data');(root/'composition.json').write_text(json.dumps({'base':base,'donors':['6a45d8f8'],'thread_join':'G07 held; per-process cwd ownership only'},indent=2)+'\n')
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();d=git('show','6a45d8f8:crates/ginux-init/src/fs_hooks.rs').decode();s=s.replace('    count: usize,','    count: usize,\n    cwd: Option<i32>,',1).replace('            count,','            count,\n            cwd: None,',1)
for sig in ['    pub fn select_cwd(', '    pub fn cwd_path(', '    pub fn copy_cwd(', '    pub fn close_cwd(', '    pub fn descriptor_cwd(', '    pub fn getcwd(']:s=s.replace('    /// Image execution never reopens',method(d,sig)+'\n\n    /// Image execution never reopens',1)
s=s.replace('cwd = crate::tracee_io::image_cwd(pid)?;', 'cwd = self.cwd_path(pid)?;')
# Keep the current namespace resolver and native kernel authority checks.
a=s.index('    pub fn image_chdir(');b=s.index('    pub fn select_cwd(',a) if '    pub fn select_cwd(' in s[a:] else -1
old=method(s,'    pub fn image_chdir(')
new='''    pub fn chdir(&mut self, pid: usize, address: u64) -> Result<Option<i32>, i64> {
        let raw = read_path(pid, address)?;
        let path = self.path(pid, address, (-100i64) as u64)?;
        let path = self.resolve(pid, path.as_bytes(), true, false)?;
        if self.owns_path(path.as_bytes()) {
            return self.fs.open_directory(path.as_bytes(), 0).map(Some).map_err(errno);
        }
        self.check_exec_owner(path.as_bytes())?;
        if self.cwd.is_some() && raw.as_bytes().first() != Some(&b'/') { return Err(-95); }
        Ok(None)
    }''';s=s.replace(old,new)
# Only the caller's virtual cwd selects relative paths. Avoid passing them to
# an unrelated native kernel cwd before the later image/owned traversal join.
s=s.replace('        if dirfd as i32 != -100\n            && read_path(pid, address)?.as_bytes().first() != Some(&b\'/\')', '        if (dirfd as i32 != -100 || self.cwd.is_some())\n            && read_path(pid, address)?.as_bytes().first() != Some(&b\'/\')',1)
s=s.replace('        if dirfd as i32 != -100 && raw.as_bytes().first() != Some(&b\'/\') {','        if (dirfd as i32 != -100 || self.cwd.is_some()) && raw.as_bytes().first() != Some(&b\'/\') {',1)
# Native kernel-selected relative interpreters cannot use a virtual owned cwd.
s=s.replace('            let mut joined = [0; MAX_PATH];\n            let cwd;', '            if self.cwd.is_some() && name.first() != Some(&b\'/\') { return Err(-95); }\n            let mut joined = [0; MAX_PATH];\n            let cwd;',1)
a=s.index('    pub fn exec_interpreter(');b=s.index('    pub fn read_executable(',a);chunk=s[a:b].replace('        self.check_exec_owner(path.as_bytes())?;', '        if self.cwd.is_some() && name.first() != Some(&b\'/\') { return Err(-95); }\n        self.check_exec_owner(path.as_bytes())?;',1);s=s[:a]+chunk+s[b:];p.write_text(s)
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text();s=s.replace('    image: Option<Executable>,','    image: Option<Executable>,\n    cwd: Option<i32>,\n    image_chdir: Option<u64>,',1).replace('        image: None,','        image: None,\n        cwd: None,\n        image_chdir: None,',1)
s=s.replace('    fn entry(&mut self, index: usize, r: &mut UserRegs, domain: &mut Domain) {','''    fn entry(&mut self, index: usize, r: &mut UserRegs, domain: &mut Domain) {
        self.objects.filesystem.select_cwd(self.task(index).cwd);''',1)
a=s.index('            79 => {',s.index('    fn entry('));b=s.index('            59 | 322 =>',a)
s=s[:a]+'''            79 => {
                let result = self.objects.filesystem.getcwd(self.task(index).host, r.rdi, r.rsi).unwrap_or_else(|error| error);
                self.emulate(index, r, result, domain);
                return;
            }
            80 => {
                let host = self.task(index).host;
                match self.objects.filesystem.chdir(host, r.rdi) {
                    Ok(Some(fd)) => {
                        self.replace_cwd(index, Some(fd), domain);
                        self.emulate(index, r, 0, domain);
                    }
                    Ok(None) => {
                        let original = r.rdi;
                        match crate::path_hooks::Rewrite::prepare(self.objects.filesystem, host, r) {
                            Ok(rewrite) => {
                                self.task_mut(index).path_rewrite = rewrite;
                                self.task_mut(index).image_chdir = Some(original);
                                audit_write(b"mediate surface=image-cwd\\n");
                                self.run(index, r, domain);
                            }
                            Err(-5) => self.fail(domain, b"chdir path scratch restoration failed"),
                            Err(error) => self.emulate(index, r, error, domain),
                        }
                    }
                    Err(error) => self.emulate(index, r, error, domain),
                }
                return;
            }
            81 => {
                match self.task(index).descriptors.exec_descriptor(r.rdi) {
                    Ok(ExecDescriptor::Owned(handle)) => match self.objects.filesystem.descriptor_cwd(handle) {
                        Ok(fd) => { self.replace_cwd(index, Some(fd), domain); self.emulate(index, r, 0, domain); }
                        Err(error) => self.emulate(index, r, error, domain),
                    },
                    Ok(ExecDescriptor::Native(fd)) => {
                        self.task_mut(index).image_chdir = Some(r.rdi);
                        let mut native = *r;
                        native.rdi = fd as u64;
                        self.run(index, &native, domain);
                    }
                    Err(error) => self.emulate(index, r, error, domain),
                }
                return;
            }
'''+s[b:]
pos=s.index('                self.tasks[slot] = Some(Task {',s.index('            56..=58 =>'))
s=s[:pos]+'''                let cwd = match self.task(index).cwd {
                    Some(fd) => match self.objects.filesystem.copy_cwd(fd) {
                        Ok(fd) => Some(fd),
                        Err(error) => {
                            if let Some(image) = image {
                                if self.objects.filesystem.release_executable(image).is_err() { self.fail(domain, b"cwd-limited fork image rollback failed"); }
                            }
                            let mut table = table;
                            if let Err(reason) = table.release_exited(&mut self.objects) { self.fail(domain, reason); }
                            if self.processes.cancel_fork(id, child).is_err() { self.fail(domain, b"cwd-limited fork rollback failed"); }
                            self.emulate(index, r, error, domain);
                            return;
                        }
                    },
                    None => None,
                };
'''+s[pos:]
s=s.replace('                    image,\n                    pending:', '                    image,\n                    cwd,\n                    image_chdir: None,\n                    pending:',1)
pos=s.index('        let result = self.tasks[index].as_mut().unwrap().descriptors.finish(r);')
s=s[:pos]+'''        if let Some(original) = self.task_mut(index).image_chdir.take() {
            r.rdi = original;
            if r.rax == 0 { self.replace_cwd(index, None, domain); }
        }
'''+s[pos:]
pos=s.index('    fn wait_entry(');s=s[:pos]+'''    fn replace_cwd(&mut self, index: usize, next: Option<i32>, domain: &mut Domain) {
        let old = core::mem::replace(&mut self.task_mut(index).cwd, next);
        if let Some(fd) = old {
            if self.objects.filesystem.close_cwd(fd).is_err() { self.fail(domain, b"cwd reference release failed"); }
        }
    }

'''+s[pos:]
pos=s.index('        let owned =',s.index('    fn release_task_images('));s=s[:pos]+'''        if let Some(fd) = self.task_mut(index).cwd.take() {
            if self.objects.filesystem.close_cwd(fd).is_err() { self.fail(domain, b"task cwd release failed"); }
        }
'''+s[pos:];p.write_text(s)
# Retain only the thread-only joins as deferred evidence, not configured support.
(root/'held-thread-join.patch').write_bytes(git('diff','6a45d8f8^','6a45d8f8','--','scripts/test-launch-threads.py','tests/fixtures/launch-thread-fixture.c'))
print('G14 per-process source adapted')
