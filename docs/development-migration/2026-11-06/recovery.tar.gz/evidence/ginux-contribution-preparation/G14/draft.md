Retain owned current directories across process lifecycle

Use private VFS directory references for chdir/fchdir/getcwd. Fork copies the
reference, exec preserves it, and directory rename/removal retains object identity.
Keep native cwd changes transactional and roll back failed fork reservations.

Local validation:95 units and ordinary cwd/capacity, link/script/ELF/storage checks
pass in source and clean replay. Thread sharing, security/full runtime coverage,
remote CI and prerequisite merges remain pending; not ready to submit.
