from pathlib import Path
import subprocess,json,shutil,re,hashlib,sys
r=Path('/tmp/ginux-contribution-preparation/G27');src=r/(sys.argv[1] if len(sys.argv)>1 else 'source');prefix='clean-' if src.name!='source' else '';root=r/'rpm-root'
if not root.exists():
 root.mkdir();(root/'work').mkdir();files=['/usr/bin/rpm','/usr/lib/rpm/rpmrc','/usr/lib/rpm/macros'];ldd=subprocess.check_output(['ldd','/usr/bin/rpm']).decode();(r/'rpm-ldd.log').write_text(ldd)
 files+=re.findall(r'(?:=>\s+|^\s+)(/[^\s]+)',ldd,re.MULTILINE)
 provenance=[]
 for name in dict.fromkeys(files):
  source=Path(name);dest=root/name.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest);dest.chmod(0o755 if name not in ['/usr/lib/rpm/rpmrc','/usr/lib/rpm/macros'] else 0o644);provenance.append({'source':name,'resolved_source':str(source.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
 (r/'rpm-provenance.json').write_text(json.dumps({'rpm_version':subprocess.check_output(['rpm','--version']).decode().strip(),'files':provenance,'primary_api_reference':'/usr/share/doc/rpm/lua.md, uname(format); %s/%n/%r/%v/%m'},indent=2)+'\n')
receipts=[]
for name in ['rpm-domain','rpm-other']:
 args=['--rcfile','/usr/lib/rpm/rpmrc','--macros','/usr/lib/rpm/macros','--eval','%{lua:print(posix.uname("%s|%n|%r|%v|%m"))}'];config=(src/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/usr/bin/rpm"').replace('args = []','args = '+json.dumps(args)).replace('id = "gate5-demo"','id = "'+name+'"');path=r/f'{prefix}{name}.toml';path.write_text(config);result=r/f'{prefix}{name}.json';result.unlink(missing_ok=True);cmd=[str(src/'target/x86_64-unknown-linux-gnu/release/ginux'),'launch',str(path),str(root),'--result-file',str(result)];p=subprocess.run(cmd,capture_output=True,timeout=20);(r/f'{prefix}{name}.log').write_bytes(p.stderr);(r/f'{prefix}{name}.stdout').write_bytes(p.stdout);receipt={'command':cmd,'exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'result':json.loads(result.read_text())};receipts.append(receipt);(r/(prefix+'rpm-receipt.json')).write_text(json.dumps(receipts,indent=2)+'\n');print(name,'RPM exit',p.returncode,'stdout',repr(p.stdout),flush=True)
 expected=f'Linux|{name}|0.1.0-ginux|ginux|x86_64\n'.encode();assert p.returncode==0 and p.stdout==expected and receipt['result']['outcome']=='exited' and receipt['result']['code']==0,(p.returncode,p.stdout,p.stderr[-4000:]);assert p.stderr.count(b'emulate surface=lane-contract result=0')>=1
