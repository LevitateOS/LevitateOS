from pathlib import Path
import json,hashlib,shutil,re
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G27');art=root/'.artifacts/ginux-contribution-preparation/G27';assert not (docs/'g27-review.md').exists();m=json.loads((temp/'manifest.json').read_text());stat=[json.loads((temp/(p+'static-receipt.json')).read_text()) for p in ['final-','clean-']];assert all(x['exit_code']==0 and x['head']==m['head'] and x['matched_paths']==150 for x in stat);assert stat[0]['binary_sha256']==stat[1]['binary_sha256'] and stat[0]['fixture_sha256']==stat[1]['fixture_sha256'];assert sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', (temp/'clean-static-build.log').read_text()))==65
for prefix in ['', 'clean-']:
 results=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(results)==4 and all(x['exit_code']==0 for x in results)
 rpm=json.loads((temp/(prefix+'rpm-receipt.json')).read_text());assert len(rpm)==2 and all(x['exit_code']==0 and x['result']['outcome']=='exited' and x['result']['code']==0 for x in rpm)
baseline=json.loads((temp/'baseline-receipt.json').read_text());assert [x['exit_code'] for x in baseline]==[170,139]
wait_hashes=[hashlib.sha256((temp/p/'.artifacts/process/wait_status').read_bytes()).hexdigest() for p in ['source','verified-head']];assert wait_hashes[0]==wait_hashes[1]
m.update(status='ordinary source/clean ABI and actual RPM preparation plus separate self-review retained; policy/security/full CI/fresh upstream acceptance pending',unit_tests=65,kernel_view_tests=6,clean_matched_paths=150,review='separate whole-diff self-review; no independent reviewer/security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=stat[0]['binary_sha256'],clean_binary_sha256=stat[1]['binary_sha256'],fixture_sha256=stat[0]['fixture_sha256'],ordinary_wait_status_fixture_sha256=wait_hashes[0],actual_rpm='RPM4.19.1.1 documented Lua posix.uname(%s|%n|%r|%v|%m), exact configured values across two domains; source and clean pass',rpm_provenance='rpm-provenance.json',baseline_behavior='exact main valid raw ABI unsupported (170); same actual RPM identity query signaled11 after uname denial (139); not a root-cause/security conclusion',held_dependencies=['#179 configured identity policy','security/full CI'],combined_join='G06 task supervisor must retain configured uname emulation at F02; no process/task loop is imported here')
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
private_results={'rpm-domain.json','rpm-other.json','clean-rpm-domain.json','clean-rpm-other.json','baseline-rpm.json'}
for p in temp.iterdir():
 if p.name in private_results:continue # Complete result records already live in the readable receipts.
 if p.is_file() and p.suffix in ['.json','.log','.patch','.diff','.txt','.stdout']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g27*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(temp/'candidate.patch',docs/'patches/G27.patch')
(art/'draft.md').write_text('''Project domain-owned uname identity in configured launch

Encode Linux utsname fields with the existing identity view: domain ID as
nodename, package-based virtual release, ginux version label, x86_64 machine and
empty domainname. Emulate configured-launch uname through strict supervisor
copyout while preserving shared native syscall and sysinfo defaults.

Local static/build checks and65 units pass in source and clean main-plus-patch
replay. Raw ABI/padding/max-valid-ID and actual RPM Lua uname queries pass, as
does an ordinary native wait-status copy regression control. Identity policy,
adversarial validation and full runtime/remote CI remain pending.
Not ready to submit.
''')
assert not any(x in (art/'draft.md').read_text() for x in ['LevitateOS','Recipe','Daybreak'])
(docs/'g27-review.md').write_text(f'''# G27 — configured virtual uname identity

Head `{m['head']}`, tree `{m['tree']}`, solely on recorded main
`{m['base']}`. [Patch](patches/G27.patch):6 files,+119/-16.
Ordinary source preparation, including actual RPM identity queries, is retained;
#179 identity policy, security, full CI and fresh upstream acceptance are pending.

IdentityView encodes six65-byte Linux utsname fields: Linux, domain ID, kernel-
views package version plus-ginux, ginux, x86_64, and empty domainname. It validates
field length/NUL constraints before zeroing/writing the390-byte ABI output. The
launch entry handles syscall63 after x86-64 ABI validation and returns through
existing emulated-entry/exit handling. It never invokes host uname. Shared core/
native syscall policy, config schema, existing identity filesystem and sysinfo
remain unchanged. Existing valid64-byte domain IDs fit with final termination.

The supervisor's existing process_vm syscall is extracted unchanged for reuse by
a strict copyout sibling: the new uname path checks address arithmetic, requires
complete copy and never uses forced ptrace writes. The legacy helper retains its
same cached availability/error decisions and documented ptrace fallback; no
fallback policy is silently changed. A copy failure can retain a written prefix
and returns an error. Security acceptance of those paths remains unrun.

Separate whole-diff self-review inspected all six changed paths, config identifier
bounds, ABI field offsets/padding, error ordering, architecture check and emulated
entry/exit state, copy addresses/lengths, legacy fallback/cache callers, docs,
fixtures and Make/workflow coverage. This is self-review, not an independent or
adversarial review.

- **Dependency correction:** the donor's runtime hook lived in the later G06
  process supervisor. The existing main launch supervisor already owns a usable
  entry. Source is extracted directly on main without G06/G26/storage/I/O policy.
  Its future G06 task-loop join is explicitly assigned to F02.
- **Strict output preserved:** the new call does not opt into the legacy helper's
  documented forced-write fallback. Both use the same raw syscall owner without
  changing old callers. Unavailable process_vm errors propagate; no fallback or
  protection-bypass injection was run.
- **Build correction:** the initial helper extraction needed parentheses around
  an unsafe expression cast. The initial failed static log is preserved; final
  source/clean checks below are passing evidence.
- **Policy remains held:** Linux/machine/package-release/domainname choices are
  the donor's virtual identity contract, not proof of a complete host Linux ABI
  or upstream consent. No sysinfo/#219, new hostname configuration or host name/
  release passthrough is introduced.

Source and strict clean main-plus-patch replay pass make check test-unit build
build-launch-fixture:65 units,6 kernel-view tests,150 tracked paths byte-matched.
Ginux, launch fixture and ordinary wait-status fixture hashes match. Both copies
pass four fresh raw uname launches (two names, maximum valid64-byte ID and repeat),
comparing all390 output bytes and zero padding. The valid output is unaligned;
five bytes on each side stay unchanged. Existing argument/exit controls pass.
The existing native wait_status case (valid unaligned status buffer, no protected
memory or syscall injection) also passes, exercising the shared copy refactor.
Existing default launch tests and static-and-unit coverage remain intact, and
existing Make/workflow callers include the new ABI cases.

Actual RPM4.19.1.1 runs in a disposable read-only image built from hashed host RPM,
its transitive runtime libraries and explicit rpmrc/macros. The primary installed
RPM Lua documentation describes posix.uname format%s/%n/%r/%v/%m. The real command
reports Linux|rpm-domain|0.1.0-ginux|ginux|x86_64 and then the changed rpm-other
nodename, in both source and clean replay. Audit confirms configured emulation;
this is actual RPM querying uname, not a substitute script or compiled default
macro. Runtime inputs/version/hashes are saved in rpm-provenance.json. No package
installation, acquisition or full RPM conversion is claimed by this identity check.

Exact main (reused verified main binary hash) returns unsupported for the valid
ABI fixture, which exits170. The same actual RPM identity command terminates by
signal11 after syscall63 is denied and prints no virtual identity. That observed
baseline failure is recorded; no root-cause or security conclusion about RPM is
inferred and no crash exploitation was attempted. Candidate runs exit0.

[DaybreakBlue](daybreakblue-handoff.md) owns invalid/oversized/NUL identity inputs,
short outputs, protected/mutable output buffers, partial faults/address overflow,
copy unavailability/failure and signal/thread authority races. Those checks, full
Linux/default suites, independent review and macOS/remote CI are unrun. F02 must
carry uname into the configured task-loop owner while retaining defaults; F03
still needs the complete current Recipe/actual consumer closure, including G23–
G26's other outstanding acceptance. Fresh main and #179 disposition precede delivery.

Patch, generic draft, exact commands/SHAs/hashes, logs/provenance and helpers are
retained in .artifacts/ginux-contribution-preparation/G27/. No real Ginux branch,
checkout/index/ref, remote text or maintainer message changed. No publication;
F04 remains the user inspection boundary.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G27');row.update(m);row.update(evidence='g27-review.md',source_patch='patches/G27.patch');p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'p04-dependencies.md';p.write_text(p.read_text()+f'''\nG27 `{m['head'][:8]}` is one coherent source packet directly on recorded main:
IdentityView encoder plus its existing configured-launch entry and strict copyout
in the supervisor copy owner. It needs no G06/G26/storage/I/O packet.65 units,
raw390-byte ABI/max-valid IDs, actual RPM identity queries and ordinary valid
native wait-status copying pass in source/clean. G06 task-loop emulation join is
F02 work; #179, security/full CI and fresh upstream acceptance remain pending.
Sysinfo/#219 stays outside this identity contribution; [review](g27-review.md).
''')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\n## G27 — configured uname identity

Exact head `{m['head']}` solely on recorded main `{m['base']}`.
65 routine units, full ordinary390-byte utsname ABI/padding/max-valid ID and
actual RPM4.19.1.1 documented Lua identity queries pass in source/clean. The
existing ordinary valid-buffer native wait_status case also passes. New uname
copyout is strict process_vm; existing legacy helper fallback remains unchanged.
No fallback injection or protected output probe ran here.

DaybreakBlue must validate invalid/oversized/NUL identity fields and short output,
protected/mutable/partially mapped destinations, address arithmetic and prefix
fault effects, process_vm unavailability/failure, signal/thread races and correct
owner joins. The trusted ordinary RPM baseline on exact main signals11 after
uname is denied; candidate succeeds. Treat that as observed functional evidence,
not an exploitability conclusion; no hostile input or crash exploitation ran.
No cloud dispatch occurred. #179 identity policy, full CI and G06/F02 task-loop
join remain pending; [review/evidence](g27-review.md).
''')
p=root/'docs/ginux-contribution-task-list.md';t=p.read_text();a=t.index('Exact next task: **G27');b=t.index('\nActive skill:',a);t=t[:a]+f'''G27 source/ordinary preparation is retained at `{m['head'][:8]}` directly on recorded
main, without G06/G26/storage prerequisites. [Review/evidence](ginux-contributions/g27-review.md)
records65 units,150-path strict replay, complete390-byte ABI/padding/max-valid ID,
actual RPM4.19.1.1 identity queries under two domain names and ordinary valid
native wait-status copy control passing in source/clean. IdentityView and the
existing launch/copy owners provide the behavior; core/native defaults and
sysinfo/#219 remain unchanged. Exact main lacks the ABI and its RPM query fails.
#179 identity policy, security/full CI, fresh upstream acceptance and G06/F02
runtime-owner join remain pending. No publication occurred.

Exact next task: **G28 — bounded TCP device backend**.
Inspect8ff83d64/539c1c77/9a70427b against current device assignment/backend owners.
Keep useful backend-only behavior separate from G29 syscall/readiness policy.
Review exact endpoint/connection/byte budgets and cleanup; use controlled trusted
local peers for ordinary functional checks. Record scanning, denied/foreign
endpoints, bypass/authority/revocation attacks and adversarial network/race probes
for DaybreakBlue. Preserve all pending G23–G27/F02/F03 acceptance and public policy
holds. No publication or maintainer messages before F04.
''' +t[b:];p.write_text(t);print('saved G27',m['head'])
