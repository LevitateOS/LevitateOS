from pathlib import Path
import subprocess,json,sys
r=Path('/tmp/ginux-contribution-preparation/G27');s=r/(sys.argv[1] if len(sys.argv)>1 else 'source');prefix='' if s.name=='source' else 'clean-';commands=[['sudo','-n','python3','scripts/test-launch.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-fixture','ordinary-uname'],['sudo','-n','python3','/tmp/ginux-g27-rpm.py',s.name],['make','build-process-fixtures'],['python3','scripts/test-process-native.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/process','target/x86_64-unknown-linux-gnu/release/process-native-fixture','wait_status']];results=[]
for i,cmd in enumerate(commands):
 with (r/f'{prefix}functional-{i}.log').open('w') as f:p=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
 results.append({'command':cmd,'exit_code':p.returncode});(r/(prefix+'functional-receipt.json')).write_text(json.dumps(results,indent=2)+'\n');print(prefix,'functional',i,p.returncode,flush=True);assert p.returncode==0
