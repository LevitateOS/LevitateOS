from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G27');src=root/'source';base=json.loads((root/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['README.md','crates/ginux-kernel-views/src/lib.rs','crates/ginux-init/src/launch.rs','crates/ginux-init/src/supervisor.rs','scripts/test-launch.py','tests/fixtures/launch-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g27-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(src/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',base,input=('feat(kernel-views): project configured uname identity at launch\n\nEncode domain-owned utsname fields in the existing identity view and expose\nthem through configured launch with strict tracee copyout. Keep native\nsyscall defaults and sysinfo behavior unchanged.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert not any(x in patch for x in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in git('ls-tree','-r','--name-only',base).decode().splitlines():
 if name in files:continue
 p=src/name;assert (os.readlink(p).encode() if p.is_symlink() else p.read_bytes())==git('show',base+':'+name),name
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G27','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':[],'standalone_source':True,'status':'ordinary source ABI/actual RPM checks pass; separate review/clean replay/security/policy/full CI pending','patch_sha256':hashlib.sha256(patch).hexdigest(),'deferred_joins':['G06 task-loop configured uname at F02, without changing shared core defaults'],'policy':'#179 configured identity contract unresolved; sysinfo/#219 excluded'};(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
