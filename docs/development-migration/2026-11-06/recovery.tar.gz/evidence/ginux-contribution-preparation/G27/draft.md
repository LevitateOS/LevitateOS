Project domain-owned uname identity in configured launch

Encode Linux utsname fields with the existing identity view: domain ID as
nodename, package-based virtual release, ginux version label, x86_64 machine and
empty domainname. Emulate configured-launch uname through strict supervisor
copyout while preserving shared native syscall and sysinfo defaults.

Local static/build checks and65 units pass in source and clean main-plus-patch
replay. Raw ABI/padding/max-valid-ID and actual RPM Lua uname queries pass, as
does an ordinary native wait-status copy regression control. Identity policy,
adversarial validation and full runtime/remote CI remain pending.
Not ready to submit.
