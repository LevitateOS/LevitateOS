from pathlib import Path
import subprocess,tarfile,io,json
r=Path('/tmp/ginux-contribution-preparation/G27');r.mkdir(exist_ok=True);s=r/'source';assert not s.exists();s.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='3f2fe7dfadd4b40e235d982a6a3d386dc6490177'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(s,filter='data')
(r/'composition.json').write_text(json.dumps({'base':base,'dependencies':[],'source':['9cf265bab6f24cd398af4dd5b4fd71ee3147c81c'],'runtime_owner':'existing single-task configured launch entry; no G06/G26 prerequisite','copy_owner':'existing supervisor process_vm copy syscall extracted for strict new uname copyout; legacy fallback behavior preserved','excluded':['sysinfo/#219','new schema/hostname setting','G06 task loop','G26 resource enforcement'],'policy':'#179 configured virtual identity contract still requires disposition before publication'},indent=2)+'\n')
p=s/'crates/ginux-kernel-views/src/lib.rs';t=p.read_text();donor=git('show','9cf265ba:crates/ginux-kernel-views/src/lib.rs').decode();a=donor.index("impl IdentityView<'_>");b=donor.index('#[derive(Clone, Copy)]\npub struct NamespaceView',a);needle='#[derive(Clone, Copy)]\npub struct NamespaceView';t=t.replace(needle,donor[a:b]+needle);p.write_text(t)
p=s/'crates/ginux-init/src/supervisor.rs';t=p.read_text();a=t.index('        let local = [bytes.as_ptr() as usize, bytes.len()];',t.index('pub fn write_tracee_bytes('));b=t.index('        let unavailable =',a);raw=t[a:b];t=t[:a]+'        let written = process_vm_write_bytes(pid, address, bytes);\n'+t[b:];idx=t.index('/// Map a failed ptrace access');helper='''/// Copy without ptrace fallback: guest page protections remain authoritative.
pub fn write_tracee_bytes_strict(pid: usize, address: usize, bytes: &[u8]) -> Result<(), i64> {
    address.checked_add(bytes.len()).ok_or(-EFAULT)?;
    let written = process_vm_write_bytes(pid, address, bytes);
    if written == bytes.len() as i64 {
        Ok(())
    } else if written < 0 {
        Err(written)
    } else {
        Err(-EFAULT)
    }
}

fn process_vm_write_bytes(pid: usize, address: usize, bytes: &[u8]) -> i64 {
    let local = [bytes.as_ptr() as usize, bytes.len()];
    let remote = [address, bytes.len()];
    unsafe {
        syscall6(
            SYS_PROCESS_VM_WRITEV,
            pid,
            local.as_ptr() as usize,
            1,
            remote.as_ptr() as usize,
            1,
            0,
        )
    } as i64
}

''';t=t[:idx]+helper+t[idx:];p.write_text(t)
p=s/'crates/ginux-init/src/launch.rs';t=p.read_text();old='        let decision = match decide_native(syscall, registers.rdi, registers.rsi, registers.rdx) {';assert old in t;t=t.replace(old,'''        let entry = if syscall == ginux_core::SYS_UNAME {
            let identity = ginux_kernel_views::IdentityView {
                hostname: domain.config().id.as_bytes(),
                machine_id: b"",
                boot_id: b"",
            };
            let mut bytes = [0u8; 390];
            let result = identity
                .uname(b"x86_64", &mut bytes)
                .map_err(|_| -5)
                .and_then(|_| {
                    crate::supervisor::write_tracee_bytes_strict(pid, registers.rdi as usize, &bytes)
                })
                .map(|_| 0)
                .unwrap_or_else(|error| error);
            NativeDecision::Hooked {
                lane: crate::dispatch::Lane::Contract,
                result,
            }
        } else {
            decide_native(syscall, registers.rdi, registers.rsi, registers.rdx)
        };
        let decision = match entry {''');p.write_text(t)
p=s/'README.md';t=p.read_text();old='notice. This path does not implement resource quotas from the domain metadata.';assert old in t;t=t.replace(old,old+'''
Configured `uname` returns `Linux`, the domain id as nodename, the kernel-views
package version with `-ginux` as its virtual release, version `ginux`, machine
`x86_64`, and an empty domainname. This identifies the virtual implementation;
it does not report host kernel/hostname data or promise the host kernel's ABI.
The shared native syscall contract and `sysinfo` behavior are unchanged.''');p.write_text(t)
p=s/'tests/fixtures/launch-fixture.c';t=p.read_text();idx=t.index("    case 'e':");t=t[:idx]+'''    case 'u': {
        unsigned char bytes[400];
        for(word i=0;i<sizeof bytes;++i) bytes[i]=0xa5;
        if(call3(63,(word)(bytes+5),0,0)!=0) return 170;
        for(word i=0;i<5;++i) if(bytes[i]!=0xa5 || bytes[395+i]!=0xa5) return 171;
        if(call3(1,1,(word)(bytes+5),390)!=390) return 172;
        return 0;
    }
''' +t[idx:];p.write_text(t)
p=s/'scripts/test-launch.py';t=p.read_text().replace('if len(sys.argv) != 3','if len(sys.argv) < 3').replace('for arg in sys.argv[1:])','for arg in sys.argv[1:3])');idx=t.index('        for code in (0, 3, 120, 127, 128, 255):');t=t[:idx]+'''        def identity_cases():
            manifest = (Path(__file__).resolve().parent.parent /
                        'crates/ginux-kernel-views/Cargo.toml').read_text()
            release = re.search(r'^version = "([^"]+)"', manifest, re.MULTILINE).group(1) + '-ginux'
            for name in ['gate5-demo', 'identity-other', 'u'*64, 'gate5-demo']:
                fields = ['Linux', name, release, 'ginux', 'x86_64', '']
                expected = b''.join(field.encode() + b'\\0'*(65-len(field)) for field in fields)
                invoke(['uname'], 0, 'exited', stdout=expected,
                       changes={'id = "gate5-demo"': 'id = "' + name + '"'})
            invoke(['exit', '3'], 3, 'exited')
            invoke(['args', 'identity-control'], 0, 'exited', stdout=b'identity-control\\n')
        if sys.argv[3:]:
            if sys.argv[3:] != ['ordinary-uname']:
                sys.exit('unknown selected launch scenario')
            identity_cases()
            return
        identity_cases()
''' +t[idx:];p.write_text(t)
print('G27 exported on recorded main with existing launch/copy/identity owners')
