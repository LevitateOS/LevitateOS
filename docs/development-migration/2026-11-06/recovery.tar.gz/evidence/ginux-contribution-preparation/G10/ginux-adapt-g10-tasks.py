from pathlib import Path
import re,subprocess
root=Path('/tmp/ginux-contribution-preparation/G10/source');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def git(*args):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*args]).decode()
def function(text,name):
 m=re.search(r'^    (?:pub(?:\([^)]*\))? )?fn '+name+r'\b',text,re.M);assert m,name
 i=text.index('{',m.start())+1;depth=1
 while depth:depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[m.start():i]+'\n'
p=root/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text();d=git('show','c5ae1c5d:crates/ginux-init/src/launch_tasks.rs');s=s.replace('use crate::descriptors::{Backends, DescriptorTable};','use crate::descriptors::{Backends, DescriptorTable, ExecDescriptor};').replace('use ginux_domain::Domain;','use ginux_domain::Domain;\nuse ginux_vfs::Executable;')
s=s.replace('''    Reenter,
    Kernel,''','''    Reenter,
    Create,
    Close,
    Kernel,''')
s=s.replace('''    stage: ExecStage,
}

struct Task''','''    stage: ExecStage,
    owned: Option<OwnedExec>,
}

#[derive(Clone, Copy)]
struct OwnedExec {
    image: Executable,
    empty_path: u64,
    descriptor: Option<u32>,
    legacy_create: bool,
    failure: Option<i64>,
}

struct Task''')
s=s.replace('''    descriptors: DescriptorTable,
    pending: Pending,''','''    descriptors: DescriptorTable,
    image: Option<Executable>,
    pending: Pending,''')
s=s.replace('''        descriptors,
        pending: Pending::None,''','''        descriptors,
        image: None,
        pending: Pending::None,''')
s=s.replace('ExecStage::Sync | ExecStage::Reenter)', 'ExecStage::Sync | ExecStage::Reenter | ExecStage::Create | ExecStage::Close)')
# The committed program reference follows fork reservation and rollback, exactly
# like the current per-process descriptor snapshot (no thread groups imported).
s=s.replace('''                self.tasks[slot] = Some(Task {''','''                let image = self.task(index).image;
                if let Some(image) = image {
                    if self.objects.filesystem.retain_executable(image).is_err() {
                        let mut table = table;
                        if let Err(reason) = table.release_exited(&mut self.objects) { self.fail(domain, reason); }
                        self.fail(domain, b"fork executable retain failed");
                    }
                }
                self.tasks[slot] = Some(Task {''',1)
s=s.replace('''                    descriptors: table,
                    pending: Pending::None,''','''                    descriptors: table,
                    image,
                    pending: Pending::None,''',1)
s=s.replace('''                    self.tasks[child] = None;''','''                    self.release_task_images(child, domain);
                    self.tasks[child] = None;''')
old=function(s,'prepare_exec');new='''    fn prepare_exec(&mut self, index: usize, r: &mut UserRegs) -> Result<(), i64> {
        let host = self.task(index).host;
        let mut instruction = [0; 2];
        if copy_memory(host, r.rip.checked_sub(2).ok_or(-95)?, &mut instruction, false) != Ok(2)
            || instruction != [0x0f, 0x05] { return Err(-95); }
        let mut native_dirfd = r.rdi;
        let (image, empty_path) = if r.orig_rax == 59 {
            let path = crate::tracee_io::read_path(host, r.rdi)?;
            let end = r.rdi.checked_add(path.as_bytes().len() as u64).ok_or(-14)?;
            let image = self.objects.filesystem.exec_path(host, r.rdi, (-100i64) as u64, true)?;
            (image, end)
        } else {
            if r.r8 & !0x1100 != 0 { return Err(-22); }
            let path = crate::tracee_io::read_path(host, r.rsi)?;
            let end = r.rsi.checked_add(path.as_bytes().len() as u64).ok_or(-14)?;
            let image = if path.is_empty() {
                if r.r8 & 0x1000 == 0 { return Err(-2); }
                match self.task(index).descriptors.exec_descriptor(r.rdi)? {
                    ExecDescriptor::Native(fd) => {
                        native_dirfd = fd as u64;
                        self.objects.filesystem.native_exec_fd(host, fd)?;
                        None
                    }
                    ExecDescriptor::Owned(handle) => Some(self.objects.filesystem.exec_descriptor(host, handle)?),
                }
            } else {
                let dirfd = self.task(index).descriptors.exec_path_dirfd(host, r.rdi, r.rsi)?;
                native_dirfd = (-100i64) as u64;
                self.objects.filesystem.exec_path(host, r.rsi, dirfd, r.r8 & 0x100 == 0)?
            };
            (image, end)
        };
        if image.is_none() {
            let rewrite = crate::path_hooks::Rewrite::prepare(self.objects.filesystem, host, r)?;
            self.task_mut(index).path_rewrite = rewrite;
            if r.orig_rax == 59 { native_dirfd = r.rdi; }
        }
        self.task_mut(index).exec = Some(Exec {
            original: *r, native_dirfd, next_native: 0, stage: ExecStage::Reenter,
            owned: image.map(|image| OwnedExec { image, empty_path, descriptor: None, legacy_create: false, failure: None }),
        });
        Ok(())
    }
''';s=s.replace(old,new)
old=function(s,'exec_step');new=function(d,'exec_step').replace('self.table(index)','self.task(index).descriptors');s=s.replace(old,new+'\n'+function(d,'replay_exec')+'\n'+function(d,'finish_exec_failure'))
# Preserve current typed wait/fork/death code and scratch restoration after the
# selected exec transaction stages, rather than transplanting the old task loop.
a=s.index('    fn syscall_exit(');b=s.index('        if let Some(rewrite)',a);fn=function(d,'syscall_exit');part=fn[:fn.index('        let pending =')];s=s[:a]+part+s[b:]
anchor='''        // Exec replaced the address space: the old path scratch no longer exists.''';assert anchor in s
s=s.replace(anchor,'''        let image = self.task_mut(index).exec.as_mut().unwrap().owned.take().map(|owned| owned.image);
        let old = core::mem::replace(&mut self.task_mut(index).image, image);
        if let Some(old) = old {
            if self.objects.filesystem.release_executable(old).is_err() {
                self.fail(domain, b"replaced executable release failed");
            }
        }
'''+anchor)
anchor='''    fn died(&mut self, index: usize, status: i32, domain: &mut Domain) {''';assert anchor in s
s=s.replace(anchor,'''    fn release_task_images(&mut self, index: usize, domain: &mut Domain) {
        let pending = self.task_mut(index).exec.take().and_then(|exec| exec.owned).map(|owned| owned.image);
        let committed = self.task_mut(index).image.take();
        for image in [pending, committed].into_iter().flatten() {
            if self.objects.filesystem.release_executable(image).is_err() {
                self.fail(domain, b"task executable release failed");
            }
        }
    }

'''+anchor)
s=s.replace('''        self.task_mut(index).alive = false;''','''        self.release_task_images(index, domain);
        self.task_mut(index).alive = false;''',1)
# teardown's remaining tasks also include unpublished reservations on failures.
anchor='''        for task in self.tasks.iter_mut().flatten() {
            if let Err(reason) = task.descriptors.release_exited''';assert anchor in s
s=s.replace(anchor,'''        for index in 0..TASKS {
            if self.tasks[index].is_some() { self.release_task_images(index, domain); }
        }
'''+anchor)
# Prefer the VFS name for owned execution even when the tracee root is '/'.
# Kernel memfd names must never win merely because they share that prefix.
anchor='''        match r.orig_rax {
            79 =>''';assert anchor in s
s=s.replace(anchor,'''        match r.orig_rax {
            89 | 267 => {
                let host = self.task(index).host;
                let (address, output, size, dirfd) = if r.orig_rax == 89 {
                    (r.rdi, r.rsi, r.rdx, (-100i64) as u64)
                } else { (r.rsi, r.rdx, r.r10, r.rdi) };
                let path = self.objects.filesystem.path(host, address, dirfd);
                if path.as_ref().is_ok_and(|path| matches!(path.as_bytes(), b"/proc/self/exe" | b"/proc/thread-self/exe")) {
                    let result = (|| {
                        if size == 0 { return Err(-22); }
                        let name = if let Some(image) = self.task(index).image {
                            self.objects.filesystem.executable_name(image)?
                        } else {
                            let image = crate::tracee_io::image_link(host, b"/exe")?;
                            ginux_domain::Text::<{ ginux_vfs::MAX_PATH + 10 }>::from_bytes(image.as_bytes()).map_err(|_| -36)?
                        };
                        let count = name.as_bytes().len().min(size as usize);
                        let mut bytes = [0; ginux_vfs::MAX_PATH + 10];
                        bytes[..count].copy_from_slice(&name.as_bytes()[..count]);
                        if copy_memory(host, output, &mut bytes[..count], true)? != count as i64 { return Err(-14); }
                        Ok(count as i64)
                    })().unwrap_or_else(|error| error);
                    self.emulate(index, r, result, domain);
                    return;
                }
            }
            79 =>''',1)
assert 'self.groups' not in s and 'self.table(' not in s and 'DescriptorCall' not in s
p.write_text(s)
print('Adapted owned exec transactions to current per-process tasks and cleanup.')
