from pathlib import Path
import subprocess,tempfile,tarfile,io,json
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G10');src=root/'source';assert not src.exists();src.mkdir(parents=True);base='85b53fe15a64041f451ec7e7aa1e77d08cb2c18a'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(src,filter='data')
conflicts=[]
with tempfile.TemporaryDirectory(prefix='ginux-g10-merge-') as tmp:
 t=Path(tmp)
 for file in git('diff-tree','--no-commit-id','--name-only','-r','c5ae1c5d').decode().splitlines():
  if file in ['README.md','crates/ginux-init/src/launch_tasks.rs']:continue
  dest=src/file;feature=git('show','c5ae1c5d:'+file)
  if not dest.exists():dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(feature);continue
  ancestor=git('show','c5ae1c5d^:'+file)
  for name,data in [('ours',dest.read_bytes()),('base',ancestor),('theirs',feature)]:(t/name).write_bytes(data)
  r=subprocess.run(['git','merge-file','-p','-L','current','-L','ancestor','-L','feature',str(t/'ours'),str(t/'base'),str(t/'theirs')],capture_output=True);assert 0<=r.returncode<=127,r.stderr;dest.write_bytes(r.stdout)
  if r.returncode:conflicts.append({'file':file,'conflicts':r.returncode})
(root/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G09d'],'source_commits':['c5ae1c5d','32ba41e9'],'status':'initial extraction; task-loop adaptation and security validation pending','conflicts':conflicts,'security_handoff':'downstream daybreakblue-handoff.md'},indent=2)+'\n');print(conflicts)
