Title: Execute configured owned ELF files with pinned byte lifetime

Execute assigned writable ELF files through private sealed backing while tying
executable references and descriptor retirement to successful replacement and
task lifetime. Reuse the existing interpreter metadata and namespace checks.

Validation: local static/build checks, 91 unit tests and ordinary exec/FD/fork/
storage scenarios pass in source and clean patch replay. Security scenarios,
full Linux/macOS CI and current-main independence remain pending; this proposal
is not ready for publication.
