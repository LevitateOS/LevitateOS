from pathlib import Path
import subprocess,json
root=Path('/tmp/ginux-contribution-preparation/G10');src=root/'source';binary=Path('/tmp/ginux-contribution-preparation/G09d/source/target/x86_64-unknown-linux-gnu/release/ginux')
command=['sudo','-n','python3',str(src/'scripts/test-launch-owned-exec.py'),str(binary),str(src/'.artifacts/launch/launch-owned-exec-fixture'),'ordinary-path']
r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(root/'baseline-ordinary-path.log').write_bytes(r.stdout);assert r.returncode!=0 and b"'ordinary-path', 128," in r.stdout,r.stdout[-300:]
(root/'baseline-ordinary-receipt.json').write_text(json.dumps({'binary_revision':'85b53fe15a64041f451ec7e7aa1e77d08cb2c18a','scenario':'ordinary-path','harness_exit':r.returncode,'workload_exit':128,'meaning':'old configured launch rejects owned executable replacement'},indent=2)+'\n');print('Exact G09d prerequisite rejects ordinary owned execution, workload exit128.')
