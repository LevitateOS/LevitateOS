from pathlib import Path
import subprocess,json
root=Path('/tmp/ginux-contribution-preparation/G10');src=root/'source';modes=['ordinary-path','ordinary-fd','ordinary-unlinked','ordinary-relative','ordinary-child','ordinary-reexec'];results=[]
commands=[['sudo','-n','python3','scripts/test-launch-owned-exec.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-owned-exec-fixture',*modes],['sudo','-n','python3','scripts/test-launch-directories.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-directory-fixture','cwd'],['sudo','-n','python3','scripts/test-launch-storage.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-storage-fixture','growth','bounds','quota']]
for i,command in enumerate(commands):
 with (root/f'final-ordinary-{i}.log').open('w') as log:r=subprocess.run(command,cwd=src,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':command,'exit_code':r.returncode});(root/'ordinary-receipt.json').write_text(json.dumps(results,indent=2)+'\n');print('ordinary group',i,'exit',r.returncode)
 assert r.returncode==0,(i,r.returncode)
