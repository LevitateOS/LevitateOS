from pathlib import Path
root=Path('/tmp/ginux-contribution-preparation/G10/source');p=root/'tests/fixtures/launch-owned-exec-fixture.c';s=p.read_text();anchor='long owned_exec_main(word *stack)\n{';assert anchor in s
ordinary='''static int equal(const char *a, const char *b)
{ while (*a && *a==*b) { ++a; ++b; } return *a==*b; }
static long ordinary_exec(word *stack)
{
    char **argv=(char **)(stack+1);
    static const char message[]="owned-ordinary: PASS\\n";
    if(equal(argv[1],"ordinary-released")) {
        long writer=DO(2,"/work/program",1,0);
        CHECK(writer>=3 && DO(3,writer,0,0)==0,110);
        CHECK(DO(1,1,message,sizeof message-1)==sizeof message-1,111);
        return 0;
    }
    if(equal(argv[1],"ordinary-after")) {
        CHECK(stack[0]==3 && DO(8,3,0,0)==0 && DO(0,3,buffer,1)==1 && buffer[0]=='K',112);
        CHECK(DO(72,4,1,0)==-9,113); /* Successful exec retired a public CLOEXEC file. */
        if(equal(argv[2],"ordinary-reexec")) {
            char *next[]={"payload","ordinary-released",argv[2],0};
            DO(59,"/bin/payload",next,empty_env); return 114;
        }
        CHECK(DO(1,1,message,sizeof message-1)==sizeof message-1,115);
        return 0;
    }
    long source=DO(2,"/bin/payload",0,0),dest=DO(2,"/work/program",0102,0600);
    CHECK(source>=3 && dest>=3,116);
    for(;;) {
        long n=DO(0,source,buffer,sizeof buffer); CHECK(n>=0,117);
        if(!n) break;
        CHECK(DO(1,dest,buffer,n)==n,118);
    }
    CHECK(DO(91,dest,0755,0)==0 && DO(3,source,0,0)==0 && DO(3,dest,0,0)==0,119);
    CHECK(DO(2,"/work/keep",0102,0600)==3 && DO(1,3,"K",1)==1,120);
    CHECK(DO(2,"/work/drop",02000102,0600)==4,121);
    char *next[]={"payload","ordinary-after",argv[1],0};
    if(equal(argv[1],"ordinary-child")) {
        long child=DO(57,0,0,0); CHECK(child>=0,122);
        if(child) {
            int status=-1;
            CHECK(DO(61,child,&status,0)==child && status==0,123);
            CHECK(DO(1,1,message,sizeof message-1)==sizeof message-1,124);
            return 0;
        }
    }
    if(equal(argv[1],"ordinary-fd") || equal(argv[1],"ordinary-unlinked")) {
        long fd=DO(2,"/work/program",02000000,0); CHECK(fd>=5,125);
        if(equal(argv[1],"ordinary-unlinked")) CHECK(DO(87,"/work/program",0,0)==0,126);
        call(322,fd,(word)"",(word)next,(word)empty_env,0x1000,0);
    } else if(equal(argv[1],"ordinary-relative")) {
        long dir=DO(2,"/work",02200000,0); CHECK(dir>=5,127);
        call(322,dir,(word)"program",(word)next,(word)empty_env,0,0);
    } else DO(59,"/work/program",next,empty_env);
    return 128;
}
'''
s=s.replace(anchor,ordinary+anchor);s=s.replace('''    char mode=argc>1 ? argv[1][0] : 's';''','''    char mode=argc>1 ? argv[1][0] : 's';
    if(mode=='o') return ordinary_exec(stack);''')
s=s.replace("    if (mode=='a') {",'''    if (mode=='a') {
        const char *expected=argv[2][0]=='u'?"/work/program (deleted)":"/work/program";
        long length=DO(89,"/proc/self/exe",buffer,sizeof buffer);
        long wanted=argv[2][0]=='u'?23:13;
        CHECK(length==wanted,90);
        for(long i=0;i<length;i++) CHECK(buffer[i]==expected[i],91);''');p.write_text(s)
p=root/'tests/fixtures/launch-exec-fixture.c';s=p.read_text();anchor="    char mode=argc>1 ? argv[1][0] : 's';";assert anchor in s
s=s.replace(anchor,anchor+'''
    char exe[64];
    long length=DO(89,"/proc/self/exe",exe,sizeof exe);
    CHECK(length>5 && exe[0]=='/' && exe[1]=='b' && exe[2]=='i' && exe[3]=='n' && exe[4]=='/',90);
    CHECK(call(267,-100,(word)"/proc/self/exe",(word)exe,4,0,0)==4,91);
    CHECK(DO(89,"/proc/self/exe",exe,0)==-22,92);
    CHECK(DO(89,"/proc/self/exe",1,8)==-14,93);''');p.write_text(s)
p=root/'scripts/test-launch-owned-exec.py';s=p.read_text();s=s.replace('len(sys.argv) != 3','len(sys.argv) < 3').replace("<owned-exec-fixture>'","<owned-exec-fixture> [scenario ...]'").replace('for p in sys.argv[1:]]','for p in sys.argv[1:3]]')
s=s.replace("        for mode in ('success', 'descriptor', 'unlinked', 'relative', 'child', 'vfork', 'mixed-clone'):",'''        ordinary = ('ordinary-path', 'ordinary-fd', 'ordinary-unlinked', 'ordinary-relative', 'ordinary-child', 'ordinary-reexec')
        full = ('success', 'descriptor', 'unlinked', 'relative', 'child', 'vfork', 'mixed-clone')
        for mode in (sys.argv[3:] or (*full, *ordinary)):
            if mode not in (*full, *ordinary):
                sys.exit('unknown owned exec scenario')''')
anchor="            with audit_path.open('wb') as audit:";assert anchor in s
s=s.replace(anchor,'''            if mode in ordinary:
                proc = subprocess.run([binary, 'launch', str(path), str(root), '--result-file', str(result)],
                                      capture_output=True, timeout=15)
                audit_path.write_bytes(proc.stderr)
                expected = b'owned-ordinary: PASS\\n' * (2 if mode == 'ordinary-child' else 1)
                assert proc.returncode == 0 and proc.stdout == expected, (mode, proc.returncode, proc.stdout, proc.stderr)
                assert json.loads(result.read_text()) == dict(version=1, outcome='exited', code=0, signal=None, generation=None)
                assert b'teardown tasks=0 owned-handles=0' in proc.stderr
                assert list((root / 'work').iterdir()) == []
                assert (root / 'input').read_bytes() == b'Q'
                print('PASS owned exec ' + mode, flush=True)
                continue
'''+anchor)
s=s.replace("        print('test-launch-owned-exec: PASS (ELF, execveat, CLOEXEC, failed exec, private fds, text busy, fork/vfork lifetime)')","        print('test-launch-owned-exec: PASS (' + (', '.join(sys.argv[3:]) if sys.argv[3:] else 'full scenarios') + ')')");p.write_text(s)
print('Added six ordinary controlled-program scenarios; security scenarios remain in the default suite.')
