from pathlib import Path
import re,subprocess
root=Path('/tmp/ginux-contribution-preparation/G10/source');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def git(*args):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*args]).decode()
def function(text,name):
 m=re.search(r'^    (?:pub(?:\([^)]*\))? )?fn '+name+r'\b',text,re.M);assert m,name
 i=text.index('{',m.start())+1;depth=1
 while depth:depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[m.start():i]+'\n'
p=root/'.github/workflows/check.yml';s=p.read_text();blocks=list(re.finditer(r'<<<<<<< current\n(.*?)=======\n(.*?)>>>>>>> feature\n',s,re.S));assert len(blocks)==2
for i,m in reversed(list(enumerate(blocks))):s=s[:m.start()]+(m.group(1).replace('build-launch-directory-fixture','build-launch-directory-fixture build-launch-owned-exec-fixture') if i==0 else m.group(1)+m.group(2))+s[m.end():]
p.write_text(s)
p=root/'crates/ginux-vfs/src/lib.rs';s=p.read_text();blocks=list(re.finditer(r'<<<<<<< current\n(.*?)=======\n(.*?)>>>>>>> feature\n',s,re.S));assert len(blocks)==3
for i,m in reversed(list(enumerate(blocks))):
 a,b=m.groups()
 if i==0:r=a.replace('state == 2 &&','state == 2 && self.overlay[object].executions == 0 &&')
 elif i==1:r='                        && entry.executions == 0\n'+a
 else:r=a+'    }\n'+b
 s=s[:m.start()]+r+s[m.end():]
s=s.replace('''Some(slot) if self.overlay[slot].state == 2 && !self.referenced(slot) => slot,''','''Some(slot) if self.overlay[slot].state == 2 && self.overlay[slot].executions == 0 && !self.referenced(slot) => slot,''')
s=s.replace('''        let path = normalize(path)?;
        let metadata = self.metadata(path.as_bytes())?;''','''        let path = self.resolved_path(path, true, false)?;
        let metadata = self.metadata_at(path.as_bytes())?;''')
method=function(git('show','32ba41e9:crates/ginux-vfs/src/lib.rs'),'executable_name');s=s.replace('''    pub fn executable_pins(&self)''',method+'\n    pub fn executable_pins(&self)',1)
s=s.replace('''        object.executions = object
            .executions
            .checked_sub(1)''','''        if object.len != image.size { return Err(VfsError::InvalidDescriptor); }
        object.executions = object
            .executions
            .checked_sub(1)''');p.write_text(s)
# Rebuild the filesystem adapter from the current owner; retain native exec
# validation and introduce only the owned-reference paths from this packet.
p=root/'crates/ginux-init/src/fs_hooks.rs';s=git('show','85b53fe1:crates/ginux-init/src/fs_hooks.rs');d=git('show','c5ae1c5d:crates/ginux-init/src/fs_hooks.rs');s=s.replace('Entry, FileMetadata','Entry, Executable, FileMetadata').replace('type Path = Text<MAX_PATH>;','type Path = Text<MAX_PATH>;\ntype ExecutableName = Text<{ MAX_PATH + 10 }>;')
s=s.replace('//! Retained storage, mappings and generated-file exec are not provided.','//! Executable references share the VFS owner; retained storage and guest file\n//! mappings are not provided.')
s=s.replace('    fn path(&self,','    pub(crate) fn path(&self,',1)
s=s.replace('''    pub fn teardown(&mut self) {
        self.fs.teardown();''','''    pub fn teardown(&mut self) {
        assert_eq!(self.fs.executable_pins(), 0, "overlay teardown retained executable references");
        self.fs.teardown();''')
methods='''    pub fn exec_path(&mut self, pid: usize, address: u64, dirfd: u64, follow: bool) -> Result<Option<Executable>, i64> {
        let raw = read_path(pid, address)?;
        let path = self.path(pid, address, dirfd)?;
        let path = self.resolve(pid, path.as_bytes(), follow, false)?;
        if self.owns_path(path.as_bytes()) {
            let image = self.fs.pin_executable(path.as_bytes()).map_err(errno)?;
            return self.check_exec(pid, image).map(Some);
        }
        if dirfd as i32 != -100 && raw.as_bytes().first() != Some(&b'/') { return Err(-95); }
        self.native_exec_path(pid, address, follow)?;
        Ok(None)
    }

'''+function(d,'exec_descriptor').replace('(&mut self, handle:', '(&mut self, pid: usize, handle:').replace('self.check_exec(image)','self.check_exec(pid, image)')+'\n'+function(d,'check_exec').replace('(&mut self, image:', '(&mut self, pid: usize, image:')
methods=methods.replace('''                Ok(image)
''','''                let mut name = [0; MAX_PATH];
                let next = crate::path_hooks::interpreter_metadata(
                    |offset, output| self.read_executable(image, usize::try_from(offset).map_err(|_| -8)?, output),
                    &mut name,
                )?;
                let root = crate::path_hooks::ImageRoot::new(pid)?;
                self.check_interpreter_chain(pid, &root, name, next)?;
                Ok(image)
''')
methods+='\n'+function(d,'read_executable')+'\n'+function(d,'retain_executable')+'\n'+function(d,'release_executable')
methods+='''
    pub fn executable_name(&self, image: Executable) -> Result<ExecutableName, i64> {
        let (name, deleted) = self.fs.executable_name(image).map_err(errno)?;
        let suffix = if deleted { b" (deleted)".as_slice() } else { b"" };
        let mut bytes = [0; MAX_PATH + 10];
        bytes[..name.len()].copy_from_slice(name);
        bytes[name.len()..name.len()+suffix.len()].copy_from_slice(suffix);
        ExecutableName::from_bytes(&bytes[..name.len()+suffix.len()]).map_err(|_| -36)
    }
'''
s=s.replace('''    /// Configured-launch dispatch only;''',methods+'\n    /// Configured-launch dispatch only;',1).replace('''        VfsError::DirectoryNotEmpty => -39,''','''        VfsError::DirectoryNotEmpty => -39,
        VfsError::TextBusy => -26,''');p.write_text(s)
# Share the already existing bounded kernel-interpreter metadata reader.
p=root/'crates/ginux-init/src/path_hooks.rs';s=p.read_text();method=function(s,'interpreter') if False else None
start=s.index('impl ImageFile {');i=s.index('    fn interpreter(',start);a=s.index('{',i);depth=1;j=a+1
while depth:depth+=(s[j]=='{')-(s[j]=='}');j+=1
method=s[i:j];body=method[method.index('{')+1:-1];body=body.replace('self\n            .read(', 'read(').replace('self.read(', 'read(')
wrapper='''    fn interpreter(&self, output: &mut [u8; MAX_PATH]) -> Result<Option<(usize, bool)>, i64> {
        interpreter_metadata(|offset, buffer| self.read(offset, buffer), output)
    }'''
s=s[:i]+wrapper+s[j:];helper='''pub(crate) fn interpreter_metadata(
    mut read: impl FnMut(u64, &mut [u8]) -> Result<usize, i64>,
    output: &mut [u8; MAX_PATH],
) -> Result<Option<(usize, bool)>, i64> {'''+body+'}\n\n';assert 'self.' not in helper;s=s.replace('struct ImageFile(usize);',helper+'struct ImageFile(usize);');p.write_text(s)
# Preserve the current proc-root '/' correction while sharing cwd/exe lookup.
p=root/'crates/ginux-init/src/tracee_io.rs';s=p.read_text();s=s.replace('''pub fn image_cwd(pid: usize) -> Result<Path, i64> {
    fn link''','''pub fn image_cwd(pid: usize) -> Result<Path, i64> { image_link(pid, b"/cwd") }

pub fn image_link(pid: usize, member: &[u8]) -> Result<Path, i64> {
    fn link''').replace('''let cwd_len = link(pid, b"/cwd", &mut cwd)?;''','''let cwd_len = link(pid, member, &mut cwd)?;''');p.write_text(s)
# Keep current regression assertions; adjust only errors whose owned-exec
# capability is newly available. Identity probes will be separate scenarios.
p=root/'tests/fixtures/launch-exec-fixture.c';s=p.read_text();m=re.search(r'<<<<<<< current\n(.*?)=======\n(.*?)>>>>>>> feature\n',s,re.S);assert m;r=m.group(1).replace('"/work/closed",next,next_env)==-95','"/work/closed",next,next_env)==-13').replace('"/work/hidden",next,next_env)==-95','"/work/hidden",next,next_env)==-2').replace('"/owned-link",next,next_env)==-95','"/owned-link",next,next_env)==-2');s=s[:m.start()]+r+s[m.end():];p.write_text(s)
print('Resolved foundation conflicts; owned ELF metadata uses current interpreter authority checks.')
