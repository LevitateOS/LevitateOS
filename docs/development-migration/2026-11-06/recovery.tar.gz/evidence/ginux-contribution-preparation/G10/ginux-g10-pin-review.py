from pathlib import Path
import subprocess,tarfile,io,os
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G10');src=root/'source';dest=root/'review-pin-regression';assert not dest.exists();dest.mkdir();base='85b53fe15a64041f451ec7e7aa1e77d08cb2c18a'
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'archive',base]))) as t:t.extractall(dest,filter='data')
file='crates/ginux-vfs/src/lib.rs';s=(src/file).read_text();old='''                    && self.overlay[slot].executions == 0
''';assert s.count(old)==1;s=s.replace(old,'',1);(dest/file).write_text(s)
with (root/'review-before-whiteout-pin-fix.log').open('w') as log:r=subprocess.run(['cargo','test','-p','ginux-vfs','executable_pins_exclude_writers_and_retain_unlinked_bytes'],cwd=dest,env={**os.environ,'RUSTFLAGS':'','CARGO_TARGET_DIR':'.artifacts/unit'},stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==101,r.returncode;print('Reproduced the port without the pin-reuse guard: unit exit101; actual candidate remains unchanged.')
