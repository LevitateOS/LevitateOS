from pathlib import Path
import subprocess,tarfile,io,json,hashlib,shutil,os
r=Path('/tmp/ginux-contribution-preparation/F03');r.mkdir(exist_ok=True);s=r/'recipe-source';s.mkdir(exist_ok=True);assert not any(s.iterdir()) and not (r/'state.json').exists();root=Path('/home/vince/Projects/LevitateOS');repo=root/'tools/recipe';git=['git','-C',str(repo),'--work-tree='+str(repo)];head=subprocess.check_output(git+['rev-parse','HEAD']).decode().strip();status=subprocess.check_output(git+['status','--short']).decode();dirty=subprocess.check_output(git+['diff','--name-only','HEAD']).decode().splitlines();assert all(name=='.gitignore' or name.endswith('.rs') for name in dirty),status
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(git+['archive',head]))) as t:t.extractall(s,filter='data')
overlay={}
for name in dirty:
 path=repo/name;dest=s/name
 if path.exists():
  assert path.is_file() and not path.is_symlink(),name
  data=path.read_bytes();dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);overlay[name]=hashlib.sha256(data).hexdigest()
 else:dest.unlink();overlay[name]='deleted'
lock=root/'Cargo.lock';shutil.copyfile(lock,s/'Cargo.lock');(r/'bin').mkdir();gx=json.loads(Path('/tmp/ginux-contribution-preparation/F02/state.json').read_text());g=Path(gx['source'])/'target/x86_64-unknown-linux-gnu/release/ginux';shutil.copyfile(g,r/'bin/ginux');(r/'bin/ginux').chmod(0o755);image=root/'.artifacts/ginux-env/prepared-image-git-musl/rootfs.tar';digest=hashlib.file_digest(image.open('rb'),'sha256').hexdigest();m={'status':'fresh Recipe snapshot build; full suite and security criteria pending','recipe_head':head,'recipe_original_status':status,'tracked_dirty_overlay_sha256':overlay,'recipe_source':str(s),'root_snapshot_head':subprocess.check_output(['git','-C',str(root),'--work-tree='+str(root),'rev-parse','HEAD']).decode().strip(),'workspace_lock_sha256':hashlib.sha256(lock.read_bytes()).hexdigest(),'ginux_head':gx['combined_head'],'ginux_binary_sha256':gx['source_binary_sha256'],'image':str(image),'image_sha256':digest,'image_identity':'oci:recipe-compiler@sha256:'+digest,'security':'only explicitly selected ordinary integration scenarios will run; no full hostile/protected fixtures','publication':'not authorized'};assert hashlib.sha256((r/'bin/ginux').read_bytes()).hexdigest()==m['ginux_binary_sha256'];(r/'state.json').write_text(json.dumps(m,indent=2)+'\n');print('Recipe snapshot',head,'image',digest,flush=True)
commands=[['cargo','build','--offline','--locked','--bin','recipe','--bin','recipe-image'],['cargo','test','--offline','--locked','--test','e2e','--no-run']]
for i,cmd in enumerate(commands):
 with (r/f'build-{i}.log').open('w') as f:p=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
 m.setdefault('builds',[]).append({'command':cmd,'exit_code':p.returncode});(r/'state.json').write_text(json.dumps(m,indent=2)+'\n');print('build',i,p.returncode,flush=True)
 if p.returncode:print((r/f'build-{i}.log').read_text()[-3500:],flush=True);break
if all(x['exit_code']==0 for x in m['builds']) and len(m['builds'])==2:
 for name in ['recipe','recipe-image']:shutil.copyfile(s/'target/debug'/name,r/'bin'/name);(r/'bin'/name).chmod(0o755)
 executables=[p for p in (s/'target/debug/deps').glob('e2e-*') if p.is_file() and os.access(p,os.X_OK)];assert len(executables)==1,executables;shutil.copyfile(executables[0],r/'bin/e2e');(r/'bin/e2e').chmod(0o755);m['binary_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'bin').iterdir()};m['status']='fresh standalone snapshot binaries built; ordinary probe pending';(r/'state.json').write_text(json.dumps(m,indent=2)+'\n');print('fresh binaries retained',json.dumps(m['binary_hashes']),flush=True)
