from pathlib import Path
import subprocess,json,os
r=Path('/tmp/ginux-contribution-preparation/F03');m=json.loads((r/'state.json').read_text());env={**os.environ,'RECIPE_TEST_BIN':str(r/'bin/recipe'),'RECIPE_WORKER_BIN':str(r/'bin/recipe'),'GINUX_BIN':str(r/'bin/ginux'),'GINUX_ROOTFS':m['image'],'GINUX_ROOT':m['image_identity']};cases=[
'managed_inputs::managed_inputs_preserve_nested_modules_and_dependency_closure',
'managed_inputs::managed_check_reads_staged_base_and_imported_module',
'managed_inputs::managed_cleanup_and_remove_return_context_after_checkpoint_ack',
'managed_inputs::managed_cleanup_without_a_hook_is_a_noop',
'managed_inputs::managed_lifecycle_transforms_files_and_cleanup_reads_actual_product',
'managed_inputs::managed_cleanup_and_remove_mutate_domain_files',
'managed_inputs::managed_helpers_use_the_assigned_null_device',
'managed_inputs::managed_bash_child_writes_domain_files_and_keeps_logs_out_of_json',
'managed_inputs::managed_owned_elf_build_executes_and_validates_its_product',
'managed_state::managed_state_restores_files_and_nested_values_without_rewriting_sources',
'managed_storage::managed_storage_preserves_source_modes_links_and_restart_identity',
'dependencies::cli_transitive_dependencies_compile_tools_through_the_shared_lifecycle']
cmd=[str(r/'bin/e2e'),'--exact',*cases,'--nocapture','--test-threads=2'];listing=subprocess.check_output(cmd+['--list'],env=env).decode();assert listing.count(': test\n')==len(cases),listing;(r/'ordinary-batch-selection.txt').write_text(listing);m['ordinary_batch']={'command':cmd,'selected':cases,'status':'running','log':'ordinary-batch.log','security':'reviewed normal lifecycle/dependency/C compiler/metadata/storage operations only; no hostile fixtures'};(r/'state.json').write_text(json.dumps(m,indent=2)+'\n')
with (r/'ordinary-batch.log').open('w') as f:p=subprocess.run(cmd,cwd=Path(m['recipe_source']),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
m=json.loads((r/'state.json').read_text());m['ordinary_batch']['exit_code']=p.returncode;m['ordinary_batch']['status']='passed' if p.returncode==0 else 'failed';m['status']='ordinary Recipe batch completed; inspect exact results, complete suite still pending';(r/'state.json').write_text(json.dumps(m,indent=2)+'\n');print('Recipe ordinary batch',p.returncode,flush=True);print((r/'ordinary-batch.log').read_text()[-9000:],flush=True)
