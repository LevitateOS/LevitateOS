from pathlib import Path
import subprocess,json,hashlib,shutil,os,tomllib
r=Path('/tmp/ginux-contribution-preparation/F03');m=json.loads((r/'state.json').read_text());s=Path(m['recipe_source']);assert m['builds'][-1]['exit_code']==101
before=(s/'Cargo.lock').read_bytes();(r/'workspace-input-Cargo.lock').write_bytes(before)
commands=[['cargo','build','--offline','--bin','recipe','--bin','recipe-image'],['cargo','test','--offline','--locked','--test','e2e','--no-run']]
for i,cmd in enumerate(commands):
 with (r/f'build-retry-{i}.log').open('w') as f:p=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
 m.setdefault('build_retries',[]).append({'command':cmd,'exit_code':p.returncode});(r/'state.json').write_text(json.dumps(m,indent=2)+'\n');print('build retry',i,p.returncode,flush=True)
 if p.returncode:print((r/f'build-retry-{i}.log').read_text()[-3500:],flush=True);break
if len(m['build_retries'])==2 and all(x['exit_code']==0 for x in m['build_retries']):
 after=(s/'Cargo.lock').read_bytes();old={(p['name'],p['version'],p.get('source','')) for p in tomllib.loads(before.decode())['package']};new={(p['name'],p['version'],p.get('source','')) for p in tomllib.loads(after.decode())['package']};m['standalone_lock']={'sha256':hashlib.sha256(after).hexdigest(),'new_package_tuples':sorted(new-old),'removed_workspace_package_count':len(old-new),'reason':'workspace lock needed normalization for standalone source export; offline build, then locked e2e build'}
 for name in ['recipe','recipe-image']:shutil.copyfile(s/'target/debug'/name,r/'bin'/name);(r/'bin'/name).chmod(0o755)
 executables=[p for p in (s/'target/debug/deps').glob('e2e-*') if p.is_file() and os.access(p,os.X_OK)];assert len(executables)==1,executables;shutil.copyfile(executables[0],r/'bin/e2e');(r/'bin/e2e').chmod(0o755);m['binary_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'bin').iterdir()};m['status']='fresh Recipe snapshot binaries built; explicit ordinary probe pending';(r/'state.json').write_text(json.dumps(m,indent=2)+'\n');print('fresh binaries retained',json.dumps(m['binary_hashes']),flush=True)
