from pathlib import Path
s=Path('/tmp/ginux-contribution-preparation/G29/source');p=s/'crates/ginux-init/src/network_hooks.rs';t=p.read_text();t=t.replace('if !self.complete(slot)? {\n                        return Err(-107);','if !self.complete(slot)? {\n                        return Err(if state.connecting { -11 } else { -107 });')
a='''                if r.rdx == 4 {
                    let _ = self.complete(slot);
                }
''';b='''                if r.rdx == 4 {
                    let _ = self.complete(slot);
                    if self.sockets[slot].unwrap().connected {
                        let error = self.network.as_mut().ok_or(-9)?.socket_error(handle).map_err(errno)?;
                        if error != 0 { self.sockets[slot].as_mut().unwrap().error = error; }
                    }
                }
''';assert a in t;t=t.replace(a,b);p.write_text(t)
p=s/'scripts/test-launch-network.py';t=p.read_text().replace('if len(sys.argv) != 3 or os.geteuid() != 0:', 'if len(sys.argv) < 3 or os.geteuid() != 0:').replace('<network-fixture>\'','<network-fixture> [modes...]\'').replace('for p in sys.argv[1:]', 'for p in sys.argv[1:3]')
a="    template = (Path(__file__)";t=t.replace(a,"    modes = ('io', 'nonblock', 'deny', 'quota', 'timeout', 'hold', 'hold-kill', 'slots', 'off', 'ordinary-hold')\n    selected = sys.argv[3:] or modes\n    if any(mode not in modes for mode in selected):\n        sys.exit('unknown configured TCP mode')\n"+a)
t=t.replace("for mode in ('io', 'nonblock', 'deny', 'quota', 'timeout', 'hold', 'hold-kill', 'slots', 'off'):", 'for mode in selected:')
t=t.replace("'timeout', 'hold', 'hold-kill'):","'timeout', 'hold', 'hold-kill', 'ordinary-hold'):")
t=t.replace("if mode.startswith('hold'):","if mode.startswith('hold') or mode == 'ordinary-hold':")
a="                            children = Path(f'/proc/{proc.pid}/task/{proc.pid}/children').read_text().split()\n                            assert len(children) == 1, children\n                            assert sorted(p.name for p in Path(f'/proc/{children[0]}/fd').iterdir()) == ['0', '1', '2']"
assert a in t;t=t.replace(a,"                            if mode != 'ordinary-hold':\n"+'\n'.join('    '+l for l in a.splitlines()))
t=t.replace("if mode == 'hold':", "if mode in ('hold', 'ordinary-hold'):")
t=t.replace("    print('test-launch-network: PASS')", "    print('test-launch-network: PASS ('+', '.join(selected)+')')")
p.write_text(t)
p=s/'tests/fixtures/launch-network-fixture.c';t=p.read_text().replace("if(mode=='o'){", "if(mode=='o' && argv[1][1]=='f'){").replace("if(mode=='h'){", "if(mode=='h' || mode=='o'){")
a='''    CHECK(DO(0,fd,buffer,4)==4 && buffer[0]=='p' && buffer[3]=='g',30);'''
b='''    CHECK(DO(0,fd,buffer,0)==0 && DO(1,fd,buffer,0)==0,42);
    if(mode=='i'){
        struct {char *base;word length;} output[3]={{buffer,1},{buffer+1,0},{buffer+1,1}};
        CHECK(DO(19,fd,output,3)==2 && buffer[0]=='p' && buffer[1]=='i',43);
        CHECK(DO(0,fd,buffer+2,2)==2 && buffer[2]=='n' && buffer[3]=='g',44);
    }else CHECK(DO(0,fd,buffer,4)==4 && buffer[0]=='p' && buffer[3]=='g',30);'''
assert a in t;t=t.replace(a,b);p.write_text(t)
print('Adjusted connection-in-progress IO, retained established SO_ERROR, selected ordinary runner and valid zero/short/vector coverage')
