from pathlib import Path
p=Path('/tmp/ginux-contribution-preparation/G29/source/crates/ginux-init/src/network_hooks.rs');t=p.read_text()
t=t.replace('use crate::supervisor::UserRegs;', 'use crate::supervisor::{syscall2, UserRegs, SYS_KILL};').replace('use crate::tracee_io::{copy_memory, write_stat, Stat};','use crate::tracee_io::{copy_memory, write_stat, IoVectors, Stat};')
t=t.replace('    connected: bool,','''    connected: bool,
    // SO_ERROR is consumed by the guest; failed connection state is not.
    failure: i32,
    error: i32,''')
t=t.replace('pub enum Result {','''struct Receive {
    bytes: [u8; IO],
    at: usize,
    end: usize,
}
impl Receive {
    const fn new() -> Self { Self { bytes: [0; IO], at: 0, end: 0 } }
}
pub enum Result {''')
t=t.replace('    sockets: [Option<Socket>; FDS],','    sockets: [Option<Socket>; FDS],\n    received: [Receive; FDS],')
t=t.replace('            sockets: [None; FDS],','            sockets: [None; FDS],\n            received: [const { Receive::new() }; FDS],')
a=t.index('        let slot = handle - FD_BASE;',t.index('    pub fn readiness'));b=t.index('    pub fn claim',a)
t=t[:a]+'''        let slot = (handle - FD_BASE) as usize;
        let state = self.sockets[slot]?;
        if !state.connecting && !state.connected && state.failure == 0 {
            return Some(4 | 16); // An unconnected stream cannot wait for data.
        }
        // Completion consumes the private SO_ERROR only once and retains it.
        let _ = self.complete(slot);
        let pending = &self.received[slot];
        Some(match self.network.as_mut()?.readiness(slot as u32) {
            Ok(r) => {
                u16::from(r.readable || pending.at < pending.end)
                    | (u16::from(r.writable) * 4)
                    | (u16::from(r.error || self.sockets[slot]?.error != 0) * 8)
                    | (u16::from(r.hangup) * 16)
            }
            Err(_) => 8,
        })
    }
    fn complete(&mut self, slot: usize) -> core::result::Result<bool, i64> {
        let state = self.sockets[slot].ok_or(-9)?;
        if state.failure != 0 { return Err(-(state.failure as i64)); }
        if !state.connecting { return Ok(state.connected); }
        let net = self.network.as_mut().ok_or(-9)?;
        let ready = net.readiness(slot as u32).map_err(errno)?;
        if !ready.writable && !ready.error && !ready.hangup { return Ok(false); }
        let error = net.socket_error(slot as u32).map_err(errno)?;
        let state = self.sockets[slot].as_mut().unwrap();
        state.connecting = false;
        if error != 0 {
            state.failure = error;
            state.error = error;
            return Err(-(error as i64));
        }
        state.connected = true;
        Ok(true)
    }
'''+t[b:]
t=t.replace('            connecting: false,','            connecting: false,\n            failure: 0,\n            error: 0,')
t=t.replace('        Ok((FD_BASE + slot) as i64)','        self.received[slot as usize] = Receive::new();\n        Ok((FD_BASE + slot) as i64)')
t=t.replace('        let net = self.network.as_mut().ok_or(-9)?;\n        let handle', '        let handle')
t=t.replace('                net.close(handle).map_err(errno)?;','                self.network.as_mut().ok_or(-9)?.close(handle).map_err(errno)?;\n                self.received[slot] = Receive::new();')
a=t.index('            42 => {');b=t.index('            0 | 1 | 19',a)
t=t[:a]+'''            42 => {
                if state.connected { return Err(-106); }
                if state.failure != 0 { return Err(-(state.failure as i64)); }
                if !state.connecting {
                    let endpoint = read_endpoint(pid, r.rsi, r.rdx)?;
                    let net = self.network.as_mut().ok_or(-9)?;
                    net.connect(handle, endpoint).map_err(errno)?;
                    self.sockets[slot].as_mut().unwrap().connecting = true;
                    if state.nodelay { net.set_nodelay(handle, true).map_err(errno)?; }
                    if state.flags & 0o4000 != 0 { return Err(-115); }
                } else if state.flags & 0o4000 != 0 {
                    if self.complete(slot)? { return Err(-106); }
                    return Err(-114);
                }
                if self.complete(slot)? { Ok(0) } else { Err(-11) }
            }
'''+t[b:]
a=t.index('                let write = matches!');b=t.index('            48 => {',a)
t=t[:a]+'''                let write = matches!(r.orig_rax, 1 | 20 | 44);
                let vectors = if matches!(r.orig_rax, 19 | 20) {
                    IoVectors::read(pid, r.rsi, r.rdx)?
                } else { IoVectors::single(r.rsi, r.rdx) };
                let length = vectors.length.min(IO);
                if length == 0 { return Ok(0); }
                // Preserve already received bytes even after the shared transport
                // budget is exhausted. Only backend transfers spend that budget.
                if write {
                    if !self.complete(slot)? { return Err(-107); }
                    let mut buffer = [0u8; IO];
                    let copied = vectors.copy(pid, &mut buffer[..length], false)?;
                    let result = self.network.as_mut().ok_or(-9)?.write(handle, &buffer[..copied]).map_err(errno);
                    if result == Err(-32) && !(r.orig_rax == 44 && r.r10 & 0x4000 != 0) {
                        // The backend suppresses host SIGPIPE; signal its guest caller.
                        let _ = unsafe { syscall2(SYS_KILL, pid, 13) };
                    }
                    return result.map(|n| n as i64);
                }
                if self.received[slot].at == self.received[slot].end {
                    if !self.complete(slot)? { return Err(-107); }
                    let pending = &mut self.received[slot];
                    let n = self.network.as_mut().ok_or(-9)?.read(handle, &mut pending.bytes[..length]).map_err(errno)?;
                    pending.at = 0;
                    pending.end = n;
                }
                let pending = &mut self.received[slot];
                let end = pending.end.min(pending.at + length);
                // No copyin/preflight of a receive destination. Advance only by
                // the copied prefix; a failed copy leaves the bytes for aliases.
                let copied = vectors.copy(pid, &mut pending.bytes[pending.at..end], true)?;
                pending.at += copied;
                Ok(copied as i64)
            }
'''+t[b:]
t=t.replace('                net.shutdown(handle,', '                self.network.as_mut().ok_or(-9)?.shutdown(handle,')
t=t.replace('                let endpoint = net.endpoint(handle,','                let endpoint = self.network.as_mut().ok_or(-9)?.endpoint(handle,')
t=t.replace('                        net.set_nodelay(handle,','                        self.network.as_mut().ok_or(-9)?.set_nodelay(handle,')
a=t.index('                let value = if r.rdx == 3');b=t.index('                let mut length = [0u8; 4];',a)
t=t[:a]+'''                if r.rdx == 4 { let _ = self.complete(slot); }
                let value = if r.rdx == 3 { 1 } else { self.sockets[slot].unwrap().error };
'''+t[b:]
a=t.index('            55 =>');b=t.index('            72 =>',a);part=t[a:b];part=part.replace('                Ok(0)','                if r.rdx == 4 { self.sockets[slot].as_mut().unwrap().error = 0; }\n                Ok(0)');t=t[:a]+part+t[b:]
p.write_text(t)
