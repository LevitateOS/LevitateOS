from pathlib import Path
import subprocess,tarfile,io,json,os,tempfile
r=Path('/tmp/ginux-contribution-preparation/G29');s=r/'source';assert not s.exists();s.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';poll='fe27c693bf2629166ee82da2efefb62b298bb567';tcp='0a3cf5f5ab7e77080eb9491cb6bffd5ba642cb68'
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
with tarfile.open(fileobj=io.BytesIO(git('archive',poll))) as t:t.extractall(s,filter='data')
file='crates/ginux-devices/src/lib.rs';assert (s/file).read_bytes()==git('show','3f2fe7df:'+file);(s/file).write_bytes(git('show',tcp+':'+file))
p=s/'README.md';t=p.read_text();source=git('show',tcp+':README.md').decode();t+='\n'+source[source.index('### Supervisor-owned TCP backend'):];p.write_text(t)
p=s/'.github/workflows/check.yml';t=p.read_text();needle='      - run: make build build-launch-fixture';assert needle in t;t=t.replace(needle,"      - run: RUSTFLAGS='' CARGO_TARGET_DIR=.artifacts/unit cargo test -p ginux-devices --lib\n"+needle);p.write_text(t)
files=['README.md','.github/workflows/check.yml','crates/ginux-devices/src/lib.rs']
with tempfile.TemporaryDirectory(prefix='ginux-g29-composition-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',poll,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(s/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();base=git('commit-tree',tree,'-p',poll,input=b'Local preparation: compose public readiness and bounded TCP backend\n').decode().strip()
git('diff','--check',poll,base);(r/'prerequisite-composition.patch').write_bytes(git('diff','3f2fe7df',base));m={'base':base,'tree':tree,'dependencies':['G08a','G28'],'prerequisite_heads':{'G08a':poll,'G28':tcp},'source':['66de28808afd59808d6c0180a376629e41478a9c'],'composition_adaptations':['Preserve both README sections and both poll/Linux TCP CI invocations'],'excluded':['G07 threads/socketpairs','G02 guest clocks','G25 native scalar clamp','G26 resource/affinity','archive/time/identity changes'],'deferred_joins':['G24 socket Stat field initialization at F02','G07/shared FD calls and G20 event wait at F02','final actual consumer closure F02/F03']};(r/'composition.json').write_text(json.dumps(m,indent=2)+'\n');b=r/'base';assert not b.exists();b.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(b,filter='data')
print(json.dumps(m,indent=2))
