from pathlib import Path
import json,shutil,hashlib,subprocess
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';r=Path('/tmp/ginux-contribution-preparation/G29');art=root/'.artifacts/ginux-contribution-preparation/G29';m=json.loads((r/'manifest.json').read_text());stats=[json.loads((r/(p+'static-receipt.json')).read_text()) for p in ['final-','clean-']];assert all(x['head']==m['head'] and x['exit_code']==0 and x['matched_paths']==173 for x in stats);assert stats[0]['binary_sha256']==stats[1]['binary_sha256']
for prefix in ['', 'clean-']:
 units=json.loads((r/(prefix+'unit-receipt.json')).read_text());assert all(x['exit_code']==0 for x in units) and sum(x['passed'] for x in units)==84
 assert all(x['exit_code']==0 for x in json.loads((r/(('final-' if prefix=='' else prefix)+'functional-receipt.json')).read_text()))
 consumers=json.loads((r/(prefix+'consumer-receipt.json')).read_text());curl=[x for x in consumers if x['case'].startswith('curl')];assert len(curl)==2 and all(x['exit_code']==0 and x['stdout']==x['expected_stdout'] for x in curl)
 ipv6=json.loads((r/(prefix+'ipv6-consumer-receipt.json')).read_text());assert len(ipv6)==1 and ipv6[0]['exit_code']==0 and ipv6[0]['stdout']==ipv6[0]['expected_stdout']
assert json.loads((r/'baseline-receipt.json').read_text())['exit_code']==2
network_hashes=[hashlib.sha256((r/d/'.artifacts/launch/launch-network-fixture').read_bytes()).hexdigest() for d in ['source','verified-head']];assert network_hashes[0]==network_hashes[1]
m.update(status='ordinary source/clean preparation and separate full-diff self-review retained; full G29 partial: Git/cwd/consumer joins, security/network policy/full CI/fresh upstream acceptance pending',routine_unit_tests=84,security_tests_unrun=3,default_linux_unit_total=87,full_make_test_unit='not run unfiltered; three new policy/security tests remain default-enabled and handed to DaybreakBlue',clean_matched_paths=173,review='separate whole-diff self-review, not independent or security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=stats[0]['binary_sha256'],clean_binary_sha256=stats[1]['binary_sha256'],network_fixture_sha256=network_hashes[0],evidence='g29-review.md',source_patch='patches/G29.patch',functional_evidence='five ordinary TCP and five poll modes source/clean; actual curl controlled IPv4 HTTP, IPv6 HTTP and trusted TLS; final aliases/fork/close/normal EOF accounting',consumer_limits='actual Git exits128 before transport at unsupported getcwd; preserve for G14/F02/F03; no workaround or broader prerequisite import')
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in r.iterdir():
 if not p.is_file():continue
 if p.suffix in ['.log','.audit','.stdout','.diff','.patch'] or p.name.endswith('receipt.json') or p.name in ['composition.json','manifest.json','consumer-provenance.json']:
  shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g29*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(r/'candidate.patch',docs/'patches/G29.patch')
(art/'draft.md').write_text('''Mediate explicitly configured TCP through public descriptors

Allow numeric endpoint grants with connection and cumulative transfer budgets.
Reuse existing descriptor aliases, process lifetimes and readiness; retain
undelivered receive data and failed connection state across SO_ERROR reads.
The immutable core/default native socket policy stays unchanged.

Local static/build checks,84 selected routine units, ordinary socket/poll cases
and actual curl over controlled IPv4/IPv6 HTTP and trusted TLS pass in source and
clean replay. Full/default security coverage, Git/filesystem joins, policy and
remote CI remain pending. Not ready to submit.
''')
(docs/'g29-review.md').write_text(f'''# G29 — configured TCP integration (partial)

Head `{m['head']}`, tree `{m['tree']}`, on local prerequisite
composition `{m['base']}` of G08a `fe27c693` and G28 `0a3cf5f5`.
[Patch](patches/G29.patch):12 files,+1022/-13, adapted from66de2880 to current
per-process owners. This is local preparation, not a standalone-ready proposal
or a completed network/security/consumer acceptance.

The config owner adds at most8 numeric IPv4/IPv6 destinations, live connection
limit1–16 and a positive cumulative sent/received byte budget. Old configs and
normalization remain unchanged when fields are absent. Legacy mediated metadata
without grants still parses but configured launch requires the complete explicit
policy. No DNS or arbitrary native socket fallback is added. Core/native rules
stay unchanged. NetworkBackend/endpoint/budget contract still needs upstream review.

Public socket allocation reserves a slot before acquiring the owned object;
errors release it. The existing160-entry reference owner now includes16 network
objects after its144 existing objects. Dup/fork share a socket and its private
transport; final close/exec/death use existing releases. Network syscalls on
non-sockets return ENOTSOCK. Poll uses the same registered owner and external1 ms
scheduler tick, with one stored timeout per parked call. No G07 shared-table,
G02 guest clock, G26 resource, archive or native scalar-clamp ancestry is imported.
G25's canonical IoVectors helper is reused verbatim without regular-file/pwrite
prerequisites. Deduplicate that same helper when the owners join at F01/F02.

Separate whole-diff self-review read all12 changed files, public reservation/
close/alias/fork/finish/death owners, G08a retries and timer loop, strict vector
copies, G28 API/error/byte accounting, full default fixtures, docs and CI. This
is self-review, not an independent or adversarial assessment.

Findings and corrections:

- **High, corrected in source — receive copyout/data loss:** donor preflight
  copyin/writeback is removed. Each socket retains at most4096 received bytes,
  charges actual transport once, advances only by the copied prefix and keeps
  the tail for aliases until delivered/closed. Staged data supplies POLLIN even
  after transport budget exhaustion; zero/EOF does not touch destination bytes.
  Protected/partial/mutable destination verification is explicitly unrun.
- **High, corrected in source — consumed connection error:** completion now
  checks transport readiness and stores persistent failure separately from the
  consumable SO_ERROR value. Poll, connect retry and getsockopt share this state;
  consuming the error cannot make the failed connection connected. Established
  transport errors still use native SO_ERROR. Refusal/error races remain unrun.
- **Medium, corrected — vector divergence and signal handling:** canonical16-
  vector checked aggregate/copy rules replace separate parsing. MSG_NOSIGNAL
  protects the supervisor; ordinary EPIPE writes signal the guest unless the
  guest send requests suppression. Shared-thread signal targeting and adversarial
  copy/prefix verification remain F02/DaybreakBlue joins.
- **Medium, corrected — timeout retries:** ppoll snapshots its initial timeout
  and poll layout, rather than rereading relative deadlines on every tick.
  Per-socket timeouts similarly freeze on first park. Arithmetic is checked.
  Null ppoll signal masks only, millisecond rounding/no timespec mutation and
  unfinished general signal restart/interruption are documented.
- **Coverage preserved:** every old unit and target remains. Donor default
  deny/quota/FD-inspection/kill/slot/off scenarios remain enabled. Optional mode
  selection accurately names only checks actually run. New ordinary-hold and
  budget modes verify normal peer EOF and exactly8 transferred bytes without
  exercising a denied operation. The valid receive-vector fixture respects short
  stream reads. Essential new fixture build/run wiring stays in this packet.

Source and strict clean base-plus-patch replay pass make check build plus both
network/poll fixture builds. All173 tracked paths match, Ginux and fixture hashes
match. Both copies pass84 selected routine units (all82 preexisting composition
units plus2 ordinary G28 TCP units). Three new policy/security tests remain
default-enabled but unrun: tcp_grants_are_numeric_bounded_and_complete and the
2 G28 donor tests. Unfiltered make test-unit/full Linux CI/macOS/remote CI is
pending, not green. Default Linux total would be87.

Five ordinary TCP modes in each copy cover blocking and nonblocking connect,
SO_ERROR success, poll/ppoll peer wakeup, NODELAY, socket names, valid readv/writev,
zero/short reads, alias/fork lifetime, half-close/EOF,50 ms receive timeout, normal
controlled close and exact byte-budget use. Five existing ordinary poll controls
also pass. Actual trusted host curl fetches the exact payload on controlled
IPv4 HTTP, IPv6 HTTP and TLS with an explicit private test CA in source/clean.
Minimal host binaries/DSOs and their hashes are recorded in consumer-provenance;
no external network or negative TLS probes ran. TLS verification is not disabled.

Actual Git ls-remote was attempted: it exits128 before transport at unsupported
getcwd (syscall79). Its earlier harness attempts exceeded the8-argument config
bound or omitted explicitly assigned null; corrected harness evidence is retained.
Do not substitute curl or historical integrated Git logs for this failed actual
Git acceptance. G14 and remaining combined consumer capabilities must join and
Git/Recipe must rerun at F02/F03. No cwd bypass or unrelated filesystem import was
added. Exact prerequisite rejects these newly introduced valid grant config
fields with unknown-field/exit2 before workload; final candidate accepts them.

Remaining joins: G07 shared FD/call/thread owners and the unresolved shared-path
security hold; G20 event wait with a finite tick while network/timers wait;
G24 socket Stat nlink/time fields; G25 helper deduplication; actual HTTP/TLS/Git
acquisition and complete Recipe consumer closure on fresh combined revisions.
No live sockets are exported/restored. Private descriptor/CLOEXEC/grant authority,
refused endpoints, protected buffers, error/race/cancel/revoke/exhaustion and fault
injection remain [DaybreakBlue](daybreakblue-handoff.md) work. Full default network
security modes and unfiltered CI remain unrun. No cloud dispatch occurred.

Patch/draft/helpers/commands/results/failures/hashes are retained under
.artifacts/ginux-contribution-preparation/G29/. No branches, refs, checkouts,
real indexes, remote text or publication were changed. F04 is the user inspection
stop before any push, PR or maintainer message.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G29');row.update(m);p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'p04-dependencies.md';t=p.read_text();a="Its receive-copy,\nSO_ERROR state and vector/SIGPIPE review findings remain unfixed source findings;";b="Its initial receive-copy,\nSO_ERROR state and vector/SIGPIPE findings were subsequently corrected in G29;\nsource/clean ordinary TCP/curl validation passes while actual Git needs G14\nat F02/F03 and policy/security/full CI remain held;";assert a in t;t=t.replace(a,b);p.write_text(t)
p=docs/'daybreakblue-handoff.md';t=p.read_text();a=t.index('G29 has source-only receive ownership');t=t[:a]+f'''## G29 — configured TCP integration (partial)

Head `{m['head']}` on G08a/G28 composition `{m['base']}`.
84 selected routine units, ordinary source/clean TCP/poll modes and actual curl
IPv4/IPv6 HTTP and trusted TLS pass. Actual Git remains blocked before transport
by absent getcwd until G14/F02/F03. No negative TLS/foreign endpoint or hostile
buffer probes ran. [Review/evidence](g29-review.md).

Initial source findings are corrected: receive data is staged until copied,
failed connection state survives SO_ERROR consumption, canonical vector copies
are reused and deadlines persist across retries. These fixes have source review
and ordinary functional evidence, not adversarial verification.

DaybreakBlue must validate partial/protected/mutable scalar/vector receive and
send buffers, retained tails across aliases and exhausted budget, zero/EOF and
copy-error ordering, address/aggregate overflow, malformed/denied/foreign numeric
endpoints/families/scope/mapped representations, SO_ERROR refusal/reset/poll/retry
races and consumable versus persistent state, SIGPIPE/MSG_NOSIGNAL and thread
signal targeting, private-FD/CLOEXEC/assignment authority, stale/reused/closed
handles, concurrent fork/exec/close/cancel/revoke, shutdown/error/timeout edges,
quota/connection exhaustion and injected backend failures. Preserve full default
fixture modes deny/quota/hold/hold-kill/slots/off and the3 new policy/security
units; all remain enabled and locally unrun. G07 shared-path/thread hold still
applies. No cloud dispatch or security acceptance occurred; policy/full CI/fresh
upstream independence and final consumer closure remain pending.
''';p.write_text(t)
p=root/'docs/ginux-contribution-task-list.md';t=p.read_text();a=t.index('[G29 progress](ginux-contributions/g29-review.md) records unfixed source receive');b=t.index('\nActive skill:',a);t=t[:a]+f'''G29 `{m['head'][:8]}` is retained on G08a/G28 composition `{m['base'][:8]}`.
[Review/evidence](ginux-contributions/g29-review.md) records173-path strict replay,
84 selected routine units and five ordinary TCP/five poll modes passing in
source/clean. Receive tails and failed connection state are now retained; shared
vector copies and frozen deadlines replace the donor's divergent handling.
Actual curl IPv4/IPv6 HTTP and verified local TLS pass. Actual Git fails before
transport at absent getcwd; preserve for G14/F02/F03, without a workaround or
false closure. Three default-enabled policy/security units/full security modes,
G07/G20/G24/G25 joins, network policy and full CI/upstream independence remain
pending. G29 is partial, not publication-ready. No publication occurred.

Exact next task: **G30 — trace and extract virtual root ownership**.
Inspect7cf2638a against the existing inode/path/descriptor owners and prove its
smallest actual prerequisites before composing. Keep correct uid/gid zero or
unchanged semantics and nofollow/absence/error behavior; test actual trusted cpio
extraction with the needed reviewed consumer capabilities. Preserve every G08,
G23–G29/F02/F03 open criterion. Then reconcile G31 and perform F01/F02/F03/F04.
No branch/ref/publication or maintainer messages before user inspection.
''' +t[b:];p.write_text(t);print('saved G29',m['head'],'ordinary preparation; Git/security/full task remains partial; next G30')
