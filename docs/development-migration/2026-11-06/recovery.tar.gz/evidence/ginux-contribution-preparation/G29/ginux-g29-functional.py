from pathlib import Path
import subprocess,json,sys
r=Path('/tmp/ginux-contribution-preparation/G29')
for directory,prefix in [('source','final-'),('verified-head','clean-')]:
 s=r/directory;receipts=[]
 for name,script,fixture,modes in [('network','test-launch-network.py','launch-network-fixture',['io','nonblock','timeout','ordinary-hold','budget']),('poll','test-launch-poll.py','launch-poll-fixture',['ordinary','read','write','hup','ordinary-timer'])]:
  cmd=['sudo','-n','python3','scripts/'+script,'target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/'+fixture,*modes]
  with (r/(prefix+name+'-functional.log')).open('w') as f:p=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
  receipts.append({'command':cmd,'exit_code':p.returncode});(r/(prefix+'functional-receipt.json')).write_text(json.dumps(receipts,indent=2)+'\n');print(directory,name,p.returncode,flush=True);assert p.returncode==0
