from pathlib import Path
import subprocess
s=Path('/tmp/ginux-contribution-preparation/G29/source');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
def donor(f):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'show','66de2880:'+f]).decode()
def edit(f,fn):
 p=s/f;p.write_text(fn(p.read_text()))
d=donor('crates/ginux-domain/src/lib.rs')
def domain(t):
 for prefix in ['    pub ','    ']:
  a=prefix+'network_backend: NetworkBackend,'
  t=t.replace(a,a+'\n'+''.join(prefix+x+'\n' for x in ['network_endpoints: TextList<ASSIGNMENT_ITEMS, ASSIGNMENT_BYTES>,','network_max_connections: u64,','network_max_bytes: u64,']).rstrip())
 for a,extra in [('            network_backend: NetworkBackend::None,','            network_endpoints: TextList::empty(),\n            network_max_connections: 0,\n            network_max_bytes: 0,'),('            network_backend: self.network_backend,','            network_endpoints: self.network_endpoints,\n            network_max_connections: self.network_max_connections,\n            network_max_bytes: self.network_max_bytes,')]:t=t.replace(a,a+'\n'+extra)
 parser=d[d.index('/// Numeric destination parsing'):d.index('#[derive(Clone, Copy, Debug, Eq, PartialEq)]\npub enum ConfigError')]
 a='#[derive(Clone, Copy, Debug, Eq, PartialEq)]\npub enum ConfigError';t=t.replace(a,parser+a)
 validation=d[d.index('        let endpoints = self.network_endpoints'):d.index('        if !(1..=1_000_000)')];a='        if !(1..=64)';t=t.replace(a,validation+a)
 norm=d[d.index('        if !self.network_endpoints'):d.index('        output.raw(b"\\n\\n[audit]')];a='        output.raw(b"\\n\\n[audit]';t=t.replace(a,norm+a)
 t=t.replace('+ 2 * ASSIGNMENT_ITEMS * ASSIGNMENT_BYTES;', '+ 3 * ASSIGNMENT_ITEMS * ASSIGNMENT_BYTES;')
 fields=d[d.index('        (Section::Network, b"endpoints")'):d.index('        (Section::Audit, b"mode")')];a='        (Section::Audit, b"mode")';t=t.replace(a,fields+a)
 unit=d[d.index('    #[test]\n    fn tcp_grants_are_numeric'):d.index('    #[test]\n    fn storage_bounds')];t=t.replace('    #[test]\n',unit+'    #[test]\n',1)
 return t
edit('crates/ginux-domain/src/lib.rs',domain)
# Preserve G25's canonical vector layout and copy implementation byte-for-byte.
q=Path('/tmp/ginux-contribution-preparation/G25/source/crates/ginux-init/src/tracee_io.rs').read_text();edit('crates/ginux-init/src/tracee_io.rs',lambda t:t+'\n'+q[q.index('/// Bounded scatter/gather layout'):])
edit('crates/ginux-init/src/main.rs',lambda t:t.replace('mod device_hooks;', 'mod device_hooks;\nmod network_hooks;'))
def devices(t):
 t=t.replace('pub struct LaunchDevices {','pub struct LaunchDevices {\n    pub network: crate::network_hooks::LaunchNetwork,')
 t=t.replace('pub fn readiness(&self, handle: u32) -> Option<u16> {','pub fn readiness(&mut self, handle: u32) -> Option<u16> {\n        if crate::network_hooks::LaunchNetwork::owns(handle) {\n            return self.network.readiness(handle);\n        }')
 t=t.replace('        Ok(Self {\n            registry,','        Ok(Self {\n            network: crate::network_hooks::LaunchNetwork::prepare(config)?,\n            registry,')
 return t
edit('crates/ginux-init/src/device_hooks.rs',devices)
def dispatch(t):
 a='    } else if let Some(result) = devices.claim(pid, registers, filesystem) {'
 t=t.replace(a,'''    } else if let Some(result) = devices.network.claim(pid, registers) {
        match result {
            crate::network_hooks::Result::Ready(result) => NativeDecision::Hooked {
                lane: Lane::Device,
                result,
            },
            crate::network_hooks::Result::Blocked => NativeDecision::Park { fd: registers.rdi as u32 },
        }
'''+a)
 return t
edit('crates/ginux-init/src/dispatch.rs',dispatch)
def descriptors(t):
 t=t.replace('counts: [u16; 144]','counts: [u16; 144 + crate::network_hooks::FDS]').replace('counts: [0; 144]','counts: [0; 144 + crate::network_hooks::FDS]')
 t=t.replace('        if (0x4000_0000..0x4000_0040)', '        if crate::network_hooks::LaunchNetwork::owns(handle) {\n            144 + (handle - crate::network_hooks::FD_BASE) as usize\n        } else if (0x4000_0000..0x4000_0040)')
 t=t.replace('            22 | 293 => {','            41 => {\n                self.save(r);\n                self.socket(pid, r, backends)\n            }\n            22 | 293 => {')
 t=t.replace('0 | 1 | 5 | 8 | 16 | 17 | 18 | 19 | 20 | 74 | 75 | 77 | 78 | 91 | 217 =>', '0 | 1 | 5 | 8 | 16 | 17 | 18 | 19 | 20 | 42 | 44 | 45 | 48 | 51 | 52 | 54 | 55 | 74 | 75 | 77 | 78 | 91 | 217 =>')
 t=t.replace('            7 => self.poll(', '            7 | 271 => self.poll(')
 ds=donor('crates/ginux-init/src/descriptors.rs');socket=ds[ds.index('    fn socket('):ds.index('    fn path_descriptor(')];t=t.replace('    fn path_descriptor(',socket+'    fn path_descriptor(')
 t=t.replace('    fn descriptor(\n        &self,','    fn descriptor(\n        &mut self,')
 t=t.replace('        let public_fd = r.rdi as u32;','''        let public_fd = r.rdi as u32;
        let network = matches!(entry.handle, Handle::Owned(h) if crate::network_hooks::LaunchNetwork::owns(h));
        if matches!(r.orig_rax, 42 | 44 | 45 | 48 | 51 | 52 | 54 | 55) && !network {
            return Err(-88);
        }
        if network && self.poll_deadline.is_some_and(|end| monotonic_nanoseconds().is_ok_and(|now| now >= end)) {
            return Ok(ready(-11));
        }''')
 t=t.replace('            NativeDecision::Park { .. } => NativeDecision::Park { fd: public_fd },','''            NativeDecision::Park { .. } => {
                if network {
                    if !self.poll_tick {
                        let timeout = backends.devices.network.timeout(r.rdi as u32, r.orig_rax);
                        if timeout != 0 {
                            self.poll_deadline = Some(monotonic_nanoseconds()?.checked_add(timeout).ok_or(-22)?);
                        }
                    }
                    self.poll_tick = true;
                }
                NativeDecision::Park { fd: public_fd }
            },''')
 t=t.replace('        backends: &Backends,','        backends: &mut Backends,')
 t=t.replace('        let timeout = r.rdx as i32;','''        // Snapshot ppoll's relative timeout once, like the pollfd layout. A
        // parked task must retain its original deadline across scheduler ticks.
        let timeout = if self.poll_wait {
            -1
        } else if r.orig_rax == 271 {
            if r.r10 != 0 { return Err(-95); }
            if r.rdx == 0 { -1 } else {
                let mut time = [0u8; 16];
                if copy_memory(pid, r.rdx, &mut time, false)? != 16 { return Err(-14); }
                let sec = i64::from_ne_bytes(time[..8].try_into().unwrap());
                let ns = i64::from_ne_bytes(time[8..].try_into().unwrap());
                if sec < 0 || !(0..1_000_000_000).contains(&ns) || sec > 300 { return Err(-22); }
                (sec * 1000 + (ns + 999999) / 1000000) as i32
            }
        } else { r.rdx as i32 };''')
 t=t.replace('        let mut ready_count = 0;', '        let mut ready_count = 0;\n        let mut network_wait = false;')
 t=t.replace('                    let available = backends','                    network_wait |= crate::network_hooks::LaunchNetwork::owns(handle);\n                    let available = backends')
 t=t.replace('self.poll_tick = timeout > 0 || consoles[..count].iter().any(|fd| fd.fd >= 0);','self.poll_tick = network_wait || self.poll_deadline.is_some() || consoles[..count].iter().any(|fd| fd.fd >= 0);')
 return t
edit('crates/ginux-init/src/descriptors.rs',descriptors)
for f in ['tests/fixtures/launch-network-fixture.c','scripts/test-launch-network.py']:
 p=s/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(donor(f))
m=donor('Makefile');edit('Makefile',lambda t:t+'\n'+m[m.index('.PHONY: build-launch-network-fixture'):])
def ci(t):
 lines=t.splitlines()
 for i,l in enumerate(lines):
  if 'make build build-launch-fixture' in l:lines[i]+=' build-launch-network-fixture'
 lines.insert(next(i for i,l in enumerate(lines) if 'sudo make test-launch-poll' in l)+1,'      - run: sudo make test-launch-network')
 return '\n'.join(lines)+'\n'
edit('.github/workflows/check.yml',ci)
d=donor('README.md');edit('README.md',lambda t:t+'\n'+d[d.index('## Configured TCP grants'):d.index('## Native process scenarios')])
(s/'crates/ginux-init/src/network_hooks.rs').write_text(Path('/tmp/ginux-contribution-preparation/G29/network_hooks-donor.rs').read_text().replace('                    links: 1,\n',''))
print('Ported config, current per-process owners, canonical vectors, fixture/CI/docs and donor network for correction')
