Mediate explicitly configured TCP through public descriptors

Allow numeric endpoint grants with connection and cumulative transfer budgets.
Reuse existing descriptor aliases, process lifetimes and readiness; retain
undelivered receive data and failed connection state across SO_ERROR reads.
The immutable core/default native socket policy stays unchanged.

Local static/build checks,84 selected routine units, ordinary socket/poll cases
and actual curl over controlled IPv4/IPv6 HTTP and trusted TLS pass in source and
clean replay. Full/default security coverage, Git/filesystem joins, policy and
remote CI remain pending. Not ready to submit.
