from pathlib import Path
import subprocess,shutil,re,hashlib,json,threading,http.server,ssl,sys,socket
r=Path('/tmp/ginux-contribution-preparation/G29');s=r/(sys.argv[1] if len(sys.argv)>1 else 'source');prefix='clean-' if s.name!='source' else '';root=r/'consumer-root';root.mkdir(exist_ok=True)
files=['/usr/bin/curl','/usr/bin/git','/usr/libexec/git-core/git-remote-http','/usr/libexec/git-core/git-remote-https'];provenance=[]
for name in list(files):
 output=subprocess.check_output(['ldd',name]).decode();files+=re.findall(r'(?:=>\s+|^\s+)(/[^\s]+)',output,re.MULTILINE)
for name in dict.fromkeys(files):
 source=Path(name);dest=root/name.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest);dest.chmod(0o755);provenance.append({'source':name,'resolved_source':str(source.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
(root/'work').mkdir(exist_ok=True)
(r/'consumer-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
cert=r/'localhost-cert.pem';key=r/'localhost-key.pem'
if not cert.exists():
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','2','-subj','/CN=localhost','-addext','subjectAltName=IP:127.0.0.1','-keyout',str(key),'-out',str(cert)],check=True,capture_output=True);key.chmod(0o600)
shutil.copyfile(cert,root/'ca.pem')
payload=b'configured HTTP and TLS transport\n';head='0123456789abcdef0123456789abcdef01234567';observed=[]
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  observed.append(self.path)
  data=(head+'\trefs/heads/main\n').encode() if self.path.startswith('/repo/info/refs') else ((head+'\n').encode() if self.path=='/repo/HEAD' else payload)
  self.send_response(200);self.send_header('Content-Length',str(len(data)));self.send_header('Content-Type','text/plain');self.end_headers();self.wfile.write(data)
 def log_message(self,*args):pass
receipts=[]
for tls,kind in [(False,'curl-http'),(True,'curl-tls'),(False,'git-http'),(True,'git-tls'),(False,'curl-http6')]:
 if len(sys.argv)>2 and kind not in sys.argv[2:]:continue
 ipv6=kind.endswith('6');host='::1' if ipv6 else '127.0.0.1';url_host='[::1]' if ipv6 else host
 class Server(http.server.HTTPServer):address_family=socket.AF_INET6 if ipv6 else socket.AF_INET
 with Server((host,0),Handler) as server:
  if tls:
   context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(str(cert),str(key));server.socket=context.wrap_socket(server.socket,server_side=True)
  port=server.server_address[1];thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url=f'{"https" if tls else "http"}://{url_host}:{port}'
  if kind.startswith('curl'):
   executable='/usr/bin/curl';args=['-qsS','--noproxy','*','-m5']+(['--cacert','/ca.pem'] if tls else [])+[url+'/payload'];expected=payload
  else:
   executable='/usr/bin/git';args=['-c','http.proxy=','-c','http.sslCAInfo=/ca.pem','ls-remote',url+'/repo'];expected=(head+'\tHEAD\n'+head+'\trefs/heads/main\n').encode()
  config=(s/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = '+json.dumps(executable)).replace('args = []','args = '+json.dumps(args)).replace('environment = ["container=ginux"]','environment = ["container=ginux", "GIT_EXEC_PATH=/usr/libexec/git-core", "GIT_CONFIG_NOSYSTEM=1", "GIT_CONFIG_GLOBAL=/dev/null"]')
  config=config.replace('[devices]\nassignments = []','[devices]\nassignments = ["null"]')
  config=config.replace('backend = "none"',f'backend = "mediated"\nendpoints = ["{url_host}:{port}"]\nmax_connections = 4\nmax_bytes = 1048576');path=r/(prefix+kind+'.toml');path.write_text(config);result=r/(prefix+kind+'.json');result.unlink(missing_ok=True);cmd=[str(s/'target/x86_64-unknown-linux-gnu/release/ginux'),'launch',str(path),str(root),'--result-file',str(result)]
  p=subprocess.run(cmd,capture_output=True,timeout=15);server.shutdown();thread.join();(r/(prefix+kind+'.audit')).write_bytes(p.stderr);(r/(prefix+kind+'.stdout')).write_bytes(p.stdout)
  receipt={'case':kind,'command':cmd,'exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'result':json.loads(result.read_text()) if result.exists() else None,'expected_stdout':expected.decode(),'requests':list(observed)};receipts.append(receipt);(r/(prefix+('ipv6-' if sys.argv[2:]==['curl-http6'] else '')+'consumer-receipt.json')).write_text(json.dumps(receipts,indent=2)+'\n');print(kind,p.returncode,repr(p.stdout),flush=True)
  if p.returncode or p.stdout!=expected: print(p.stderr[-2500:].decode(errors='replace'),flush=True)
print('consumer checks completed; inspect receipts for each pass/failure, no negative/security scenarios executed')
