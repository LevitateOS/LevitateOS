Launching with an absent working directory calls x86-64 syscall259 (`mknodat`) and then fails to enter it. Use `mkdirat` (258) and cover creation of the configured directory in the existing launch suite.

The regression fails on upstream `3f2fe7df`. Static/unit, build and required Linux launch/native/process/setup checks pass locally. macOS Actions and the full Rocky VM suite have not run on this unpublished candidate.
