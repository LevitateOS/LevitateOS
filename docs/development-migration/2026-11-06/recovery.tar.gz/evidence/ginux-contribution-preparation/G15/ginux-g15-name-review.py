from pathlib import Path
import subprocess,json
root=Path('/tmp/ginux-contribution-preparation/G15');src=root/'source';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';review=root/'name-review';review.mkdir(exist_ok=True)
probe='''
    #[test]
    fn hardlink_exec_name_review_probe() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 3, 32, 3> = VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        let fd = fs.open(b"/program", O_CREATE | O_WRITE).unwrap();
        fs.write(fd, b"trusted program bytes").unwrap();
        fs.fchmod(fd, 0o755).unwrap();
        fs.close(fd).unwrap();
        fs.hard_link(b"/program", b"/invoked", false).unwrap();
        let image = fs.pin_executable(b"/invoked").unwrap();
        assert_eq!(fs.executable_name(image), Ok((b"/invoked".as_slice(), false)));
        fs.rename(b"/invoked", b"/moved", false).unwrap();
        assert_eq!(fs.executable_name(image), Ok((b"/moved".as_slice(), false)));
        fs.unlink(b"/moved").unwrap();
        assert_eq!(fs.executable_name(image), Ok((b"/moved".as_slice(), true)));
        fs.release_executable(image).unwrap();
    }
'''
records=[]
for label,s in [('donor',subprocess.check_output(['git','-C',repo,'show','9e2a39e8:crates/ginux-vfs/src/lib.rs']).decode()),('candidate',(src/'crates/ginux-vfs/src/lib.rs').read_text())]:
 pos=s.rfind('}');p=review/(label+'.rs');p.write_text(s[:pos]+probe+s[pos:]);binary=review/(label+'-unit')
 subprocess.run(['rustc','--test','--edition=2021',str(p),'-o',str(binary)],check=True)
 with (root/('review-'+label+'-exec-name.log')).open('w') as log:r=subprocess.run([str(binary),'hardlink_exec_name_review_probe'],stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==(101 if label=='donor' else 0),(label,r.returncode)
 records.append({'revision':'9e2a39e8' if label=='donor' else 'candidate source','exit_code':r.returncode})
(root/'review-exec-name-receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records))
