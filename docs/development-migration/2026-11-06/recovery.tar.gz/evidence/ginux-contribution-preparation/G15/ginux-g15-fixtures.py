from pathlib import Path
import subprocess
src=Path('/tmp/ginux-contribution-preparation/G15/source');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
p=src/'crates/ginux-vfs/src/lib.rs';s=p.read_text();pos=s.index('    #[test]\n    fn create_unlink_and_failures');s=s[:pos]+'''    #[test]
    fn hardlink_file_and_exec_references_retain_the_named_entry() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 3, 32, 4> = VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        let writer = fs.open(b"/one", O_CREATE | O_WRITE).unwrap();
        fs.write(writer, b"shared").unwrap();
        fs.fchmod(writer, 0o755).unwrap();
        fs.close(writer).unwrap();
        fs.hard_link(b"/one", b"/two", false).unwrap();
        let fd = fs.open(b"/two", O_READ).unwrap();
        let dup = fs.duplicate(fd, false).unwrap();
        let reopen = fs.reopen_readonly(fd, 0).unwrap();
        let mut bytes = [0; 6];
        fs.read(fd, &mut bytes[..2]).unwrap();
        assert_eq!(&bytes[..2], b"sh");
        fs.read(dup, &mut bytes[..2]).unwrap();
        assert_eq!(&bytes[..2], b"ar");
        fs.read(reopen, &mut bytes[..2]).unwrap();
        assert_eq!(&bytes[..2], b"sh");
        assert_eq!(fs.seek(fd, 0, 1), Ok(4));
        let old = fs.pin_executable_fd(fd).unwrap();
        assert_eq!(fs.executable_name(old), Ok((b"/two".as_slice(), false)));
        fs.retain_executable(old).unwrap();
        fs.unlink(b"/two").unwrap();
        fs.hard_link(b"/one", b"/two", false).unwrap();
        let new = fs.pin_executable(b"/two").unwrap();
        fs.rename(b"/two", b"/renamed", false).unwrap();
        assert_eq!(fs.executable_name(old), Ok((b"/two".as_slice(), true)));
        assert_eq!(fs.executable_name(new), Ok((b"/renamed".as_slice(), false)));
        assert_eq!(fs.read_executable(old, 0, &mut bytes), Ok(6));
        assert_eq!(&bytes, b"shared");
        assert_eq!(fs.open(b"/one", O_WRITE), Err(VfsError::TextBusy));
        for fd in [fd, dup, reopen] { fs.close(fd).unwrap(); }
        assert_eq!(fs.open(b"/fresh", O_CREATE | O_WRITE), Err(VfsError::OverlayLimit));
        fs.release_executable(old).unwrap();
        assert_eq!(fs.open(b"/fresh", O_CREATE | O_WRITE), Err(VfsError::OverlayLimit));
        fs.release_executable(old).unwrap();
        let fresh = fs.open(b"/fresh", O_CREATE | O_WRITE).unwrap();
        fs.close(fresh).unwrap();
        assert_eq!(fs.open(b"/one", O_WRITE), Err(VfsError::TextBusy));
        fs.release_executable(new).unwrap();
        let writer = fs.open(b"/renamed", O_WRITE).unwrap();
        fs.write(writer, b"S").unwrap();
        fs.close(writer).unwrap();
        assert_eq!(fs.metadata(b"/one"), fs.metadata(b"/renamed"));
        assert_eq!(fs.metadata(b"/one").unwrap().links, 2);
        assert_eq!(fs.executable_pins(), 0);
    }

    #[test]
    fn hardlink_creation_preserves_entries_on_failure_and_follows_only_when_requested() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 4, 32, 4> = VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        let fd = fs.open(b"/one", O_CREATE | O_WRITE).unwrap();
        fs.write(fd, b"data").unwrap();
        fs.close(fd).unwrap();
        assert_eq!(fs.hard_link(b"/one", b"/missing/", false), Err(VfsError::NotFound));
        assert_eq!(fs.metadata_no_follow(b"/missing"), Err(VfsError::NotFound));
        fs.symlink(b"one", b"/sym").unwrap();
        assert_eq!(fs.hard_link(b"/sym", b"/no-follow", false), Err(VfsError::PermissionDenied));
        assert_eq!(fs.metadata(b"/one").unwrap().links, 1);
        fs.hard_link(b"/sym", b"/follow", true).unwrap();
        assert_eq!(fs.metadata(b"/follow"), fs.metadata(b"/one"));
        assert_eq!(fs.metadata_no_follow(b"/sym").unwrap().links, 1);
        assert_eq!(fs.hard_link(b"/one", b"/follow", false), Err(VfsError::AlreadyExists));
        assert_eq!(fs.metadata(b"/one").unwrap().links, 2);
    }

'''+s[pos:];p.write_text(s)
# Keep full donor checks with a selected ordinary mode, avoiding all old routes.
d=subprocess.check_output(['git','-C',repo,'show','9e2a39e8:tests/fixtures/launch-directory-fixture.c']).decode();a=d.index('    CHECK(create("/work/link-source"');b=d.index('    CHECK(DO(83,"/work/cwd"',a);part=d[a:b].replace('    CHECK(DO(86,"/image"','    if(!functional) CHECK(DO(86,"/image"',1)
p=src/'tests/fixtures/launch-directory-fixture.c';s=p.read_text();pos=s.index('long directory_main(');s=s[:pos]+'''static long hardlinks(int functional) {
'''+part+'''    DO(1,1,"owned-directories: PASS\\n",24); return 0;
}
static long hardlink_quota(void) {
    long fd=DO(2,"/work/large",0102,0600); CHECK(fd>=3,180);
    buffer[0]='Q';
    for(word offset=0;offset<12UL*1024*1024;offset+=sizeof buffer) CHECK(DO(1,fd,buffer,sizeof buffer)==sizeof buffer,181);
    CHECK(DO(86,"/work/large","/work/large-alias",0)==0,182);
    CHECK(DO(4,"/work/large-alias",meta,0)==0 && *(word *)(meta+16)==2 && *(word *)(meta+48)==12UL*1024*1024,183);
    long alias=DO(2,"/work/large-alias",0,0); CHECK(alias>=3,184);
    CHECK(DO(87,"/work/large",0,0)==0 && DO(3,fd,0,0)==0,185);
    CHECK(DO(0,alias,buffer,1)==1 && buffer[0]=='Q' && DO(3,alias,0,0)==0,186);
    DO(1,1,"owned-directories: PASS\\n",24); return 0;
}
'''+s[pos:];pos=s.index('    int functional=',s.index('long directory_main('));s=s[:pos]+'''    if(stack[0]>1 && equal(argv[1],"ordinary-hardlinks")) return hardlinks(1);
    if(stack[0]>1 && equal(argv[1],"hardlinks")) return hardlinks(0);
    if(stack[0]>1 && equal(argv[1],"ordinary-hardlink-quota")) return hardlink_quota();
'''+s[pos:];p.write_text(s)
p=src/'scripts/test-launch-directories.py';s=p.read_text().replace("['all', 'cwd']","['all', 'cwd', 'hardlinks', 'ordinary-hardlinks', 'ordinary-hardlink-quota']").replace("('all', 'functional', 'cwd')","('all', 'functional', 'cwd', 'hardlinks', 'ordinary-hardlinks', 'ordinary-hardlink-quota')").replace('            for i in range(2):','            if mode == \'ordinary-hardlink-quota\':\n                (work/\'launch.toml\').write_text((work/\'launch.toml\').read_text().replace(\'memory_mib = 256\', \'memory_mib = 16\'))\n            for i in range(2):');p.write_text(s)
p=src/'tests/fixtures/launch-owned-exec-fixture.c';s=p.read_text();s=s.replace('        if(equal(argv[2],"ordinary-reexec")) {','''        if(equal(argv[2],"ordinary-hardlinked") || equal(argv[2],"ordinary-fd-hardlinked")) {
            CHECK(DO(2,"/work/program",1,0)==-26,132);
            if(equal(argv[2],"ordinary-hardlinked")) CHECK(DO(2,"/work/alias",1,0)==-26 && DO(87,"/work/alias",0,0)==0,133);
            CHECK(DO(2,"/work/program",1,0)==-26,134);
        }
        if(equal(argv[2],"ordinary-reexec")) {''',1)
s=s.replace('    char *next[]={"payload","ordinary-after",argv[1],0};','''    if(equal(argv[1],"ordinary-hardlinked") || equal(argv[1],"ordinary-fd-hardlinked")) CHECK(DO(86,"/work/program","/work/alias",0)==0,135);
    char *next[]={"payload","ordinary-after",argv[1],0};''',1)
s=s.replace('if(equal(argv[1],"ordinary-fd") || equal(argv[1],"ordinary-unlinked")) {','if(equal(argv[1],"ordinary-fd") || equal(argv[1],"ordinary-unlinked") || equal(argv[1],"ordinary-fd-hardlinked")) {',1).replace('long fd=DO(2,"/work/program",02000000,0);','long fd=DO(2,equal(argv[1],"ordinary-fd-hardlinked")?"/work/alias":"/work/program",02000000,0);',1).replace('        if(equal(argv[1],"ordinary-unlinked")) CHECK','        if(equal(argv[1],"ordinary-fd-hardlinked")) CHECK(DO(87,"/work/alias",0,0)==0,136);\n        if(equal(argv[1],"ordinary-unlinked")) CHECK',1).replace('    } else DO(59,"/work/program",next,empty_env);','    } else DO(59,equal(argv[1],"ordinary-hardlinked")?"/work/alias":"/work/program",next,empty_env);',1);p.write_text(s)
p=src/'scripts/test-launch-owned-exec.py';s=p.read_text().replace("'ordinary-child', 'ordinary-reexec')","'ordinary-child', 'ordinary-reexec', 'ordinary-hardlinked', 'ordinary-fd-hardlinked')");p.write_text(s)
p=src/'README.md';s=p.read_text().replace('owned directories as cwd, relative image-directory FD access, hardlinks and\nguest file mappings remain unsupported.','owned directories as cwd, relative image-directory FD access and guest file\nmappings remain unsupported.\nOwned regular-file link/linkat names share inode, bytes, permissions and link\ncounts. Removing one name preserves data through other names, file descriptions\nand executable references. Descriptions and executable pins retain the name\nthrough which they were obtained, including rename and deletion state. Hardlinks\nconsume namespace entries without duplicating file capacity. Only owned regular\nfiles are linkable; linkat supports flags zero or AT_SYMLINK_FOLLOW. Symlink inode\nlinks, image-file imports, descriptor-only AT_EMPTY_PATH linking and directory\nhardlinks remain unsupported. Failed creation preserves names and link counts.')
p.write_text(s)
print('G15 named reference units and ordinary alias/quota/exec scenarios added; full authority checks retained')
