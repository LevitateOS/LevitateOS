from pathlib import Path
import subprocess,tarfile,io,json,re
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G15');src=root/'source';base='5c3ae8e5068b5da21d2c37f9545c0f7b10eba147'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
def method(s,sig):
 a=s.index(sig);b=s.index('{',a);n=1;i=b+1
 while n:n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
assert not src.exists();src.mkdir(parents=True);tarfile.open(fileobj=io.BytesIO(git('archive',base))).extractall(src,filter='data');(root/'composition.json').write_text(json.dumps({'base':base,'donors':['9e2a39e8'],'excluded':['G14 cwd','G12 mappings','archive joins until G19/G22']},indent=2)+'\n')
p=src/'crates/ginux-vfs/src/lib.rs';s=p.read_text();d=git('show','9e2a39e8:crates/ginux-vfs/src/lib.rs').decode()
# Preserve the current walker, offsets, reopen model and metadata policy.
s=re.sub(r'(?<!struct )\bFileMetadata \{\n','FileMetadata {\n                links: 1,\n',s)
s=s.replace('    pub size: u64,\n}', '    pub size: u64,\n    pub links: u64,\n}',1)
s=s.replace('    object: usize,\n    pub size: usize,', '    object: usize,\n    entry: usize,\n    pub size: usize,',1)
s=s.replace('    executions: usize,\n}', '    executions: usize,\n    links: u64,\n    object: Option<usize>,\n    name_pins: usize,\n}',1)
s=s.replace('            executions: 0,','            executions: 0,\n            links: 1,\n            object: None,\n            name_pins: 0,')
a=s.index('impl OverlayFile {');b=s.index('struct Descriptor',a);part=s[a:b].replace('            links: 1,','            links: 0,',1);s=s[:a]+part+s[b:]
s=s.replace('    object: usize,\n    position:', '    object: usize,\n    entry: usize,\n    position:',1).replace('            object: 0,\n            position:', '            object: 0,\n            entry: 0,\n            position:',1)
# All path opens remember the entry as well as the canonical data slot.
s=s.replace('            Some(index) => {\n                if writable', '            Some(index) => {\n                let index = self.object(index);\n                if writable',1)
s=s.replace('        self.positions[position] = 0;\n        self.descriptors[slot] = Descriptor {\n            open: true,\n            overlay,\n            object,', '''        let entry = if overlay { self.find_overlay(path.as_bytes()).unwrap() } else { object };
        self.positions[position] = 0;
        self.descriptors[slot] = Descriptor {
            open: true,
            overlay,
            object,
            entry,''',1)
s=s.replace('            object: source.object,\n            position,','            object: source.object,\n            entry: source.entry,\n            position,',1)
s=s.replace('            overlay: overlay.is_some(),\n            object,\n            position,','            overlay: overlay.is_some(),\n            object,\n            entry: object,\n            position,',1)
s=s.replace('matches!(entry.state, 1 | 3 | 4)', 'matches!(entry.state, 1 | 3 | 4 | 5)')
s=s.replace('inode: (self.index.len() + object + 1) as u64,\n                        kind:', 'inode: (self.index.len() + self.object(object) + 1) as u64,\n                        kind:',1)
s=s.replace('self.release_unlinked(state.object);','self.release_unlinked(state.entry);',1)
s=s.replace('fd.open && fd.overlay && fd.object == object','fd.open && fd.overlay && (fd.object == object || fd.entry == object)',1)
a=method(s,'    fn release_unlinked(')
s=s.replace(a,'''    fn object(&self, slot: usize) -> usize { self.overlay[slot].object.unwrap_or(slot) }

    fn link_count(&self, object: usize) -> u64 { self.overlay[object].links }

    fn remove_name(&mut self, slot: usize) {
        let object = self.object(slot);
        self.overlay[object].links = self.overlay[object].links.checked_sub(1).expect("live inode link count");
        self.overlay[slot].state = 2;
        self.release_unlinked(slot);
    }

    fn release_unlinked(&mut self, slot: usize) {
        let object = self.object(slot);
        if object != slot && self.overlay[slot].state == 2 && self.overlay[slot].name_pins == 0 && !self.referenced(slot) {
            self.overlay[slot].object = None;
        }
        if self.overlay[object].state == 2 && self.overlay[object].links == 0 && self.overlay[object].executions == 0 && !self.referenced(object) {
            self.storage.clear(object);
            self.overlay[object].len = 0;
        }
    }''')
# Names, including directory entries, retire through one link-count owner.
s=s.replace('            self.overlay[index].state = 2;\n            self.release_unlinked(index);','            self.remove_name(index);',1)
s=s.replace('        self.overlay[slot].state = 2;\n        self.release_unlinked(slot);','        self.remove_name(slot);',1)
s=s.replace('            self.overlay[target].state = 2;\n            self.release_unlinked(target);','            self.remove_name(target);',1)
# Distinct aliases of one inode are a rename no-op.
s=s.replace('        // Check every new descendant path before changing any namespace entry.', '        if target.is_some_and(|target| self.object(target) == self.object(source_slot)) { return Ok(()); }\n        // Check every new descendant path before changing any namespace entry.',1)
s=s.replace('        self.overlay[slot].mode = mode;\n        Ok(())','        let object = self.object(slot);\n        self.overlay[object].mode = mode;\n        Ok(())',1)
# Single name reservation owner retains current same-name whiteout reuse.
pos=s.index('    fn create_overlay(')
s=s[:pos]+'''    fn name_slot(&self, path: &[u8]) -> Result<usize, VfsError> {
        match self.find_overlay(path) {
            Some(slot) if self.overlay[slot].state == 2 && self.overlay[slot].executions == 0 && self.overlay[slot].name_pins == 0 && self.overlay[slot].links == 0 && !self.referenced(slot) => Ok(slot),
            _ => self.allocate_overlay(),
        }
    }

'''+s[pos:]
a=method(s,'    fn create_overlay(');s=s.replace(a,'''    fn create_overlay(&mut self, path: Path, mode: u32) -> Result<usize, VfsError> {
        let index = self.name_slot(path.as_bytes())?;
        self.storage.clear(index);
        self.overlay[index] = OverlayFile { state: 1, path, mode, links: 1, ..OverlayFile::empty() };
        Ok(index)
    }''')
a=method(s,'    pub fn symlink(');start=a.index('        let slot = match self.find_overlay(');end=a.index('        self.storage.clear(slot);',start);new=a[:start]+'        let slot = self.name_slot(path.as_bytes())?;\n'+a[end:];s=s.replace(a,new)
s=s.replace('                    entry.state == 2\n                        && entry.executions == 0','                    entry.state == 2\n                        && entry.executions == 0\n                        && entry.name_pins == 0\n                        && entry.links == 0',1)
# Shared metadata and hardlink creation; no archive API import.
new=method(d,'    fn overlay_metadata(')+'\n\n';new+=method(d,'    pub fn hard_link(').replace('        let destination = self.namespace_path(destination, true)?;', '        let directory_destination = destination.ends_with(b"/");\n        let destination = self.namespace_path(destination, true)?;').replace('            Err(VfsError::NotFound) => {}','            Err(VfsError::NotFound) if directory_destination => return Err(VfsError::NotFound),\n            Err(VfsError::NotFound) => {}',1).replace('        let slot = self.allocate_overlay()?;', '        let links = self.overlay[object].links.checked_add(1).ok_or(VfsError::OverlayLimit)?;\n        let slot = self.name_slot(destination.as_bytes())?;',1).replace('        self.overlay[object].links += 1;','        self.overlay[object].links = links;',1)+'\n\n'
s=s.replace('    pub fn metadata_no_follow(',new+'    pub fn metadata_no_follow(',1)
a=method(s,'    fn metadata_at(');start=a.index('            return Ok(FileMetadata {');end=a.index('\n        }',start);a2=a[:start]+'            return Ok(self.overlay_metadata(index));'+a[end:];s=s.replace(a,a2)
a=method(s,'    pub fn fstat(');a2=a.replace('links: 1,','links: self.link_count(state.object),',1);s=s.replace(a,a2)
# Executable name and shared inode lifetime are retained independently.
s=s.replace('        self.pin_object(object)\n', '        self.pin_object(object)\n',1) # caller passes its named entry
s=s.replace('        self.pin_object(state.object)','        self.pin_object(state.entry)',1)
a=method(s,'    fn pin_object(');a2=a.replace('fn pin_object(&mut self, object: usize)', 'fn pin_object(&mut self, entry: usize)').replace('        if self.overlay[object].mode', '        let object = self.object(entry);\n        if self.overlay[object].mode',1).replace('            object,\n            size:', '            object,\n            entry,\n            size:',1)
start=a2.index('        self.overlay[object].executions =');end=a2.index('        Ok(image)',start);a2=a2[:start]+'''        let executions = self.overlay[object].executions.checked_add(1).ok_or(VfsError::OverlayLimit)?;
        let names = self.overlay[entry].name_pins.checked_add(1).ok_or(VfsError::OverlayLimit)?;
        self.overlay[object].executions = executions;
        self.overlay[entry].name_pins = names;
'''+a2[end:];s=s.replace(a,a2)
for sig,operation in [('    pub fn retain_executable(', 'add'),('    pub fn release_executable(', 'sub')]:
 a=method(s,sig);name='retain_executable' if operation=='add' else 'release_executable';checked='checked_add(1)' if operation=='add' else 'checked_sub(1)';error='OverlayLimit' if operation=='add' else 'InvalidDescriptor'
 s=s.replace(a,f'''    pub fn {name}(&mut self, image: Executable) -> Result<(), VfsError> {{
        let object = self.overlay.get(image.object).ok_or(VfsError::InvalidDescriptor)?;
        let entry = self.overlay.get(image.entry).ok_or(VfsError::InvalidDescriptor)?;
        if object.executions == 0 || object.len != image.size || entry.name_pins == 0 || self.object(image.entry) != image.object {{ return Err(VfsError::InvalidDescriptor); }}
        let executions = object.executions.{checked}.ok_or(VfsError::{error})?;
        let names = entry.name_pins.{checked}.ok_or(VfsError::{error})?;
        self.overlay[image.object].executions = executions;
        self.overlay[image.entry].name_pins = names;
        '''+('self.release_unlinked(image.entry);' if operation=='sub' else '')+'''
        Ok(())
    }''')
a=method(s,'    pub fn executable_name(');a2=a.replace('        Ok((object.path.as_bytes(), object.state == 2))','''        let entry = self.overlay.get(image.entry).ok_or(VfsError::InvalidDescriptor)?;
        if entry.name_pins == 0 || self.object(image.entry) != image.object { return Err(VfsError::InvalidDescriptor); }
        Ok((entry.path.as_bytes(), entry.state == 2))''');s=s.replace(a,a2)
# Retain donor's meaningful regular alias lifetime regression.
test=method(d,'    fn hardlinks_share_identity_and_preserve_pinned_bytes_at_capacity(');s=s.replace('    #[test]\n    fn create_unlink_and_failures', '    #[test]\n'+test+'\n\n    #[test]\n    fn create_unlink_and_failures',1)
p.write_text(s)
# Stat link counts through existing ABI encoder; non-file devices/channels stay1.
for filename in ['tracee_io.rs','channel_hooks.rs','device_hooks.rs']:
 p=src/'crates/ginux-init/src'/filename
 old=root/'merge-old';new=root/'merge-new';old.write_bytes(git('show','9e2a39e8^:crates/ginux-init/src/'+filename));new.write_bytes(git('show','9e2a39e8:crates/ginux-init/src/'+filename));r=subprocess.run(['git','merge-file',str(p),str(old),str(new)]);assert r.returncode==0,(filename,r.returncode)
p=src/'crates/ginux-init/src/descriptors.rs';s=p.read_text().replace('            264 | 316 => {','            264 | 265 | 316 => {',1);p.write_text(s)
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();s=s.replace('        if matches!(r.orig_rax, 82 | 264 | 316) {','        if matches!(r.orig_rax, 86 | 265) { return Some(self.hard_link(pid, r).unwrap_or_else(|error| error)); }\n        if matches!(r.orig_rax, 82 | 264 | 316) {',1)
d=git('show','9e2a39e8:crates/ginux-init/src/fs_hooks.rs').decode();new=method(d,'    fn hard_link(').replace('self.owned_path(source.as_bytes(), flags & 0x400 != 0, false)?','self.resolve(pid, source.as_bytes(), flags & 0x400 != 0, false)?').replace('self.mutation_path(destination.as_bytes(), true)?','self.mutation_path(pid, destination.as_bytes(), true)?');new=new.replace('        if !self.owns_path(source.as_bytes()) || !self.owns_path(destination.as_bytes()) {\n            return Err(-18);\n        }\n','')
new=new.replace('        self.fs\n            .hard_link', '''        if !self.owns_path(source.as_bytes()) || !self.owns_path(destination.as_bytes()) { return Err(-18); }
        if raw_destination_slash && self.fs.metadata_no_follow(destination.as_bytes()).is_err() { return Err(-2); }
        self.fs
            .hard_link''').replace('        let destination = self.mutation_path', '        let raw_destination_slash = destination.as_bytes().ends_with(b"/");\n        let destination = self.mutation_path',1)
s=s.replace('    fn rename(',new+'\n\n    fn rename(',1)
s=s.replace('            inode: metadata.inode,','            inode: metadata.inode,\n            links: metadata.links,',1)
# No current fs_hooks FileMetadata constructors, if present preserve legacy nlink1.
s=re.sub(r'(?<!struct )\bFileMetadata \{\n', 'FileMetadata {\n                links: 1,\n',s);p.write_text(s)
print('G15 hardlink/inode and named reference source adapted')
