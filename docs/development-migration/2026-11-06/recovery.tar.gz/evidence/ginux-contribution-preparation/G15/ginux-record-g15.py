from pathlib import Path
import json,shutil,hashlib
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';temp=Path('/tmp/ginux-contribution-preparation/G15');art=root/'.artifacts/ginux-contribution-preparation/G15'
m=json.loads((temp/'manifest.json').read_text())
m.update(status='source separately self-reviewed; static/unit/build and selected ordinary runtime pass in source/clean replay; security/full CI/current-main independence pending',unit_tests=98,vfs_tests=40,clean_matched_paths=177,review='separate self-review; no independent reviewer/security acceptance claimed',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=json.loads((temp/'final-static-receipt.json').read_text())['binary_sha256'],clean_binary_sha256=json.loads((temp/'clean-static-receipt.json').read_text())['binary_sha256'],final_clean_export='verified-head')
assert m['source_binary_sha256']==m['clean_binary_sha256']
fixtures={}
for name in ['launch-directory-fixture','launch-storage-fixture','launch-script-fixture','launch-owned-exec-fixture']:
 a=(temp/'source/.artifacts/launch'/name).read_bytes();b=(temp/'verified-head/.artifacts/launch'/name).read_bytes();assert a==b,name;fixtures[name]=hashlib.sha256(a).hexdigest()
m['fixture_sha256']=fixtures
for prefix in ['', 'clean-']:
 receipts=json.loads((temp/(prefix+'functional-receipt.json')).read_text());assert len(receipts)==4 and all(r['exit_code']==0 for r in receipts)
(temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in temp.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.patch','.diff']:shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g15*.py'):shutil.copyfile(p,art/p.name)
(art/'draft.md').write_text('''Share owned regular-file identity across hardlink names

Implement link/linkat for owned regular files. Aliases share bytes, permissions,
inode and link counts without duplicating backing capacity. Open descriptions
and executable pins retain the invoked name through rename or deletion; final
unlink and close release backing capacity.

Local validation:98 units and selected hardlink/quota/ELF/script/storage scenarios
pass in source and clean replay. Full security coverage, remote CI and prerequisite
merges remain pending; not ready to submit.
''')
assert not any(s in (art/'draft.md').read_text() for s in ['LevitateOS','Recipe','Daybreak'])
shutil.copyfile(temp/'candidate.patch',docs/'patches/G15.patch')
(docs/'g15-review.md').write_text(f'''# G15 — owned hardlink identity; security acceptance pending

Head `{m['head']}`, tree `{m['tree']}`, sole local prerequisite
G13 `{m['base']}`. [Retained patch](patches/G15.patch). Eleven files,+441/-72.
Source and ordinary functionality are prepared; security/full CI/current-main
independence remain pending. No G14 cwd, G12 mapping or G07 thread ancestry is imported.

## Implementation and separate self-review

Owned regular-file names refer directly to one canonical VFS data owner. Metadata,
bytes, permissions, inode identity and executable writer exclusion follow that
owner. Link counts count live names. Aliases consume namespace capacity without
allocating another file buffer. Removing the last name preserves backing through
file descriptions and executable pins; the final release returns capacity.

Descriptors retain both data identity and the entry used to open them. Duplicates
retain shared offsets; reopen_readonly retains entry identity with a fresh offset.
Executable references count both canonical data pins and per-entry name pins, so
rename/deletion of an invoked alias remains observable without recycling its slot.
No new lifetime owner or thread abstraction is introduced. Existing task/script
pin retain/release callers remain unchanged. Public FileMetadata adds links:u64;
private stat/statx encoding and device/pipe constructors are updated accordingly.
Directories/symlinks/image entries keep the existing one-link approximation.

link/linkat reuse current path translation and descriptor register restoration.
Only assigned owned regular files are linkable; linkat permits zero flags or
AT_SYMLINK_FOLLOW. No directory links, symlink-inode links, image imports or
AT_EMPTY_PATH linking are promised. Namespace/parent/capacity checks finish before
publishing an alias or changing the link count. Same-inode rename is a no-op.
The current component walker is byte-for-byte preserved.

A separate final self-review read the entire candidate diff and current VFS
allocation/open/duplicate/reopen/close, rename/unlink, pin retain/release/name,
metadata/enumeration, runtime dispatch, descriptor translation, script/ELF and
task cleanup callers. This is self-review, not independent reviewer coverage.

- **High, executable alias identity:** the donor pins only the canonical data
  entry, reporting /program when /invoked was executed. A focused ordinary VFS
  API comparison fails on exact donor9e2a39e8 and passes on the candidate through
  alias rename and deletion. Per-entry descriptor/name pins prevent reuse while
  an old alias is still referenced, even after a new alias gets the same name.
  A focused unit checks retained/released pins, duplicate versus reopened offsets,
  old/new alias names, slot exhaustion/reclamation and writer exclusion.
- **Moderate, live file counting:** the initial adaptation counted only canonical
  live names. Removing the original name left a live alias but reported zero
  overlay_files. The focused unit reproduces that failure and passes after live
  alias entries are included. Metadata and directory enumeration use canonical
  inode identity; chmod affects every alias.
- **High, capacity/lifetime preservation:** same-name whiteout reservation is
  shared with existing create/symlink behavior. Canonical data slots with live
  links, descriptions or pins cannot be reused. Alias entry refs survive FD-based
  exec even when unlinked before exec and the public CLOEXEC descriptor closes.
  Failed creation and unsupported source types preserve names and link counts.
- **Scope reconciliation:** donor overlay_entry/read_overlay and hardlink export
  joins have no consumer in this base; retain their disposition for G19/G22 rather
  than adding unused APIs. G14 cwd and G12 mapping interactions still require F02.
- **Blocking for publication:** shared mutable arguments, adversarial namespace/
  FD authority, protected copy and low-level executable identity need the
  [DaybreakBlue handoff](daybreakblue-handoff.md). Ordinary API/runtime results do
  not establish confinement or eliminate the inherited G07 security hold.

## Exact evidence

Both source and strict clean prerequisite-plus-patch export pass `make check
 test-unit build build-launch-script-fixture build-launch-owned-exec-fixture
 build-launch-directory-fixture build-launch-storage-fixture`:98 units,40 VFS,
177 matching tracked paths. All four fixture bytes and Ginux binaries match.
Clean apply uses git apply --whitespace=error. Unit/CI defaults are retained;
new hardlink modes are registered in existing harness defaults.

Selected ordinary runtime groups pass in both exports: hardlink metadata/bytes,
same-inode rename, unlink/open lifetime, relative linkat and shared chmod; quota
alias creation with a12 MiB file and last-descriptor reclamation; two hardlinked
ELF scenarios (path and unlinked FD); six existing ELF modes;16 script modes;
ordinary symlink, growth/bounds/quota and directory functional/native-cwd controls.
The directory harness runs each selected mode twice. Exact G13 rejects link86
with ENOSYS(-38), producing workload131 on the same new valid-hardlink fixture.

Donor executable-name failure and pre-fix overlay count failure, corrections,
commands and receipts are retained separately. The initial adaptation's accidental
recursive remove_name failed static validation, was corrected immediately, and its
log is retained; no warning was suppressed. Supplemental donor-name comparison is
not included in the98 unit count. Full default runtime/security cases, independent
review, macOS Actions/remote CI and refreshed upstream independence are unrun.
Linux-local success is not green remote CI.

Exact patch, draft, manifest, fixture hashes, reproduction helpers and logs are
retained under .artifacts/ginux-contribution-preparation/G15/. Intermediate helper
steps are not the final source; candidate.patch and manifest identify the final
revision. No branch, real checkout/index, remote, PR text or maintainer message
changed. F04 user inspection continues to precede publication.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G15');row.update(m);row.update(evidence='g15-review.md',source_patch='patches/G15.patch');p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''

### G15 exact retained revision

Candidate {m['head']} on G13 {m['base']} has98 passing routine units and
selected ordinary alias/quota/ELF/script/storage checks in source and clean replay.
[Review/evidence](g15-review.md) records name-versus-data identity, final-close
reclamation and ordinary donor regression comparisons. Adversarial namespace,
FD/private backing, protected copy, shared arguments and low-level executable-name
validation remain pending. No cloud agent was dispatched and no security
acceptance is claimed. G14 cwd/G12 mappings still need the later combined review.
''')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text();a=s.index('Exact next task: **G15');b=s.index('\nActive skill:',a)
s=s[:a]+f'''G15 source/ordinary preparation is retained at `{m['head'][:8]}` directly on
G13{m['base'][:8]}. [Review/evidence](ginux-contributions/g15-review.md) records98
units,177-path strict replay, shared hardlink metadata/bytes, alias executable
identity and final-descriptor quota reclamation, plus script/ELF/storage/directory
controls passing in source/clean exports. Donor executable-name and initial file-
count regressions are reproduced and corrected. Exact G13 rejects the valid-link
fixture. G19/G22 export joins and G14/G12 interactions remain explicitly assigned;
security/full CI/upstream prerequisites remain pending. Nothing was published.

Exact next task: **G16 — unified image/owned traversal**. Inspect1da0ce13 and
93a1a56d against existing G03c/G13 walker and G14 cwd owners. Extract on the
smallest proven capability base; exclude accidental G15/G12/G07 ancestry unless a
real consumer requires it. Preserve link-before-parent semantics, assignment
precedence, executable/script identity, native rewrites and hidden /dev behavior.
Perform ordinary cross-boundary path/parent/exec checks; record exploit-like
namespace, authority, race and protected-buffer probes for DaybreakBlue. Keep all
inherited security and standalone prerequisites pending; no publication before F04.
''' +s[b:];p.write_text(s)
print('Retained G15',m['head'])
