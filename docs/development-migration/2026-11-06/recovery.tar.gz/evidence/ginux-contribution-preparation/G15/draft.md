Share owned regular-file identity across hardlink names

Implement link/linkat for owned regular files. Aliases share bytes, permissions,
inode and link counts without duplicating backing capacity. Open descriptions
and executable pins retain the invoked name through rename or deletion; final
unlink and close release backing capacity.

Local validation:98 units and selected hardlink/quota/ELF/script/storage scenarios
pass in source and clean replay. Full security coverage, remote CI and prerequisite
merges remain pending; not ready to submit.
