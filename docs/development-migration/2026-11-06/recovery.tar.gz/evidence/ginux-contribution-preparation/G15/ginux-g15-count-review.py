from pathlib import Path
import subprocess,os,json
root=Path('/tmp/ginux-contribution-preparation/G15');src=root/'source';p=src/'crates/ginux-vfs/src/lib.rs';s=p.read_text();a=s.index('    fn hardlinks_share_identity_and_preserve_pinned_bytes_at_capacity(');b=s.index('    #[test]',a);part=s[a:b].replace('        fs.unlink(b"/one").unwrap();','        fs.unlink(b"/one").unwrap();\n        assert_eq!(fs.overlay_files(), 1);',1);s=s[:a]+part+s[b:];p.write_text(s)
cmd=['cargo','test','-p','ginux-vfs','hardlinks_share_identity_and_preserve_pinned_bytes_at_capacity'];env={**os.environ,'RUSTFLAGS':'','CARGO_TARGET_DIR':str(root/'review-unit-target')}
with (root/'review-before-name-count-fix.log').open('w') as log:before=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
assert before.returncode==101
old='self.overlay.iter().filter(|entry| entry.state == 1).count()';assert old in s;s=s.replace(old,'self.overlay.iter().filter(|entry| matches!(entry.state, 1 | 5)).count()',1);p.write_text(s)
with (root/'review-after-name-count-fix.log').open('w') as log:after=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
assert after.returncode==0;(root/'review-name-count-receipt.json').write_text(json.dumps({'before':before.returncode,'after':after.returncode},indent=2)+'\n');print('remaining alias count: before101, after0')
