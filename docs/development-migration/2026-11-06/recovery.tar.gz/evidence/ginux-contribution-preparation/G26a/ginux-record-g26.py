from pathlib import Path
import json,hashlib,shutil,re
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';assert not (docs/'g26-review.md').exists();heads={};records={}
for packet,units,vfs,paths in [('G26a',65,12,None),('G26b',82,24,168)]:
 temp=Path('/tmp/ginux-contribution-preparation')/packet;art=root/'.artifacts/ginux-contribution-preparation'/packet;m=json.loads((temp/'manifest.json').read_text());stat=[json.loads((temp/(p+'static-receipt.json')).read_text()) for p in ['final-','clean-']];assert all(x['exit_code']==0 and x['head']==m['head'] for x in stat);assert stat[0]['binary_sha256']==stat[1]['binary_sha256'] and stat[0]['fixture_sha256']==stat[1]['fixture_sha256'];paths=stat[0]['matched_paths'];assert paths==stat[1]['matched_paths'];assert sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', (temp/'clean-static-build.log').read_text()))==units
 for prefix in ['', 'clean-']:
  receipt=json.loads((temp/(prefix+'functional-receipt.json')).read_text());receipt=[receipt] if isinstance(receipt,dict) else receipt;assert all(x['exit_code']==0 for x in receipt)
 baseline=json.loads((temp/'baseline-functional-receipt.json').read_text());assert baseline.get('workload_exit_code',baseline['exit_code'])==(160 if packet=='G26a' else 207)
 m.update(status='ordinary source/clean preparation and separate self-review retained; G26 full task partial: thread join/security, policy/full CI/fresh upstream acceptance pending',unit_tests=units,vfs_tests=vfs,clean_matched_paths=paths,review='separate whole-diff self-review; no independent reviewer or security acceptance',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=stat[0]['binary_sha256'],clean_binary_sha256=stat[1]['binary_sha256'],fixture_sha256=stat[0]['fixture_sha256'],evidence='g26-review.md',source_patch='patches/'+packet+'.patch')
 if packet=='G26a':m['affinity_evidence']='same bootstrap function checked byte-identical in G26b; exact subset and fork/exec pass in that task-aware composition; public query stays denied on main'
 else:m['thread_join_finding']='Nonleader query of own TGID must resolve the registered leader host before G07 thread composition; this candidate has only process tasks where pid==tgid'
 (temp/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
 for p in temp.iterdir():
  if p.is_file() and p.suffix in ['.json','.log','.patch','.diff','.txt']:shutil.copyfile(p,art/p.name)
 for p in Path('/tmp').glob('ginux-*g26*.py'):shutil.copyfile(p,art/p.name)
 shutil.copyfile(temp/'candidate.patch',docs/'patches'/f'{packet}.patch');heads[packet]=m['head'];records[packet]=m
 (art/'draft.md').write_text(('''Apply configured process bounds before launch exec

Install child-only hard/soft RLIMIT_AS without raising operator limits and
select at most the configured eligible CPUs from the inherited affinity mask.
Document per-process virtual address space and eligible CPUs, without claiming
aggregate RSS or CPU-time enforcement. Keep workload affinity policy unchanged.

Local static/build checks and 65 units pass in source and clean main-plus-patch
replay, as do configured and lower operator AS-limit checks. Exact affinity and
fork/exec checks pass in a separate task-aware local composition. Security,
public-contract review and full runtime/remote CI remain pending.
Not ready to submit.
''' if packet=='G26a' else '''Expose task-owned affinity queries and retain configured process bounds

Resolve self affinity queries through registered virtual task identity and copy
the bounded kernel mask through existing strict tracee I/O. Deny affinity and
address-space-limit mutation, and cover inherited AS/CPU bounds across fork/exec.

Local static/build checks and 82 units pass in source and clean prerequisite
replay, as do ordinary exact CPU-subset, AS and process lifecycle checks.
Thread integration, security, public-contract review, prerequisite merges and
full runtime/remote CI remain pending. Not ready to submit.
'''))
 assert not any(x in (art/'draft.md').read_text() for x in ['LevitateOS','Recipe','Daybreak'])
a=records['G26a'];b=records['G26b'];(docs/'g26-review.md').write_text(f'''# G26 — inherited process resource bounds (partial)

Two source packets are retained from0c571cbb. They are work units, not a promise
of two PRs. Public metadata-to-enforcement policy, thread/security acceptance,
full CI and refreshed upstream disposition remain pending.

| Packet | Exact head | Base | Patch |
| --- | --- | --- | --- |
| G26a bootstrap | `{a['head']}` | main `{a['base']}` | [5 files,+103/-7](patches/G26a.patch) |
| G26b task queries/guards | `{b['head']}` | G06b/G26a composition `{b['base']}` | [5 files,+116/-6](patches/G26b.patch) |

G26a applies checked memory_mib-to-bytes conversion, then child-only hard/soft
RLIMIT_AS=min(configured bytes, inherited soft, inherited hard). It selects at
most vcpus logical CPUs from the launcher's inherited affinity mask before exec.
The1024-byte bootstrap mask supports CPU IDs within8192 bits; unavailable bounds
fail bootstrap explicitly. Configuration already validates1–64 vcpus and16–1048576
MiB, without changing schema. This bounds per-process virtual AS and eligible
CPUs, not aggregate RSS, aggregate storage or CPU time. Parent/global policy is
unchanged. Existing core policy still denies workload affinity syscalls on main.

G26b uses the existing registered process task and strict copy_memory owner for
self sched_getaffinity queries (zero, virtual PID/TGID), bounded to1024 bytes.
Affinity mutation returns EPERM; existing public-FD prlimit mutation guards also
cover RLIMIT_AS. It introduces no host PID/FD assignment, generic scheduler,
thread ownership or new core syscall rules. Kernel inheritance, rather than
extra bookkeeping, retains the bounds through supported process fork/exec.

Separate full-diff self-review inspected both patches and current config bounds,
bootstrap failure/privilege/FD ordering, native prlimit rules, registered task
identity, query copyout, fork/exec/death, descriptor guards, fixtures, docs and
CI callers. This is self-review, not independent or adversarial review.

- **Arithmetic correction:** donor's unchecked memory-size multiplication now
  uses checked conversion/multiplication even though current config bounds fit
  the x86-64 representation. Invalid/hostile boundary probes were not executed.
- **Minimal split:** bootstrap needs no unmerged process/thread/storage packet;
  task-aware queries use G06b. G26b's local composition preserves subreaper,
  private descriptor reservation, existing CLOEXEC-stdin setup and all prior
  launch fixtures. Plain patch-check conflicts were recorded, then these owners
  were reconciled explicitly; no failed partial patch was applied.
- **Required thread join:** donor queries always use the calling task's host ID.
  That is correct here, where each supported process has PID==TGID. A future
  G07 nonleader query of its TGID must resolve the registered leader's host ID;
  mark that interaction unresolved at F02 rather than claiming thread acceptance.
- **Contract review still required:** prior resource metadata now enforces AS and
  CPU eligibility. No maintainer consent or fresh policy resolution is inferred.
  G26a permits the existing native prlimit behavior under its hard bound; G26b
  adds the explicit AS-mutation denial. State the distinction when delivering.

Source and strict clean replay pass make check test-unit build and existing
launch/task fixture builds: G26a65 units/{a['clean_matched_paths']} matching tracked paths;
G26b82 units/168 paths. Respective Ginux and fixture hashes match. Ordinary checks
in both copies demonstrate32 MiB AS, lower24 MiB operator limit,64 MiB virtual
reservation refusal, successful1 MiB mapping touching only two pages, and brk
refusal without host pressure. The task-aware composition verifies exact masks:
operator CPUs[0,1], configured1 gives[0], configured3 retains[0,1], including self
queries by zero/virtual PID, fork and exec. The bootstrap helper's source bytes
are checked identical between G26a and G26b. Host runner limit/affinity stays
unchanged. Ten existing ordinary process lifecycle/control modes also pass.

Fresh exact main lacks the AS cap and the final fixture exits160. Exact G06b/G26a
composition installs bounds but lacks self affinity queries and exits207. Receipts
include exact base/binary hashes. Existing Make/workflow invocations already run
the new launch/task cases with all old default scenarios; no coverage is removed.
The first G26a build command ran from /tmp and failed without changing source;
correct-cwd builds above are the actual evidence, not that failed attempt.

[DaybreakBlue](daybreakblue-handoff.md) owns mutation/bypass/authority, invalid or
protected/mutable buffers, syscall/CPU-ID boundaries, hostile exhaustion, CPU
hotplug/reconfiguration, failures and races. Those probes and cloud dispatch are
unrun. Full/default Linux runtime, macOS/remote CI, independent review, G07 thread
and final combined consumer/F02/F03 acceptance are pending. G26b is not standalone
until its actual prerequisites merge. G26a source applies alone to recorded main,
but fresh main/public contract/security/full CI still prevent ready-to-submit claims.

Retained patches, generic drafts, command/log receipts, exact SHAs/hashes and
helpers live in .artifacts/ginux-contribution-preparation/G26a/ and G26b/.
G26b retains its full prerequisite reconstruction patch. No Ginux real checkout,
index, branch/ref or remote text changed; no PR or maintainer message was sent.
Publication stops at F04 for user inspection.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G26');row.update(status='split source/ordinary preparation retained; full G26 partial: G07/security, resource contract/full CI/upstream independence pending',subpackets=['G26a','G26b'],evidence='g26-review.md',source_disposition={'bootstrap':'G26a standalone source on recorded main','affinity_and_AS_mutation_guard':'G26b on G06b/G26a','thread_group_target_resolution':'required G07/F02 join; unresolved'})
for packet in ['G26a','G26b']:
 assert not any(x['packet']==packet for x in plan['packets']);record=records[packet];record.update(purpose='Child-only bootstrap AS/CPU bounds' if packet=='G26a' else 'Task-owned self affinity and AS mutation guard',source_commits=['0c571cbbc36756c55af051cd07f513dd2b9228af'],artifact_directory='.artifacts/ginux-contribution-preparation/'+packet,acceptance='G26 original criteria; see g26-review.md for split evidence and still-pending acceptance');plan['packets'].append(record)
p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'p04-dependencies.md';p.write_text(p.read_text()+f'''\nG26 split: G26a `{a['head'][:8]}` has only recorded main as parent and installs
child-only AS/CPU bounds; G26b `{b['head'][:8]}` requires the G06b process owner
and G26a, composed at `{b['base'][:8]}` without G07. Ordinary AS and exact CPU
subsets/fork/exec pass; thread-group affinity target resolution (calling nonleader
versus requested TGID leader), resource policy, security and full CI remain
unresolved. Bootstrap helper bytes match across both exports. No generic resource
framework or aggregate RSS/time semantics are introduced; [review](g26-review.md).
''')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\n## G26 — inherited AS/CPU bounds and task queries (partial)

Exact G26a `{a['head']}` on recorded main; G26b `{b['head']}` on
G06b/G26a composition `{b['base']}`. Ordinary source/clean AS bounds,
lower operator limit, exact eligible CPU subsets and fork/exec inheritance pass.
No host-pressure stress: over-limit requests reserve virtual space only and
successful1 MiB mappings touch two pages. Existing default coverage is preserved.

DaybreakBlue must validate resource/affinity mutation and bypass, unsupported or
foreign identities/CPU IDs, oversized/invalid/protected/mutable query buffers,
partial copyout, AS arithmetic/limits, hostile memory/process exhaustion,
bootstrap syscall failures, CPU hotplug/reconfiguration, stop/death/exec races
and thread-group target selection. Known F02 join: a nonleader requesting its
own TGID must resolve the registered leader host, not always the caller. Current
G26b is process-only (PID==TGID); do not imply G07 acceptance. No adversarial
probes or cloud dispatch occurred. Public resource contract, full CI and combined
consumer evidence remain pending; [review/evidence](g26-review.md).
''')
p=root/'docs/ginux-contribution-task-list.md';t=p.read_text();a0=t.index('Exact next task: **G26');z=t.index('\nActive skill:',a0);t=t[:a0]+f'''G26 is split into source packets G26a `{a['head'][:8]}` on recorded main and G26b
`{b['head'][:8]}` on G06b/G26a composition `{b['base'][:8]}`.
[Review/evidence](ginux-contributions/g26-review.md) records65/82 units and strict
clean replay, configured/lower-operator AS limits, exact operator CPU subsets and
process fork/exec inheritance plus ordinary lifecycle controls passing. Kernel
limits are per-process AS/eligible CPUs, not aggregate RSS or CPU time. Existing
bootstrap/descriptor/CLOEXEC owners and full default coverage are preserved.
Full G26 remains partial: resource contract, G07 nonleader/TGID target join,
security/full CI and fresh upstream independence are pending; no publication.

Exact next task: **G27 — configured virtual platform identity**.
Inspect9cf265ba against current identity/config/ABI owners. Distinguish virtual
uname from sysinfo (#219), preserve existing defaults and avoid downstream policy
in upstream code. Verify ordinary raw ABI and actual RPM when consumer capabilities
permit; keep invalid/oversized inputs and authority probes with DaybreakBlue.
Preserve all pending G23–G26/F02/F03 acceptance. No publication or maintainer messages before F04.
''' +t[z:];p.write_text(t)
print('saved G26a',heads['G26a'],'and G26b',heads['G26b'])
