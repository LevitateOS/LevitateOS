from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G26a');src=root/'source';base=json.loads((root/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['README.md','config/domain-gate5.toml','crates/ginux-init/src/launch.rs','scripts/test-launch.py','tests/fixtures/launch-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g26a-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(src/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',base,input=('feat(init): apply configured process bounds before launch exec\n\nSet child-only address-space hard/soft limits without raising lower operator\nlimits and select eligible CPUs within the inherited affinity mask.\nDocument per-process virtual memory and CPU eligibility rather than aggregate\nRSS or CPU time, and retain existing workload affinity syscall policy.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert not any(x in patch for x in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in git('ls-tree','-r','--name-only',base).decode().splitlines():
 if name in files:continue
 p=src/name;assert (os.readlink(p).encode() if p.is_symlink() else p.read_bytes())==git('show',base+':'+name),name
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G26a','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':[],'standalone_source':True,'status':'bootstrap source/ordinary AS checks pass; clean replay/affinity/inheritance/security/policy/full CI pending','patch_sha256':hashlib.sha256(patch).hexdigest(),'deferred_joins':['G26b affinity queries/resource mutation in task owner','G06/G07 fork/exec/thread inheritance'],'policy':'metadata-to-enforcement contract requires upstream review; no consent inferred'};(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
