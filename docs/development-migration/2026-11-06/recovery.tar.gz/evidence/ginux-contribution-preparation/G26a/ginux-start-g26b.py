from pathlib import Path
import subprocess,tarfile,io,json
r=Path('/tmp/ginux-contribution-preparation/G26b');r.mkdir(exist_ok=True);s=r/'source';assert not s.exists();s.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';process='8c783e717b839b0e511820e89d29840cae0f3c0c';bootstrap=json.loads(Path('/tmp/ginux-contribution-preparation/G26a/manifest.json').read_text())['head']
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',process))) as t:t.extractall(s,filter='data')
patch=Path('/tmp/ginux-contribution-preparation/G26a/candidate.patch');p=subprocess.run(['git','apply','--check',str(patch)],cwd=s,capture_output=True);(r/'bootstrap-composition-apply.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,p.stderr.decode();subprocess.run(['git','apply','--whitespace=error',str(patch)],cwd=s,check=True)
(r/'composition-inputs.json').write_text(json.dumps({'process_base':process,'bootstrap':bootstrap,'dependencies':['G06b','G26a'],'source':'0c571cbbc36756c55af051cd07f513dd2b9228af','excluded':['G07 threads/argument races','all storage/mapping/archive/clock/network capability extensions']},indent=2)+'\n')
print('G26a applies cleanly to G06b; source composition ready to retain')
