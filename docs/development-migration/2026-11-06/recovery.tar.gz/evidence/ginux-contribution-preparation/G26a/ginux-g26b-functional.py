from pathlib import Path
import subprocess,json,tempfile,shutil,os,hashlib
r=Path('/tmp/ginux-contribution-preparation/G26b')
for directory,prefix in [('source',''),('verified-head','clean-')]:
 s=r/directory;commands=[['sudo','-n','python3','scripts/test-launch-tasks.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-task-fixture','ordinary-resources'],['sudo','-n','python3','scripts/test-launch.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-fixture','ordinary-resources']];receipts=[]
 for i,cmd in enumerate(commands):
  with (r/f'{prefix}functional-{i}.log').open('w') as f:p=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
  receipts.append({'command':cmd,'exit_code':p.returncode});(r/(prefix+'functional-receipt.json')).write_text(json.dumps(receipts,indent=2)+'\n');print(directory,i,p.returncode,flush=True);assert p.returncode==0
s=r/'source';base=r/'base/target/x86_64-unknown-linux-gnu/release/ginux'
with tempfile.TemporaryDirectory(prefix='ginux-resource-query-baseline-') as name:
 w=Path(name);root=w/'root';(root/'bin').mkdir(parents=True);(root/'work').mkdir();shutil.copyfile(s/'.artifacts/launch/launch-task-fixture',root/'bin/fixture');(root/'bin/fixture').chmod(0o755)
 config=(s/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/fixture"').replace('args = []','args = '+json.dumps(['Resources',str(min(os.sched_getaffinity(0)))])).replace('memory_mib = 256','memory_mib = 32');path=w/'config.toml';path.write_text(config);result=w/'result.json';cmd=[str(base),'launch',str(path),str(root),'--result-file',str(result)];p=subprocess.run(cmd,capture_output=True,timeout=20);record=json.loads(result.read_text());(r/'baseline-functional.log').write_bytes(p.stderr);assert p.returncode==207 and record['code']==207 and record['outcome']=='exited',(p.returncode,record)
 (r/'baseline-functional-receipt.json').write_text(json.dumps({'command':cmd,'base':json.loads((r/'manifest.json').read_text())['base'],'exit_code':p.returncode,'binary_sha256':hashlib.sha256(base.read_bytes()).hexdigest()},indent=2)+'\n')
a=Path('/tmp/ginux-contribution-preparation/G26a/source/crates/ginux-init/src/launch.rs').read_text();b=(s/'crates/ginux-init/src/launch.rs').read_text()
def function(t):return t[t.index('fn restrict_tracee_resources('):t.index('fn launch_tracee(')]
assert function(a)==function(b);(r/'bootstrap-equivalence.json').write_text(json.dumps({'G26a':json.loads(Path('/tmp/ginux-contribution-preparation/G26a/manifest.json').read_text())['head'],'G26b':json.loads((r/'manifest.json').read_text())['head'],'restrict_tracee_resources':'identical source bytes','sha256':hashlib.sha256(function(a).encode()).hexdigest()},indent=2)+'\n');print('baseline composition has bounds but lacks affinity query; fixture exits207',flush=True)
