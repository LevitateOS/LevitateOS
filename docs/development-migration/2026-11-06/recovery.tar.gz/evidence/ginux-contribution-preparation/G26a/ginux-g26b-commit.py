from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G26b');src=root/'source';base=json.loads((root/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['README.md','crates/ginux-init/src/launch_tasks.rs','crates/ginux-init/src/descriptors.rs','scripts/test-launch-tasks.py','tests/fixtures/launch-task-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g26b-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(src/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',base,input=('feat(init): expose task-owned affinity and preserve process bounds\n\nTranslate self affinity queries through the registered virtual task identity\nand copy only the bounded kernel mask to the tracee. Deny affinity and\naddress-space limit mutation and verify process-bound inheritance across fork\nand exec within the operator CPU subset.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert not any(x in patch for x in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in git('ls-tree','-r','--name-only',base).decode().splitlines():
 if name in files:continue
 p=src/name;assert (os.readlink(p).encode() if p.is_symlink() else p.read_bytes())==git('show',base+':'+name),name
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G26b','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':['G06b','G26a'],'standalone':False,'status':'ordinary source checks pass; separate review/clean replay pending; G07/security/policy/full CI held','patch_sha256':hashlib.sha256(patch).hexdigest(),'deferred_joins':['G07 nonleader/thread-group affinity target and shared-argument security'],'policy':'metadata-to-enforcement and affinity public contract need upstream review'};(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
