from pathlib import Path
import subprocess,tarfile,io,json
r=Path('/tmp/ginux-contribution-preparation/G26a');r.mkdir(exist_ok=True);s=r/'source';assert not s.exists();s.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='3f2fe7dfadd4b40e235d982a6a3d386dc6490177'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a]).decode()
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',repo,'archive',base]))) as t:t.extractall(s,filter='data')
(r/'composition.json').write_text(json.dumps({'base':base,'dependencies':[],'source':['0c571cbbc36756c55af051cd07f513dd2b9228af'],'deferred_joins':['G26b virtual-PID affinity query/resource mutation owner','G06/G07 ordinary fork/exec/thread inheritance'],'policy':'metadata-to-enforcement contract requires upstream review; no upstream consent claimed'},indent=2)+'\n')
p=s/'crates/ginux-init/src/launch.rs';t=p.read_text().replace('launch_tracee(root_path);','launch_tracee(root_path, &config);');donor=git('show','0c571cbb:crates/ginux-init/src/launch.rs');a=donor.index('// Limits apply only to this child');b=donor.index('fn launch_tracee(',a);fn=donor[a:b];fn=fn.replace('let bound = (config.memory_mib as usize * 1024 * 1024)\n        .min(limits[0])\n        .min(limits[1]);', '''let Some(bytes) = usize::try_from(config.memory_mib)
        .ok()
        .and_then(|mib| mib.checked_mul(1024 * 1024))
    else {
        return false;
    };
    let bound = bytes.min(limits[0]).min(limits[1]);''');t=t.replace('fn launch_tracee(root_path: *const u8) -> ! {',fn+'fn launch_tracee(root_path: *const u8, config: &DomainConfig) -> ! {');t=t.replace('    static ROOT: &[u8] = b"/\\0";', '''    static ROOT: &[u8] = b"/\\0";
    if !restrict_tracee_resources(config) {
        tracee_setup_fail(
            b"ginux: launch bootstrap failed: resource bounds unavailable\\n",
            132,
        );
    }''');p.write_text(t)
p=s/'README.md';t=p.read_text();old='notice. This path does not implement resource quotas from the domain metadata.';assert old in t;t=t.replace(old,'''notice. `[resources].memory_mib` caps each tracee process's virtual address space
with hard/soft `RLIMIT_AS`, preserving lower operator limits. This includes
anonymous and image mappings; it is not an aggregate domain RSS limit.
`[resources].vcpus` restricts the child to at most that many logical CPUs selected
from the launcher's allowed affinity mask. This bounds eligible CPUs, not CPU
time. Limits are installed only in the child before exec; no host-global cgroup
policy is changed. Kernel inheritance preserves them for supported descendants.
CPU affinity syscalls retain the existing default-denied policy.''');p.write_text(t)
p=s/'config/domain-gate5.toml';t=p.read_text().replace('vcpus = 1','# Maximum eligible logical CPUs within the operator affinity mask.\nvcpus = 1').replace('memory_mib = 256','# Per-process virtual address-space bound, not aggregate RSS.\nmemory_mib = 256');p.write_text(t)
p=s/'tests/fixtures/launch-fixture.c';t=p.read_text();a=t.index('/* Signal return');helper='''static long call6(long n, word a, word b, word c, word d, word e, word f)
{
    register word r10 __asm__("r10") = d;
    register word r8 __asm__("r8") = e;
    register word r9 __asm__("r9") = f;
    long result;
    __asm__ volatile("syscall" : "=a"(result) : "a"(n), "D"(a), "S"(b), "d"(c),
                     "r"(r10), "r"(r8), "r"(r9) : "rcx", "r11", "memory");
    return result;
}

''';t=t[:a]+helper+t[a:];idx=t.index("    case 'e':");body='''    case 'r': {
        word limits[2];
        word expected=(argc>2 ? number(argv[2]) : 32)*1024*1024;
        if(call4(302,0,9,0,(word)limits)!=0 || limits[0]!=expected || limits[1]!=expected) return 160;
        /* Reserve virtual space only; no host memory pressure is generated. */
        if(call6(9,0,64*1024*1024,3,0x22,-1,0)!=-12) return 161;
        long memory=call6(9,0,1024*1024,3,0x22,-1,0);
        if(memory<=0) return 162;
        ((volatile char *)memory)[0]=1;
        ((volatile char *)memory)[1024*1024-1]=2;
        if(call3(11,memory,1024*1024,0)!=0) return 163;
        long previous=call3(12,0,0,0);
        if(previous<=0 || call3(12,previous+64*1024*1024,0,0)!=previous) return 164;
        print("process-address-space: PASS");
        return 0;
    }
''';t=t[:idx]+body+t[idx:];p.write_text(t)
p=s/'scripts/test-launch.py';t=p.read_text().replace('if len(sys.argv) != 3','if len(sys.argv) < 3').replace('for arg in sys.argv[1:])','for arg in sys.argv[1:3])');idx=t.index('        for code in (0, 3, 120, 127, 128, 255):');t=t[:idx]+'''        def resource_cases():
            invoke(["resources", "32"], 0, "exited", stdout=b"process-address-space: PASS\\n",
                   changes={"memory_mib = 256": "memory_mib = 32"})
            original = resource.getrlimit(resource.RLIMIT_AS)
            try:
                # Change only this test runner's soft limit temporarily; the
                # launcher child installs it as both soft/hard limits.
                resource.setrlimit(resource.RLIMIT_AS, (24*1024*1024, original[1]))
                invoke(["resources", "24"], 0, "exited", stdout=b"process-address-space: PASS\\n",
                       changes={"memory_mib = 256": "memory_mib = 32"})
            finally:
                resource.setrlimit(resource.RLIMIT_AS, original)
            assert resource.getrlimit(resource.RLIMIT_AS) == original
        if sys.argv[3:]:
            if sys.argv[3:] != ['ordinary-resources']:
                sys.exit('unknown selected launch scenario')
            resource_cases()
            return
        resource_cases()
''' +t[idx:];p.write_text(t)
print('G26a exported and adapted on main')
