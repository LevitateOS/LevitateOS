from pathlib import Path
import subprocess,tarfile,io,json
r=Path('/tmp/ginux-contribution-preparation/G26b');s=r/'source';repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base=json.loads((r/'composition.json').read_text())['base']
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
b=r/'base';assert not b.exists();b.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(b,filter='data')
p=s/'crates/ginux-init/src/launch_tasks.rs';t=p.read_text();donor=git('show','0c571cbb:crates/ginux-init/src/launch_tasks.rs').decode();a=donor.index('            203 => {');z=donor.index('            89 | 267 => {',a);body=donor[a:z];needle='        let id = self.task(index).id;\n        match r.orig_rax {';assert needle in t;t=t.replace(needle,needle+'\n'+body,1);p.write_text(t)
p=s/'crates/ginux-init/src/descriptors.rs';t=p.read_text();old='if r.orig_rax == 302 && r.rsi == 7 && r.rdx != 0 {';assert old in t;t=t.replace(old,'if r.orig_rax == 302 && matches!(r.rsi, 7 | 9) && r.rdx != 0 {').replace('// Resource changes cannot silently invalidate the public allocator.','// Resource changes cannot invalidate the public allocator or address-space bound.');p.write_text(t)
p=s/'README.md';t=p.read_text().replace('CPU affinity syscalls retain the existing default-denied policy.','Self affinity queries (zero, current virtual PID or thread-group ID) report the\nactual eligible CPU subset. Affinity mutation and address-space limit mutation\nare denied; unrelated virtual PIDs are not native scheduler targets.');p.write_text(t)
p=s/'tests/fixtures/launch-task-fixture.c';t=p.read_text();idx=t.index('long task_main(');t=t[:idx]+'''static long ordinary_resources(word argc, char **argv) {
    const word mib=1024*1024;
    long self=argc>3 ? 2 : 1;
    CHECK(argc>2 && DO(39,0,0,0)==self && DO(186,0,0,0)==self,200);
    word limits[2];
    CHECK(call(302,0,9,0,(word)limits,0,0)==0 && limits[0]==32*mib && limits[1]==limits[0],201);
    CHECK(call(9,0,64*mib,3,0x22,-1,0)==-12,202);
    long memory=call(9,0,mib,3,0x22,-1,0);CHECK(memory>0,203);
    ((volatile char *)memory)[0]=1;((volatile char *)memory)[mib-1]=2;
    CHECK(DO(11,memory,mib,0)==0,204);
    unsigned char expected[1024]={0},mask[1024]={0};
    const char *text=argv[2];
    while(*text) {
        word cpu=0;
        while(*text>='0' && *text<='9') cpu=cpu*10+(*text++-'0');
        CHECK(cpu<8192,205);expected[cpu/8]|=1<<(cpu%8);
        if(*text==',') ++text; else CHECK(*text==0,206);
    }
    for(word which=0;which<2;++which) {
        long size=DO(204,which ? self : 0,sizeof mask,mask);CHECK(size>0 && size<=1024,207);
        for(word i=0;i<sizeof mask;++i) CHECK(mask[i]==expected[i],208);
    }
    if(argc>3) return 0;
    long child=DO(57,0,0,0);CHECK(child>=0,209);
    if(child==0) {
        CHECK(call(302,0,9,0,(word)limits,0,0)==0 && limits[0]==32*mib && limits[1]==limits[0],210);
        long size=DO(204,2,sizeof mask,mask);CHECK(size>0 && size<=1024,211);
        for(word i=0;i<sizeof mask;++i) CHECK(mask[i]==expected[i],212);
        char *arguments[]={"/bin/fixture","Resources",argv[2],"exec",0};
        char *environment[]={0};
        DO(59,"/bin/fixture",arguments,environment);return 213;
    }
    int status=-1;CHECK(DO(61,child,&status,0)==child && status==0,214);
    DO(1,1,"owned-tasks: PASS\\n",18);
    return 0;
}
''' +t[idx:];t=t.replace("    char mode=argc>1 ? argv[1][0] : 'f';", "    char mode=argc>1 ? argv[1][0] : 'f';\n    if(mode=='R') return ordinary_resources(argc,argv);");p.write_text(t)
p=s/'scripts/test-launch-tasks.py';t=p.read_text().replace('if len(sys.argv) != 3','if len(sys.argv) < 3').replace('for p in sys.argv[1:]]','for p in sys.argv[1:3]]');old="        for mode in ('qfault', 'fork', 'vfork', 'clone', 'shared-vfork', 'libc-fork', 'junk-child-tid', 'protected-child-tid', 'x-child-tid', 'handler-return', 'inherit', 'kill', 'bound', 'orphan', 'adopted-zombie', 'rollback', 'inherit'):";assert old in t;replacement='''        original_affinity = os.sched_getaffinity(0)
        allowed = sorted(original_affinity)[:2]
        assert allowed
        scenarios = [(1, allowed[:1])]
        scenarios.append((3, allowed))
        for vcpus, expected_cpus in scenarios:
            path, result = work / f'resources-{vcpus}.toml', work / f'resources-{vcpus}.json'
            current = config.replace('memory_mib = 256', 'memory_mib = 32')
            current = current.replace('vcpus = 1', f'vcpus = {vcpus}')
            current = current.replace('args = []', 'args = ' + json.dumps(
                ['Resources', ','.join(str(cpu) for cpu in expected_cpus)]))
            path.write_text(current)
            def restrict_operator_cpus():
                os.sched_setaffinity(0, allowed)
            proc = subprocess.run([binary, 'launch', str(path), str(root), '--result-file', str(result)],
                                  capture_output=True, timeout=20, preexec_fn=restrict_operator_cpus)
            assert proc.returncode == 0, (proc.returncode, proc.stderr.decode())
            assert proc.stdout == b'owned-tasks: PASS\\n', proc.stdout
            assert json.loads(result.read_text()) == {'version': 1, 'outcome': 'exited',
                'code': 0, 'signal': None, 'generation': None}
            assert b'teardown tasks=0 owned-handles=0' in proc.stderr
            assert os.sched_getaffinity(0) == original_affinity
            print(f'PASS launch resources: vcpus={vcpus}, operator={allowed}, actual={expected_cpus}; fork/exec')
        ordinary = ('fork', 'vfork', 'clone', 'shared-vfork', 'libc-fork', 'handler-return',
                    'inherit', 'kill', 'orphan', 'adopted-zombie')
        if sys.argv[3:] and sys.argv[3:] != ['ordinary-resources']:
            sys.exit('unknown selected task scenario')
        modes = ordinary if sys.argv[3:] else ('qfault', 'fork', 'vfork', 'clone', 'shared-vfork', 'libc-fork', 'junk-child-tid', 'protected-child-tid', 'x-child-tid', 'handler-return', 'inherit', 'kill', 'bound', 'orphan', 'adopted-zombie', 'rollback', 'inherit')
        for mode in modes:''';t=t.replace(old,replacement);t=t.replace('        # No descendant may survive root death or a supervisor failure.',"        if sys.argv[3:]:\n            return\n        # No descendant may survive root death or a supervisor failure.");p.write_text(t)
print('G26b task-owned query, mutation guard and ordinary inheritance fixtures prepared')
