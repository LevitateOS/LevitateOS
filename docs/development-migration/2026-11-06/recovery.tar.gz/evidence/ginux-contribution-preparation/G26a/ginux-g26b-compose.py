from pathlib import Path
import subprocess,json,os,tempfile
r=Path('/tmp/ginux-contribution-preparation/G26b');s=r/'source';a=Path('/tmp/ginux-contribution-preparation/G26a/source');repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';process='8c783e717b839b0e511820e89d29840cae0f3c0c'
def git(*args,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*args],env=env,input=input)
for name in ['config/domain-gate5.toml','tests/fixtures/launch-fixture.c']:(s/name).write_bytes((a/name).read_bytes())
p=s/'README.md';t=p.read_text();at=(a/'README.md').read_text();text=at[at.index('notice. `[resources].memory_mib`'):at.index('\n\nWhen requested,')];assert 'notice. This path does not implement resource quotas from the domain metadata.' in t;t=t.replace('notice. This path does not implement resource quotas from the domain metadata.',text);p.write_text(t)
p=s/'crates/ginux-init/src/launch.rs';t=p.read_text().replace('launch_tracee(root_path);','launch_tracee(root_path, &config);');at=(a/'crates/ginux-init/src/launch.rs').read_text();body=at[at.index('// Limits apply only'):at.index('    // Host descriptors',at.index('// Limits apply only'))];old='fn launch_tracee(root_path: *const u8) -> ! {\n    static ROOT: &[u8] = b"/\\0";\n';assert old in t;t=t.replace(old,body);p.write_text(t)
p=s/'scripts/test-launch.py';t=p.read_text().replace('if len(sys.argv) != 3','if len(sys.argv) < 3').replace('for arg in sys.argv[1:])','for arg in sys.argv[1:3])').replace('cloexec_stdin=False):','cloexec_stdin=False, preexec=None):');idx=t.index('            proc = subprocess.run(');t=t[:idx]+'''            def prepare_child():
                if cloexec_stdin:
                    fcntl.fcntl(0, fcntl.F_SETFD, fcntl.FD_CLOEXEC)
                if preexec:
                    preexec()
''' +t[idx:];t=t.replace('preexec_fn=(lambda: fcntl.fcntl(0, fcntl.F_SETFD, fcntl.FD_CLOEXEC)) if cloexec_stdin else None)','preexec_fn=prepare_child if cloexec_stdin or preexec else None)');at=(a/'scripts/test-launch.py').read_text();body=at[at.index('        def resource_cases():'):at.index('        for code in (0, 3, 120, 127, 128, 255):')];idx=t.index('        for code in (0, 3, 120, 127, 128, 255):');t=t[:idx]+body+t[idx:];p.write_text(t)
files=['README.md','config/domain-gate5.toml','crates/ginux-init/src/launch.rs','scripts/test-launch.py','tests/fixtures/launch-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g26b-composition-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',process,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(s/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();base=git('commit-tree',tree,'-p',process,input=b'Local preparation: compose process ownership and bootstrap bounds\n').decode().strip()
git('diff','--check',process,base);(r/'prerequisite-composition.patch').write_bytes(git('diff','3f2fe7df',base));m={'base':base,'tree':tree,'process_base':process,'bootstrap':json.loads(Path('/tmp/ginux-contribution-preparation/G26a/manifest.json').read_text())['head'],'dependencies':['G06b','G26a'],'composition_adaptations':['Retain existing subreaper and public descriptor reservation in launch bootstrap','Retain CLOEXEC stdin preexec setup while supporting the lower operator-limit fixture'],'source':['0c571cbbc36756c55af051cd07f513dd2b9228af'],'deferred_joins':['G07 threads/argument races']};(r/'composition.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2))
