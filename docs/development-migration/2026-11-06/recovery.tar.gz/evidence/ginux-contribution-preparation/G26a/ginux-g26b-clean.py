from pathlib import Path
import subprocess,tarfile,io,json,os,hashlib,re
r=Path('/tmp/ginux-contribution-preparation/G26b');src=r/'source';dest=r/'verified-head';assert not dest.exists();dest.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';m=json.loads((r/'manifest.json').read_text())
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',m['base']))) as t:t.extractall(dest,filter='data')
subprocess.run(['git','apply','--whitespace=error',str(r/'candidate.patch')],cwd=dest,check=True)
names=git('ls-tree','-r','--name-only',m['head']).decode().splitlines()
for name in names:
 a=src/name;b=dest/name;assert a.is_symlink()==b.is_symlink(),name
 assert (os.readlink(a)==os.readlink(b) if a.is_symlink() else a.read_bytes()==b.read_bytes()),name
for path,prefix in [(src,'final-'),(dest,'clean-'),(r/'base','baseline-')]:
 cmd=['cargo','build','-p','ginux-init','--target','x86_64-unknown-linux-gnu','--release'] if prefix=='baseline-' else ['make','check','test-unit','build','build-launch-fixture','build-launch-task-fixture']
 with (r/(prefix+'static-build.log')).open('w') as log:p=subprocess.run(cmd,cwd=path,stdout=log,stderr=subprocess.STDOUT)
 receipt={'command':cmd,'exit_code':p.returncode,'matched_paths':len(names) if prefix!='baseline-' else None,'head':m['base'] if prefix=='baseline-' else m['head'],'binary_sha256':hashlib.sha256((path/'target/x86_64-unknown-linux-gnu/release/ginux').read_bytes()).hexdigest()}
 if prefix!='baseline-':receipt['fixture_sha256']={n:hashlib.sha256((path/'.artifacts/launch'/n).read_bytes()).hexdigest() for n in ['launch-fixture','launch-task-fixture']}
 (r/(prefix+'static-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(prefix,'static',p.returncode,'paths',len(names),flush=True);assert p.returncode==0
 if prefix!='baseline-':print('units',sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', (r/(prefix+'static-build.log')).read_text())),flush=True)
