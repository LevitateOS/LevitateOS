from pathlib import Path
import subprocess,json,hashlib
r=Path('/tmp/ginux-contribution-preparation/G26a')
for directory,prefix in [('source',''),('verified-head','clean-')]:
 s=r/directory;cmd=['sudo','-n','python3','scripts/test-launch.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-fixture','ordinary-resources']
 with (r/(prefix+'functional.log')).open('w') as f:p=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
 (r/(prefix+'functional-receipt.json')).write_text(json.dumps({'command':cmd,'exit_code':p.returncode},indent=2)+'\n');print(directory,p.returncode,flush=True);assert p.returncode==0
s=r/'source';base=r/'base/target/x86_64-unknown-linux-gnu/release/ginux';cmd=['sudo','-n','python3','scripts/test-launch.py',str(base),'.artifacts/launch/launch-fixture','ordinary-resources'];p=subprocess.run(cmd,cwd=s,capture_output=True);(r/'baseline-functional.log').write_bytes(p.stdout+p.stderr);assert p.returncode!=0 and b'exit=160' in p.stderr,p.stderr
(r/'baseline-functional-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':p.returncode,'base':'3f2fe7dfadd4b40e235d982a6a3d386dc6490177','workload_exit_code':160,'binary_sha256':hashlib.sha256(base.read_bytes()).hexdigest()},indent=2)+'\n');print('exact main lacks configured RLIMIT_AS; fixture exits160',flush=True)
