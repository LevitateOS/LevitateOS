Apply configured process bounds before launch exec

Install child-only hard/soft RLIMIT_AS without raising operator limits and
select at most the configured eligible CPUs from the inherited affinity mask.
Document per-process virtual address space and eligible CPUs, without claiming
aggregate RSS or CPU-time enforcement. Keep workload affinity policy unchanged.

Local static/build checks and 65 units pass in source and clean main-plus-patch
replay, as do configured and lower operator AS-limit checks. Exact affinity and
fork/exec checks pass in a separate task-aware local composition. Security,
public-contract review and full runtime/remote CI remain pending.
Not ready to submit.
