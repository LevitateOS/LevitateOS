Expose task-owned affinity queries and retain configured process bounds

Resolve self affinity queries through registered virtual task identity and copy
the bounded kernel mask through existing strict tracee I/O. Deny affinity and
address-space-limit mutation, and cover inherited AS/CPU bounds across fork/exec.

Local static/build checks and 82 units pass in source and clean prerequisite
replay, as do ordinary exact CPU-subset, AS and process lifecycle checks.
Thread integration, security, public-contract review, prerequisite merges and
full runtime/remote CI remain pending. Not ready to submit.
