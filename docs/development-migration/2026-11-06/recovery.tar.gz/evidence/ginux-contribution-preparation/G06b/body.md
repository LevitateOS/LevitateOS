Configured launch currently cannot run child commands. Add bounded fork/vfork, process-only clone, image exec and child waits using virtual identities and shared owned-object lifetimes. Register children before they run and drain descendants when init exits.

Commit close-on-exec changes only after successful exec. Preserve descriptor state on failure, reap children on wait-status faults without partial status writes, and validate kernel-selected interpreter paths against configured storage authority. Threads, generated executables and descriptor polling remain unsupported.

Static checks,82 unit tests and all applicable Linux launch/native/process/setup scenarios pass locally, including a clean patch replay and20 repeated child/exec runs. Existing unit and native-process coverage is retained; macOS CI is pending.
