from pathlib import Path
import tempfile,subprocess,json,shutil
source=Path('/tmp/ginux-contribution-preparation/G06b/source')
with tempfile.TemporaryDirectory(prefix='ginux-interpreter-probe-') as d:
 p=Path(d);root=p/'root';(root/'bin').mkdir(parents=True);(root/'work').mkdir()
 hidden=p/'hidden.S';hidden.write_text('.global _start\n_start:\nmov $77,%edi\nmov $60,%eax\nsyscall\nud2\n')
 subprocess.run(['cc','-nostdlib','-static',str(hidden),'-o',str(root/'work/hidden')],check=True)
 controller=p/'controller.c';controller.write_text('''static const char *args[]={"image-script",0};static const char *env[]={0};
void _start(void) {long result; __asm__ volatile("syscall":"=a"(result):"a"(59),"D"("/image-script"),"S"(args),"d"(env):"rcx","r11","memory");
__asm__ volatile("syscall"::"a"(60),"D"(result==-95?0:42):"rcx","r11","memory");__builtin_unreachable();}
''')
 subprocess.run(['cc','-nostdlib','-static','-fno-stack-protector','-fno-builtin','-O2',str(controller),'-o',str(root/'bin/controller')],check=True)
 (root/'image-script').write_text('#!/work/hidden\n');(root/'image-script').chmod(0o755)
 text=(source/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/controller"').replace('[storage]\nassignments = []','[storage]\nassignments = ["memory:/work"]')
 config=p/'launch.toml';config.write_text(text);result=p/'result.json'
 proc=subprocess.run([str(source/'target/x86_64-unknown-linux-gnu/release/ginux'),'launch',str(config),str(root),'--result-file',str(result)],capture_output=True,timeout=20)
 print('exit',proc.returncode,'record',result.read_text() if result.exists() else 'missing');print(proc.stderr.decode())
