from pathlib import Path
import tempfile,shutil,subprocess,json
source=Path('/tmp/ginux-contribution-preparation/G06b/source')
with tempfile.TemporaryDirectory(prefix='ginux-wait-fault-') as d:
 p=Path(d);root=p/'root';(root/'bin').mkdir(parents=True);(root/'work').mkdir()
 shutil.copyfile(source/'.artifacts/launch/launch-task-fixture',root/'bin/fixture');(root/'bin/fixture').chmod(0o755)
 config=(source/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/fixture"').replace('args = []','args = ["qfault"]')
 path=p/'launch.toml';path.write_text(config);result=p/'result.json'
 proc=subprocess.run([str(source/'target/x86_64-unknown-linux-gnu/release/ginux'),'launch',str(path),str(root),'--result-file',str(result)],capture_output=True,timeout=20)
 print('exit',proc.returncode,'result',result.read_text() if result.exists() else 'missing');print(proc.stderr.decode())
