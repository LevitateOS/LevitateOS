/* Freestanding workload for real configured-launch memory-storage checks. */
typedef unsigned long word;
static long call(long n, word a, word b, word c, word d, word e, word f)
{
    register word r10 __asm__("r10") = d;
    register word r8 __asm__("r8") = e;
    register word r9 __asm__("r9") = f;
    long result;
    __asm__ volatile("syscall" : "=a"(result) : "a"(n), "D"(a), "S"(b), "d"(c),
                     "r"(r10), "r"(r8), "r"(r9) : "rcx", "r11", "memory");
    return result;
}
#define DO(n,a,b,c) call(n,(word)(a),(word)(b),(word)(c),0,0,0)
#define CHECK(expr,code) if (!(expr)) return code
static char bytes[4096];
static unsigned long meta[32];
long storage_main(word *stack) {
    (void)stack;
    long child=DO(57,0,0,0); CHECK(child>=0,80);
    if(child==0){char *args[]={"/usr/bin/cpio","-i","--quiet",0};char *env[]={"LC_ALL=C",0};return DO(59,args[0],args,env)<0?81:82;}
    int status=-1; CHECK(DO(61,child,&status,0)==child && status==0,83);
    const char *names[]={"/work/file","/work/alias","/work/link"};word inode=0;
    for(word k=0;k<3;++k){
        long fd=DO(2,names[k],0,0);CHECK(fd>=3,84);
        CHECK(DO(5,fd,meta,0)==0 && ((unsigned *)meta)[7]==0 && ((unsigned *)meta)[8]==0,85);
        CHECK(meta[2]==2 && meta[6]==8229 && (((unsigned *)meta)[6]&0777)==0640,86);
        if(k==0)inode=meta[1];else CHECK(meta[1]==inode,87);
        word at=0;while(at<8229){long n=DO(0,fd,bytes,sizeof bytes);CHECK(n>0 && (word)n<=8229-at,88);for(long j=0;j<n;++j)CHECK((unsigned char)bytes[j]==(at+(word)j)%251,89);at+=n;}
        CHECK(DO(0,fd,bytes,1)==0 && DO(3,fd,0,0)==0,90);
    }
    CHECK(DO(6,"/work/link",meta,0)==0 && (((unsigned *)meta)[6]&0170000)==0120000,91);
    CHECK(((unsigned *)meta)[7]==0 && ((unsigned *)meta)[8]==0,92);
    return DO(1,1,"cpio-owned-root: PASS\n",22)==22?0:93;
}
__asm__(".global _start\n_start:\nmov %rsp,%rdi\nandq $-16,%rsp\ncall storage_main\nmov %rax,%rdi\nmov $60,%rax\nsyscall\nud2\n");
