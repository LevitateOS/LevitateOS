from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';r=Path('/tmp/ginux-contribution-preparation/G30');s=r/'source';base=json.loads((r/'composition.json').read_text())['base']
def git(*a,env=None,input=None):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a],env=env,input=input)
files=['README.md','crates/ginux-init/src/descriptors.rs','crates/ginux-init/src/fs_hooks.rs','scripts/test-launch-storage.py','tests/fixtures/launch-storage-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g30-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env)
 for name in files:
  blob=git('hash-object','-w','--stdin',input=(s/name).read_bytes()).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,name,env=env)
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip();head=git('commit-tree',tree,'-p',base,input=('feat(launch): preserve virtual root ownership on assigned storage\n\nHandle chown variants through existing inode, path and descriptor owners.\nAccept root or unchanged IDs on existing storage objects without issuing host\nownership calls, including no-follow and empty-path descriptor operations.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert not any(x in patch for x in [b'LevitateOS',b'Recipe',b'DaybreakBlue'])
for name in git('ls-tree','-r','--name-only',base).decode().splitlines():
 if name in files:continue
 p=s/name;assert (os.readlink(p).encode() if p.is_symlink() else p.read_bytes())==git('show',base+':'+name),name
(r/'candidate.patch').write_bytes(patch);(r/'candidate.diff').write_bytes(git('diff',base,head));m={'packet':'G30','base':base,'head':head,'tree':tree,'changed_files':files,'dependencies':['G15'],'standalone_source':False,'status':'source/ordinary cpio and metadata controls pass; exact clean replay/full diff review/security/full CI/upstream prerequisites pending','patch_sha256':hashlib.sha256(patch).hexdigest(),'deferred_joins':['G07 shared paths/FD calls security','G24/G25/F02 package pipeline, no runtime source dependency'],'policy':'virtual root-preserving storage operations only; arbitrary identity changes unsupported; no host chown forwarded'};(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
