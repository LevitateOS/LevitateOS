Preserve virtual root ownership on assigned storage

GNU cpio extraction reports ownership failures even when the archive requests
the storage inode's existing virtual root identity. Route chown variants through
the existing path/inode/descriptor owners, accepting0 or unchanged IDs without
forwarding host ownership calls. Include no-follow and empty-path dispatch.

Local check/unit/build and98 units pass in source and strict clean replay.
Ordinary metadata/storage cases and actual GNU cpio extraction preserve payload,
hardlink identity and symlink ownership. Full security/default runtime, remote CI
and prerequisite/current-main review remain pending. Not ready to submit.
