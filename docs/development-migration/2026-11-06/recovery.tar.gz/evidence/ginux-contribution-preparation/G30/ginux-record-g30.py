from pathlib import Path
import subprocess,json,shutil,hashlib
root=Path('/home/vince/Projects/LevitateOS');docs=root/'docs/ginux-contributions';r=Path('/tmp/ginux-contribution-preparation/G30');art=root/'.artifacts/ginux-contribution-preparation/G30';m=json.loads((r/'manifest.json').read_text());stats=[json.loads((r/(p+'static-receipt.json')).read_text()) for p in ['final-','clean-']];assert all(x['exit_code']==0 and x['head']==m['head'] and x['matched_paths']==177 and x['unit_tests']==98 for x in stats);assert stats[0]['binary_sha256']==stats[1]['binary_sha256'] and stats[0]['fixture_sha256']==stats[1]['fixture_sha256']
for prefix in ['final-','clean-']:assert json.loads((r/(prefix+'functional-receipt.json')).read_text())['exit_code']==0
cpios=[json.loads((r/(p+'cpio-receipt.json')).read_text()) for p in ['', 'clean-','baseline-']];assert [x['exit_code'] for x in cpios]==[0,0,83];assert len({x['archive_sha256'] for x in cpios})==1 and len({x['wrapper_sha256'] for x in cpios})==1
base=Path('/tmp/ginux-contribution-preparation/G15');bm=json.loads((base/'manifest.json').read_text());bb=base/'verified-head/target/x86_64-unknown-linux-gnu/release/ginux';assert bm['head']==m['base'] and hashlib.sha256(bb.read_bytes()).hexdigest()==bm['clean_binary_sha256']
m.update(status='source/strict clean preparation and separate full-diff self-review retained; security/full CI/fresh upstream independence and combined consumer joins pending',unit_tests=98,vfs_tests=40,clean_matched_paths=177,review='separate whole-diff self-review; no independent or security acceptance claimed',remote_ci='not run',security_handoff='daybreakblue-handoff.md',source_binary_sha256=stats[0]['binary_sha256'],clean_binary_sha256=stats[1]['binary_sha256'],fixture_sha256=stats[0]['fixture_sha256'],functional_evidence='ordinary root/unchanged path/FD/dirfd/nofollow/empty-path/alias/unlinked ownership plus existing storage controls; actual GNU cpio2.15 valid8229-byte extraction, hardlink identity and symlink metadata source/clean',baseline_evidence='same frozen valid cpio archive/wrapper on exact G15 fails ownership syscalls with ENOSYS and wrapper exits83; candidate succeeds',baseline_binary_sha256=bm['clean_binary_sha256'],evidence='g30-review.md',source_patch='patches/G30.patch')
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');art.mkdir(parents=True,exist_ok=True)
for p in r.iterdir():
 if p.is_file() and (p.suffix in ['.log','.audit','.stdout','.diff','.patch','.c','.cpio'] or p.name.endswith('receipt.json') or p.name in ['composition.json','manifest.json','cpio-provenance.json']):shutil.copyfile(p,art/p.name)
for p in Path('/tmp').glob('ginux-*g30*.py'):shutil.copyfile(p,art/p.name)
shutil.copyfile(r/'candidate.patch',docs/'patches/G30.patch')
(art/'draft.md').write_text('''Preserve virtual root ownership on assigned storage

GNU cpio extraction reports ownership failures even when the archive requests
the storage inode's existing virtual root identity. Route chown variants through
the existing path/inode/descriptor owners, accepting0 or unchanged IDs without
forwarding host ownership calls. Include no-follow and empty-path dispatch.

Local check/unit/build and98 units pass in source and strict clean replay.
Ordinary metadata/storage cases and actual GNU cpio extraction preserve payload,
hardlink identity and symlink ownership. Full security/default runtime, remote CI
and prerequisite/current-main review remain pending. Not ready to submit.
''')
(docs/'g30-review.md').write_text(f'''# G30 — preserve virtual root ownership on assigned storage

Head `{m['head']}`, tree `{m['tree']}`, directly on G15
`{m['base']}`. [Patch](patches/G30.patch):5 files,+88/-7,
adapted from7cf2638a. No G25/G24/G14/G07/network/archive ancestry is needed for
these runtime operations or the demonstrated cpio consumer. G15 already supplies
public descriptors, inode aliases, directories and shared symlink/path resolution.
This is local preparation; upstream prerequisites/security/full CI remain open.

Existing assigned-storage metadata projects uid/gid0. Chown/fchown/lchown/fchownat
now verify the addressed object exists and accept each32-bit ID as0 or unchanged
(-1), returning EOPNOTSUPP for a different identity. These are identity-preserving
operations, not arbitrary Linux ownership changes. There is no host chown call,
new stored identity field or separate inode/path owner. Native fchown stays EPERM;
unassigned path operations retain the immutable default contract. Nofollow and
AT_EMPTY_PATH use existing metadata/descriptor dispatch, including relative
owned directory handles and aliases that outlive their final pathname.

Separate full-diff self-review read all5 changes, existing path walker, dispatch
precedence, public FD translation/close, VFS metadata/fstat/alias lifetime, ABI
metadata serialization, default contract, storage runner and existing CI target.
This is self-review, not independent or adversarial review.

- **Medium, reproduced/corrected — empty-path dispatch:** the first port returned
  ENOENT for valid fchownat(fd,"",...,AT_EMPTY_PATH); the device owner's shared path
  lookup ran before filesystem descriptor dispatch. request_path now leaves that
  operation to the existing descriptor owner. The ordinary fixture failed at106
  before this correction and passes after it. Invalid flags are checked before
  nonempty-path resolution, and descriptor dispatch retains its own flag check.
- **Dependency correction:** source tracing and actual cpio prove no G25 vectors,
  G24 timestamps or G14 owned cwd dependency for root-preserving ownership. The
  actual combined package pipeline still joins those owners at F02/F03; no
  no-preserve-owner flag or extraction bypass was introduced.
- **Coverage preserved:** existing units and storage target remain. The runner's
  default now includes the full ownership scenario, with separate ordinary mode
  for valid calls. Donor dangling/absent/unsupported-ID/invalid-pointer/flag/native
  checks remain enabled and unrun locally for DaybreakBlue. Existing CI invokes
  this updated runner, so no extra wiring-only packet is required.

Source and strict clean base-plus-patch replay pass make check test-unit build
build-launch-storage-fixture:98 units including40 VFS,177 tracked paths matched,
identical Ginux/fixture hashes. Ordinary ownership checks exercise root/unchanged
IDs by path and FD, nofollow symlink, relative directory FD and AT_EMPTY_PATH,
stat/statx uid/gid0, preserved modes/bytes/link counts and unlinked open aliases.
Existing ordinary symlink/growth/bounds/quota controls also pass in both copies.

Actual trusted GNU cpio2.15 runs normally in a supervised child and extracts a
locally produced valid newc archive with root UID/GID. Its arguments are -i
--quiet; ownership preservation is not suppressed. Parent checks every8229
payload byte through file/hardlink/symlink names, shared inode/nlink2, mode0640,
uid/gid0, symlink type/ownership and EOF. Source and clean replay both exit0.
The same frozen archive and wrapper on exact G15 produce fchown/lchown ENOSYS,
cpio ownership errors and wrapper exit83. Archive/wrapper/binary/runtime file
hashes and provenance are retained. No host packages or external downloads were
needed. The initial harness mistakenly included work/ in names despite the
configured default cwd already being /work; that failure is retained and the
corrected relative archive uses the existing supported cwd behavior.

Initial local port formatting was attempted from /tmp, and its first check
caught a missing helper insertion; neither is an upstream defect or a final
check. Corrected source and exact replay pass the checks above.

[DaybreakBlue](daybreakblue-handoff.md) must validate protected/mutable paths,
invalid UID/GID/flags and missing/dangling targets, native/private descriptor and
assignment authority, nofollow/rename/close races, shared-thread transactions,
copy/lookup errors and host ownership nonmutation under adversarial conditions.
Full/default storage runtime, Linux/macOS remote CI, independent review, G07's
shared-path hold and fresh upstream independence remain pending. This focused
cpio evidence does not complete APK/RPM/Recipe integration at F02/F03.

Patch/draft/helpers/logs/results/failures/provenance are retained under
.artifacts/ginux-contribution-preparation/G30/. No Ginux branches/refs/real index/
checkouts, remote text or publication changed. F04 remains the user inspection
stop before publication.
''')
p=docs/'p05-package-plan.json';plan=json.loads(p.read_text());row=next(x for x in plan['packets'] if x['packet']=='G30');row.update(m);p.write_text(json.dumps(plan,indent=2)+'\n')
p=docs/'p04-dependencies.md';p.write_text(p.read_text()+f'''\nG30 `{m['head'][:8]}` extracts directly on G15: existing shared inode/path/public FD
owners suffice; no G25/G24/G14 ancestry is required. Actual GNU cpio2.15 extracts
root-owned regular/hardlink/symlink content in source/clean, while exact G15 fails
fchown/lchown;98 units pass. General package/cwd/time/vector/thread integration
still belongs to F02/F03, and security/full CI remain pending. Empty-path
ownership must bypass shared path resolution to reach its descriptor owner;
[review/evidence](g30-review.md).
''')
p=docs/'daybreakblue-handoff.md';p.write_text(p.read_text()+f'''\n## G30 — storage virtual-root ownership

Head `{m['head']}` directly on G15 `{m['base']}`.
98 units and ordinary source/clean ownership/storage checks plus actual trusted
GNU cpio2.15 valid archive extraction pass. Actual cpio fails ownership syscalls
on exact G15. A reproduced empty-path dispatch failure is corrected. No ownership
suppression flags, external downloads, invalid archive or hostile buffer probes.
[Review/evidence](g30-review.md).

Validate protected/mutable ownership paths, UID/GID width/invalid IDs, flags and
missing/dangling/empty-path behavior; native/private/closed/reused descriptors,
assignment and inode authority; shared-thread/rename/close/exec races and error
ordering; verify no host ownership mutation or fallback. The full new ownership
mode retains donor negative/pointer/authority checks but is locally unrun. G07
shared-path/security, full CI and combined consumers remain pending. No cloud
dispatch or security acceptance occurred.
''')
p=root/'docs/ginux-contribution-task-list.md';t=p.read_text();a=t.index('Exact next task: **G30');b=t.index('\nActive skill:',a);t=t[:a]+f'''G30 `{m['head'][:8]}` is retained directly on G15.
[Review/evidence](ginux-contributions/g30-review.md) records98 units,177-path strict
replay and ordinary owner/path/FD/nofollow/empty-path/alias metadata plus storage
controls passing in source/clean. Actual GNU cpio2.15 extracts all8229 payload
bytes, hardlink identity and symlink metadata with UID/GID0; the same archive and
wrapper fail ownership on exact G15. Empty-path shared routing was reproduced
and corrected. No G25/G24/G14 ancestry or ownership-suppression flag is needed.
Security/full default runtime/remote CI/current-main independence and actual
combined package/Recipe closure remain pending. No publication occurred.

Exact next task: **G31 — reconcile checkpoint/restore coverage into its owners**.
Trace5e20a65f against retained G20/G21 CI/Make/runner evidence and account for its
single coverage line without a duplicate wiring-only packet. Preserve all unit
modules and default runner scenarios. Then proceed F01 complete hunk accounting,
F02 combined owners, F03 fresh Recipe/actual consumers and F04 user inspection.
All G08/G23–G30/security/policy/consumer open criteria remain active. No branches,
refs, pushes, PRs or maintainer messages before user inspection.
''' +t[b:];p.write_text(t);print('saved G30',m['head'],'next G31 coverage reconciliation')
