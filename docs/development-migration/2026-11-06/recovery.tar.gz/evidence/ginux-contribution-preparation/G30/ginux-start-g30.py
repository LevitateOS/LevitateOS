from pathlib import Path
import subprocess,tarfile,io,json
r=Path('/tmp/ginux-contribution-preparation/G30');s=r/'source';assert not s.exists();s.mkdir(parents=True);repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='8ab24d4b47adeb9897623627060846070d41219d'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(s,filter='data')
def edit(f,fn):p=s/f;p.write_text(fn(p.read_text()))
d=git('show','7cf2638a:crates/ginux-init/src/fs_hooks.rs').decode()
def fs(t):
 t=t.replace('4 | 21 | 90 =>','4 | 21 | 90 | 92 =>').replace('6 | 84 | 87 | 89 =>','6 | 84 | 87 | 89 | 94 =>')
 t=t.replace('            262 => (1, r.rsi, r.rdi, r.r10 & 0x100 == 0, false),','            260 if r.r8 & !0x1100 != 0 => return Err(-22),\n            260 => (1, r.rsi, r.rdi, r.r8 & 0x100 == 0, false),\n            262 => (1, r.rsi, r.rdi, r.r10 & 0x100 == 0, false),')
 t=t.replace('matches!(r.orig_rax, 262 | 332 | 439 | 322)','matches!(r.orig_rax, 260 | 262 | 332 | 439 | 322)').replace('matches!(r.orig_rax, 262 | 332 | 439)', 'matches!(r.orig_rax, 260 | 262 | 332 | 439)')
 t=t.replace('                | 91\n','                | 91\n                | 93\n')
 a='            21 | 269 | 439 =>';ops=d[d.index('            92 | 94 =>'):d.index('            280 => self.timestamps')];t=t.replace(a,ops+a)
 a='            77 if r.rsi as i64';ops=d[d.index('            93 => self'):d.index('            74 | 75 => self.fs.fstat')];t=t.replace(a,ops+a)
 helper=d[d.index('// Owned inode uid/gid'):d.index('// Owned files belong')];t=t.replace('// Owned files belong',helper+'// Owned files belong')
 return t
edit('crates/ginux-init/src/fs_hooks.rs',fs)
def descriptors(t):
 t=t.replace('0 | 1 | 5 | 8 | 16 | 17 | 18 | 19 | 20 | 74 | 75 | 77 | 78 | 91 | 217 =>','0 | 1 | 5 | 8 | 16 | 17 | 18 | 19 | 20 | 74 | 75 | 77 | 78 | 91 | 93 | 217 =>')
 t=t.replace('258 | 262 | 263 | 267 | 268 | 269 | 332 | 439 =>','258 | 260 | 262 | 263 | 267 | 268 | 269 | 332 | 439 =>')
 t=t.replace('            Handle::Native { fd, console } => {\n                if console', '            Handle::Native { fd, console } => {\n                if r.orig_rax == 93 { return Err(-1); }\n                if console')
 return t
edit('crates/ginux-init/src/descriptors.rs',descriptors)
edit('README.md',lambda t:t+'\nOwned storage inode uid/gid are virtual root. `chown`, `fchown`, `lchown` and\n`fchownat` can preserve 0 or unchanged (-1) on existing assigned storage objects,\nincluding symlinks and empty-path descriptor operations. Other identities remain\nunsupported; these operations never change host ownership.\n')
(r/'composition.json').write_text(json.dumps({'base':base,'dependencies':['G15'],'source':['7cf2638adaf2fd3b783be636fe2a05b2d60458c5'],'dependency_notes':'G15 already supplies symlink/hardlink inode/path/public FD owners; no runtime symbols require G25 vectors, G24 timestamps, G14 cwd, G07 threads or G29 networking. Actual cpio consumer will establish any additional prerequisite rather than import it speculatively.','deferred_joins':['G07 shared paths/FD calls','G24/G25/F02 actual package pipeline']},indent=2)+'\n')
print('G30 starts directly on G15, targeted inode/path/public descriptor ownership')
