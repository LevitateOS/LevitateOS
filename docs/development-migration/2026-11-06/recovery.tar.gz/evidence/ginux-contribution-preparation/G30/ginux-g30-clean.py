from pathlib import Path
import subprocess,tarfile,io,json,os,hashlib,re
r=Path('/tmp/ginux-contribution-preparation/G30');s=r/'source';d=r/'verified-head';assert not d.exists();d.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';m=json.loads((r/'manifest.json').read_text())
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',m['base']))) as t:t.extractall(d,filter='data')
subprocess.run(['git','apply','--whitespace=error',str(r/'candidate.patch')],cwd=d,check=True);names=git('ls-tree','-r','--name-only',m['head']).decode().splitlines()
for name in names:
 a=s/name;b=d/name;assert a.is_symlink()==b.is_symlink(),name
 assert (os.readlink(a)==os.readlink(b) if a.is_symlink() else a.read_bytes()==b.read_bytes()),name
for path,prefix in [(s,'final-'),(d,'clean-')]:
 cmd=['make','check','test-unit','build','build-launch-storage-fixture']
 with (r/(prefix+'static-build.log')).open('w') as f:p=subprocess.run(cmd,cwd=path,stdout=f,stderr=subprocess.STDOUT)
 receipt={'command':cmd,'exit_code':p.returncode,'head':m['head'],'matched_paths':len(names),'binary_sha256':hashlib.sha256((path/'target/x86_64-unknown-linux-gnu/release/ginux').read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256((path/'.artifacts/launch/launch-storage-fixture').read_bytes()).hexdigest(),'unit_tests':sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',(r/(prefix+'static-build.log')).read_text()))};(r/(prefix+'static-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(prefix,p.returncode,len(names),receipt['unit_tests'],flush=True);assert p.returncode==0
