from pathlib import Path
s=Path('/tmp/ginux-contribution-preparation/G30/source');p=s/'tests/fixtures/launch-storage-fixture.c';t=p.read_text();a='long storage_main(word *stack)';f='''static long ownership(int full) {
    long fd=DO(2,"/work/owner",0102,0640); CHECK(fd>=3,100);
    CHECK(DO(1,fd,"root",4)==4 && DO(86,"/work/owner","/work/alias",0)==0,101);
    CHECK(DO(93,fd,0,-1)==0 && DO(92,"/work/alias",-1,0)==0,102);
    long alias=DO(32,fd,0,0); CHECK(alias>=3 && DO(3,fd,0,0)==0,103);
    CHECK(DO(88,"owner","/work/owner-link",0)==0 && DO(94,"/work/owner-link",0,0)==0,104);
    CHECK(call(260,-100,(word)"/work/owner-link",-1,0,0x100,0)==0,105);
    CHECK(call(260,alias,(word)"",0,-1,0x1000,0)==0,106);
    long dir=DO(2,"/work",0200000,0); CHECK(dir>=3,107);
    CHECK(call(260,dir,(word)"alias",0,0,0,0)==0 && DO(93,dir,-1,-1)==0,108);
    CHECK(DO(5,alias,meta,0)==0 && *(unsigned *)(meta+28)==0 && *(unsigned *)(meta+32)==0,109);
    CHECK(*(word *)(meta+16)==2 && *(word *)(meta+48)==4 && (*(unsigned *)(meta+24)&0777)==0640,110);
    CHECK(call(332,alias,(word)"",0x1000,0x7ff,(word)meta,0)==0 && *(unsigned *)(meta+20)==0 && *(unsigned *)(meta+24)==0,111);
    CHECK(DO(87,"/work/owner",0,0)==0 && DO(87,"/work/alias",0,0)==0 && DO(93,alias,0,0)==0,112);
    CHECK(DO(8,alias,0,0)==0 && DO(0,alias,output,4)==4 && output[0]=='r' && output[3]=='t',113);
    if(full) {
        CHECK(DO(88,"missing","/work/dangling",0)==0 && DO(94,"/work/dangling",0,0)==0,114);
        CHECK(DO(92,"/work/dangling",0,0)==-2 && call(260,-100,(word)"/work/dangling",0,0,0x100,0)==0,115);
        CHECK(call(260,alias,(word)"",0,0,0,0)==-2 && DO(93,alias,1,0)==-95,116);
        CHECK(DO(92,"/work/missing",0,0)==-2 && DO(92,1,0,0)==-14,117);
        CHECK(call(260,dir,(word)"missing",0,0,2,0)==-22 && DO(93,0,0,0)==-1,118);
    }
    CHECK(DO(3,dir,0,0)==0 && DO(3,alias,0,0)==0,119);
    return 0;
}
''';assert a in t;t=t.replace(a,f+a);a='    char **argv = (char **)(stack + 1);';t=t.replace(a,a+'\n    if(argc>1 && named(argv[1],"ordinary-ownership"))return ownership(0);\n    if(argc>1 && named(argv[1],"ownership"))return ownership(1);');p.write_text(t)
p=s/'scripts/test-launch-storage.py';t=p.read_text().replace("'symlinks', 'ordinary-symlinks'):","'symlinks', 'ordinary-symlinks', 'ownership', 'ordinary-ownership'):");a="        invoke([], ['no-storage'])";assert a in t;t=t.replace(a,"        invoke(['memory:/work'], ['ownership'])\n"+a);p.write_text(t)
