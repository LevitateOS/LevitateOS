from pathlib import Path
import subprocess,json
r=Path('/tmp/ginux-contribution-preparation/G30')
for d,prefix in [('source','final-'),('verified-head','clean-')]:
 s=r/d;cmd=['sudo','-n','python3','scripts/test-launch-storage.py','target/x86_64-unknown-linux-gnu/release/ginux','.artifacts/launch/launch-storage-fixture','ordinary-ownership','ordinary-symlinks','growth','bounds','quota']
 with (r/(prefix+'functional.log')).open('w') as f:p=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT)
 (r/(prefix+'functional-receipt.json')).write_text(json.dumps({'command':cmd,'exit_code':p.returncode},indent=2)+'\n');print(d,p.returncode,flush=True);assert p.returncode==0
