from pathlib import Path
p=Path('crates/ginux-init/src/exec_script.rs');s=Path('/tmp/ginux-stashed-exec-script.rs').read_text().replace('fs.exec_interpreter(header.interpreter.as_bytes())?', 'fs.exec_interpreter(host, header.interpreter.as_bytes())?')
a=s.index('    pub fn restore(')
s=s[:a]+'''    pub fn restore(self, host: usize, fd: u32, r: &mut UserRegs) -> Result<(), i64> {
        let argc = word(host, r.rsp)? as usize;
        let prefix = if self.kernel_script {
            let prefix = argc.checked_sub(self.original_argc).filter(|n| *n > 0).ok_or(-5)?;
            let actual = read_path(host, word(host, r.rsp + ((prefix + 1) * 8) as u64)?)?;
            let mut expected = [0u8; 32];
            expected[..8].copy_from_slice(b"/dev/fd/");
            let mut digits = [0u8; 10];
            let mut n = fd;
            let mut len = 0;
            loop {
                digits[len] = b'0' + (n % 10) as u8;
                len += 1; n /= 10;
                if n == 0 { break; }
            }
            for (i, digit) in digits[..len].iter().rev().enumerate() { expected[8+i] = *digit; }
            if actual.as_bytes() != &expected[..8+len] { return Err(-5); }
            prefix
        } else {
            if argc != self.original_argc { return Err(-5); }
            0
        };
        if argc > ARGUMENTS + 16 { return Err(-7); }
        let mut words = [0u64; STACK_WORDS];
        let mut strings = [0u8; (2 * SCRIPTS + 1) * MAX_PATH];
        let mut strings_len = 0;
        let mut patched = [0usize; 2 * SCRIPTS + 1];
        let mut patches = 0;
        let mut used = 1;
        // Keep any prefix the kernel produced through immutable interpreters.
        for n in 0..prefix {
            words[used] = word(host, r.rsp + ((n + 1) * 8) as u64)?;
            used += 1;
        }
        let mut append = |path: Path| -> Result<(), i64> {
            let bytes = path.as_bytes();
            let end = strings_len.checked_add(bytes.len() + 1).filter(|n| *n <= strings.len()).ok_or(-7)?;
            strings[strings_len..end-1].copy_from_slice(bytes);
            words[used] = strings_len as u64;
            patched[patches] = used; patches += 1;
            used += 1; strings_len = end;
            Ok(())
        };
        if !self.kernel_script { append(self.leaf)?; }
        for index in (0..self.count).rev() {
            // The kernel already supplied the last owned script's shebang arg.
            if !(self.kernel_script && index + 1 == self.count) {
                if let Some(argument) = self.segments[index].argument { append(argument)?; }
            }
            append(self.segments[index].path)?;
        }
        // The last inserted string is always the originally invoked script.
        let execfn = words[patched[patches - 1]];
        for n in prefix + 1..argc {
            words[used] = word(host, r.rsp + ((n + 1) * 8) as u64)?;
            used += 1;
        }
        words[0] = (used - 1) as u64;
        used += 1; // argv terminator
        if word(host, r.rsp + ((argc + 1) * 8) as u64)? != 0 { return Err(-5); }
        let mut cursor = argc + 2;
        let mut envc = 0;
        loop {
            if envc > ARGUMENTS || used >= STACK_WORDS { return Err(-7); }
            let value = word(host, r.rsp.checked_add((cursor * 8) as u64).ok_or(-14)?)?;
            cursor += 1;
            words[used] = value; used += 1;
            if value == 0 { break; }
            envc += 1;
        }
        let aux = used;
        for n in 0..AUX_PAIRS {
            if used + 2 > STACK_WORDS { return Err(-7); }
            words[used] = word(host, r.rsp.checked_add((cursor * 8) as u64).ok_or(-14)?)?;
            words[used+1] = word(host, r.rsp.checked_add(((cursor+1) * 8) as u64).ok_or(-14)?)?;
            cursor += 2; used += 2;
            if words[used-2] == 0 { break; }
            if n+1 == AUX_PAIRS { return Err(-7); }
        }
        // Place the expanded pointers and new strings entirely below the old
        // pointer block. Existing argv/env/aux data stay intact above it.
        let bytes = (used * 8 + strings_len).next_multiple_of(16) as u64;
        let start = r.rsp.checked_sub(bytes).ok_or(-14)?;
        let names = start + (used * 8) as u64;
        for &index in &patched[..patches] { words[index] += names; }
        for pair in words[aux..used].as_chunks_mut::<2>().0 {
            if pair[0] == 31 { pair[1] = names + execfn; }
        }
        let pointers = unsafe { core::slice::from_raw_parts_mut(words.as_mut_ptr().cast::<u8>(), used * 8) };
        if copy_memory(host, start, pointers, true) != Ok(pointers.len() as i64)
            || copy_memory(host, names, &mut strings[..strings_len], true) != Ok(strings_len as i64) {
            return Err(-14);
        }
        r.rsp = start;
        Ok(())
    }
}
''';p.write_text(s)
p=Path('crates/ginux-init/src/fs_hooks.rs');s=p.read_text();a=s.index('        if self.owns_path(path.as_bytes()) {',s.index('    pub fn exec_path('));s=s[:a]+'''        self.exec_resolved(path.as_bytes())
    }

    pub fn exec_interpreter(&mut self, pid: usize, name: &[u8]) -> Result<Option<Executable>, i64> {
        let cwd;
        let base = if name.first() == Some(&b'/') { b"/".as_slice() } else {
            cwd = crate::tracee_io::image_cwd(pid)?; cwd.as_bytes()
        };
        let path = normalize(base, name)?;
        self.exec_resolved(path.as_bytes())
    }

    fn exec_resolved(&mut self, path: &[u8]) -> Result<Option<Executable>, i64> {
'''+s[a:];a=s.index('    fn exec_resolved');b=s.index('    pub fn exec_descriptor',a);s=s[:a]+s[a:b].replace('path.as_bytes()', 'path')+s[b:]
a=s.index('    pub fn is_script(');b=s.index('    pub fn mapping_reference',a);s=s[:a]+'''    pub fn is_script(&self, image: Executable) -> Result<bool, i64> {
        let mut header = [0u8; 2];
        self.read_executable(image, 0, &mut header)?;
        Ok(header == *b"#!")
    }

'''+s[b:];p.write_text(s)
p=Path('crates/ginux-init/src/launch_tasks.rs');s=p.read_text();a=s.index('        let script = if let Some(image) = image {');b=s.index('        self.task_mut(index).exec = Some(Exec {',a);s=s[:a]+'''        let mut image = image;
        let script = if let Some(initial) = image {
            let check = (|| {
                if self.objects.filesystem.is_script(initial)? && r.orig_rax == 322 {
                    let path = crate::tracee_io::read_path(host, r.rsi)?;
                    if (path.is_empty() || (path.as_bytes()[0] != b'/' && r.rdi as i32 != -100))
                        && self.table(index).exec_cloexec(r.rdi)? { return Err(-2); }
                }
                Ok(())
            })();
            if let Err(error) = check {
                self.objects.filesystem.release_executable(initial).expect("script setup release");
                return Err(error);
            }
            // Resolution consumes the initial pin on both success and failure.
            let (resolved, script) = crate::exec_script::Script::resolve(self.objects.filesystem, host, r, initial)?;
            image = Some(resolved);
            script
        } else { None };
'''+s[b:]
s=s.replace('u64::from(owned.script.is_none())', 'u64::from(!owned.script.is_some_and(|script| script.kernel_script))')
# Release intermediate script references on failed exec and killed transactions.
for reason in ['failed exec reference release failed','terminated exec reference release failed']:
    before=s.index('            if self\n', s.index('if let Some(owned)', s.index('fn finish_exec_failure' if reason.startswith('failed') else 'fn died')))
    s=s[:before]+'''            if owned.script.is_some_and(|script| script.release_held(self.objects.filesystem).is_err()) {
                self.fail(domain, b"interpreter reference release failed");
            }
'''+s[before:]
a=s.index('                self.task_mut(index).exec.as_mut().unwrap().retire = Some(fd);',s.index('fn exec_completed'));b=s.index('            } else {',a)
s=s[:a]+'''                self.task_mut(index).exec.as_mut().unwrap().owned = None;
                if script.release_held(self.objects.filesystem).is_err() {
                    self.fail(domain, b"committed interpreter references release failed");
                }
                if script.kernel_script {
                    self.task_mut(index).exec.as_mut().unwrap().retire = Some(fd);
                    if self.objects.filesystem.release_executable(owned.image).is_err() {
                        self.fail(domain, b"committed script reference release failed");
                    }
                    None
                } else {
                    Some(owned.image)
                }
'''+s[b:];p.write_text(s)
