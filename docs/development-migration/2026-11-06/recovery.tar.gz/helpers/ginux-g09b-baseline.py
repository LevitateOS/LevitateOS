from pathlib import Path
import subprocess,tarfile,io,json
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G09b');dest=root/'baseline';assert not dest.exists();dest.mkdir();base=json.loads((root/'composition.json').read_text())['base']
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'archive',base]))) as t:t.extractall(dest,filter='data')
with (root/'baseline-build.log').open('w') as log:subprocess.run(['cargo','build','-p','ginux-init','--target','x86_64-unknown-linux-gnu','--release'],cwd=dest,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Built exact G09b prerequisite source.')
