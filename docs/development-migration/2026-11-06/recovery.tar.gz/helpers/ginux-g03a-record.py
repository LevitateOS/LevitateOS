from pathlib import Path
import json,shutil,hashlib
root=Path('/home/vince/Projects/LevitateOS')
src=Path('/tmp/ginux-contribution-preparation/G03a')
dest=root/'.artifacts/ginux-contribution-preparation/G03a';dest.mkdir(parents=True,exist_ok=True)
for f in src.iterdir():
 if f.is_file() and f.suffix in ['.patch','.diff','.log','.json','.md','.txt']:shutil.copyfile(f,dest/f.name)
p=dest/'manifest.json';m=json.loads(p.read_text())
m.update(status='reviewed and locally validated standalone candidate; user inspection and remote CI pending',runtime_results=json.loads((src/'runtime-results.json').read_text()),clean_runtime_results=json.loads((src/'clean-runtime-results.json').read_text()),baseline_binary_sha256=hashlib.sha256((Path('/tmp/ginux-contribution-preparation/baseline-main/source/target/x86_64-unknown-linux-gnu/release/ginux')).read_bytes()).hexdigest())
p.write_text(json.dumps(m,indent=2)+'\n')
doc=root/'docs/ginux-contributions'
(doc/'g03a-review.md').write_text('''# G03a — create an absent workload directory correctly

Local candidate `0b563cf87a3c0e83a20a22eee3af8ffdb7adf015` has sole parent
upstream `3f2fe7dfadd4b40e235d982a6a3d386dc6490177`. Two files, +4/-1.
This one-line correction was already included in the local10091e4e storage
commit; it is independently useful and is extracted from that larger feature.

The x86-64 launch bootstrap labels syscall259 as mkdirat. Installed ABI headers
confirm259 is mknodat and258 is mkdirat. When the configured working directory
does not exist, the bootstrap cannot enter it and returns supervisor-error2.
Use258 in the existing call and add a real missing-workdir invocation to the
launch harness, asserting the result is a directory. Existing workdir and all
other launch failure cases remain in the suite.

Full final diff/call-site review found no additional required change. The call
still occurs after chroot, before dropping privileges and entering the configured
directory; existing path validation, permissions, result reporting and failure
behavior remain in their original owners. No new syscall surface is granted to
the workload. Files retain their upstream modes. This was reviewed by the author
in a separate pass; no independent reviewer is claimed.

## Verification

The new real launch scenario fails against an unmodified upstream3f2fe7df binary:
exit2, supervisor-error, configured domain workdir unavailable. With the candidate
it returns0 and the configured directory exists. Baseline binary SHA and full
failure output are retained with the package.

Both the initial isolated candidate source and a separate clean upstream export
with only this patch applied pass:

- `make check test-unit`:65 unit tests; every existing unit module retained.
- `make build build-launch-fixture build-process-fixtures build-gate1-fixture`.
- `sudo -n make test-launch`, including the new absent-workdir case.
- `sudo -n make test-native-supervision`.
- `make test-process-native`.
- `sudo -n make test-gate1-setup`.

All150 tracked source paths in the clean-applied export match the tested
candidate; only the stated two files differ from upstream. A temporary index
created the local commit object without modifying any real index/ref/worktree.
Patch, concise draft body, manifests, timings and all logs are in
`.artifacts/ginux-contribution-preparation/G03a/`.

R01–R04 pass locally. macOS Actions/full Rocky VM checks remain unrun; no remote
CI result is claimed. No branch was created/switched and no remote was changed.
User inspection of the full package remains F04. The broader G03 writable-storage
and metadata feature is still pending; this small fix does not complete it.
''')
p=doc/'p05-package-plan.json';pkg=json.loads(p.read_text())
assert not any(x['packet']=='G03a' for x in pkg['packets'])
i=next(i for i,x in enumerate(pkg['packets']) if x['packet']=='G03')
pkg['packets'].insert(i,{'packet':'G03a','parent_packet':'G03','purpose':'correct the existing launch bootstrap mkdirat syscall','dependencies':[],'source_commits':['10091e4e48bb14dcf9f0ee20e62f471fb7d0cf2f'],'acceptance':'real absent-workdir launch fails at upstream and passes with correction; directory is created; existing suite preserved','status':m['status'],'base':m['base'],'head':m['head'],'tree':m['tree'],'evidence':'g03a-review.md','artifact_directory':'.artifacts/ginux-contribution-preparation/G03a'})
p.write_text(json.dumps(pkg,indent=2)+'\n')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text()
s=s.replace('records all32 rows, exact source commits','records the original32 rows plus extracted subpackets, exact source commits')
s=s.replace('No branch/index/worktree/remote was changed; only local commit objects and exports\nwere created.', 'No Ginux branch/index/worktree/remote was changed; only local commit objects and\nsource exports were created.')
a=s.index('Exact next task: **G03 — configured writable storage and file metadata**.')
b=s.index('\nActive skill:',a)
s=s[:a]+'''G03a is a second independent candidate, extracted from the existing G03 donor:
correct the mkdirat syscall for an absent configured workdir. [Review/evidence](ginux-contributions/g03a-review.md)
records exact upstream failure, candidate0b563cf8,65 unit tests and all required
Linux runtime checks passing in both candidate and clean-applied source. Its sole
parent is upstream3f2fe7df; patch/draft/logs are retained with the package. The
larger G03 feature is still incomplete.

Current goal-turn classification: **progress**. P03–P05 are complete; two actual
standalone candidates now have full local review, negative/positive evidence and
clean-apply validation. No publication occurred and the integration remains
unchanged at7cf2638a. Goal remains active with the complete original scope.

Exact next task: **G03 — remaining writable-storage/metadata extraction**.
Start with the VFS metadata/seek/mkdir/chmod/append/exclusive API in222d29ff,
reconcile current #216–#218 semantics and G05a offset sharing, then the controlled
LaunchFs runtime join in10091e4e. Separate the now-prepared mkdirat fix from those
patches. Fully review/test before moving on. Existing G01/G02 policy holds and
G02's missing standalone runtime acceptance remain visible. F04 is the user
checkpoint before publication.
''' + s[b:]
p.write_text(s)
print('G03a recorded; broader G03 remains next; complete goal stays active')
