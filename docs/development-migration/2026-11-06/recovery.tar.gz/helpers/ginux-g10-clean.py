from pathlib import Path
import subprocess,tarfile,io,json,os
root=Path('/tmp/ginux-contribution-preparation/G10');src=root/'source';dest=root/'clean-apply';assert not dest.exists();dest.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';m=json.loads((root/'manifest.json').read_text())
def git(*args):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*args])
with tarfile.open(fileobj=io.BytesIO(git('archive',m['base']))) as t:t.extractall(dest,filter='data')
subprocess.run(['git','apply','--whitespace=error',str(root/'candidate.patch')],cwd=dest,check=True)
names=git('ls-tree','-r','--name-only',m['head']).decode().splitlines()
for name in names:
 a=src/name;b=dest/name;assert a.is_symlink()==b.is_symlink(),name
 assert (os.readlink(a)==os.readlink(b) if a.is_symlink() else a.read_bytes()==b.read_bytes()),name
with (root/'clean-static-build.log').open('w') as log:r=subprocess.run(['make','check','test-unit','build','build-launch-owned-exec-fixture','build-launch-exec-fixture'],cwd=dest,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,r.returncode
(root/'clean-static-receipt.json').write_text(json.dumps({'command':'make check test-unit build build-launch-owned-exec-fixture build-launch-exec-fixture','exit_code':r.returncode,'matched_paths':len(names),'head':m['head']},indent=2)+'\n');print('Clean replay:',len(names),'paths; static/unit/build passed.')
