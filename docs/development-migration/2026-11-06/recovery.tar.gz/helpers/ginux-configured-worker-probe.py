"""Diagnostic only: launch the real worker with copied Rocky runtime libraries."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile

source = Path('/home/vince/Projects/LevitateOS')
checkout = Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
archive = source / '.artifacts/ginux-env/oci-cache/rocky-10.2.20260525.0-amd64-rootfs.tar'
digest = '1026f8d3b36eaea1bcab8e609045991f08c70eb7645cb37f58f48faa8b40be9c'
with archive.open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == digest
work = Path(tempfile.mkdtemp(prefix='ginux-configured-worker-'))
work.chmod(0o755)
root = work / 'root'
for directory in ('usr/lib64', 'inputs', 'work/build', 'work/tmp', 'out'):
    (root / directory).mkdir(parents=True, exist_ok=True)
(root / 'lib64').symlink_to('usr/lib64')
for directory in ('work', 'work/build', 'work/tmp', 'out'):
    (root / directory).chmod(0o777)
with tarfile.open(archive) as image:
    for name in ('ld-linux-x86-64.so.2', 'libc.so.6', 'libm.so.6', 'liblzma.so.5', 'libgcc_s.so.1'):
        # Read only selected archive members; no archive paths are extracted.
        with image.extractfile('usr/lib64/' + name) as stream:
            (root / 'usr/lib64' / name).write_bytes(stream.read())
        (root / 'usr/lib64' / name).chmod(0o555)
worker = source / 'target/debug/recipe'
shutil.copyfile(worker, root / 'inputs/recipe-worker')
(root / 'inputs/recipe-worker').chmod(0o555)
(root / 'inputs/main.rhai').write_text('const RECIPE_API = 2; let ctx = #{};\n')
(root / 'inputs/main.rhai').chmod(0o444)
env = ['PATH=/usr/bin:/bin', 'RECIPE_WORKER=1', 'RECIPE_INVOCATION=configured-worker-probe',
       'BUILD_DIR=/work/build', 'TMPDIR=/work/tmp', 'ARCH=x86_64', 'NPROC=1']
config = (checkout / 'config/domain-gate5.toml').read_text()
config = config.replace('init = "/bin/bash"', 'init = "/inputs/recipe-worker"')
config = config.replace('args = []', 'args = ["/inputs/main.rhai"]')
config = config.replace('["container=ginux"]', json.dumps(env))
(work / 'config.toml').write_text(config)
command = ['/tmp/ginux-recipe-local-build/x86_64-unknown-linux-gnu/release/ginux', 'launch',
           str(work / 'config.toml'), str(root), '--result-file', str(work / 'result.json')]
proc = subprocess.run(command, input=b'', capture_output=True, timeout=20)
(work / 'stdout.bin').write_bytes(proc.stdout)
(work / 'stderr.log').write_bytes(proc.stderr)
(work / 'command.json').write_text(json.dumps(command))
print(json.dumps({'artifacts': str(work), 'exit': proc.returncode,
                  'stdout_bytes': len(proc.stdout), 'result': json.loads((work / 'result.json').read_text())}))
print(proc.stderr.decode(errors='replace'))
