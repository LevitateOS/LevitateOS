from pathlib import Path
import subprocess,os,tempfile,json,hashlib,tarfile,io,re
repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux');root=Path('/tmp/ginux-contribution-preparation/G06a');src=root/'source'
def git(*args,env=None,input=None):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*args],env=env,input=input)
composition=json.loads((root/'composition.json').read_text());base=composition['base']
expected=['crates/ginux-process/src/lib.rs']
with tempfile.TemporaryDirectory(prefix='ginux-g03c-index-') as temp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(temp)/'index')};git('read-tree',base,env=env)
 entries={}
 for line in git('ls-tree','-r',base).decode().splitlines():
  info,name=line.split('\t');mode,kind,blob=info.split();entries[name]=(mode,blob)
 changed=[]
 for name in sorted(set(entries)|set(expected)):
  p=src/name;assert p.exists(),name
  data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes();mode,old=entries.get(name,('100644',None));blob=git('hash-object','-w','--stdin',input=data).decode().strip()
  if blob!=old:git('update-index','--add','--cacheinfo',mode,blob,name,env=env);changed.append(name)
 assert changed==sorted(expected),changed
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip()
 msg=('fix(process): adopt orphans after the last parent thread exits\n\n'
 'Reparent children to a live virtual init group when the final running\n'
 'member of their parent thread group exits or is signaled. Keep children\n'
 'with their process while another thread remains alive, and never adopt\n'
 'into an init group that has already died.\n\n'
 'Cover normal and signaled exits, thread-origin forks, live init threads\n'
 'and subsequent waits while retaining the current status/wait API.\n\n'
 f'Signed-off-by: {name} <{email}>\n')
 head=git('commit-tree',tree,'-p',base,input=msg.encode()).decode().strip()
patch=git('format-patch','-1','--stdout','--no-signature',head)
assert b'Levitate' not in patch and b'Recipe' not in patch
assert not git('diff','--summary','--diff-filter=M',base,head)
git('diff','--check',base,head)
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head,'--'))
m={'packet':'G06a','parent_packet':'G06','purpose':'process-table orphan adoption after final parent-thread retirement','upstream_base':git('rev-parse','3f2fe7df').decode().strip(),'base':base,'local_prerequisites':composition['dependencies'],'head':head,'tree':tree,'changed_files':changed,'patch_sha256':hashlib.sha256(patch).hexdigest(),'unit_tests':sum(int(x) for x in re.findall(r'test result: ok\. (\d+) passed',(root/'validation-static-build.log').read_text())),'standalone':True,'status':'review and clean replay pending','remote_ci':'not run; publication unauthorized'}
(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
