from pathlib import Path
import subprocess,os,tempfile,json,hashlib,re
repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux');root=Path('/tmp/ginux-contribution-preparation/G06b');src=root/'source'
def git(*args,env=None,input=None):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*args],env=env,input=input)
c=json.loads((root/'composition.json').read_text());base=c['base'];expected=json.loads((root/'changed-files.json').read_text())
with tempfile.TemporaryDirectory(prefix='ginux-g06b-index-') as temp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(temp)/'index')};git('read-tree',base,env=env)
 entries={}
 for line in git('ls-tree','-r',base).decode().splitlines():
  info,name=line.split('\t');mode,kind,blob=info.split();entries[name]=(mode,blob)
 changed=[]
 for name in sorted(set(entries)|set(expected)):
  p=src/name;assert p.exists(),name
  data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes();mode,old=entries.get(name,('100644',None));blob=git('hash-object','-w','--stdin',input=data).decode().strip()
  if blob!=old:git('update-index','--add','--cacheinfo',mode,blob,name,env=env);changed.append(name)
 assert changed==sorted(expected),changed
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip()
 msg=('feat(launch): supervise configured child and exec lifecycles\n\n'
 'Own bounded process identities and descriptor snapshots before children\n'
 'run. Join fork, image exec, child waits and signals to shared filesystem,\n'
 'device and pipe ownership; drain descendants when init exits.\n\n'
 'Commit CLOEXEC retirement only after successful exec, preserve public\n'
 'state on failure, and validate kernel-selected interpreter authority.\n'
 'Keep typed child outcomes and all-or-nothing TID/status writes while\n'
 'reaping children even when wait status copyout faults.\n\n'
 f'Signed-off-by: {name} <{email}>\n')
 head=git('commit-tree',tree,'-p',base,input=msg.encode()).decode().strip()
patch=git('format-patch','-1','--stdout','--no-signature',head)
assert b'Levitate' not in patch and b'Recipe' not in patch
assert not git('diff','--summary','--diff-filter=M',base,head)
git('diff','--check',base,head)
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head,'--'))
m={'packet':'G06b','parent_packet':'G06','purpose':'configured bounded child/exec lifecycle with shared descriptor ownership','upstream_base':c['upstream'],'base':base,'local_prerequisites':c['dependencies'],'head':head,'tree':tree,'changed_files':changed,'patch_sha256':hashlib.sha256(patch).hexdigest(),'unit_tests':sum(int(x) for x in re.findall(r'test result: ok\. (\d+) passed',(root/'validation-static-build.log').read_text())),'standalone':False,'status':'self-review complete; race repetition and clean replay pending','remote_ci':'not run; publication unauthorized'}
(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
c['status']='conflicts resolved; source reviewed and locally validated; clean replay pending';c['merge_conflicts_resolution']='All listed initial conflicts resolved by retaining current-main owners and adapting selected donor behavior.';(root/'composition.json').write_text(json.dumps(c,indent=2)+'\n')
print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
