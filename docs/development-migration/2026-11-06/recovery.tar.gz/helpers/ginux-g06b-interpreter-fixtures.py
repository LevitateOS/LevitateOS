from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G06b/source')
(src/'tests/fixtures/launch-interpreter-fixture.S').write_text('''/* A PIE that names an interpreter hidden by the memory assignment. */
.global _start
.text
_start:
    mov $88, %edi
    mov $60, %eax
    syscall
    ud2
.section .note.GNU-stack,"",@progbits
''')
p=src/'Makefile';s=p.read_text();needle='''\t$(CC) -nostdlib -static -fno-stack-protector -fno-builtin -O2 -Wall -Wextra -Werror tests/fixtures/launch-exec-fixture.c -o .artifacts/launch/launch-exec-fixture''';assert needle in s;s=s.replace(needle,needle+'''\n\t$(CC) -nostdlib -pie -Wl,--dynamic-linker=/work/hidden tests/fixtures/launch-interpreter-fixture.S -o .artifacts/launch/launch-interpreter-fixture''',1).replace('scripts/test-launch-exec.py $(GINUX) .artifacts/launch/launch-exec-fixture','scripts/test-launch-exec.py $(GINUX) .artifacts/launch/launch-exec-fixture .artifacts/launch/launch-interpreter-fixture',1);p.write_text(s)
p=src/'tests/fixtures/launch-exec-fixture.c';s=p.read_text().replace("    if (mode=='a') {",'''    if (mode=='/') return 77; // Interpreter of the allowed image script.
    if (mode=='u') {
        char *args[]={"probe",0};
        for(word i=0;i<4;++i) {
            const char *paths[]={"/image-script","/image-elf","/link-script","/mixed-script"};
            CHECK(DO(59,paths[i],args,empty_env)==-95,73);
        }
        CHECK(call(322,-100,(word)"/image-elf",(word)args,(word)empty_env,0x100,0)==-95,74);
        for(word i=0;i<2;++i) {
            long fd=DO(2,i?"/image-elf":"/image-script",0,0);
            CHECK(fd>=3,75);
            CHECK(call(322,fd,(word)"",(word)args,(word)empty_env,0x1000,0)==-95,76);
            CHECK(DO(3,fd,0,0)==0,77);
        }
        long child=DO(57,0,0,0);
        if(child==0) { DO(59,"/allowed-script",args,empty_env); return 78; }
        int status=-1;
        CHECK(child==2 && DO(61,child,&status,0)==child && status==(77<<8),79);
        CHECK(DO(1,1,"interpreter-guards: PASS\\n",25)==25,80);
        return 0;
    }
    if (mode=='a') {''',1)
# Actual length is 25 including the newline.
assert len('interpreter-guards: PASS\n')==25
p.write_text(s)
p=src/'scripts/test-launch-exec.py';s=p.read_text().replace('if len(sys.argv) != 3', 'if len(sys.argv) != 4',1).replace('<ginux> <exec-fixture>', '<ginux> <exec-fixture> <interpreter-fixture>',1).replace('binary, fixture = [str(Path(p).resolve()) for p in sys.argv[1:]]','binary, fixture, interpreter = [str(Path(p).resolve()) for p in sys.argv[1:]]',1)
s=s.replace("        (root / 'owned-link').symlink_to('/work/hidden')", "        (root / 'owned-link').symlink_to('/work/hidden')\n        (root / 'work/nested').mkdir()\n        (root / 'virtual').symlink_to('/work/nested')\n        shutil.copyfile(fixture, root / 'hidden')\n        (root / 'hidden').chmod(0o755)\n        shutil.copyfile(interpreter, root / 'image-elf')\n        (root / 'image-elf').chmod(0o755)\n        for name, target in [('image-script', '/work/hidden'), ('allowed-script', '/bin/second'),\n                             ('link-script', '/owned-link'), ('mixed-script', '/virtual/../hidden')]:\n            (root / name).write_text('#!' + target + '\\n')\n            (root / name).chmod(0o755)")
s=s.replace('[storage]\\nassignments = ["memory:/work"]','[storage]\\nassignments = ["memory:/work", "memory:/virtual"]',1)
needle="        for mode in ('success', 'bad', 'child', 'descriptor', 'path', 'relative', 'link'):";assert needle in s
block='''        for initial, mode, expected in [('/bin/fixture', 'u-guards', 0),
                                        ('/image-script', '', 1), ('/image-elf', '', 1),
                                        ('/allowed-script', '', 77)]:
            label=initial.strip('/').replace('/', '-') + '-' + (mode or 'initial')
            path, result = work / (label+'.toml'), work / (label+'.json')
            text=config.replace('init = "/bin/fixture"', 'init = '+json.dumps(initial))
            text=text.replace('args = []', 'args = '+json.dumps([mode] if mode else []))
            path.write_text(text)
            proc=subprocess.run([binary,'launch',str(path),str(root),'--result-file',str(result)],capture_output=True,timeout=20)
            record=json.loads(result.read_text())
            assert proc.returncode==expected, (label,proc.returncode,proc.stderr,record)
            assert record['outcome']==('supervisor-error' if expected==1 else 'exited'),record
            assert proc.stdout==(b'interpreter-guards: PASS\\n' if mode else b''),proc.stdout
            if expected!=1: assert record['code']==expected,record
            print('PASS interpreter ownership:',label)
''';s=s.replace(needle,block+needle,1);p.write_text(s)
