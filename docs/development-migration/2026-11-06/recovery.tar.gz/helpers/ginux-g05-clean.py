from pathlib import Path
import subprocess,tarfile,io,json,hashlib
root=Path('/tmp/ginux-contribution-preparation/G05');repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux');m=json.loads((root/'manifest.json').read_text());fresh=root/'clean-apply';assert not fresh.exists();fresh.mkdir()
def git(*a):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*a])
with tarfile.open(fileobj=io.BytesIO(git('archive',m['base']))) as t:t.extractall(fresh,filter='data')
subprocess.run(['git','apply','--check','--whitespace=error',str(root/'candidate.patch')],cwd=fresh,check=True)
subprocess.run(['git','apply','--whitespace=error',str(root/'candidate.patch')],cwd=fresh,check=True)
paths=git('ls-tree','-r','--name-only',m['head']).decode().splitlines()
for name in paths:
 a=fresh/name;b=root/'source'/name
 if a.is_symlink():assert a.readlink()==b.readlink(),name
 else:assert a.read_bytes()==b.read_bytes(),name
print('Clean local-prerequisite export plus only G05 matches all',len(paths),'tracked paths')
for file in ['crates/ginux-core/src/lib.rs']:
 assert (fresh/file).read_bytes()==git('show',m['base']+':'+file),file
print('Current syscall contract preserved byte for byte')
a=git('show',m['base']+':crates/ginux-init/src/supervisor.rs');b=(fresh/'crates/ginux-init/src/supervisor.rs').read_bytes();assert b==a.replace(b'#[repr(C)]\npub struct UserRegs {',b'#[repr(C)]\n#[derive(Clone, Copy)]\npub struct UserRegs {',1);print('Supervisor unchanged except Clone/Copy on register value type; #221 helpers preserved')
