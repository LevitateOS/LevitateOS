from pathlib import Path
p=Path('/tmp/ginux-contribution-preparation/G03b/source/crates/ginux-vfs/src/lib.rs')
s=p.read_text();at=s.rfind('\n}')
tests='''
    #[test]
    fn owned_paths_check_components_and_preserve_image_link_order() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 8, 32, 4> =
            VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        fs.mkdir(b"/work", 0o755).unwrap();
        fs.mkdir(b"/work/dir", 0o755).unwrap();
        let fd = fs.open(b"/work/dir/file", O_READ | O_WRITE | O_CREATE).unwrap();
        fs.write(fd, b"kept").unwrap();
        assert_eq!(fs.metadata(b"/work/dir/file/../file"), Err(VfsError::NotDirectory));
        assert_eq!(fs.metadata(b"/work/dir/file/."), Err(VfsError::NotDirectory));
        assert_eq!(fs.chmod(b"/work/missing/../dir/file", 0o777), Err(VfsError::NotFound));
        assert_eq!(fs.fstat(fd).unwrap().mode, 0o600);
        fs.mkdir(b"/bin/../created", 0o750).unwrap();
        assert_eq!(fs.metadata(b"/usr/created").unwrap().kind, NodeKind::Directory);
        assert_eq!(fs.metadata(b"/created"), Err(VfsError::NotFound));
        assert_eq!(fs.metadata(b"/bin/sh").unwrap().size, 4);
    }

    #[test]
    fn exclusive_create_and_mkdir_do_not_follow_an_existing_final_link() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 4, 32, 4> =
            VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        assert_eq!(fs.open(b"/loop", O_WRITE | O_CREATE | O_EXCLUSIVE), Err(VfsError::AlreadyExists));
        assert_eq!(fs.open(b"/bin/sh", O_WRITE | O_CREATE | O_EXCLUSIVE), Err(VfsError::AlreadyExists));
        assert_eq!(fs.mkdir(b"/loop", 0o755), Err(VfsError::AlreadyExists));
        assert_eq!(fs.overlay_files(), 0);
    }

    #[test]
    fn seek_shares_alias_position_and_errors_leave_it_unchanged() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 4, 32, 4> =
            VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        let fd = fs.open(b"/new", O_READ | O_WRITE | O_CREATE).unwrap();
        fs.write(fd, b"abc").unwrap();
        let alias = fs.duplicate(fd, false).unwrap();
        fs.seek(alias, 0, 0).unwrap();
        let mut byte = [0];
        assert_eq!(fs.read(fd, &mut byte), Ok(1));
        assert_eq!(&byte, b"a");
        assert_eq!(fs.seek(alias, i64::MAX, 0), Ok(i64::MAX as u64));
        assert_eq!(fs.seek(fd, 1, 1), Err(VfsError::InvalidPath));
        assert_eq!(fs.seek(fd, -1, 0), Err(VfsError::InvalidPath));
        assert_eq!(fs.seek(fd, 0, 99), Err(VfsError::InvalidPath));
        assert_eq!(fs.seek(fd, 0, 1), Ok(i64::MAX as u64));
        assert_eq!(fs.read(fd, &mut byte), Ok(0));
        assert_eq!(fs.write(fd, b""), Ok(0));
        assert_eq!(fs.write(alias, b"x"), Err(VfsError::FileTooLarge));
        assert_eq!(fs.fstat(fd).unwrap().size, 3);
        assert_eq!(fs.seek(fd, -2, 2), Ok(1));
        assert_eq!(fs.read(alias, &mut byte), Ok(1));
        assert_eq!(&byte, b"b");
    }

    #[test]
    fn metadata_and_cloexec_flags_follow_their_distinct_owners() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 4, 32, 4> =
            VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        let fd = fs.open(b"/new", O_READ | O_WRITE | O_CREATE | O_APPEND | O_CLOEXEC).unwrap();
        let alias = fs.duplicate(fd, false).unwrap();
        fs.chmod(b"/new", 0o750).unwrap();
        assert_eq!(fs.fstat(fd), fs.metadata(b"/new"));
        assert_eq!(fs.fstat(alias).unwrap().mode, 0o750);
        assert_eq!(fs.fchmod(alias, 0o4755), Err(VfsError::PermissionDenied));
        assert_eq!(fs.fstat(fd).unwrap().mode, 0o750);
        assert_eq!(fs.descriptor_flags(fd), Ok((0o2002, true)));
        assert_eq!(fs.descriptor_flags(alias), Ok((0o2002, false)));
        fs.set_close_on_exec(alias, true).unwrap();
        fs.set_close_on_exec(fd, false).unwrap();
        fs.close_on_exec();
        assert_eq!(fs.fstat(alias), Err(VfsError::InvalidDescriptor));
        assert!(fs.fstat(fd).is_ok());
        let image = fs.open(b"/base", O_READ).unwrap();
        assert_eq!(fs.fchmod(image, 0o600), Err(VfsError::PermissionDenied));
        assert_eq!(fs.chmod(b"/usr", 0o700), Err(VfsError::PermissionDenied));
    }

    #[test]
    fn directory_capacity_failure_and_unlink_preserve_existing_objects() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 2, 32, 4> =
            VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        let old = fs.open(b"/base", O_READ | O_WRITE).unwrap();
        let old_inode = fs.fstat(old).unwrap().inode;
        fs.unlink(b"/base").unwrap();
        fs.mkdir(b"/base", 0o755).unwrap();
        assert_ne!(fs.metadata(b"/base").unwrap().inode, old_inode);
        assert_eq!(fs.metadata(b"/base").unwrap().kind, NodeKind::Directory);
        assert_eq!(fs.unlink(b"/base"), Err(VfsError::IsDirectory));
        assert_eq!(fs.open(b"/base", O_READ), Err(VfsError::IsDirectory));
        assert_eq!(fs.mkdir(b"/base/child", 0o755), Err(VfsError::OverlayLimit));
        assert_eq!(fs.metadata(b"/base/child"), Err(VfsError::NotFound));
        let mut contents = [0; 4];
        assert_eq!(fs.read(old, &mut contents), Ok(4));
        assert_eq!(&contents, b"BASE");
        fs.close(old).unwrap();
        fs.mkdir(b"/base/child", 0o755).unwrap();
        assert_eq!(fs.metadata(b"/base/child").unwrap().kind, NodeKind::Directory);
    }

    #[test]
    fn sparse_write_after_truncate_never_restores_discarded_bytes() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 2, 32, 4> =
            VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        let fd = fs.open(b"/new", O_READ | O_WRITE | O_CREATE).unwrap();
        fs.write(fd, b"secret").unwrap();
        let trunc = fs.open(b"/new", O_WRITE | O_TRUNC).unwrap();
        fs.close(trunc).unwrap();
        fs.seek(fd, 3, 0).unwrap();
        fs.write(fd, b"x").unwrap();
        fs.seek(fd, 0, 0).unwrap();
        let mut contents = [0xff; 4];
        assert_eq!(fs.read(fd, &mut contents), Ok(4));
        assert_eq!(&contents, b"\\0\\0\\0x");
    }
'''
p.write_text(s[:at]+tests+s[at:])
Path('/tmp/ginux-contribution-preparation/G03b/review-tests.txt').write_text(tests)
