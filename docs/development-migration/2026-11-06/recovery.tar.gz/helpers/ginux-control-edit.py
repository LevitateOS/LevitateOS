from pathlib import Path
root=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
p=root/'crates/ginux-init/src/storage_export.rs';s=p.read_text();s=s.replace('''    let mut length = 0;''','''    unsafe { EXPORT_FD = create(path)?; }
    Ok(())
}

fn create(path: *const u8) -> Result<isize, Error> {
    let mut length = 0;''',1);s=s.replace('''    unsafe {
        EXPORT_FD = fd;
    }
    Ok(())
}

pub fn finish''','''    Ok(fd)
}

pub fn capture(path: *const u8, write: impl FnOnce(&mut Archive) -> Result<(), Error>) -> Result<(), Error> {
    complete(create(path)?, write)
}

pub fn finish''',1);s=s.replace('''    let mut archive = Archive(fd as usize);''','''    complete(fd, write)
}

fn complete(fd: isize, write: impl FnOnce(&mut Archive) -> Result<(), Error>) -> Result<(), Error> {
    let mut archive = Archive(fd as usize);''',1);p.write_text(s)
p=root/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();a=s.index('    pub fn export(&self)');b=s.index('    pub fn teardown',a);s=s[:a]+'''    pub fn export(&self) -> Result<(), &'static [u8]> {
        crate::storage_export::finish(|archive| self.write_archive(archive))
    }

    pub fn snapshot(&self, path: *const u8) -> Result<(), &'static [u8]> {
        crate::storage_export::capture(path, |archive| self.write_archive(archive))
    }

    fn write_archive(&self, archive: &mut crate::storage_export::Archive) -> Result<(), &'static [u8]> {
        for slot in 0..OBJECTS {
            if let Some((path, metadata)) = self.fs.overlay_entry(slot) {
                archive.entry(path, metadata, |offset, buffer| {
                    self.fs.read_overlay(slot, offset, buffer).map_err(|_| b"export read failed".as_slice())
                })?;
            }
        }
        Ok(())
    }

'''+s[b:];p.write_text(s)
p=root/'crates/ginux-init/src/launch.rs';s=p.read_text();s=s.replace('    Launch(*const u8, *const u8, *const u8, *const u8),','    Launch(*const u8, *const u8, *const u8, *const u8, Option<usize>),');s=s.replace('        let mut i = 4;','        let mut control_fd = None;\n        let mut i = 4;',1);s=s.replace('''            } else {
                return Some(Command::LaunchUsage);
            }
            i += 2;''','''            } else if c_string_equals(option, b"--control-fd") && control_fd.is_none() {
                control_fd = parse_control_fd(value);
                if control_fd.is_none() { return Some(Command::LaunchUsage); }
            } else {
                return Some(Command::LaunchUsage);
            }
            i += 2;''',1);s=s.replace('''            export_path,
        ))''','''            export_path,
            control_fd,
        ))''',1)
a=s.index('\npub fn load_config(');s=s[:a]+'''
fn parse_control_fd(value: *const u8) -> Option<usize> {
    let mut fd = 0usize;
    for i in 0..6 {
        let byte = unsafe { core::ptr::read_volatile(value.add(i)) };
        if byte == 0 { return (i != 0 && (3..=65535).contains(&fd)).then_some(fd); }
        if !byte.is_ascii_digit() { return None; }
        fd = fd * 10 + (byte - b'0') as usize;
    }
    None
}
'''+s[a:];s=s.replace('''    export_path: *const u8,
) -> ! {''','''    export_path: *const u8,
    control_fd: Option<usize>,
) -> ! {''',1);s=s.replace('    let config = launch_load_config(config_path);','    crate::checkpoint_control::prepare(control_fd).unwrap_or_else(|reason| launch_startup_fail(reason));\n    let config = launch_load_config(config_path);',1);s=s.replace('[--export-file <fresh tar path>]','[--export-file <fresh tar path>] [--control-fd <inherited socket>]');p.write_text(s)
p=root/'crates/ginux-init/src/main.rs';s=p.read_text().replace('mod channel_hooks;','mod channel_hooks;\nmod checkpoint_control;').replace('Some(Command::Launch(config_path, root_path, result_path, export_path)) => {\n            launch_main(config_path, root_path, result_path, export_path)','Some(Command::Launch(config_path, root_path, result_path, export_path, control_fd)) => {\n            launch_main(config_path, root_path, result_path, export_path, control_fd)');p.write_text(s)
p=root/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text().replace('''    loop {
        let polling = s
            .tasks''','''    loop {
        // No owned mutation can interleave with snapshot serialization here.
        // Native mappings only hold readonly backing references.
        if let Err(reason) = crate::checkpoint_control::poll(&s.objects.filesystem) {
            s.fail(domain, reason);
        }
        let polling = crate::checkpoint_control::enabled() || s
            .tasks''',1);p.write_text(s)
