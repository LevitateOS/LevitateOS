from pathlib import Path
import subprocess,os,tempfile,json,hashlib,tarfile,io,re
r=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
root=Path('/tmp/ginux-contribution-preparation/G03a')
base='3f2fe7dfadd4b40e235d982a6a3d386dc6490177'
files=['crates/ginux-init/src/launch.rs','scripts/test-launch.py']
def git(*args,env=None,input=None):return subprocess.check_output(['git','-C',str(r),'--work-tree='+str(r),*args],env=env,input=input)
with tempfile.TemporaryDirectory(prefix='ginux-g03a-index-') as temp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(temp)/'index')};git('read-tree',base,env=env)
 for f in files:
  blob=git('hash-object','-w','--stdin',input=(root/'source'/f).read_bytes()).decode().strip()
  mode=git('ls-tree',base,'--',f).decode().split()[0]
  git('update-index','--add','--cacheinfo',mode,blob,f,env=env)
 tree=git('write-tree',env=env).decode().strip()
 name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip()
 msg=('fix(launch): use mkdirat when creating the workload directory\n\n'
      'Use the x86-64 mkdirat syscall number instead of mknodat so launch\n'
      'can enter a configured working directory that does not exist yet.\n'
      'Add a real launch regression that checks the created directory.\n\n'
      f'Signed-off-by: {name} <{email}>\n')
 head=git('commit-tree',tree,'-p',base,input=msg.encode()).decode().strip()
# Preserve the original mode of every path (do not introduce executable churn).
stat=git('diff','--summary',base,head).decode();assert not stat,stat
patch=git('format-patch','-1','--stdout','--no-signature',head)
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head,'--'))
assert git('diff','--name-only',base,head).decode().splitlines()==files
fresh=root/'clean-apply';assert not fresh.exists();fresh.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(fresh,filter='data')
subprocess.run(['git','apply','--check',str(root/'candidate.patch')],cwd=fresh,check=True)
subprocess.run(['git','apply',str(root/'candidate.patch')],cwd=fresh,check=True)
for name in git('ls-tree','-r','--name-only',base).decode().splitlines():
 a=fresh/name;b=root/'source'/name
 if a.is_symlink():assert a.readlink()==b.readlink()
 elif a.is_file():assert a.read_bytes()==b.read_bytes(),name
m={'packet':'G03a','parent_packet':'G03','purpose':'correct existing bootstrap mkdirat syscall','base':base,'head':head,'tree':tree,'changed_files':files,'patch_sha256':hashlib.sha256(patch).hexdigest(),'source_hashes':{f:hashlib.sha256((root/'source'/f).read_bytes()).hexdigest() for f in files},'unit_tests':sum(int(x) for x in re.findall(r'test result: ok\. (\d+) passed',(root/'static-unit.log').read_text())),'baseline':'exact upstream3f2fe7df fails the missing-workdir real launch regression with supervisor-error exit2','standalone':True,'status':'local runtime/clean replay finishing; user review and remote CI pending'}
(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
(root/'title.txt').write_text('fix(launch): use mkdirat when creating the workload directory\n')
(root/'body.md').write_text('''Launching with an absent working directory calls x86-64 syscall259 (`mknodat`) and then fails to enter it. Use `mkdirat` (258) and cover creation of the configured directory in the existing launch suite.

The regression fails on upstream `3f2fe7df`. Static/unit, build and required Linux launch/native/process/setup checks pass locally. macOS Actions and the full Rocky VM suite have not run on this unpublished candidate.
''')
print('G03a standalone local commit:',head,'unit count:',m['unit_tests'])
