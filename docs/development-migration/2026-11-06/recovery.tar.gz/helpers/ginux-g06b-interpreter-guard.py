from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G06b/source')
p=src/'crates/ginux-init/src/path_hooks.rs';s=p.read_text();needle='''    pub fn lookup(
''';method='''    /// Inspect only the kernel loader's interpreter metadata. The descriptor
    /// stays private and is closed on every return path.
    pub fn interpreter(&self, path: &[u8], output: &mut [u8; MAX_PATH]) -> Result<Option<(usize, bool)>, i64> {
        let mut name = [0; MAX_PATH + 1];
        let path = path.strip_prefix(b"/").ok_or(-22)?;
        name[..path.len()].copy_from_slice(path);
        let fd = unsafe { syscall4(257, self.0, name.as_ptr() as usize, 0o2400000, 0) };
        if fd < 0 { return Err(fd as i64); }
        let file = ImageFile(fd as usize);
        let mut first = [0; 256];
        let n = file.read(0, &mut first)?;
        if first[..n].starts_with(b"#!") {
            let mut start = 2;
            while start < n && matches!(first[start], b' ' | b'\\t') { start += 1; }
            let mut end = start;
            while end < n && !matches!(first[end], 0 | b' ' | b'\\t' | b'\\n') { end += 1; }
            if start == end || end == first.len() { return Err(-8); }
            output[..end-start].copy_from_slice(&first[start..end]);
            return Ok(Some((end-start, true)));
        }
        if n < 64 || &first[..6] != b"\\x7fELF\\x02\\x01" { return Ok(None); }
        let offset = u64::from_le_bytes(first[32..40].try_into().unwrap());
        let size = u16::from_le_bytes(first[54..56].try_into().unwrap());
        let count = u16::from_le_bytes(first[56..58].try_into().unwrap()) as usize;
        if size != 56 { return Err(-8); }
        offset.checked_add((count * 56) as u64).ok_or(-8)?;
        let mut buffer = [0; 56 * 73];
        let mut index = 0;
        let mut interpreter = None;
        while index < count {
            let headers = (count-index).min(73);
            let bytes = headers * 56;
            if file.read(offset + (index*56) as u64, &mut buffer[..bytes])? != bytes { return Err(-8); }
            for header in buffer[..bytes].chunks_exact(56) {
                if u32::from_le_bytes(header[..4].try_into().unwrap()) != 3 { continue; }
                if interpreter.is_some() { return Err(-8); }
                interpreter = Some((u64::from_le_bytes(header[8..16].try_into().unwrap()),
                    u64::from_le_bytes(header[32..40].try_into().unwrap())));
            }
            index += headers;
        }
        let Some((offset, length)) = interpreter else { return Ok(None); };
        if length == 0 { return Err(-8); }
        if length > MAX_PATH as u64 { return Err(-36); }
        let length = length as usize;
        if file.read(offset, &mut output[..length])? != length || output[length-1] != 0 { return Err(-8); }
        let end = output[..length].iter().position(|byte| *byte == 0).ok_or(-8)?;
        if end == 0 { return Err(-8); }
        Ok(Some((end, false)))
    }

    pub fn resolve_image(&self, path: &[u8], output: &mut [u8; MAX_PATH]) -> Result<usize, VfsError> {
        ginux_vfs::resolve_namespace(path, true, false, output, |path, target| self.lookup(path, target))
    }

''';assert needle in s;s=s.replace(needle,method+needle,1)
needle='pub struct Rewrite {';helper='''struct ImageFile(usize);
impl ImageFile {
    fn read(&self, offset: u64, output: &mut [u8]) -> Result<usize, i64> {
        let n = unsafe { syscall4(17, self.0, output.as_mut_ptr() as usize, output.len(), offset as usize) };
        if n < 0 { Err(n as i64) } else { Ok(n as usize) }
    }
}
impl Drop for ImageFile {
    fn drop(&mut self) { unsafe { syscall1(3, self.0); } }
}

''';assert needle in s;s=s.replace(needle,helper+needle,1);p.write_text(s)
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text().replace('    cwd: Path,','    cwd: Path,\n    init: Path,',1).replace('''            cwd: Path::from_bytes(config.workdir.as_bytes())''','''            init: Path::from_bytes(config.init.as_bytes()).map_err(|_| b"init path exceeds bound".as_slice())?,
            cwd: Path::from_bytes(config.workdir.as_bytes())''',1)
a=s.index('    /// Image execution never reopens');b=s.index('    /// Configured-launch dispatch',a)
s=s[:a]+'''    /// Image execution never reopens assigned paths, including implicit script
    /// and ELF interpreters selected by the native kernel loader.
    pub fn native_exec_path(&self, pid: usize, address: u64, follow: bool) -> Result<(), i64> {
        let path = self.path(pid, address, (-100i64) as u64)?;
        let path = self.resolve(pid, path.as_bytes(), follow, true)?;
        self.check_exec_owner(path.as_bytes())?;
        if !follow { return Ok(()); } // Kernel rejects a final symlink itself.
        self.check_interpreters(pid, path)
    }

    pub fn validate_initial_exec(&self, pid: usize) -> Result<(), i64> {
        let path = self.resolve(pid, self.init.as_bytes(), true, false)?;
        self.check_exec_owner(path.as_bytes())?;
        let image = crate::path_hooks::ImageRoot::new(pid)?;
        let mut physical = [0; MAX_PATH];
        let length = image.resolve_image(self.init.as_bytes(), &mut physical).map_err(errno)?;
        if physical[..length] != *path.as_bytes() { return Err(-95); }
        self.check_interpreters(pid, path)
    }

    fn check_exec_owner(&self, path: &[u8]) -> Result<(), i64> {
        if self.owns_path(path) { return Err(-95); }
        if [b"/dev".as_slice(), b"/proc", b"/sys"].iter().any(|p| within(path, p)) { return Err(-13); }
        Ok(())
    }

    fn check_interpreters(&self, pid: usize, mut path: Path) -> Result<(), i64> {
        let image = crate::path_hooks::ImageRoot::new(pid)?;
        for _ in 0..16 {
            let mut name = [0; MAX_PATH];
            let Some((length, script)) = image.interpreter(path.as_bytes(), &mut name)? else { return Ok(()); };
            // Relative interpreters, like relative exec paths, use the domain cwd.
            let mut joined = [0; MAX_PATH];
            let base = if name.first() == Some(&b'/') { b"".as_slice() } else { self.cwd.as_bytes() };
            let separator = usize::from(!base.is_empty() && base != b"/");
            let end = base.len().checked_add(separator).and_then(|n| n.checked_add(length))
                .filter(|end| *end < MAX_PATH).ok_or(-36)?;
            joined[..base.len()].copy_from_slice(base);
            if separator != 0 { joined[base.len()] = b'/'; }
            joined[base.len()+separator..end].copy_from_slice(&name[..length]);
            path = self.resolve(pid, &joined[..end], true, true)?;
            self.check_exec_owner(path.as_bytes())?;
            // A loader pathname cannot be rewritten inside immutable image bytes.
            // Require its native and domain resolutions to name the same file.
            let mut physical = [0; MAX_PATH];
            let n = image.resolve_image(&joined[..end], &mut physical).map_err(errno)?;
            if physical[..n] != *path.as_bytes() { return Err(-95); }
            if !script { return Ok(()); }
        }
        Err(-40)
    }

'''+s[b:];p.write_text(s)
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text();needle='''    let mut processes = ProcessTable::new();''';assert needle in s;s=s.replace(needle,'''    if objects.filesystem.validate_initial_exec(root).is_err() {
        let _ = unsafe { syscall2(SYS_KILL, root, SIGKILL) };
        while wait(root, &mut status) == -4 {}
        supervision_error(domain, b"initial executable interpreter is outside its image namespace");
    }
'''+needle,1);p.write_text(s)
