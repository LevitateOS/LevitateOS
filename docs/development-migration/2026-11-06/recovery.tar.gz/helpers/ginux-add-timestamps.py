from pathlib import Path
b=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
p=b/'crates/ginux-vfs/src/lib.rs';s=p.read_text();pos=s.index('/// Metadata from the domain image/overlay')
s=s[:pos]+'''/// Explicit domain inode timestamps, independent of host file identities.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Timestamp {
    pub seconds: i64,
    pub nanoseconds: u32,
}
impl Timestamp {
    pub const ZERO: Self = Self { seconds: 0, nanoseconds: 0 };
}

'''+s[pos:]
s=s.replace('pub struct FileMetadata {','pub struct FileMetadata {\n    pub accessed: Timestamp,\n    pub modified: Timestamp,')
s=s.replace('pub struct OverlayFile {','pub struct OverlayFile {\n    accessed: Timestamp,\n    modified: Timestamp,')
s=s.replace('''impl OverlayFile {
    pub const fn empty() -> Self {
        Self {''','''impl OverlayFile {
    pub const fn empty() -> Self {
        Self {
            accessed: Timestamp::ZERO,
            modified: Timestamp::ZERO,''')
s=s.replace('''        FileMetadata {
            inode:''','''        FileMetadata {
            accessed: entry.accessed,
            modified: entry.modified,
            inode:''')
s=s.replace('''        Ok(FileMetadata {
            inode:''','''        Ok(FileMetadata {
            accessed: Timestamp::ZERO,
            modified: Timestamp::ZERO,
            inode:''')
s=s.replace('''            Ok(FileMetadata {
                inode: (self.index.len()''','''            Ok(FileMetadata {
                accessed: file.accessed,
                modified: file.modified,
                inode: (self.index.len()''')
s=s.replace('''            Ok(FileMetadata {
                inode: (descriptor.object''','''            Ok(FileMetadata {
                accessed: Timestamp::ZERO,
                modified: Timestamp::ZERO,
                inode: (descriptor.object''')
pos=s.index('    pub fn fchmod(')
s=s[:pos]+'''    pub fn set_times(&mut self, path: &[u8], follow: bool, accessed: Option<Timestamp>, modified: Option<Timestamp>) -> Result<(), VfsError> {
        let path = self.resolved_path(path, follow, false)?;
        let slot = self.find_overlay(path.as_bytes()).ok_or(VfsError::PermissionDenied)?;
        if self.overlay[slot].state == 2 { return Err(VfsError::NotFound); }
        self.set_object_times(self.object(slot), accessed, modified)
    }
    pub fn fset_times(&mut self, fd: i32, accessed: Option<Timestamp>, modified: Option<Timestamp>) -> Result<(), VfsError> {
        let descriptor = self.descriptors[self.descriptor(fd)?];
        if !descriptor.overlay { return Err(VfsError::PermissionDenied); }
        self.set_object_times(descriptor.object, accessed, modified)
    }
    fn set_object_times(&mut self, object: usize, accessed: Option<Timestamp>, modified: Option<Timestamp>) -> Result<(), VfsError> {
        if [accessed, modified].iter().flatten().any(|time| time.nanoseconds >= 1_000_000_000) {
            return Err(VfsError::InvalidPath);
        }
        if let Some(time) = accessed { self.overlay[object].accessed = time; }
        if let Some(time) = modified { self.overlay[object].modified = time; }
        Ok(())
    }

'''+s[pos:];p.write_text(s)
p=b/'crates/ginux-init/src/tracee_io.rs';s=p.read_text().replace('pub struct Stat {','pub struct Stat {\n    pub accessed: ginux_vfs::Timestamp,\n    pub modified: ginux_vfs::Timestamp,');needle='''    bytes[ino..ino + 8].copy_from_slice(&metadata.inode.to_le_bytes());'''
s=s.replace(needle,'''    for (index, time) in [metadata.accessed, metadata.modified].iter().enumerate() {
        let offset = if statx { 64 + index * 48 } else { 72 + index * 16 };
        bytes[offset..offset + 8].copy_from_slice(&time.seconds.to_le_bytes());
        if statx {
            bytes[offset + 8..offset + 12].copy_from_slice(&time.nanoseconds.to_le_bytes());
        } else {
            bytes[offset + 8..offset + 16].copy_from_slice(&(time.nanoseconds as u64).to_le_bytes());
        }
    }
'''+needle);p.write_text(s)
# Update all projection constructors: devices and channels retain zero timestamps.
for p in (b/'crates/ginux-init/src').glob('*.rs'):
    if p.name=='tracee_io.rs':continue
    s=p.read_text()
    import re
    s=re.sub(r'(\b(?:crate::tracee_io::)?Stat \{\n)(?!\s*pub)',r'\1            accessed: ginux_vfs::Timestamp::ZERO,\n            modified: ginux_vfs::Timestamp::ZERO,\n',s)
    if p.name=='fs_hooks.rs':
        s=s.replace('accessed: ginux_vfs::Timestamp::ZERO,\n            modified: ginux_vfs::Timestamp::ZERO,','accessed: metadata.accessed,\n            modified: metadata.modified,')
    p.write_text(s)
p=b/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text().replace('    pub hardlink: bool,','    pub hardlink: bool,\n    pub modified: u64,')
s=s.replace('''        let fd = r.rdi as i32;
        if matches!(''','''        let fd = r.rdi as i32;
        if r.orig_rax == 280 && r.rsi == 0 {
            return Some(if (FD_BASE as i32..FD_BASE as i32 + 64).contains(&fd) {
                self.descriptor_call(pid, r, fd - FD_BASE as i32 + 3)
            } else { -9 });
        }
        if matches!(''')
s=s.replace('257 | 258 | 262 | 263 | 267 | 268 | 269 | 332 | 439 => (r.rsi, r.rdi),','257 | 258 | 262 | 263 | 267 | 268 | 269 | 280 | 332 | 439 => (r.rsi, r.rdi),')
s=s.replace('''            262 => r.r10 & 0x100 == 0,''','''            262 | 280 => r.r10 & 0x100 == 0,''')
s=s.replace('''            4 | 6 => self.stat(pid, path.as_bytes(), r.rsi, false),''','''            4 | 6 => self.stat(pid, path.as_bytes(), r.rsi, false),
            280 => self.timestamps(pid, r).and_then(|times| self.fs.set_times(path.as_bytes(), false, times[0], times[1]).map(|_| 0).map_err(errno)),''')
s=s.replace('''            73 => self.flock(fd, r.rsi),''','''            280 if r.r10 == 0 => self.timestamps(pid, r).and_then(|times| self.fs.fset_times(fd, times[0], times[1]).map(|_| 0).map_err(errno)),
            280 => Err(-22),
            73 => self.flock(fd, r.rsi),''')
pos=s.index('    fn flock(')
s=s[:pos]+'''    fn timestamps(&self, pid: usize, r: &UserRegs) -> Result<[Option<ginux_vfs::Timestamp>; 2], i64> {
        if r.r10 & !0x100 != 0 { return Err(-22); }
        let mut bytes = [0u8; 32];
        if r.rdx != 0 && copy_memory(pid, r.rdx, &mut bytes, false)? != 32 { return Err(-14); }
        let mut times = [None; 2];
        let mut now = None;
        for (index, time) in times.iter_mut().enumerate() {
            let seconds = i64::from_ne_bytes(bytes[index*16..index*16+8].try_into().unwrap());
            let nanos = if r.rdx == 0 { (1<<30)-1 } else { i64::from_ne_bytes(bytes[index*16+8..index*16+16].try_into().unwrap()) };
            *time = match nanos {
                1_073_741_822 => None,
                1_073_741_823 => {
                    if now.is_none() {
                        let mut clock = [0i64; 2];
                        if unsafe { crate::supervisor::syscall2(228, 0, clock.as_mut_ptr() as usize) } != 0 { return Err(-5); }
                        now = Some(ginux_vfs::Timestamp {seconds:clock[0], nanoseconds:clock[1] as u32});
                    }
                    now
                },
                0..=999_999_999 => Some(ginux_vfs::Timestamp {seconds, nanoseconds:nanos as u32}),
                _ => return Err(-22),
            };
        }
        Ok(times)
    }

'''+s[pos:]
# Restore metadata is assigned after contents, and aliases must agree with their prior inode.
s=s.replace('''        // This launch view has a one-entry immutable root;''','''        self.fs.set_times(path, false, None, Some(ginux_vfs::Timestamp {seconds: entry.modified as i64, nanoseconds: 0}))
            .map_err(|_| b"restore timestamp failed".as_slice())?;
        // This launch view has a one-entry immutable root;''')
# Locate existing hardlink mode check after inspection if names differ.
s=s.replace('metadata.mode != mode', 'metadata.mode != mode || metadata.modified.seconds != entry.modified as i64')
p.write_text(s)
p=b/'crates/ginux-init/src/descriptors.rs';s=p.read_text().replace('''            72 => {
                call.save(r);''','''            280 if r.rsi == 0 => {
                call.save(r);
                self.get(r.rdi).and_then(|d| self.descriptor(pid, r, d, backends, call))
            }
            72 => {
                call.save(r);''').replace('258 | 262 | 263 | 267 | 268 | 269 | 332 | 439 => {','258 | 262 | 263 | 267 | 268 | 269 | 280 | 332 | 439 => {');p.write_text(s)
p=b/'crates/ginux-init/src/storage_restore.rs';s=p.read_text().replace('''                mode: mode as u32,''','''                mode: mode as u32,
                modified: octal(&header[136..148])?,''');p.write_text(s)
p=b/'crates/ginux-init/src/storage_export.rs';s=p.read_text().replace('b\'L\', b"")?', 'b\'L\', b"", 0)?').replace('b\'K\', b"")?', 'b\'K\', b"", 0)?')
s=s.replace('''            &target[..target.len().min(100)],
        )?;''','''            &target[..target.len().min(100)],
            u64::try_from(metadata.modified.seconds).map_err(|_| b"export timestamp is negative".as_slice())?,
        )?;''').replace('''        link: &[u8],
    ) -> Result<(), Error>''','''        link: &[u8],
        modified: u64,
    ) -> Result<(), Error>''').replace('octal(&mut header[136..148], 0)?;', 'octal(&mut header[136..148], modified)?;');p.write_text(s)
