from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G06b/source')
p=src/'tests/fixtures/launch-task-fixture.c';s=p.read_text().replace("mode=='l' || mode=='j' || mode=='p' || mode=='h'", "mode=='l' || mode=='j' || mode=='p' || mode=='h' || mode=='x'",1).replace('''long protected=call(9,0,4096,1,0x22,(word)-1,0);''','''long protected=call(9,0,mode=='x'?8192:4096,mode=='x'?3:1,0x22,(word)-1,0);''',1).replace('''        word address=mode=='j'?1:(mode=='p'?(word)protected:(word)&fork_tid);''','''        if(mode=='x') {
            for(word i=4094;i<4098;++i) ((unsigned char *)protected)[i]=0x5a;
            CHECK(DO(10,protected+4096,4096,1)==0,130);
        }
        word address=mode=='j'?1:(mode=='p'?(word)protected:(mode=='x'?(word)protected+4094:(word)&fork_tid));''',1)
s=s.replace('''            else { CHECK(fork_tid==0x1357 && *(volatile int *)protected==0,85); }''','''            else { CHECK(fork_tid==0x1357 && *(volatile int *)protected==0,85); }
            if(mode=='x') for(word i=4094;i<4098;++i) CHECK(((unsigned char *)protected)[i]==0x5a,131);''',1).replace('''CHECK(DO(11,protected,4096,0)==0,91);''','''CHECK(DO(11,protected,mode=='x'?8192:4096,0)==0,91);''',1);p.write_text(s)
p=src/'scripts/test-launch-tasks.py';s=p.read_text().replace("'protected-child-tid', 'handler-return'", "'protected-child-tid', 'x-child-tid', 'handler-return'",1);p.write_text(s)
p=src/'tests/fixtures/launch-exec-fixture.c';s=p.read_text().replace('''        CHECK(DO(59,"/work/hidden",next,next_env)==-95 && intact(),46);''','''        CHECK(DO(59,"/work/hidden",next,next_env)==-95 && intact(),46);
        CHECK(DO(59,"/owned-link",next,next_env)==-95 && intact(),70);
        CHECK(call(322,-100,(word)"/bin/link",(word)next,(word)next_env,0x100,0)==-40 && intact(),71);
        long failed=59;
        word path=(word)"/work/../bin/second", arguments=1, environment=(word)next_env;
        __asm__ volatile("syscall":"+a"(failed),"+D"(path),"+S"(arguments),"+d"(environment)::"rcx","r11","memory");
        CHECK(failed==-14 && path==(word)"/work/../bin/second" && arguments==1 && environment==(word)next_env && intact(),72);''',1);p.write_text(s)
p=src/'scripts/test-launch-exec.py';s=p.read_text().replace("        (root / 'bin/link').symlink_to('/bin/second')", "        (root / 'bin/link').symlink_to('/bin/second')\n        (root / 'owned-link').symlink_to('/work/hidden')");p.write_text(s)
p=src/'crates/ginux-process/src/lib.rs';s=p.read_text();needle='    #[test]\n    fn threads_groups_and_sessions_remain_virtual()';tests='''    #[test]
    fn fork_reservation_cancellation_preserves_published_state() {
        let mut table: ProcessTable<8> = ProcessTable::new();
        let init = table.create_init(Credentials::root()).unwrap();
        let reserved = table.fork(init).unwrap();
        let other = table.fork(init).unwrap();
        assert_eq!(table.cancel_fork(other, reserved), Err(ProcessError::InvalidState));
        table.cancel_fork(init, reserved).unwrap();
        assert_eq!(table.view(reserved), Err(ProcessError::InvalidTask));
        let executed = table.fork(init).unwrap();
        table.exec(executed).unwrap();
        assert_eq!(table.cancel_fork(init, executed), Err(ProcessError::InvalidState));
        let threaded = table.fork(init).unwrap();
        let thread = table.clone_thread(threaded).unwrap();
        assert_eq!(table.cancel_fork(init, threaded), Err(ProcessError::InvalidState));
        assert_eq!(table.cancel_fork(init, thread), Err(ProcessError::InvalidState));
        let parent = table.fork(init).unwrap();
        let child = table.fork(parent).unwrap();
        assert_eq!(table.cancel_fork(init, parent), Err(ProcessError::InvalidState));
        assert_eq!(table.view(child).unwrap().parent, parent.pid);
        assert_eq!(table.active(), 7);
    }

    #[test]
    fn wait_inspection_preserves_typed_outcomes_until_consumed() {
        let mut table: ProcessTable<4> = ProcessTable::new();
        let init = table.create_init(Credentials::root()).unwrap();
        let thread = table.clone_thread(init).unwrap();
        let child = table.fork(thread).unwrap();
        table.signaled(child, 15).unwrap();
        let report = table.peek_wait(thread, WaitTarget::Group(1), 0).unwrap();
        assert_eq!(report.child, child);
        assert_eq!(report.status, ChildStatus::Signaled(15));
        assert_eq!(table.peek_wait(init, WaitTarget::Specific(child.pid), 0), Ok(report));
        assert_eq!(table.active(), 3);
        assert_eq!(table.wait(thread, WaitTarget::Specific(child.pid), 0), Ok(report));
        assert_eq!(table.peek_wait(init, WaitTarget::Specific(child.pid), 0), Err(ProcessError::NotChild));
        assert_eq!(table.has_waitable_child(init, WaitTarget::Any), Ok(false));
    }

''';assert needle in s;s=s.replace(needle,tests+needle,1);p.write_text(s)
