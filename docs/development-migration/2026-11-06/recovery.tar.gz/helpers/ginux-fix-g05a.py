from pathlib import Path
p=Path('/tmp/ginux-contribution-preparation/G05a/source/crates/ginux-vfs/src/lib.rs')
s=p.read_text()
assert s.count('    offset: usize,\n')==1
s=s.replace('    offset: usize,\n','    position: usize,\n',1)
s=s.replace('            offset: 0,\n','            position: 0,\n',1)
needle='    descriptors: [Descriptor; FDS],\n'
assert s.count(needle)==1
s=s.replace(needle,needle+'    positions: [usize; FDS],\n')
needle='            descriptors: [Descriptor::empty(); FDS],\n'
s=s.replace(needle,needle+'            positions: [0; FDS],\n')
needle='''            .ok_or(VfsError::DescriptorLimit)?;
        let overlay_index'''
assert s.count(needle)==1
s=s.replace(needle,'''            .ok_or(VfsError::DescriptorLimit)?;
        // Duplicates share a position until their last close. A free descriptor
        // implies a position unreferenced by every live descriptor.
        let position = (0..FDS)
            .find(|position| {
                !self.descriptors.iter().any(|fd| fd.open && fd.position == *position)
            })
            .ok_or(VfsError::DescriptorLimit)?;
        let overlay_index''')
needle='''        self.descriptors[slot] = Descriptor {
            open: true,
            overlay,
            object,
            offset: 0,'''
assert s.count(needle)==1
s=s.replace(needle,'''        self.positions[position] = 0;
        self.descriptors[slot] = Descriptor {
            open: true,
            overlay,
            object,
            position,''')
a=s.index('    pub fn read(&mut self, descriptor: i32, output:')
b=s.index('    pub fn duplicate(',a)
part=s[a:b]
assert part.count('let state = self.descriptors[slot];')==2
part=part.replace('let state = self.descriptors[slot];','let state = self.descriptors[slot];\n        let offset = self.positions[state.position];')
part=part.replace('state.offset','offset')
part=part.replace('''let end = state
            .offset''','''let end = offset''')
part=part.replace('self.descriptors[slot].offset += length;','self.positions[state.position] += length;')
part=part.replace('self.descriptors[slot].offset = end;','self.positions[state.position] = end;')
s=s[:a]+part+s[b:]
assert 'state.offset' not in part
p.write_text(s)
