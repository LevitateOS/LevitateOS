from pathlib import Path
root=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
p=root/'crates/ginux-init/src/tracee_io.rs'; s=p.read_text().replace('pub fn image_cwd(pid: usize) -> Result<Path, i64> {','''pub fn image_cwd(pid: usize) -> Result<Path, i64> {
    image_link(pid, b"/cwd")
}

/// Only callers in the supervisor choose the proc member; no host prefix is
/// returned unless it resolves beneath the tracee's immutable root.
pub fn image_link(pid: usize, member: &[u8]) -> Result<Path, i64> {''').replace('let cwd_len = link(pid, b"/cwd", &mut cwd)?;', 'let cwd_len = link(pid, member, &mut cwd)?;'); p.write_text(s)
p=root/'crates/ginux-vfs/src/lib.rs'; s=p.read_text(); at=s.index('    pub fn executable_pins(&self)')
s=s[:at]+'''    /// Current namespace name of a pinned image, retaining unlink identity.
    pub fn executable_name(&self, image: Executable) -> Result<(&[u8], bool), VfsError> {
        let object = self.overlay.get(image.object).ok_or(VfsError::InvalidDescriptor)?;
        if object.executions == 0 || object.len != image.size {
            return Err(VfsError::InvalidDescriptor);
        }
        Ok((object.path.as_bytes(), object.state == 2))
    }

'''+s[at:]; p.write_text(s)
p=root/'crates/ginux-init/src/fs_hooks.rs'; s=p.read_text(); at=s.index('    pub fn read_executable(')
s=s[:at]+'''    pub fn executable_name(&self, image: Executable) -> Result<Path, i64> {
        let (name, deleted) = self.fs.executable_name(image).map_err(errno)?;
        let mut bytes = [0u8; MAX_PATH];
        let suffix = if deleted { b" (deleted)".as_slice() } else { b"" };
        let len = name.len().checked_add(suffix.len()).filter(|n| *n <= MAX_PATH).ok_or(-36)?;
        bytes[..name.len()].copy_from_slice(name);
        bytes[name.len()..len].copy_from_slice(suffix);
        Path::from_bytes(&bytes[..len]).map_err(|_| -36)
    }

'''+s[at:]; p.write_text(s)
p=root/'crates/ginux-init/src/launch_tasks.rs'; s=p.read_text(); marker='''        match r.orig_rax {
            80 => {'''; assert marker in s
s=s.replace(marker,'''        match r.orig_rax {
            89 | 267 => {
                let host = self.task(index).host;
                let (address, output, size, dirfd) = if r.orig_rax == 89 {
                    (r.rdi, r.rsi, r.rdx, (-100i64) as u64)
                } else { (r.rsi, r.rdx, r.r10, r.rdi) };
                let path = self.objects.filesystem.path(host, address, dirfd);
                if path.as_ref().is_ok_and(|p| matches!(p.as_bytes(), b"/proc/self/exe" | b"/proc/thread-self/exe")) {
                    let result = (|| {
                        if size == 0 { return Err(-22); }
                        let name = crate::tracee_io::image_link(host, b"/exe").or_else(|error| {
                            self.groups[parent_group].as_ref().unwrap().image
                                .ok_or(error).and_then(|image| self.objects.filesystem.executable_name(image))
                        })?;
                        let mut bytes = [0u8; ginux_vfs::MAX_PATH];
                        let count = name.as_bytes().len().min(size as usize);
                        bytes[..count].copy_from_slice(&name.as_bytes()[..count]);
                        if copy_memory(host, output, &mut bytes[..count], true)? != count as i64 { return Err(-14); }
                        Ok(count as i64)
                    })().unwrap_or_else(|error| error);
                    self.emulate(index, r, result, domain);
                    return;
                }
            }
            80 => {'''); p.write_text(s)
p=root/'tests/fixtures/launch-exec-fixture.c'; s=p.read_text().replace('''    char mode=argc>1 ? argv[1][0] : 's';''','''    char mode=argc>1 ? argv[1][0] : 's';
    char exe[64];
    long length=DO(89,"/proc/self/exe",exe,sizeof exe);
    CHECK(length>5 && exe[0]=='/' && exe[1]=='b' && exe[2]=='i' && exe[3]=='n' && exe[4]=='/',90);
    CHECK(call(267,-100,(word)"/proc/self/exe",(word)exe,4,0,0)==4,91);
    CHECK(DO(89,"/proc/self/exe",exe,0)==-22,92);
    CHECK(DO(89,"/proc/self/exe",1,8)==-14,93);'''); p.write_text(s)
p=root/'tests/fixtures/launch-owned-exec-fixture.c'; s=p.read_text().replace("    if (mode=='a') {",'''    if (mode=='a') {
        const char *expected=argv[2][0]=='u'?"/work/program (deleted)":"/work/program";
        long length=DO(89,"/proc/self/exe",buffer,sizeof buffer);
        long wanted=argv[2][0]=='u'?23:13;
        CHECK(length==wanted,90);
        for (long i=0;i<length;i++) CHECK(buffer[i]==expected[i],91);'''); p.write_text(s)
