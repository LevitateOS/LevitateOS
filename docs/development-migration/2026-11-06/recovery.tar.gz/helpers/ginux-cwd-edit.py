from pathlib import Path
root=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
p=root/'crates/ginux-init/src/tracee_io.rs'; s=p.read_text(); at=s.index('/// Linux file type bits')
s=s[:at]+'''/// Kernel-owned image cwd, expressed relative to the tracee's chroot. Reading
/// the two proc links does not let a workload select a supervisor host path.
/// Fork and CLONE_FS sharing retain their native directory semantics.
pub fn image_cwd(pid: usize) -> Result<Path, i64> {
    fn link(pid: usize, suffix: &[u8], output: &mut [u8]) -> Result<usize, i64> {
        let mut name = [0u8; 64];
        name[..6].copy_from_slice(b"/proc/");
        let mut digits = [0u8; 20];
        let mut number = pid;
        let mut count = 0;
        loop {
            digits[count] = b'0' + (number % 10) as u8;
            count += 1;
            number /= 10;
            if number == 0 { break; }
        }
        for n in 0..count { name[6 + n] = digits[count - n - 1]; }
        name[6 + count..6 + count + suffix.len()].copy_from_slice(suffix);
        let result = unsafe {
            crate::supervisor::syscall3(89, name.as_ptr() as usize,
                output.as_mut_ptr() as usize, output.len())
        };
        if result < 0 { return Err(result as i64); }
        if result as usize == output.len() { return Err(-36); }
        Ok(result as usize)
    }
    let mut root = [0u8; 4096];
    let mut cwd = [0u8; 4096];
    let root_len = link(pid, b"/root", &mut root)?;
    let cwd_len = link(pid, b"/cwd", &mut cwd)?;
    let relative = cwd[..cwd_len].strip_prefix(&root[..root_len]).ok_or(-13)?;
    if relative.is_empty() { return Path::from_bytes(b"/").map_err(|_| -36); }
    if relative[0] != b'/' || relative.ends_with(b" (deleted)") { return Err(-2); }
    Path::from_bytes(relative).map_err(|_| -36)
}

'''+s[at:]; p.write_text(s)
p=root/'crates/ginux-init/src/fs_hooks.rs'; s=p.read_text(); s=s.replace('        let base = if absolute {','        let cwd;\n        let base = if absolute {',1).replace('            self.cwd.as_bytes()\n        } else {','            cwd = crate::tracee_io::image_cwd(pid)?;\n            cwd.as_bytes()\n        } else {',1)
at=s.index('    /// Assigned paths yield pinned')
s=s[:at]+'''    /// Directory changes may enter the immutable image. Owned directories
    /// have no native backing and must not silently enter a hidden image tree.
    pub fn image_chdir(&self, pid: usize, address: u64) -> Result<(), i64> {
        let path = self.path(pid, address, (-100i64) as u64)?;
        if self.owns_path(path.as_bytes()) { return Err(-95); }
        if [b"/dev".as_slice(), b"/proc", b"/sys"].iter()
            .any(|prefix| within(path.as_bytes(), prefix)) { return Err(-13); }
        Ok(())
    }

'''+s[at:]; p.write_text(s)
p=root/'crates/ginux-init/src/launch_tasks.rs'; s=p.read_text(); target='''        match r.orig_rax {
            59 | 322 => {'''; assert s.count(target)==1
s=s.replace(target,'''        match r.orig_rax {
            80 => {
                match self.objects.filesystem.image_chdir(self.task(index).host, r.rdi) {
                    Ok(()) => {
                        audit_write(b"mediate surface=image-cwd\\n");
                        self.run(index, r, domain);
                    }
                    Err(error) => self.emulate(index, r, error, domain),
                }
                return;
            }
            59 | 322 => {'''); p.write_text(s)
p=root/'tests/fixtures/launch-task-fixture.c'; s=p.read_text(); target="    if (mode=='f' || mode=='v' || mode=='c' || mode=='s') {"; s=s.replace(target,'''    if (mode=='d') {
        CHECK(DO(80,"/source",0,0)==0,90);
        long child=DO(57,0,0,0);
        CHECK(child>=0,91);
        if (child==0) {
            CHECK(DO(80,"../work",0,0)==-95,92);
            CHECK(DO(80,"sub",0,0)==0,93);
            long fd=DO(2,"value",0,0);
            CHECK(fd>=3 && DO(0,fd,buffer,1)==1 && buffer[0]=='c',94);
            CHECK(DO(3,fd,0,0)==0,95);
            fd=DO(2,"/work/child",0102,0600);
            CHECK(fd>=3 && DO(1,fd,"x",1)==1,96);
            DO(60,0,0,0);
            __builtin_unreachable();
        }
        int status=0;
        CHECK(DO(61,child,&status,0)==child && status==0,97);
        long fd=DO(2,"value",0,0);
        CHECK(fd>=3 && DO(0,fd,buffer,1)==1 && buffer[0]=='p',98);
        CHECK(DO(3,fd,0,0)==0,99);
        fd=DO(2,"../work/child",0,0);
        CHECK(fd>=3 && DO(0,fd,buffer,1)==1 && buffer[0]=='x',100);
        CHECK(DO(3,fd,0,0)==0,101);
        CHECK(DO(80,"missing",0,0)==-2,102);
    }
'''+target); p.write_text(s)
p=root/'scripts/test-launch-tasks.py'; s=p.read_text().replace("        (root / 'input').write_bytes(b'abcdef')","        (root / 'input').write_bytes(b'abcdef')\n        (root / 'source/sub').mkdir(parents=True)\n        (root / 'source/value').write_bytes(b'parent')\n        (root / 'source/sub/value').write_bytes(b'child')").replace("for mode in ('fork',", "for mode in ('directory', 'fork',"); p.write_text(s)
