from pathlib import Path
import subprocess,tarfile,io,re
root=Path('/tmp/ginux-contribution-preparation/G09a');src=root/'source';dest=root/'baseline-regression';assert not dest.exists();dest.mkdir();repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';base='785bfb9d6b7fcfb901d9f5efb8a845c8d9d4d53a'
archive=subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'archive',base])
with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(dest,filter='data')
name='crates/ginux-vfs/src/lib.rs';s=(src/name).read_text();test=re.search(r'    #\[test\]\n    fn truncate_image_does_not_need_capacity_for_discarded_contents\(\).*?\n    }\n',s,re.S).group();p=dest/name;s=p.read_text();at=s.rfind('\n}');p.write_text(s[:at]+'\n'+test+s[at:])
with (root/'baseline-truncate-regression.log').open('w') as log:
 r=subprocess.run(['cargo','test','-p','ginux-vfs','truncate_image_does_not_need_capacity_for_discarded_contents'],cwd=dest,env={**__import__('os').environ,'RUSTFLAGS':'','CARGO_TARGET_DIR':'.artifacts/unit'},stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==101,r.returncode;print('Exact prerequisite regression fails as expected:',r.returncode)
