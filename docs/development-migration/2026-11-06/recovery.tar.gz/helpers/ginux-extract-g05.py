from pathlib import Path
import subprocess,tarfile,io,json
repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux');root=Path('/tmp/ginux-contribution-preparation/G05');src=root/'source';assert not src.exists();src.mkdir(parents=True)
def git(*a):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*a])
base='5036b7e8a61c4cf1e18abad8746208d03d268ea5';donor='3b00c1c8'
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(src,filter='data')
for name in ['crates/ginux-init/src/descriptors.rs','scripts/test-launch-fds.py','tests/fixtures/launch-fd-fixture.c','tests/fixtures/launch-pipe-fixture.c']:(src/name).write_bytes(git('show',donor+':'+name))
(src/'scripts/test-launch-pipes.py').write_bytes(git('show','f1c6419e:scripts/test-launch-pipes.py'))
p=src/'crates/ginux-init/src/channel_hooks.rs';old=p.read_text();d=git('show',donor+':crates/ginux-init/src/channel_hooks.rs').decode();d=d[d.index('use crate::supervisor::{syscall2,'):];p.write_text(old+'\n'+d)
p=src/'crates/ginux-init/src/descriptors.rs';s=p.read_text().replace('            7 => self.console_poll(pid, r),\n','');a=s.index('    fn console_poll(');b=s.index('\n}\n\nfn ready(',a);s=s[:a]+s[b:];p.write_text(s)
p=src/'crates/ginux-init/src/channel_hooks.rs';s=p.read_text().replace('''                if flags != 0x1000 {
                    Err(-22)
                } else {''','''                let valid = if r.orig_rax == 262 { flags & !0x1900 == 0 }
                    else { crate::fs_hooks::valid_statx(flags, r.r10) };
                if flags & 0x1000 == 0 || !valid { Err(-22) } else {''');p.write_text(s)
p=src/'crates/ginux-init/src/dispatch.rs';s=p.read_text().replace('pub enum NativeDecision {','pub enum NativeDecision {\n    /// An owned channel cannot progress yet; retain its syscall-entry stop.\n    Park { fd: u32 },',1)
pos=s.index('/// Dispatch one process-supervision entry')
s=s[:pos]+'''/// Resolve registered backend objects before the immutable native contract.
pub fn decide_objects(
    pid: usize,
    registers: &UserRegs,
    filesystem: &mut crate::fs_hooks::LaunchFs,
    devices: &mut crate::device_hooks::LaunchDevices,
    channels: &mut crate::channel_hooks::LaunchChannels,
) -> NativeDecision {
    if let Some(result) = channels.claim(pid, registers) {
        match result {
            crate::channel_hooks::ChannelResult::Ready(result) => NativeDecision::Hooked { lane: Lane::Channel, result },
            crate::channel_hooks::ChannelResult::Blocked { fd } => NativeDecision::Park { fd },
        }
    } else if let Some(result) = devices.claim(pid, registers, filesystem) {
        NativeDecision::Hooked { lane: Lane::Device, result }
    } else if let Some(result) = filesystem.claim(pid, registers) {
        NativeDecision::Hooked { lane: Lane::Filesystem, result }
    } else { decide_native(registers.orig_rax, registers.rdi, registers.rsi, registers.rdx) }
}

'''+s[pos:];p.write_text(s)
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text().replace('use crate::supervisor::{syscall4, UserRegs};','use crate::supervisor::UserRegs;');a=s.index('    /// Both virtual object ranges');b=s.index('    fn owns_path',a);s=s[:a]+s[b:];p.write_text(s)
p=src/'crates/ginux-init/src/tracee_io.rs';s=p.read_text().replace('use crate::supervisor::syscall6;','use crate::supervisor::{syscall4, syscall6};');d=git('show',donor+':crates/ginux-init/src/tracee_io.rs').decode();s+='\n'+d[d.index('/// Native open/dup cannot'):];p.write_text(s)
p=src/'crates/ginux-init/src/supervisor.rs';s=p.read_text().replace('#[repr(C)]\npub struct UserRegs {','#[repr(C)]\n#[derive(Clone, Copy)]\npub struct UserRegs {',1);p.write_text(s)
p=src/'crates/ginux-init/src/main.rs';s=p.read_text().replace('mod device_hooks;','mod device_hooks;\nmod descriptors;',1);needle='''        let decision = match decide_native(syscall, registers.rdi, registers.rsi, registers.rdx) {
''';assert s.count(needle)==1;s=s.replace(needle,needle+'''            NativeDecision::Park { .. } => native_fail(domain, pid, b"unexpected configured channel wait"),
''');p.write_text(s)
p=src/'crates/ginux-init/src/launch.rs';s=p.read_text();s=s.replace('balanced_surface_name, decide_native, native_arguments_allowed, NativeDecision,','balanced_surface_name, native_arguments_allowed, NativeDecision,');needle='''    print_launch_config(&config);''';assert s.count(needle)==1;s=s.replace(needle,'''    let mut channels = crate::channel_hooks::LaunchChannels::new();
    let mut descriptors = crate::descriptors::DescriptorTable::new()
        .unwrap_or_else(|reason| launch_startup_fail(reason));
'''+needle)
s=s.replace('launch_tracee(root_path, &filesystem);','launch_tracee(root_path);',1).replace('supervise_launch(child as usize, &mut domain, &mut filesystem, &mut devices)','supervise_launch(child as usize, &mut domain, &mut filesystem, &mut devices, &mut channels, &mut descriptors)',1)
s=s.replace('fn launch_tracee(root_path: *const u8, filesystem: &crate::fs_hooks::LaunchFs) -> ! {','fn launch_tracee(root_path: *const u8) -> ! {',1).replace('if !filesystem.reserve_descriptors() {','if !crate::tracee_io::reserve_native_descriptors(crate::descriptors::LIMIT) {',1)
s=s.replace('''    devices: &mut crate::device_hooks::LaunchDevices,
) -> ! {''','''    devices: &mut crate::device_hooks::LaunchDevices,
    channels: &mut crate::channel_hooks::LaunchChannels,
    descriptors: &mut crate::descriptors::DescriptorTable,
) -> ! {''',1)
s=s.replace('''            if (override_exit || rewritten)''','''            let descriptor_change = descriptors.finish(&mut registers)
                .unwrap_or_else(|reason| launch_fail(domain, pid, reason));
            if (override_exit || rewritten || descriptor_change)''',1)
a=s.index('        let claimed = devices');b=s.index('        let decision = match dispatched {',a)
s=s[:a]+'''        let dispatched = descriptors.enter(pid, &mut registers, filesystem, devices, channels);
        let dispatched = match dispatched {
            NativeDecision::Contract(decision) => match crate::path_hooks::Rewrite::prepare(filesystem, pid, &mut registers) {
                Ok(rewrite) => { path_rewrite = rewrite; NativeDecision::Contract(decision) }
                Err(-5) => launch_fail(domain, pid, b"launch path scratch restoration failed"),
                Err(result) => NativeDecision::Hooked { lane: crate::dispatch::Lane::Filesystem, result },
            },
            decision => decision,
        };
'''+s[b:]
s=s.replace('''        let decision = match dispatched {
            NativeDecision::Contract''','''        let decision = match dispatched {
            NativeDecision::Park { fd } => {
                audit_write(b"ginux: park surface=lane-channel fd=");
                audit_u64(fd as u64);
                audit_write(b" syscall="); audit_u64(syscall); audit_write(b"\\n");
                // The single task has no runnable peer. SIGKILL still produces
                // its normal terminal wait status; later task ownership retries IO.
                continue;
            }
            NativeDecision::Contract''',1)
s=s.replace('Action::Mediate if native_arguments_allowed(syscall, &registers)', 'Action::Mediate if native_arguments_allowed(registers.orig_rax, &registers)',1)
needle='''                if ptrace(PTRACE_SYSCALL, pid, 0, 0) < 0 {
                    launch_fail(domain, pid, b"launch mediated syscall failed");''';assert needle in s;s=s.replace(needle,'''                if ptrace(PTRACE_SETREGS, pid, 0, &registers as *const _ as usize) < 0
                    || ptrace(PTRACE_SYSCALL, pid, 0, 0) < 0 {
                    launch_fail(domain, pid, b"launch mediated syscall failed");''',1);p.write_text(s)
# Existing fixture assertions now observe one public low-number namespace;
# keep every prior path/copy/metadata regression assertion.
p=src/'tests/fixtures/launch-storage-fixture.c';s=p.read_text().replace('>= 1048576','>= 3').replace('>=1048576','>=3').replace('== 1048576','== 3').replace('fd < 1048576','fd < 256').replace('<= 1048576','<= 256');p.write_text(s)
p=src/'tests/fixtures/launch-device-fixture.c';s=p.read_text().replace('>= 0x40000000','>= 3').replace('== 0x40000000','== 3').replace('<= 1048576','<= 256');p.write_text(s)
p=src/'Makefile';s=p.read_text();
for feature in ['pipe','fd']:
 name='pipes' if feature=='pipe' else 'fds';s+=f'''
.PHONY: build-launch-{feature}-fixture test-launch-{name}
build-launch-{feature}-fixture:
	mkdir -p .artifacts/launch
	$(CC) -nostdlib -static -fno-stack-protector -fno-builtin -O2 -Wall -Wextra -Werror tests/fixtures/launch-{feature}-fixture.c -o .artifacts/launch/launch-{feature}-fixture

test-launch-{name}:
	python3 scripts/test-launch-{name}.py $(GINUX) .artifacts/launch/launch-{feature}-fixture
'''
p.write_text(s)
p=src/'.github/workflows/check.yml';s=p.read_text().replace('build-launch-device-fixture build-process-fixtures','build-launch-device-fixture build-launch-pipe-fixture build-launch-fd-fixture build-process-fixtures').replace('      - run: sudo make test-launch-devices','      - run: sudo make test-launch-devices\n      - run: sudo make test-launch-pipes\n      - run: sudo make test-launch-fds');p.write_text(s)
p=src/'README.md';s=p.read_text().replace('rename, duplicate descriptors, file mappings','rename, file mappings');a=s.index('Virtual descriptors start at 1048576;');b=s.index('Guest-memory copies respect page protections',a);d=git('show',donor+':README.md').decode();x=d.index('Configured launch uses one table');y=d.index('Guest-memory copies respect page protections',x);common=d[x:y].replace('Relative directory-fd access, poll on remapped stdio or non-bootstrap descriptors,','Relative directory-fd access, descriptor polling,');s=s[:a]+common+s[b:];a=s.index('Unknown and duplicate assignments fail before launch. Device descriptors start');b=s.index('\nWhen requested, the result file',a);x=d.index('Unknown and duplicate assignments fail before launch. Device aliases');y=d.index('\nWhen requested, the result file',x);s=s[:a]+d[x:y]+s[b:];s=s.replace('sudo make test-launch-devices\n```','sudo make test-launch-devices\nmake build-launch-pipe-fixture build-launch-fd-fixture\nsudo make test-launch-pipes test-launch-fds\n```');p.write_text(s)
(root/'composition.json').write_text(json.dumps({'upstream':'3f2fe7df','base':base,'source_commits':['7f072f2c','3b00c1c8','f1c6419e'],'dependencies':['G04'],'scope':'owned pipes with unified public descriptors; keep together to avoid introducing a temporary high-handle public pipe ABI','excluded':'G01/G02 polling/clock surfaces and all future tasks, network or mappings'},indent=2)+'\n')
print('G05 extracted on explicit G04 base, no refs changed; held polling code excluded')
