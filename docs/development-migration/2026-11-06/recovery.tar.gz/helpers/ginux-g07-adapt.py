from pathlib import Path
import re,subprocess
root=Path('/tmp/ginux-contribution-preparation/G07/source');p=root/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text();blocks=list(re.finditer(r'<<<<<<< current\n(.*?)=======\n(.*?)>>>>>>> feature\n',s,re.S));assert len(blocks)==18
replacements=[]
for i,m in enumerate(blocks):
 ours,theirs=m.groups()
 if i==0:r=ours+theirs
 elif i==1:r=ours
 elif i in [2,4,7]:r=ours.replace('    descriptors: DescriptorTable,\n','').replace('        descriptors,\n','').replace('                    descriptors: table,\n','')+theirs
 elif i in [3,5,8]:r=ours+theirs
 elif i==6:r='''                let libc_fork = r.orig_rax == 56 && flags == 0x1200011;
                let thread = r.orig_rax == 56 && flags == 0x3d0f00;
                if r.orig_rax == 56 && !thread && !matches!(flags, 17 | 0x4111 | 0x1200011) {
'''
 elif i==9:r='''                    child_tid: libc_fork.then_some(r.r10),
                    parent_tid: thread.then_some(r.rdx),
                };
                if libc_fork {
                    r.rdi &= !0x1000000;
                }
                if thread {
                    r.rdi &= !0x100000;
'''
 elif i==10:r=theirs.replace('r: &UserRegs','r: &mut UserRegs')
 elif i==11:r=ours.replace('self.task(index).descriptors','self.table(index)')
 elif i==12:r=ours+theirs
 elif i==13:r=ours+theirs[theirs.index('        if let Some(address) = parent_tid'):]
 elif i==14:r=theirs.replace('                parent_tid,','                parent_tid,\n                ..')
 elif i==15:r=ours+theirs
 elif i==16:r=theirs[:theirs.index('                if r.rsi != 0 {')]+ours.replace('                self.task_mut(index).pending','                self.task_mut(child).waiter = Some(index);\n                self.task_mut(index).pending')
 elif i==17:
  r=ours[:ours.index('        self.task_mut(index).alive = false;')]+theirs[theirs.index('        let id = self.task(index).id;'):];r=r.replace('        self.task_mut(index).alive = false;','        self.task_mut(index).alive = false;\n        self.task_mut(index).wait_status = Some(status);')
 else:raise AssertionError(i)
 replacements.append(r)
for m,r in reversed(list(zip(blocks,replacements))):s=s[:m.start()]+r+s[m.end():]
s=s.replace('self.processes.reap_exited_thread(id)','self.processes.reap_thread(id)')
s=s.replace('self.processes.exit(id, status)','self.record_death(id, status)').replace('self.processes.exit(leader, status)','self.record_death(leader, status)')
anchor='    fn died(&mut self, index: usize, status: i32, domain: &mut Domain) {'
s=s.replace(anchor,'''    fn record_death(&mut self, id: TaskId, status: i32) -> Result<(), ProcessError> {
        if exited(status) {
            self.processes.exit(id, (status >> 8) & 255)
        } else {
            self.processes.signaled(id, (status & 127) as u8)
        }
    }
'''+anchor)
# The donor used ordinary writes in both parent-TID checks. Preserve strict words.
s=s.replace('copy_memory(self.task(index).host, r.rdx, &mut before, true) != Ok(4)','crate::tracee_io::store_u32(self.task(index).host, r.rdx, u32::from_ne_bytes(before)) != Ok(())')
s=s.replace('''            let mut virtual_tid = self.task(slot).id.pid.to_ne_bytes();
            if copy_memory(self.task(parent).host, address, &mut virtual_tid, true) != Ok(4) {
                self.fail(domain, b"thread identity copyout failed");
            }''','''            if crate::tracee_io::store_u32(self.task(parent).host, address, self.task(slot).id.pid).is_err() {
                self.fail(domain, b"thread identity copyout failed");
            }''')
assert '<<<<<<<' not in s;p.write_text(s)
# Existing main already has typed thread retirement, fork-from-thread and wait
# group semantics. Add only the missing unpublished-thread rollback helper.
p=root/'crates/ginux-process/src/lib.rs';s=p.read_text();anchor='    pub fn exec(&mut self, id: TaskId) -> Result<u32, ProcessError> {';assert anchor in s
s=s.replace(anchor,'''    /// Cancel a reserved native thread before the supervisor lets it run.
    pub fn cancel_thread(&mut self, parent: TaskId, thread: TaskId) -> Result<(), ProcessError> {
        let parent = self.tasks[self.index(parent)?];
        let index = self.index(thread)?;
        let task = self.tasks[index];
        if parent.state != TaskState::Running
            || task.tgid != parent.tgid
            || task.id.pid == task.tgid
            || task.state != TaskState::Running
            || task.exec_epoch != 0
        {
            return Err(ProcessError::InvalidState);
        }
        self.tasks[index] = Task::empty();
        Ok(())
    }

'''+anchor);p.write_text(s)
