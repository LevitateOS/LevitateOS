from pathlib import Path
import subprocess,io,tarfile
repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
root=Path('/tmp/ginux-contribution-preparation/G03b')
source=root/'source';assert not source.exists();source.mkdir(parents=True)
def git(*args):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*args],text=True)
base='bb2c82bf18bb30a7ebc514af5131fa5b03a5fcc5'
data=subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),'archive',base])
with tarfile.open(fileobj=io.BytesIO(data)) as t:t.extractall(source,filter='data')
p=source/'crates/ginux-vfs/src/lib.rs';s=p.read_text()
s=s.replace('pub const O_CLOEXEC: u32 = 16;','pub const O_CLOEXEC: u32 = 16;\npub const O_APPEND: u32 = 32;\npub const O_EXCLUSIVE: u32 = 64;',1)
needle='#[derive(Clone, Copy)]\nstruct OverlayFile'
s=s.replace(needle,'''/// Image/overlay metadata using only virtual inode identities.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct FileMetadata {
    pub inode: u64,
    pub kind: NodeKind,
    pub mode: u32,
    pub size: u64,
}

'''+needle,1)
s=s.replace('    close_on_exec: bool,\n}', '    close_on_exec: bool,\n    append: bool,\n}',1)
s=s.replace('            close_on_exec: false,','            close_on_exec: false,\n            append: false,',1)
s=s.replace('''        let path = self.resolved_path(path, true, flags & O_CREATE != 0)?;''','''        let exclusive = flags & (O_CREATE | O_EXCLUSIVE) == (O_CREATE | O_EXCLUSIVE);
        let path = self.resolved_path(path, !exclusive, flags & O_CREATE != 0)?;''',1)
needle='''        // Reserve capacity before any operation can create, copy up or truncate.'''
s=s.replace(needle,'''        if exclusive {
            match self.metadata_at(path.as_bytes()) {
                Ok(_) => return Err(VfsError::AlreadyExists),
                Err(VfsError::NotFound) => {}
                Err(error) => return Err(error),
            }
        }
'''+needle,1)
needle='''            Some(index) => {
                object = index;
                overlay = true;
            }'''
s=s.replace(needle,'''            Some(index) if self.overlay[index].state == 3 => return Err(VfsError::IsDirectory),
'''+needle,1)
s=s.replace('            close_on_exec: flags & O_CLOEXEC != 0,','            close_on_exec: flags & O_CLOEXEC != 0,\n            append: flags & O_APPEND != 0,',1)
needle='''        let length = available.min(output.len());
        if state.overlay'''
s=s.replace(needle,'''        let length = available.min(output.len());
        if length == 0 {
            return Ok(0);
        }
        if state.overlay''',1)
a=s.index('    pub fn write(&mut self, descriptor: i32, input:')
b=s.index('    /// Share the open-file offset',a)
s=s[:a]+'''    pub fn write(&mut self, descriptor: i32, input: &[u8]) -> Result<usize, VfsError> {
        let slot = self.descriptor(descriptor)?;
        let state = self.descriptors[slot];
        if !state.writable || !state.overlay {
            return Err(VfsError::PermissionDenied);
        }
        if input.is_empty() {
            return Ok(0);
        }
        let offset = if state.append {
            self.overlay[state.object].len
        } else {
            self.positions[state.position]
        };
        let end = offset.checked_add(input.len()).ok_or(VfsError::FileTooLarge)?;
        if end > FILE_SIZE {
            return Err(VfsError::FileTooLarge);
        }
        let previous = self.overlay[state.object].len;
        if offset > previous {
            self.overlay[state.object].data[previous..offset].fill(0);
        }
        self.overlay[state.object].data[offset..end].copy_from_slice(input);
        self.overlay[state.object].len = previous.max(end);
        self.positions[state.position] = end;
        Ok(input.len())
    }

'''+s[b:]
needle='''            self.overlay[index].state = 2;
            self.release_unlinked(index);'''
s=s.replace(needle,'''            if self.overlay[index].state == 3 {
                return Err(VfsError::IsDirectory);
            }
'''+needle,1)
methods='''    /// Follow image links in component order and inspect the current namespace.
    pub fn metadata(&self, path: &[u8]) -> Result<FileMetadata, VfsError> {
        let path = self.resolved_path(path, true, false)?;
        self.metadata_at(path.as_bytes())
    }

    fn metadata_at(&self, path: &[u8]) -> Result<FileMetadata, VfsError> {
        if let Some(index) = self.find_overlay(path) {
            let file = &self.overlay[index];
            if file.state == 2 {
                return Err(VfsError::NotFound);
            }
            return Ok(FileMetadata {
                inode: (self.index.len() + index + 1) as u64,
                kind: if file.state == 3 { NodeKind::Directory } else { NodeKind::File },
                mode: file.mode,
                size: file.len as u64,
            });
        }
        let entry = self.index.lookup_exact(path)?;
        Ok(FileMetadata {
            inode: (self.find_base_record(entry.path).ok_or(VfsError::InvalidIndex)? + 1) as u64,
            kind: entry.kind,
            mode: entry.mode,
            size: entry.size,
        })
    }

    pub fn fstat(&self, descriptor: i32) -> Result<FileMetadata, VfsError> {
        let state = self.descriptors[self.descriptor(descriptor)?];
        if state.overlay {
            let file = &self.overlay[state.object];
            Ok(FileMetadata {
                inode: (self.index.len() + state.object + 1) as u64,
                kind: NodeKind::File,
                mode: file.mode,
                size: file.len as u64,
            })
        } else {
            let entry = self.index.entry(state.object)?;
            Ok(FileMetadata {
                inode: (state.object + 1) as u64,
                kind: entry.kind,
                mode: entry.mode,
                size: entry.size,
            })
        }
    }

    pub fn mkdir(&mut self, path: &[u8], mode: u32) -> Result<(), VfsError> {
        let path = self.resolved_path(path, false, true)?;
        match self.metadata_at(path.as_bytes()) {
            Ok(_) => return Err(VfsError::AlreadyExists),
            Err(VfsError::NotFound) => {}
            Err(error) => return Err(error),
        }
        self.require_parent(path.as_bytes())?;
        let slot = self.create_overlay(path, mode & 0o777)?;
        self.overlay[slot].state = 3;
        Ok(())
    }

    pub fn chmod(&mut self, path: &[u8], mode: u32) -> Result<(), VfsError> {
        let path = self.resolved_path(path, true, false)?;
        let slot = self.find_overlay(path.as_bytes()).ok_or(VfsError::PermissionDenied)?;
        if mode & !0o777 != 0 {
            return Err(VfsError::PermissionDenied);
        }
        self.overlay[slot].mode = mode;
        Ok(())
    }

    pub fn fchmod(&mut self, descriptor: i32, mode: u32) -> Result<(), VfsError> {
        let state = self.descriptors[self.descriptor(descriptor)?];
        if !state.overlay || mode & !0o777 != 0 {
            return Err(VfsError::PermissionDenied);
        }
        self.overlay[state.object].mode = mode;
        Ok(())
    }

    /// Seek the shared open-file position; seeking past EOF does not grow data.
    pub fn seek(&mut self, descriptor: i32, offset: i64, whence: u32) -> Result<u64, VfsError> {
        let slot = self.descriptor(descriptor)?;
        let base = match whence {
            0 => 0,
            1 => self.positions[self.descriptors[slot].position] as u64,
            2 => self.fstat(descriptor)?.size,
            _ => return Err(VfsError::InvalidPath),
        };
        let base = i64::try_from(base).map_err(|_| VfsError::FileTooLarge)?;
        let position = base.checked_add(offset).filter(|p| *p >= 0).ok_or(VfsError::InvalidPath)?;
        self.positions[self.descriptors[slot].position] = usize::try_from(position).map_err(|_| VfsError::FileTooLarge)?;
        Ok(position as u64)
    }

    pub fn descriptor_flags(&self, descriptor: i32) -> Result<(u32, bool), VfsError> {
        let state = self.descriptors[self.descriptor(descriptor)?];
        let mode = match (state.readable, state.writable) {
            (true, false) => 0,
            (false, true) => 1,
            _ => 2,
        };
        Ok((mode | if state.append { 0o2000 } else { 0 }, state.close_on_exec))
    }

    pub fn set_close_on_exec(&mut self, descriptor: i32, enabled: bool) -> Result<(), VfsError> {
        let slot = self.descriptor(descriptor)?;
        self.descriptors[slot].close_on_exec = enabled;
        Ok(())
    }

'''
needle='''    fn descriptor(&self, descriptor: i32) -> Result<usize, VfsError> {'''
assert s.count(needle)==1;s=s.replace(needle,methods+needle,1)
s=s.replace('''            .position(|entry| entry.state == 1 && entry.path.as_bytes() == path)''','''            .position(|entry| matches!(entry.state, 1 | 3) && entry.path.as_bytes() == path)''',1)
s=s.replace('''                    Ok((NodeKind::File, 0))''','''                    Ok((if self.overlay[slot].state == 3 { NodeKind::Directory } else { NodeKind::File }, 0))''',1)
s=s.replace('''        if self.index.resolve(parent)?.kind != NodeKind::Directory {''','''        if self.metadata(parent)?.kind != NodeKind::Directory {''',1)
# Keep the original focused feature tests while retaining every current upstream test.
donor=git('show','222d29ff:crates/ginux-vfs/src/lib.rs')
teststart=donor.index('    #[test]\n    fn dynamic_directories_metadata_and_sparse_append_io')
tests=donor[teststart:donor.rfind('\n}')]
at=s.rfind('\n}');s=s[:at]+'\n'+tests+s[at:]
p.write_text(s)
(root/'dependency.txt').write_text('Local prerequisite G05a bb2c82bf; upstream base3f2fe7df. Do not publish as standalone until the shared-offset prerequisite is upstream.\n')
print('Extracted G03b VFS foundation on explicit local G05a prerequisite')
