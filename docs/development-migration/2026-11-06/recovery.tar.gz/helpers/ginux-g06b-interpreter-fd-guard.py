from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G06b/source')
p=src/'crates/ginux-init/src/path_hooks.rs';s=p.read_text();a=s.index('        let mut first = [0; 256];',s.index('    pub fn interpreter('));b=s.index('\n    pub fn resolve_image(',a);parser=s[a:b];assert parser.endswith('    }\n');parser=parser[:-6].replace('file.read(', 'self.read(').replace('.chunks_exact(56)', '.as_chunks::<56>().0')
s=s[:a]+'''        file.interpreter(output)
    }

    pub fn interpreter_fd(pid: usize, fd: u32, output: &mut [u8; MAX_PATH]) -> Result<Option<(usize, bool)>, i64> {
        let mut name = [0; 80];
        name[..6].copy_from_slice(b"/proc/");
        let mut cursor = 6;
        for (index, mut number) in [pid, fd as usize].into_iter().enumerate() {
            let mut digits = [0; 20];
            let mut length = 0;
            loop {
                digits[length] = b'0' + (number % 10) as u8;
                length += 1;
                number /= 10;
                if number == 0 { break; }
            }
            for digit in digits[..length].iter().rev() { name[cursor] = *digit; cursor += 1; }
            if index == 0 { name[cursor..cursor+4].copy_from_slice(b"/fd/"); cursor += 4; }
        }
        // fd is a registered native image handle in a stopped, owned task.
        let opened = unsafe { syscall4(257, (-100isize) as usize, name.as_ptr() as usize, 0o2000000, 0) };
        if opened < 0 { return Err(opened as i64); }
        ImageFile(opened as usize).interpreter(output)
    }
'''+s[b:]
needle='impl ImageFile {\n';s=s.replace(needle,needle+'''    fn interpreter(&self, output: &mut [u8; MAX_PATH]) -> Result<Option<(usize, bool)>, i64> {
'''+parser+'''    }

''',1);p.write_text(s)
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text().replace('''        if !follow {
            return Ok(());
        } // Kernel rejects a final symlink itself.''','''        if !follow {
            let image = crate::path_hooks::ImageRoot::new(pid)?;
            if image.lookup(path.as_bytes(), &mut [0; MAX_PATH]).map_err(errno)?.0 == NodeKind::Symlink { return Ok(()); }
        }''',1)
# Inspect exact text in case rustfmt placed the explanatory comment separately.
s=s.replace('''        if !follow {
            return Ok(());
        } // Kernel rejects a final symlink itself.''','')
a=s.index('    fn check_interpreters(');b=s.index('    /// Configured-launch dispatch',a)
s=s[:a]+'''    pub fn native_exec_fd(&self, pid: usize, fd: u32) -> Result<(), i64> {
        let image = crate::path_hooks::ImageRoot::new(pid)?;
        let mut name = [0; MAX_PATH];
        let next = crate::path_hooks::ImageRoot::interpreter_fd(pid, fd, &mut name)?;
        self.check_interpreter_chain(pid, &image, name, next)
    }

    fn check_interpreters(&self, pid: usize, path: Path) -> Result<(), i64> {
        let image = crate::path_hooks::ImageRoot::new(pid)?;
        let mut name = [0; MAX_PATH];
        let next = image.interpreter(path.as_bytes(), &mut name)?;
        self.check_interpreter_chain(pid, &image, name, next)
    }

    fn check_interpreter_chain(&self, pid: usize, image: &crate::path_hooks::ImageRoot,
        mut name: [u8; MAX_PATH], mut next: Option<(usize, bool)>) -> Result<(), i64> {
        for _ in 0..16 {
            let Some((length, script)) = next else { return Ok(()); };
            let mut joined = [0; MAX_PATH];
            let base = if name.first() == Some(&b'/') { b"".as_slice() } else { self.cwd.as_bytes() };
            let separator = usize::from(!base.is_empty() && base != b"/");
            let end = base.len().checked_add(separator).and_then(|n| n.checked_add(length))
                .filter(|end| *end < MAX_PATH).ok_or(-36)?;
            joined[..base.len()].copy_from_slice(base);
            if separator != 0 { joined[base.len()] = b'/'; }
            joined[base.len()+separator..end].copy_from_slice(&name[..length]);
            let path = self.resolve(pid, &joined[..end], true, true)?;
            self.check_exec_owner(path.as_bytes())?;
            let mut physical = [0; MAX_PATH];
            let n = image.resolve_image(&joined[..end], &mut physical).map_err(errno)?;
            if physical[..n] != *path.as_bytes() { return Err(-95); }
            if !script { return Ok(()); }
            next = image.interpreter(path.as_bytes(), &mut name)?;
        }
        Err(-40)
    }

'''+s[b:];p.write_text(s)
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text();needle='''                native_dirfd = self.task(index).descriptors.exec_native_descriptor(r.rdi)? as u64;''';assert needle in s;s=s.replace(needle,needle+'''
                self.objects.filesystem.native_exec_fd(host, native_dirfd as u32)?;''',1);p.write_text(s)
