from pathlib import Path
import subprocess,json,re
root=Path('/tmp/ginux-contribution-preparation/G03c');source=root/'source'
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux'
base=json.loads((root/'composition.json').read_text())['base']
def original(file):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'show',base+':'+file],text=True)
# Preserve the shared current native decision; only add the configured filesystem dispatch.
p=source/'crates/ginux-init/src/launch.rs';s=p.read_text()
a=s.index('<<<<<<< current');b=s.index('>>>>>>> feature',a)+len('>>>>>>> feature')
s=s[:a]+'''        let dispatched = match filesystem.claim(pid, &registers) {
            Some(result) => NativeDecision::Hooked {
                lane: crate::dispatch::Lane::Filesystem,
                result,
            },
            None => decide_native(syscall, registers.rdi, registers.rsi, registers.rdx),
        };
        let decision = match dispatched {
            NativeDecision::Contract(decision) => decision,'''+s[b:]
p.write_text(s)
# Add targets without replacing the current native-supervision target or fixtures.
p=source/'Makefile';s=original('Makefile')
s=s.replace('.PHONY: build-launch-fixture test-launch test-native-supervision', '.PHONY: build-launch-fixture test-launch test-native-supervision build-launch-storage-fixture test-launch-storage')
s+='''
build-launch-storage-fixture:
\tmkdir -p .artifacts/launch
\t$(CC) -nostdlib -static -fno-stack-protector -fno-builtin -O2 -Wall -Wextra -Werror tests/fixtures/launch-storage-fixture.c -o .artifacts/launch/launch-storage-fixture

test-launch-storage:
\tpython3 scripts/test-launch-storage.py $(GINUX) .artifacts/launch/launch-storage-fixture
'''
p.write_text(s)
p=source/'.github/workflows/check.yml';s=original('.github/workflows/check.yml')
s=s.replace('make build build-launch-fixture build-process-fixtures build-gate1-fixture', 'make build build-launch-fixture build-launch-storage-fixture build-process-fixtures build-gate1-fixture')
s=s.replace('      - run: sudo make test-launch\n', '      - run: sudo make test-launch\n      - run: sudo make test-launch-storage\n')
p.write_text(s)
# Retain all current README content, and add only the storage feature material.
p=source/'README.md';s=original('README.md')
donor=subprocess.check_output(['git','-C',repo,'--work-tree='+repo,'show','10091e4e:README.md'],text=True)
a=donor.index('Optional `[storage].assignments`');b=donor.index('When requested, the result file',a)
section=donor[a:b]
needle='When requested, the result file';assert s.count(needle)==1
s=s.replace(needle,section+needle,1)
needle='sudo make test-launch\nsudo make test-native-supervision\n';assert s.count(needle)==1
s=s.replace(needle,needle+'make build-launch-storage-fixture\nsudo make test-launch-storage\n',1)
p.write_text(s)
for file in ['.github/workflows/check.yml','Makefile','README.md','crates/ginux-init/src/launch.rs']:
 text=(source/file).read_text();assert not re.search(r'^(<<<<<<<|=======|>>>>>>>)',text,re.M),file
assert (source/'crates/ginux-init/src/supervisor.rs').read_text()==original('crates/ginux-init/src/supervisor.rs')
print('Resolved all donor conflicts while preserving all current required CI and supervisor helpers')
