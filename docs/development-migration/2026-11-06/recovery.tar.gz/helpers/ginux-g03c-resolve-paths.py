from pathlib import Path
s=Path('/tmp/ginux-contribution-preparation/G03c/source')
donor=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
p=s/'crates/ginux-vfs/src/lib.rs';v=p.read_text();d=(donor/'crates/ginux-vfs/src/lib.rs').read_text();wrapper=d[d.index('pub fn resolve_namespace('):d.index('fn resolve_components(')]
v=v.replace('// Walk original components:', '/// Resolve a composed namespace with the same component walker used by the VFS.\n'+wrapper+'// Walk original components:');p.write_text(v)
p=s/'crates/ginux-init/src/path_hooks.rs';v=(donor/'crates/ginux-init/src/path_hooks.rs').read_text().replace('use crate::tracee_io::copy_memory;','use crate::fs_hooks::copy_memory;');start=v.index('    pub fn original_args(');end=v.index('    pub fn finish(',start);v=v[:start]+v[end:];p.write_text(v)
p=s/'crates/ginux-init/src/main.rs';v=p.read_text().replace('mod fs_hooks;','mod fs_hooks;\nmod path_hooks;');p.write_text(v)
p=s/'crates/ginux-init/src/fs_hooks.rs';v=p.read_text();start=v.index('        normalize(\n');end=v.index('    /// Configured-launch dispatch',start)
v=v[:start]+'''        let mut bytes = [0; MAX_PATH];
        let base = if absolute { b"".as_slice() } else { self.cwd.as_bytes() };
        let separator = usize::from(!base.is_empty() && base != b"/");
        let end = base.len().checked_add(separator)
            .and_then(|n| n.checked_add(text.as_bytes().len()))
            .filter(|n| *n < MAX_PATH).ok_or(-36)?;
        bytes[..base.len()].copy_from_slice(base);
        if separator != 0 { bytes[base.len()] = b'/'; }
        bytes[base.len() + separator..end].copy_from_slice(text.as_bytes());
        Path::from_bytes(&bytes[..end]).map_err(|_| -36)
    }

    fn resolve(&self, pid: usize, path: &[u8], follow: bool, missing: bool) -> Result<Path, i64> {
        let image = crate::path_hooks::ImageRoot::new(pid)?;
        let mut output = [0; MAX_PATH];
        let n = ginux_vfs::resolve_namespace(path, follow, missing, &mut output, |path, target| {
            if self.owns_path(path) || path != b"/" && self.prefixes[..self.count]
                .iter().any(|prefix| within(prefix.as_bytes(), path)) {
                return self.fs.metadata(path).map(|m| (m.kind, 0));
            }
            image.lookup(path, target)
        }).map_err(errno)?;
        Path::from_bytes(&output[..n]).map_err(|_| -36)
    }

    fn request_path(&self, pid: usize, r: &UserRegs) -> Result<Option<(u8, Path)>, i64> {
        let (argument, address, dirfd, follow, missing) = match r.orig_rax {
            2 => (0, r.rdi, (-100i64) as u64, r.rsi & 0o400000 == 0 && r.rsi & 0o300 != 0o300, r.rsi & 0o100 != 0),
            257 => (1, r.rsi, r.rdi, r.rdx & 0o400000 == 0 && r.rdx & 0o300 != 0o300, r.rdx & 0o100 != 0),
            4 | 21 | 90 => (0, r.rdi, (-100i64) as u64, true, false),
            6 | 87 | 89 => (0, r.rdi, (-100i64) as u64, false, false),
            83 => (0, r.rdi, (-100i64) as u64, false, true),
            258 => (1, r.rsi, r.rdi, false, true),
            262 => (1, r.rsi, r.rdi, r.r10 & 0x100 == 0, false),
            263 => (1, r.rsi, r.rdi, false, false),
            268 => (1, r.rsi, r.rdi, true, false),
            332 => (1, r.rsi, r.rdi, r.rdx & 0x100 == 0, false),
            439 => (1, r.rsi, r.rdi, r.r10 & 0x100 == 0, false),
            _ => return Ok(None),
        };
        let path = self.path(pid, address, dirfd)?;
        self.resolve(pid, path.as_bytes(), follow, missing).map(|p| Some((argument, p)))
    }

    /// Canonical image paths preserve assignment precedence even through links
    /// and parent components; the kernel never follows a hidden image subtree.
    pub fn native_path(&self, pid: usize, r: &UserRegs) -> Result<Option<(u8, Path)>, i64> {
        if !self.enabled() { return Ok(None); }
        let Some((argument, path)) = self.request_path(pid, r)? else { return Ok(None); };
        if self.owns_path(path.as_bytes()) { return Ok(None); }
        let raw = read_path(pid, if argument == 0 { r.rdi } else { r.rsi })?;
        if raw == path { return Ok(None); }
        Ok(Some((argument, path)))
    }

'''+v[end:]
start=v.index('        let (address, dirfd) = match r.orig_rax');end=v.index('        if !self.owns_path(path.as_bytes())',start)
v=v[:start]+'''        let path = match self.request_path(pid, r) {
            Ok(Some((_, path))) => path,
            Ok(None) => return None,
            Err(error) => return Some(error),
        };
'''+v[end:]
start=v.index('fn normalize(');end=v.index('#[repr(C)]',start);v=v[:start]+v[end:];v=v.replace('fn copy_memory(', 'pub(crate) fn copy_memory(')
# Unsupported owned access/readlink must never expose the hidden image.
v=v.replace('            _ => Err(-38),','            _ => Err(-95),')
p.write_text(v)
p=s/'crates/ginux-init/src/launch.rs';v=p.read_text();v=v.replace('    let mut awaiting_exit = false;','    let mut awaiting_exit = false;\n    let mut path_rewrite: Option<crate::path_hooks::Rewrite> = None;',1)
v=v.replace('        if awaiting_exit {\n            if override_exit {','''        if awaiting_exit {
            let rewritten = path_rewrite.is_some();
            if let Some(rewrite) = path_rewrite.take() {
                if let Err(reason) = rewrite.finish(pid, &mut registers) {
                    launch_fail(domain, pid, reason);
                }
            }
            if override_exit {
                registers.rax = override_result as u64;
            }
            if override_exit || rewritten {''',1)
# Above retains original repeated assignment inside SETREGS block; remove it.
v=v.replace('            if override_exit || rewritten {\n                registers.rax = override_result as u64;','            if override_exit || rewritten {',1)
v=v.replace('''            None => decide_native(syscall, registers.rdi, registers.rsi, registers.rdx),''','''            None => match crate::path_hooks::Rewrite::prepare(filesystem, pid, &mut registers) {
                Ok(rewrite) => {
                    if rewrite.is_some()
                        && ptrace(PTRACE_SETREGS, pid, 0, &registers as *const _ as usize) < 0 {
                        launch_fail(domain, pid, b"launch path translation failed");
                    }
                    path_rewrite = rewrite;
                    decide_native(syscall, registers.rdi, registers.rsi, registers.rdx)
                }
                Err(-5) => launch_fail(domain, pid, b"launch path scratch restoration failed"),
                Err(result) => NativeDecision::Hooked {
                    lane: crate::dispatch::Lane::Filesystem,
                    result,
                },
            },''',1)
p.write_text(v)
p=s/'tests/fixtures/launch-storage-fixture.c';v=p.read_text().replace('''    if (argc > 1 && argv[1][0] == 'm') {
        CHECK''','''    if (argc > 1 && argv[1][0] == 'm') {
        CHECK(DO(2, "/work/file", 0102, 0644) >= 1048576, 85);
        CHECK''');p.write_text(v)
