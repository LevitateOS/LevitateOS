from pathlib import Path
import subprocess,tempfile,json
repo='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux';root=Path('/tmp/ginux-contribution-preparation/G07');src=root/'source'
def git(*a):return subprocess.check_output(['git','-C',repo,'--work-tree='+repo,*a])
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text();s=s.replace('<<<<<<< current\n        self.task_mut(index).wait_status = Some(status);\n=======\n        self.task_mut(index).call.reset();\n>>>>>>> feature','        self.task_mut(index).wait_status = Some(status);\n        self.task_mut(index).call.reset();');assert '<<<<<<<' not in s;p.write_text(s)
with tempfile.TemporaryDirectory(prefix='ginux-g07-taskmerge-') as temp:
 t=Path(temp)
 for name,data in [('current',p.read_bytes()),('ancestor',git('show','e59e2e61^:crates/ginux-init/src/launch_tasks.rs')),('feature',git('show','e59e2e61:crates/ginux-init/src/launch_tasks.rs'))]:(t/name).write_bytes(data)
 r=subprocess.run(['git','merge-file','-p','-L','current','-L','ancestor','-L','feature',str(t/'current'),str(t/'ancestor'),str(t/'feature')],capture_output=True);assert 0<=r.returncode<=127;p.write_bytes(r.stdout);print('thread task owner initial conflicts',r.returncode)
p=src/'.github/workflows/check.yml';s=git('show','8c783e71:.github/workflows/check.yml').decode();s=s.replace('build-process-fixtures build-gate1-fixture','build-process-fixtures build-gate1-fixture build-launch-thread-fixture').replace('      - run: sudo make test-launch-exec\n','      - run: sudo make test-launch-exec\n      - run: sudo make test-launch-threads\n');p.write_text(s)
p=src/'Makefile';s=git('show','8c783e71:Makefile').decode();s+='''
.PHONY: build-launch-thread-fixture test-launch-threads
build-launch-thread-fixture:
	mkdir -p .artifacts/launch
	$(CC) -nostdlib -static -fno-stack-protector -fno-builtin -O2 -Wall -Wextra -Werror tests/fixtures/launch-thread-fixture.c -o .artifacts/launch/launch-thread-fixture

test-launch-threads:
	python3 scripts/test-launch-threads.py $(GINUX) .artifacts/launch/launch-thread-fixture
''';p.write_text(s)
p=src/'tests/fixtures/launch-thread-fixture.c';s=p.read_text();s=s.replace('        char cwd[16];\n        CHECK(DO(79,cwd,sizeof cwd,0)==6 && cwd[0]==\'/\' && cwd[1]==\'w\' && cwd[4]==\'k\' && !cwd[5],17);\n','');s=s.replace('if (replacement==-11) DO(7,0,0,1);','if (replacement==-11) DO(39,0,0,0);');p.write_text(s)
