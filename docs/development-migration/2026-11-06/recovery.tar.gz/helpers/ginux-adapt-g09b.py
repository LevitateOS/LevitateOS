from pathlib import Path
import re
root=Path('/tmp/ginux-contribution-preparation/G09b/source')
p=root/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();m=re.search(r'<<<<<<< current\n(.*?)=======\n(.*?)>>>>>>> feature\n',s,re.S);assert m
teardown=m.group(2);teardown=teardown[teardown.index('    pub fn teardown'):teardown.index('    pub fn readiness')];s=s[:m.start()]+teardown+s[m.end():];s=s.replace('const OBJECTS: usize = 4096;', 'const OBJECTS: usize = 32;')
s=s.replace('MemoryStorage::new((config.memory_mib as usize) * 1024 * 1024)', '''MemoryStorage::new(
                usize::try_from(config.memory_mib)
                    .ok()
                    .and_then(|mib| mib.checked_mul(1024 * 1024))
                    .ok_or(b"memory storage capacity exceeds address space".as_slice())?,
            )''');p.write_text(s)
p=root/'tests/fixtures/launch-storage-fixture.c';s=p.read_text();m=re.search(r'<<<<<<< current\n(.*?)=======\n(.*?)>>>>>>> feature\n',s,re.S);assert m;s=s[:m.start()]+m.group(1)+s[m.end():]
# Keep the established object limit; namespace scaling is a later packet.
s=s.replace('''char path[] = "/out/file-0000";
        for (word i = 0; i < 9999; ++i) {
            path[10] = '0' + i / 1000;
            path[11] = '0' + i / 100 % 10;
            path[12] = '0' + i / 10 % 10;
            path[13] = '0' + i % 10;''','''char path[] = "/out/file-00";
        for (word i = 0; i < 99; ++i) {
            path[10] = '0' + i / 10;
            path[11] = '0' + i % 10;''')
anchor="    if (argc > 1 && argv[1][0] == 'n') {"
growth='''    if (argc > 1 && argv[1][0] == 'g') {
        long fd=DO(2,"/out/growing",0102,0600);
        CHECK(fd>=3,120);
        for(word i=0;i<4096;++i) data[i]=(char)(i%251);
        for(word i=0;i<32;++i) CHECK(DO(1,fd,data,4096)==4096,121);
        CHECK(DO(5,fd,meta,0)==0 && *(word *)(meta+48)==131072,122);
        CHECK(DO(8,fd,0,0)==0,123);
        for(word n=0;n<32;++n) {
            CHECK(DO(0,fd,output,4096)==4096,124);
            for(word i=0;i<4096;++i) CHECK(output[i]==data[i],125);
        }
        CHECK(DO(8,fd,2*1024*1024,0)==2*1024*1024 && DO(1,fd,"Q",1)==1,126);
        CHECK(DO(8,fd,2*1024*1024-1,0)==2*1024*1024-1,127);
        CHECK(DO(0,fd,output,2)==2 && output[0]==0 && output[1]=='Q',128);
        long alias=DO(32,fd,0,0);
        CHECK(alias>=3 && DO(77,alias,3,0)==0 && DO(77,fd,8192,0)==0,129);
        CHECK(DO(8,alias,0,0)==0 && DO(0,fd,output,4096)==4096,130);
        for(word i=0;i<4096;++i) CHECK(output[i]==(i<3?data[i]:0),131);
        CHECK(DO(0,alias,output,4096)==4096,132);
        for(word i=0;i<4096;++i) CHECK(output[i]==0,133);
        CHECK(DO(8,fd,0,0)==0,134);
        long child=DO(57,0,0,0);
        if(child==0) { long code=DO(1,alias,"Z",1)==1?17:1; DO(60,code,0,0); __builtin_unreachable(); }
        int status=0;
        CHECK(child>1 && DO(61,child,&status,0)==child && status==(17<<8),135);
        CHECK(DO(8,fd,0,1)==1 && DO(8,fd,0,0)==0,136);
        CHECK(DO(0,fd,output,1)==1 && output[0]=='Z',137);
        CHECK(DO(87,"/out/growing",0,0)==0 && DO(3,fd,0,0)==0,138);
        CHECK(DO(8,alias,0,0)==0 && DO(0,alias,output,1)==1 && output[0]=='Z',139);
        CHECK(DO(3,alias,0,0)==0,140);
        return 0;
    }
'''
assert anchor in s;s=s.replace(anchor,growth+anchor);p.write_text(s)
p=root/'scripts/test-launch-storage.py';s=p.read_text();s=s.replace('len(sys.argv) != 3','len(sys.argv) < 3').replace('<storage-fixture>\'','<storage-fixture> [growth|bounds|quota ...]\'').replace('for p in sys.argv[1:]]','for p in sys.argv[1:3]]');at='''        for mode in ['path-owned', 'missing-owned', 'image-parent', 'alias-shadow']:''';extra='''        if sys.argv[3:]:
            for mode in sys.argv[3:]:
                if mode not in ('growth', 'bounds', 'quota'):
                    sys.exit('unknown selected storage scenario')
                invoke(['memory:/work', 'memory:/work/build', 'memory:/out'], [mode],
                       memory=16 if mode == 'bounds' else 256)
                print(f'PASS launch storage: {mode}')
            return
        invoke(['memory:/work', 'memory:/work/build', 'memory:/out'], ['growth'])
''';assert at in s;s=s.replace(at,extra+at);p.write_text(s)
p=root/'README.md';s=p.read_text().replace('This path does not implement resource quotas from the domain metadata.','Process resource quotas remain unfinished; writable file backing has the allocation bound described below.')
s=s.replace('read/write/pread, seek, close, basic descriptor flags, mkdir, file unlink, chmod,','read/write/pread, ftruncate, seek, close, basic descriptor flags, mkdir, file unlink, chmod,')
s=s.replace('''to 4096 bytes per call. Capacity is 32 objects (including seeded directories),
65536 bytes per file and 64 independently opened files. Aliases use the common
public descriptor table. Exhaustion returns `ENOSPC`, `EFBIG`, or `EMFILE` as appropriate.''','''to 4096 bytes per call. Metadata capacity remains 32 objects (including seeded
 directories) and 64 independently opened files. Bytes grow on demand in anonymous
supervisor mappings. Total mapped capacity, including page rounding and growth
reserve, is bounded by `[resources].memory_mib`, shared across files instead of
a 64 KiB per-file ceiling. This accounts for writable backing, not total process
RAM. Exhaustion returns `ENOSPC` without changing file bytes, size or offset.
Truncation returns unused pages; sparse gaps and regrowth read as zero. Unlinked
bytes survive until the last open reference closes; teardown releases mappings.
Aliases use the common public descriptor table. Handle exhaustion returns `EMFILE`.'''.replace('\n directories','\ndirectories'))
s=s.replace('there is no retention, export, storage generation or configured storage quota.','there is no retention, export, storage generation or separate storage-quota setting.');p.write_text(s)
print('Adapted G09b without threads, polling, namespace scaling or memfd mappings.')
