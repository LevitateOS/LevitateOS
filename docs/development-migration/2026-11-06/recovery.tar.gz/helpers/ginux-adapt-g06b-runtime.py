from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G06b/source')
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text().replace('ProcessError, ProcessTable, TaskId','ProcessError, ProcessTable, TaskId, WaitTarget')
s=s.replace('    exec: Option<Exec>,','    exec: Option<Exec>,\n    path_rewrite: Option<crate::path_hooks::Rewrite>,');s=s.replace('        exec: None,','        exec: None,\n        path_rewrite: None,').replace('native_arguments_allowed(self.task(index).host, r.orig_rax, r)','native_arguments_allowed(r.orig_rax, r)')
s=s.replace('.peek_wait(parent, selected)', '.peek_wait(parent, selected.map_or(WaitTarget::Any, WaitTarget::Specific), r.rdx as u32)').replace('.wait(self.task(index).id, Some(id.pid))','.wait(self.task(index).id, WaitTarget::Specific(id.pid), 0)').replace('result.status.to_ne_bytes()','result.status.word().to_ne_bytes()')
s=s.replace('''        if self.processes.exit(self.task(index).id, status).is_err() {''','''        let result = if exited(status) {
            self.processes.exit(self.task(index).id, (status >> 8) & 255)
        } else {
            self.processes.signaled(self.task(index).id, (status & 127) as u8)
        };
        if result.is_err() {''')
# A native descriptor/path transaction belongs to this task only. Restore path
# scratch first, then the descriptor owner restores the public arguments.
a='''        match decision {
            NativeDecision::Park { fd } => {''';b='''        let decision = match decision {
            NativeDecision::Contract(decision) => {
                match crate::path_hooks::Rewrite::prepare(self.objects.filesystem, self.task(index).host, r) {
                    Ok(rewrite) => { self.task_mut(index).path_rewrite = rewrite; NativeDecision::Contract(decision) }
                    Err(-5) => self.fail(domain, b"launch path scratch restoration failed"),
                    Err(result) => NativeDecision::Hooked { lane: crate::dispatch::Lane::Filesystem, result },
                }
            }
            decision => decision,
        };
        match decision {
            NativeDecision::Park { fd } => {''';assert a in s;s=s.replace(a,b,1)
s=s.replace('''        let pending = self.task(index).pending;''','''        if let Some(rewrite) = self.task_mut(index).path_rewrite.take() {
            let result = rewrite.finish(self.task(index).host, r);
            if let Err(reason) = result { self.fail(domain, reason); }
        }
        let pending = self.task(index).pending;''',1)
s=s.replace('fn prepare_exec(&mut self, index: usize, r: &UserRegs)','fn prepare_exec(&mut self, index: usize, r: &mut UserRegs)').replace('native_exec_path(host, r.rdi)?','native_exec_path(host, r.rdi, true)?').replace('native_exec_path(host, r.rsi)?','native_exec_path(host, r.rsi, r.r8 & 0x100 == 0)?')
s=s.replace('''        self.task_mut(index).exec = Some(Exec {''','''        let rewrite = crate::path_hooks::Rewrite::prepare(self.objects.filesystem, host, r)?;
        self.task_mut(index).path_rewrite = rewrite;
        if r.orig_rax == 59 { native_dirfd = r.rdi; }
        self.task_mut(index).exec = Some(Exec {''',1)
s=s.replace('''                if let Err(errno) = result {''','''                if result == Err(-5) {
                    self.fail(domain, b"exec path scratch restoration failed");
                }
                if let Err(errno) = result {''',1)
s=s.replace('''        self.task_mut(index).exec.as_mut().unwrap().stage = ExecStage::Completed;''','''        // Exec replaced the address space: the old path scratch no longer exists.
        self.task_mut(index).path_rewrite = None;
        self.task_mut(index).exec.as_mut().unwrap().stage = ExecStage::Completed;''',1)
p.write_text(s)
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();a=s.index('    /// Image execution must not fall through');b=s.index('    /// Configured-launch dispatch',a)
s=s[:a]+'''    /// Image execution never reopens an assigned writable or virtual-device path.
    pub fn native_exec_path(&self, pid: usize, address: u64, follow: bool) -> Result<(), i64> {
        let path = self.path(pid, address, (-100i64) as u64)?;
        let path = self.resolve(pid, path.as_bytes(), follow, false)?;
        if self.owns_path(path.as_bytes()) { return Err(-95); }
        if [b"/dev".as_slice(), b"/proc", b"/sys"].iter().any(|p| within(path.as_bytes(), p)) { return Err(-13); }
        Ok(())
    }

'''+s[b:];s=s.replace('''            4 | 21 | 90 =>''','''            59 => (0, r.rdi, (-100i64) as u64, true, false),
            322 => (1, r.rsi, r.rdi, r.r8 & 0x100 == 0, false),
            4 | 21 | 90 =>''',1).replace('matches!(r.orig_rax, 262 | 332 | 439)','matches!(r.orig_rax, 262 | 332 | 439 | 322)',1);p.write_text(s)
