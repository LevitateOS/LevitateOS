from pathlib import Path
import subprocess,os,tempfile,json,hashlib
repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux');root=Path('/tmp/ginux-contribution-preparation/G09a');src=root/'source';base=json.loads((root/'composition.json').read_text())['base'];file='crates/ginux-vfs/src/lib.rs'
def git(*args,env=None,input=None):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*args],env=env,input=input)
with tempfile.TemporaryDirectory(prefix='ginux-g09a-index-') as tmp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(tmp)/'index')};git('read-tree',base,env=env);blob=git('hash-object','-w','--stdin',input=(src/file).read_bytes()).decode().strip();git('update-index','--cacheinfo','100644',blob,file,env=env);tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip()
 head=git('commit-tree',tree,'-p',base,input=('feat(vfs): separate owned byte storage and support truncation\n\nKeep inline backing as the default while allowing bounded external\nbacking. Preserve shared open positions, whiteouts and open unlinked\nobjects; avoid copying image contents discarded by O_TRUNC.\n\n'+f'Signed-off-by: {name} <{email}>\n').encode()).decode().strip()
git('diff','--check',base,head);patch=git('format-patch','-1','--stdout','--no-signature',head);assert b'Levitate' not in patch and b'Recipe' not in patch
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head,'--'))
m={'packet':'G09a','parent_packet':'G09','purpose':'pluggable bounded VFS storage with truncation','base':base,'head':head,'tree':tree,'dependencies':['G03b'],'standalone':False,'status':'source checks passed; clean replay and separate self-review pending','patch_sha256':hashlib.sha256(patch).hexdigest()};(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
