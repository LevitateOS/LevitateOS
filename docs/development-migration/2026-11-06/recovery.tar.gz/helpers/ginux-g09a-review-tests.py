from pathlib import Path
p=Path('/tmp/ginux-contribution-preparation/G09a/source/crates/ginux-vfs/src/lib.rs');s=p.read_text();at=s.rfind('\n}')
s=s[:at]+'''
    #[test]
    fn truncate_image_does_not_need_capacity_for_discarded_contents() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 2, 2, 4> =
            VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        let image = fs.open(b"/base", O_READ).unwrap();
        let owned = fs.open(b"/base", O_READ | O_WRITE | O_TRUNC).unwrap();
        assert_eq!(fs.fstat(owned).unwrap().size, 0);
        assert_eq!(fs.write(owned, b"ok"), Ok(2));
        let mut original = [0; 4];
        assert_eq!(fs.read(image, &mut original), Ok(4));
        assert_eq!(&original, b"BASE");
        fs.seek(owned, 0, 0).unwrap();
        assert_eq!(fs.read(owned, &mut original), Ok(2));
        assert_eq!(&original[..2], b"ok");
    }

    #[test]
    fn failed_copy_up_preserves_image_and_reuses_storage_slot() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 1, 2, 4> =
            VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        assert_eq!(fs.open(b"/base", O_WRITE), Err(VfsError::FileTooLarge));
        assert_eq!(fs.overlay_files(), 0);
        let image = fs.open(b"/base", O_READ).unwrap();
        let mut data = [0; 4];
        assert_eq!(fs.read(image, &mut data), Ok(4));
        assert_eq!(&data, b"BASE");
        let owned = fs.open(b"/new", O_READ | O_WRITE | O_CREATE).unwrap();
        assert_eq!(fs.write(owned, b"ok"), Ok(2));
        let alias = fs.duplicate(owned, true).unwrap();
        fs.unlink(b"/new").unwrap();
        fs.close(owned).unwrap();
        fs.seek(alias, 0, 0).unwrap();
        assert_eq!(fs.read(alias, &mut data), Ok(2));
        assert_eq!(&data[..2], b"ok");
        fs.close_on_exec();
        let replacement = fs.open(b"/other", O_READ | O_WRITE | O_CREATE).unwrap();
        fs.truncate(replacement, 2).unwrap();
        assert_eq!(fs.read(replacement, &mut data), Ok(2));
        assert_eq!(&data[..2], &[0, 0]);
    }
'''+s[at:];p.write_text(s)
