from pathlib import Path
import subprocess,json,sys
root=Path('/tmp/ginux-contribution-preparation/G05');which=sys.argv[1];label='validation' if which=='source' else 'clean';results=[]
for command,name in [(['sudo','-n','make','test-launch-storage','test-launch-devices','test-launch-pipes','test-launch-fds','test-launch','test-native-supervision','test-gate1-setup'],label+'-runtime.log'),(['make','test-process-native'],label+'-process.log')]:
 with (root/name).open('w') as log:r=subprocess.run(command,cwd=root/which,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':command,'exit':r.returncode,'log':name});(root/(label+'-runtime-results.json')).write_text(json.dumps(results,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
