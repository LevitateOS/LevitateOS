from pathlib import Path
p=Path('/tmp/ginux-contribution-preparation/G09c/source/crates/ginux-vfs/src/lib.rs');s=p.read_text();at=s.rfind('\n}');s=s[:at]+'''
    #[test]
    fn directory_alias_cookies_and_image_link_paths_keep_their_owners() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 8, 32, 5> =
            VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        fs.mkdir(b"/work", 0o755).unwrap();
        let file = fs.open(b"/work/file", O_READ | O_WRITE | O_CREATE).unwrap();
        fs.write(file, b"data").unwrap();
        let dir = fs.open_directory(b"/work", 0).unwrap();
        let alias = fs.duplicate(dir, false).unwrap();
        fs.seek(alias, 2, 0).unwrap();
        assert_eq!(fs.seek(dir, 0, 1), Ok(2));
        assert_eq!(fs.directory_entry(dir, 2).unwrap().unwrap().name, b"file");
        assert_eq!(fs.seek(file, 0, 1), Ok(4));
        fs.close(dir).unwrap();
        let image = fs.open_directory(b"/bin", 0).unwrap();
        assert_eq!(fs.directory_path(image), Ok(b"/usr/bin".as_slice()));
        fs.seek(image, 1, 0).unwrap();
        assert_eq!(fs.seek(alias, 0, 1), Ok(2));
        assert_eq!(fs.seek(file, 0, 1), Ok(4));
        fs.rename(b"/work", b"/moved", false).unwrap();
        assert_eq!(fs.directory_path(alias), Ok(b"/moved".as_slice()));
        fs.chmod(b"/moved", 0o40750).unwrap();
        fs.fchmod(file, 0o100640).unwrap();
        assert_eq!(fs.fstat(alias).unwrap().mode, 0o750);
        assert_eq!(fs.fstat(file).unwrap().mode, 0o640);
        assert_eq!(fs.fchmod(alias, 0o42755), Err(VfsError::PermissionDenied));
        assert_eq!(fs.fstat(alias).unwrap().mode, 0o750);
    }

    #[test]
    fn namespace_mutations_reject_dot_entries_without_moving_their_parent() {
        let bytes = index_bytes();
        let mut fs: VirtualFs<'_, Reader, 4, 32, 4> =
            VirtualFs::new(Index::new(&bytes).unwrap(), Reader(*b"BASETOOL"));
        fs.mkdir(b"/work", 0o755).unwrap();
        fs.mkdir(b"/work/empty", 0o755).unwrap();
        assert_eq!(fs.remove_directory(b"/work/empty/."), Err(VfsError::InvalidPath));
        assert_eq!(fs.rename(b"/work/empty/.", b"/other", false), Err(VfsError::InvalidPath));
        assert_eq!(fs.rename(b"/work/empty", b"/work/..", false), Err(VfsError::InvalidPath));
        assert!(fs.metadata(b"/work/empty").is_ok());
        assert_eq!(fs.metadata(b"/other"), Err(VfsError::NotFound));
        fs.remove_directory(b"/work/empty/").unwrap();
        assert_eq!(fs.metadata(b"/work/empty"), Err(VfsError::NotFound));
    }
'''+s[at:];p.write_text(s)
