from pathlib import Path
root=Path("/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux")
p=root/"crates/ginux-core/src/lib.rs"
s=p.read_text().replace("13 | 14 | 15 | SYS_FORK | SYS_WAIT4 | 99 | 158 | 202 | 218 | 273 | 302 | 334", "13 | 14 | 15 | 35 | SYS_FORK | SYS_WAIT4 | 99 | 158 | 202 | 218 | 228 | 229 | 230 | 273 | 302 | 334")
s=s.replace("        302 => arg0 == 0 && arg1 <= 15,", """        // Only global read-only clocks. Dynamic fd clocks and host process/
        // thread CPU clock encodings must never cross the virtual PID/FD ABI.
        228 | 229 => matches!(arg0, 0 | 1),
        // Relative or absolute sleeps use the same clocks; the kernel checks
        // timespec addresses/ranges and signals interrupt the actual tracee.
        230 => matches!(arg0, 0 | 1) && arg1 <= 1,
        302 => arg0 == 0 && arg1 <= 15,""")
p.write_text(s)
p=root/"tests/fixtures/launch-task-fixture.c"
s=p.read_text().replace("    if (mode=='d') {", """    if (mode=='z') {
        long before[2], after[2], delay[2]={0,20000000}, resolution[2];
        CHECK(DO(228,0,before,0)==0 && before[0]>0,103);
        CHECK(DO(229,1,resolution,0)==0 && (resolution[0] || resolution[1]),104);
        CHECK(DO(228,1,before,0)==0,105);
        CHECK(call(230,1,0,(word)delay,0,0,0)==0,106);
        CHECK(DO(228,1,after,0)==0,107);
        CHECK((after[0]-before[0])*1000000000+after[1]-before[1]>=20000000,108);
        CHECK(call(230,0,0,(word)delay,0,0,0)==0,109);
        CHECK(call(230,1,1,(word)before,0,0,0)==0,110); // Past absolute deadline.
        CHECK(DO(35,delay,0,0)==0,111);
        CHECK(DO(228,-5,after,0)<0 && DO(228,2,after,0)<0,112);
        CHECK(DO(229,-5,after,0)<0 && call(230,-5,0,(word)delay,0,0,0)<0,113);
        CHECK(call(230,1,2,(word)delay,0,0,0)<0,114);
        CHECK(DO(228,1,1,0)==-14,115);
        delay[1]=1000000000;
        CHECK(DO(35,delay,0,0)==-22 && call(230,1,0,(word)delay,0,0,0)==-22,116);
    }
    else if (mode=='d') {""")
p.write_text(s)
p=root/"scripts/test-launch-tasks.py"
p.write_text(p.read_text().replace("for mode in ('directory',", "for mode in ('z-time', 'directory',"))
