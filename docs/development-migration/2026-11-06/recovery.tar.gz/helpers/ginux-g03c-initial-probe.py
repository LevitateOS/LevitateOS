import json, pathlib, shutil, subprocess, tempfile
source=pathlib.Path('/tmp/ginux-contribution-preparation/G03c/source')
with tempfile.TemporaryDirectory(prefix='ginux-storage-path-probe-') as d:
 p=pathlib.Path(d);root=p/'root';(root/'bin').mkdir(parents=True);(root/'work').mkdir();(root/'work/existing').write_text('hidden');(root/'image').write_text('immutable');(root/'image-link').symlink_to('/work')
 shutil.copyfile(source/'.artifacts/launch/launch-storage-fixture',root/'bin/fixture');(root/'bin/fixture').chmod(0o755)
 template=(source/'config/domain-gate5.toml').read_text().replace('init = "/bin/bash"','init = "/bin/fixture"').replace('id = "gate5-demo"','id = "path-probe"\nworkdir = "/work"').replace('assignments = []','assignments = ["memory:/work"]',1)
 for mode in ['path-owned','missing-owned','image-parent','alias-shadow']:
  config=p/'launch.toml';config.write_text(template.replace('args = []','args = '+json.dumps([mode])))
  result=p/'result.json';result.unlink(missing_ok=True);r=subprocess.run(['/tmp/ginux-contribution-preparation/G03c/ginux-initial','launch',str(config),str(root),'--result-file',str(result)],capture_output=True,timeout=20)
  print(mode,r.returncode,result.read_text() if result.exists() else r.stderr.decode(),flush=True)
