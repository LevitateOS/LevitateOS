from pathlib import Path
import subprocess,os,tempfile,json,hashlib,tarfile,io
r=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
root=Path('/tmp/ginux-contribution-preparation/G05a')
file='crates/ginux-vfs/src/lib.rs'
base='3f2fe7dfadd4b40e235d982a6a3d386dc6490177'
def git(*args,env=None,input=None): return subprocess.check_output(['git','-C',str(r),'--work-tree='+str(r),*args],env=env,input=input)
with tempfile.TemporaryDirectory(prefix='ginux-g05a-index-') as temp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(temp)/'index')}
 git('read-tree',base,env=env)
 blob=git('hash-object','-w','--stdin',input=(root/'source'/file).read_bytes()).decode().strip()
 git('update-index','--add','--cacheinfo','100644',blob,file,env=env)
 tree=git('write-tree',env=env).decode().strip()
 name=git('config','user.name').decode().strip()
 email=git('config','user.email').decode().strip()
 message=('fix(vfs): share offsets between duplicated descriptors\n\n'
          'Retain one bounded offset slot per open-file description so aliases\n'
          'observe each other’s reads and writes after close or FD reuse.\n'
          'Keep independent opens and close-on-exec flags separate.\n\n'
          'Add focused read/write and lifetime regressions, and update the\n'
          'unlink regression to consume its old object through the shared offset.\n\n'
          f'Signed-off-by: {name} <{email}>\n')
 head=git('commit-tree',tree,'-p',base,input=message.encode()).decode().strip()
(root/'candidate.patch').write_bytes(git('format-patch','-1','--stdout','--no-signature',head))
(root/'candidate.diff').write_bytes(git('diff',base,head,'--'))
paths=git('diff','--name-only',base,head).decode().splitlines()
assert paths==[file],paths
fresh=root/'clean-apply';assert not fresh.exists();fresh.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(fresh,filter='data')
subprocess.run(['git','apply','--check',str(root/'candidate.patch')],cwd=fresh,check=True)
subprocess.run(['git','apply',str(root/'candidate.patch')],cwd=fresh,check=True)
assert (fresh/file).read_bytes()==(root/'source'/file).read_bytes()
# Source outside the single changed file remains byte-identical to upstream.
checked=0
for name in git('ls-tree','-r','--name-only',base).decode().splitlines():
 a=fresh/name;b=root/'source'/name
 if a.is_symlink(): assert a.readlink()==b.readlink()
 elif a.is_file(): assert a.read_bytes()==b.read_bytes(),name
 checked+=1
manifest={'packet':'G05a','base':base,'head':head,'tree':tree,'changed_files':paths,'patch_sha256':hashlib.sha256((root/'candidate.patch').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((root/'source'/file).read_bytes()).hexdigest(),'clean_apply':'passes on exact upstream source; '+str(checked)+' tracked paths match the tested source','standalone':True,'review':'authoring followed by separate full-diff/caller review; no independent reviewer claim','remote_ci':'not run; no push/PR authorized','status':'local validation finishing; user review before publication','runtime_results':json.loads((root/'runtime-results.json').read_text())}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'title.txt').write_text('fix(vfs): share offsets between duplicated descriptors\n')
(root/'body.md').write_text('''Duplicated VFS descriptors currently advance separate offsets, so reading through an alias can repeat bytes already consumed through the original. Share the offset across duplicates while keeping separate opens and close-on-exec flags independent, including after close and descriptor-slot reuse.

Validation: three new regressions fail on upstream `3f2fe7df`; local static/unit, build and launch/native/process/setup checks pass on the candidate. The existing unlink regression now checks the remaining bytes and EOF through the shared offset. macOS Actions and full Rocky VM checks have not run for this unpublished candidate.
''')
print('Local standalone commit:',head,'tree:',tree,'tracked paths verified:',checked)
