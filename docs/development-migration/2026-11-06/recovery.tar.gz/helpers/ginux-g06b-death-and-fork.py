from pathlib import Path
import subprocess
src=Path('/tmp/ginux-contribution-preparation/G06b/source');repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
def git(*a):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*a]).decode()
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();a=s.index('    pub fn native_exec_path(');b=s.index('    /// Configured-launch dispatch',a);s=s[:a]+s[a:b].replace('follow, false','follow, true')+s[b:];p.write_text(s)
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text().replace('    Fork(usize),','    Fork { child: usize, flags: u64, child_tid: Option<u64> },').replace('    alive: bool,','    alive: bool,\n    adopted_reaped: bool,\n    wait_status: Option<i32>,').replace('        alive: true,','        alive: true,\n        adopted_reaped: false,\n        wait_status: None,')
s=s.replace('''                if r.orig_rax == 56 && !matches!(r.rdi, 17 | 0x4111) {''','''                let flags = r.rdi;
                let libc_fork = r.orig_rax == 56 && flags == 0x1200011;
                if r.orig_rax == 56 && !matches!(flags, 17 | 0x4111 | 0x1200011) {''',1)
s=s.replace('''                self.task_mut(index).pending = Pending::Fork(slot);''','''                self.task_mut(index).pending = Pending::Fork { child: slot, flags, child_tid: libc_fork.then_some(r.r10) };
                if libc_fork { r.rdi &= !0x1000000; }''',1)
s=s.replace('''        let Pending::Fork(slot) = self.task(parent).pending else {''','''        let Pending::Fork { child: slot, flags, child_tid } = self.task(parent).pending else {''',1)
needle='''        audit_write(b"ginux: task registered virtual-pid=");''';s=s.replace(needle,'''        if let Some(address) = child_tid {
            match crate::tracee_io::store_u32(host, address, self.task(slot).id.pid) {
                Ok(()) | Err(-14) => {}
                Err(_) => self.fail(domain, b"child tid rollback failed"),
            }
            let mut registers = self.registers(slot, domain);
            registers.rdi = flags;
            if ptrace(PTRACE_SETREGS, host, 0, &registers as *const _ as usize) < 0 {
                self.fail(domain, b"child clone argument restoration failed");
            }
        }
'''+needle,1)
s=s.replace('''            Pending::Fork(child) => {''','''            Pending::Fork { child, flags, .. } => {
                r.rdi = flags;''',1)
a=s.index('    fn registers(');b=s.index('    fn resume(',a);s=s[:a]+'''    fn read_registers(&self, index: usize) -> Result<UserRegs, isize> {
        let mut r = core::mem::MaybeUninit::uninit();
        let result = ptrace(PTRACE_GETREGS, self.task(index).host, 0, r.as_mut_ptr() as usize);
        if result < 0 { return Err(result); }
        Ok(unsafe { r.assume_init() })
    }
    fn registers(&mut self, index: usize, domain: &mut Domain) -> UserRegs {
        self.read_registers(index).unwrap_or_else(|_| self.fail(domain, b"launch register read failed"))
    }
'''+s[b:]
s=s.replace('''        let mut r = s.registers(index, domain);''','''        let mut r = match s.read_registers(index) {
            Ok(registers) => registers,
            Err(-3) => continue,
            Err(_) => s.fail(domain, b"launch register read failed"),
        };''',1)
a=s.index('        if ptrace(\n            0x420e,');b=s.index('        match info[0] as u8',a)
s=s[:a]+'''        let info_length = ptrace(0x420e, host, core::mem::size_of_val(&info), info.as_mut_ptr() as usize);
        // Preserve task ownership when a peer's SIGKILL invalidates this stop;
        // wait4's actual terminal event remains the sole death transition.
        if info_length == -3 { continue; }
        if info_length < 24 || (info[0] >> 32) as u32 != 0xc000003e {
            s.fail(domain, b"launch requires the x86-64 syscall ABI")
        }
'''+s[b:]
s=s.replace('''        if ptrace(PTRACE_SYSCALL, self.task(index).host, 0, signal) < 0 {''','''        let result = ptrace(PTRACE_SYSCALL, self.task(index).host, 0, signal);
        if result == -3 { return; }
        if result < 0 {''',1)
a=s.index('    fn run(');b=s.index('    fn emulate(',a);s=s[:a]+'''    fn run(&mut self, index: usize, r: &UserRegs, domain: &mut Domain) {
        let result = ptrace(PTRACE_SETREGS, self.task(index).host, 0, r as *const _ as usize);
        if result == -3 { return; }
        if result < 0 { self.fail(domain, b"launch register update failed"); }
        self.resume(index, 0, domain);
    }
'''+s[b:]
s=s.replace('''        if !self.task(index).alive {
            self.fail(domain, b"duplicate task death")
        }
        self.task_mut(index).alive = false;''','''        if !self.task(index).alive {
            let task = self.task(index);
            if !task.adopted_reaped && task.id.pid != 1 && task.wait_status == Some(status)
                && self.processes.view(task.id).is_ok_and(|view| view.id.pid == view.tgid) {
                self.task_mut(index).adopted_reaped = true;
                audit_write(b"ginux: adopted zombie native-reap virtual-pid=");
                audit_u64(self.task(index).id.pid as u64); audit_write(b"\\n");
                return;
            }
            self.fail(domain, b"inconsistent repeated task death");
        }
        self.task_mut(index).alive = false;
        self.task_mut(index).wait_status = Some(status);''',1)
p.write_text(s)
# Retain only G06 fixture additions, not the later clock/directory modes.
p=src/'tests/fixtures/launch-task-fixture.c';s=p.read_text();d=git('show','9279e71b:tests/fixtures/launch-task-fixture.c');a=d.index('static volatile int fork_tid');b=d.index('long task_main(',a);s=s.replace('long task_main(',d[a:b]+'long task_main(',1);a=d.index("    } else if (mode=='l'");b=d.index("    } else if (mode=='r')",a);at="    } else if (mode=='r')";assert at in s;s=s.replace(at,d[a:b]+at,1)
s=s.replace('''CHECK(DO(57,0,0,0)==-11 && DO(57,0,0,0)==-11,77);''','''CHECK(DO(57,0,0,0)==-11 && DO(57,0,0,0)==-11,77);
        CHECK(call(56,0x1200011,0,0,(word)&fork_tid,0,0)==-11 && fork_tid==0x1357,89);''',1)
s+=d[d.index('__asm__(".global signal_return'):]
d=git('show','07c949db:tests/fixtures/launch-task-fixture.c');a=d.index("    if (mode=='a')");b=d.index("    else if (mode=='z')",a);block=d[a:b];s=s.replace("    if (mode=='q')",block+"    else if (mode=='q')",1);p.write_text(s)
p=src/'scripts/test-launch-tasks.py';s=p.read_text().replace('import tempfile','import tempfile\nimport select\nimport time',1).replace("'shared-vfork', 'inherit'", "'shared-vfork', 'libc-fork', 'junk-child-tid', 'protected-child-tid', 'handler-return', 'inherit'",1).replace("'orphan', 'rollback'", "'orphan', 'adopted-zombie', 'rollback'",1)
d=git('show','07c949db:scripts/test-launch-tasks.py');a=d.index('            command=[binary');b=d.index('            record = ',a);start=s.index('            proc = subprocess.run(');end=s.index('            record = ',start);s=s[:start]+d[a:b]+s[end:];s=s.replace('                    import select\n','');p.write_text(s)
