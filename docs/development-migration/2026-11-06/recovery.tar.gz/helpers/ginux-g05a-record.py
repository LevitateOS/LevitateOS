from pathlib import Path
import json,shutil,hashlib
root=Path('/home/vince/Projects/LevitateOS')
scratch=Path('/tmp/ginux-contribution-preparation')
doc=root/'docs/ginux-contributions'
artifacts=root/'.artifacts/ginux-contribution-preparation'
for name in ['G01','G02','G05a']:
 dest=artifacts/name;dest.mkdir(parents=True,exist_ok=True)
 for f in (scratch/name).iterdir():
  if f.is_file() and f.suffix in ['.patch','.diff','.log','.json','.md','.txt']:
   shutil.copyfile(f,dest/f.name)
p=artifacts/'G05a/manifest.json';m=json.loads(p.read_text())
clean=json.loads((scratch/'G05a/clean-runtime-results.json').read_text())
assert len(clean)==4 and all(x['exit']==0 for x in clean)
m.update(status='reviewed and locally validated standalone candidate; user inspection and remote CI pending',unit_tests=68,vfs_tests=15,regression_baseline='all3 added regressions fail at exact upstream3f2fe7df; all pass with candidate',clean_runtime_results=clean)
p.write_text(json.dumps(m,indent=2)+'\n')
(doc/'g05a-review.md').write_text('''# G05a — shared VFS descriptor offsets

Local standalone candidate: `bb2c82bf18bb30a7ebc514af5131fa5b03a5fcc5`.
Sole parent: upstream main `3f2fe7dfadd4b40e235d982a6a3d386dc6490177`.
One file, `crates/ginux-vfs/src/lib.rs`, +95/-21. No prerequisite proposal,
branch creation/switch, existing source-tree mutation, push or PR.

## Reviewed behavior

Each independent open reserves an unused bounded position slot before any
namespace mutation. Duplicate descriptors retain that same slot. Reads/writes
advance it only after their existing successful I/O path; close/CLOEXEC leaves
it referenced while an alias remains. A reused descriptor number cannot acquire
an alias's live position; independent opens retain their own offsets. Access
rights and per-descriptor CLOEXEC behavior are unchanged.

The full final diff and VFS callers were reviewed after authoring. The capacity
proof is that a free descriptor implies at most FDS-1 live position identities;
allocation fails before mutation if no slot can be reserved. No new unsafe code,
host authority, dynamic allocation, global state, overflow-prone arithmetic or
unbounded object lifetime was introduced. Full source review is by the same agent
in a separate pass; independent reviewer coverage is not claimed.

One existing unlink test asserted that a duplicate could reread the entire old
file after the original consumed it. That assumed the bug being fixed. It now
reads the first old byte through the original, closes it, consumes the remaining
two bytes through the alias and verifies EOF; all original old/new-file lifetime
and CLOEXEC assertions remain. No upstream test/module/runner was removed.

## Evidence

Three new behavior regressions all fail at the exact upstream base: duplicate
reads, combined reads/writes, and original-close/slot-reuse/CLOEXEC. After the fix,
all15 VFS tests and all68 repository unit tests pass.

The following passed both in the original isolated candidate and a second clean
export of upstream main with only this patch applied:

- `make check test-unit`
- `make build build-launch-fixture build-process-fixtures build-gate1-fixture`
- `sudo -n make test-launch`
- `sudo -n make test-native-supervision`
- `make test-process-native`
- `sudo -n make test-gate1-setup`

All150 tracked files in the clean-applied tree match the tested candidate source;
only VFSlib.rs differs from upstream. Candidate commit/tree and source/patch hashes,
commands, timings, exact logs, concise draft body and patch are retained in
`.artifacts/ginux-contribution-preparation/G05a/`. A temporary Git index created
the local commit object; the repository's real index, refs and worktrees were
untouched. The patch also preserves the newer upstream #217/#218/#221 changes.

This candidate has passed R01–R04 locally. macOS Actions and full Rocky VM checks
have not run on it. No remote CI pass is claimed before publication. User review
of the complete package remains F04.
''')
(doc/'policy-held-packets.md').write_text('''# G01/G02 preparation disposition

These records preserve the active holds from P02; they do not turn pending policy
into approval or remove these packets from the final package.

G01 is existing PR#207 at e7f5f552. Its entire8-file bounded-poll diff was reviewed:
count/time bounds, checked pointer arithmetic, stdio/negative-FD restrictions,
POLLNVAL, both native callers and fixture/build wiring. No new code blocker found.
Its head and remote text remain untouched. No new source extraction, fresh local
runtime result or fresh remote CI status is claimed. Keep the current policy hold;
there is no duplicate PR candidate to create.

G02's existing local9ec95527 core/fixture delta was reviewed as donor material.
It exposes native realtime/monotonic clocks; fd/PID clock encodings stay denied.
The old task fixture covers passage, past absolute deadlines, rejected IDs/flags,
invalid pointers and timespecs. Actual interrupted-sleep evidence and a current-main
standalone fixture remain needed for R02/R03. The source remains local and held
under #179; its patch and review limitations are retained in
`.artifacts/ginux-contribution-preparation/G02/`. Do not label it fully validated.

Proceed one task at a time with independent ready work while these publication
contracts remain unresolved. F04 must distinguish these holds and missing checks
from the independently validated G05a correction.
''')
planfile=doc/'p05-package-plan.json';pkg=json.loads(planfile.read_text())
for e in pkg['packets']:
 if e['packet']=='G05a':e.update(status=m['status'],head=m['head'],tree=m['tree'],evidence='g05a-review.md')
 if e['packet']=='G01':e.update(status='existing PR accounted and source-reviewed; unchanged policy hold; no new candidate',evidence='policy-held-packets.md')
 if e['packet']=='G02':e.update(status='existing donor source reviewed; policy hold; standalone interruption/runtime evidence pending',evidence='policy-held-packets.md')
planfile.write_text(json.dumps(pkg,indent=2)+'\n')
p=root/'docs/ginux-contribution-task-list.md';s=p.read_text()
a=s.index('Next sequential work: account for G01')
b=s.index('\nActive skill:',a)
s=s[:a]+'''G01's existing held PR and G02's local policy delta have explicit
[review/hold dispositions](ginux-contributions/policy-held-packets.md). G02 still
needs standalone interrupted-sleep/runtime acceptance; it is not marked passed.

G05a is fully prepared and locally reviewed/validated as a standalone candidate
`bb2c82bf`, with current upstream3f2fe7df as its sole parent. [Review/evidence](ginux-contributions/g05a-review.md):
three baseline failures become passes,15 VFS/68 total unit tests pass, and all
required Linux launch/native/process/setup commands pass in both the candidate
and an independent clean main-plus-patch source export. Draft/patch/logs live under
`.artifacts/ginux-contribution-preparation/G05a/`. macOS remote CI is pending.
No branch/index/worktree/remote was changed; only local commit objects and exports
were created.

Exact next task: **G03 — configured writable storage and file metadata**.
Extract its smallest library/runtime boundaries against upstream, preserve G05a
as an independent optional composition, and fully review/test before moving on.
Existing policy-held packets stay in the final package with their unresolved
acceptance visible. F04 remains the user checkpoint before publication.
''' + s[b:]
p.write_text(s)
print('G05a package retained;68 units and clean runtime checks pass; nextG03')
