from pathlib import Path
root=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
p=root/'crates/ginux-vfs/src/lib.rs';s=p.read_text();mark='    pub fn overlay_files(&self) -> usize {'
s=s.replace(mark,'''    /// Enumerate live writable entries while the caller has quiesced mutation.
    /// Slots are opaque and stable only until the next filesystem mutation.
    pub fn overlay_entry(&self, slot: usize) -> Option<(&[u8], FileMetadata)> {
        let entry = self.overlay.get(slot)?;
        if !matches!(entry.state, 1 | 3) { return None; }
        Some((entry.path.as_bytes(), FileMetadata {
            inode: (self.index.len() + slot + 1) as u64,
            kind: if entry.state == 3 { NodeKind::Directory } else { NodeKind::File },
            mode: entry.mode,
            size: entry.len as u64,
        }))
    }

    /// Read a live writable regular file without allocating a guest descriptor.
    pub fn read_overlay(&self, slot: usize, offset: usize, output: &mut [u8]) -> Result<(), VfsError> {
        let entry = self.overlay.get(slot).ok_or(VfsError::NotFound)?;
        if entry.state != 1 { return Err(VfsError::NotFound); }
        if offset.checked_add(output.len()).filter(|end| *end <= entry.len).is_none() {
            return Err(VfsError::InvalidArgument);
        }
        self.storage.read(slot, offset, output)
    }

'''+mark);p.write_text(s)
p=root/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text();s=s.replace('    pub fn teardown(&mut self) {','''    pub fn export(&self) -> Result<(), &'static [u8]> {
        crate::storage_export::finish(|archive| {
            for slot in 0..OBJECTS {
                if let Some((path, metadata)) = self.fs.overlay_entry(slot) {
                    archive.entry(path, metadata, |offset, buffer| {
                        self.fs.read_overlay(slot, offset, buffer).map_err(|_| b"export read failed".as_slice())
                    })?;
                }
            }
            Ok(())
        })
    }

    pub fn teardown(&mut self) {''');p.write_text(s)
p=root/'crates/ginux-init/src/main.rs';s=p.read_text().replace('mod storage_memory;','mod storage_memory;\nmod storage_export;').replace('Some(Command::Launch(config_path, root_path, result_path)) => {\n            launch_main(config_path, root_path, result_path)','Some(Command::Launch(config_path, root_path, result_path, export_path)) => {\n            launch_main(config_path, root_path, result_path, export_path)');p.write_text(s)
p=root/'crates/ginux-init/src/launch.rs';s=p.read_text().replace('Launch(*const u8, *const u8, *const u8),','Launch(*const u8, *const u8, *const u8, *const u8),');a=s.index('        if argc == 4 {',s.index('} else if argc >= 4 && c_string_equals(command, b"launch")'));b=s.index('\n    } else {',a)
s=s[:a]+'''        let mut result_path = core::ptr::null();
        let mut export_path = core::ptr::null();
        let mut i = 4;
        while i < argc {
            if i + 1 >= argc { return Some(Command::LaunchUsage); }
            let option = unsafe { *argv.add(i) as *const u8 };
            let value = unsafe { *argv.add(i + 1) as *const u8 };
            if unsafe { *value } == 0 { return Some(Command::LaunchUsage); }
            if c_string_equals(option, b"--result-file") && result_path.is_null() {
                result_path = value;
            } else if c_string_equals(option, b"--export-file") && export_path.is_null() {
                export_path = value;
            } else { return Some(Command::LaunchUsage); }
            i += 2;
        }
        Some(Command::Launch(config_path, root_path, result_path, export_path))'''+s[b:]
s=s.replace('pub fn launch_main(config_path: *const u8, root_path: *const u8, result_path: *const u8) -> ! {','pub fn launch_main(config_path: *const u8, root_path: *const u8, result_path: *const u8, export_path: *const u8) -> ! {')
s=s.replace('    stage_result_path(result_path);','    stage_result_path(result_path);\n    crate::storage_export::prepare(export_path).unwrap_or_else(|reason| launch_startup_fail(reason));')
s=s.replace('[--result-file <fresh host path>]','[--result-file <fresh host path>] [--export-file <fresh tar path>]');p.write_text(s)
p=root/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text().replace('                s.teardown(domain);','                s.teardown(domain, status == 0);').replace('    fn teardown(&mut self, domain: &mut Domain) {','    fn teardown(&mut self, domain: &mut Domain, export: bool) {').replace('        self.objects.filesystem.teardown();','''        if export {
            if let Err(reason) = self.objects.filesystem.export() {
                supervision_error(domain, reason);
            }
        }
        self.objects.filesystem.teardown();''').replace('        self.teardown(domain);','        self.teardown(domain, false);');p.write_text(s)
