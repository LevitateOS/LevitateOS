import json, os, pathlib, subprocess

root = pathlib.Path('/tmp/ginux-broad-review-20261105')
root.mkdir(exist_ok=True)
recipes = root / 'recipes'
(recipes / 'modules').mkdir(parents=True, exist_ok=True)
cases = {
    'define': ('const RECIPE_API = 2; let ctx = #{name: "define", value: CUSTOM_INPUT}; fn is_installed(ctx) { ready(ctx) }', ['isinstalled', '--define', 'CUSTOM_INPUT=expected']),
    'nested': ('const RECIPE_API = 2; import "modules/facts.rhai" as facts; let ctx = #{name: "nested"}; fn is_installed(ctx) { ctx.value = facts::value(); ready(ctx) }', ['isinstalled']),
    'dependency': ('const RECIPE_API = 2; let deps = ["helper"]; let ctx = #{name: "dependency"}; fn is_installed(ctx) { if ctx.contains("done") { return ready(ctx); } needs_work(ctx, "not installed") } fn is_built(ctx) { ready(ctx) } fn install(ctx) { ctx.done = true; ctx }', ['install']),
}
(recipes / 'modules/facts.rhai').write_text('fn value() { "module value" }')
(recipes / 'helper.rhai').write_text('const RECIPE_API = 2; let ctx = #{name: "helper"}; fn is_installed(ctx) { ready(ctx) }')
env = dict(os.environ, GINUX_BIN='/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux/target/x86_64-unknown-linux-gnu/release/ginux', GINUX_ROOTFS='/home/vince/Projects/LevitateOS/.artifacts/ginux-env/oci-cache/rocky-10.2.20260525.0-amd64-rootfs.tar', XDG_DATA_HOME=str(root/'data'), XDG_CONFIG_HOME=str(root/'config'), XDG_CACHE_HOME=str(root/'cache'))
results = []
for name, (source, args) in cases.items():
    (recipes / (name+'.rhai')).write_text(source)
    command = ['/home/vince/Projects/LevitateOS/target/debug/recipe', args[0], name, '--recipes-path', str(recipes), '--no-persist-ctx'] + args[1:]
    run = subprocess.run(command, env=env, capture_output=True, timeout=45)
    (root/(name+'.stdout')).write_bytes(run.stdout)
    (root/(name+'.stderr')).write_bytes(run.stderr)
    results.append(dict(name=name, command=command, code=run.returncode, stderr_tail=run.stderr.decode(errors='replace')[-3500:]))
(root/'results.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
