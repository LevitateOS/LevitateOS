from pathlib import Path
import json,subprocess,re,shutil
root=Path('/tmp/ginux-contribution-preparation/G03c');old=json.loads((root/'manifest.json').read_text());(root/'manifest-before-doc-correction.json').write_text(json.dumps(old,indent=2)+'\n')
for name in ['source','clean-apply']:
 p=root/name/'README.md';s=p.read_text();oldtext='''select `profile = "balanced"` and `backend = "ptrace-native"`; storage and device
assignments are not implemented by this command and are rejected.''';new='''select `profile = "balanced"` and `backend = "ptrace-native"`. Memory storage is
supported as described below; device assignments are rejected.''';assert oldtext in s;s=s.replace(oldtext,new).replace('directory descriptors, directory enumeration/removal, symlinks, hardlinks,','directory descriptors, directory enumeration/removal, owned symlinks, hardlinks,').replace('to 4096 bytes per call. Capacity is\n32 objects','to 4096 bytes per call. Capacity is 32 objects');p.write_text(s)
subprocess.run(['python3','/tmp/ginux-g03c-commit.py'],check=True)
new=json.loads((root/'manifest.json').read_text());updated={**old,**{k:new[k] for k in ['head','tree','patch_sha256']}};updated['documentation_correction']='Removed stale introductory rejection of memory storage; clarified owned-link exclusion. README-only change after validated source; executable bytes unchanged.'
(root/'manifest.json').write_text(json.dumps(updated,indent=2)+'\n')
repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
def git(*a):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*a])
assert git('diff','--name-only',old['head'],new['head']).decode().splitlines()==['README.md']
assert not git('diff','--check',old['head'],new['head'])
# The pre-existing clean source gains only the corrected documentation, matching
# the new object. Its previously tested executable source bytes are unchanged.
for name in git('ls-tree','-r','--name-only',new['head']).decode().splitlines():
 a=root/'source'/name;b=root/'clean-apply'/name
 if a.is_symlink():assert a.readlink()==b.readlink()
 else:assert a.read_bytes()==b.read_bytes()
print('Corrected README-only G03c:',new['head']);print(git('diff','--stat',new['base'],new['head']).decode())
p=Path('/tmp/ginux-contribution-preparation/G04/composition.json');d=json.loads(p.read_text());assert d['base']==old['head'];d['base']=new['head'];p.write_text(json.dumps(d,indent=2)+'\n')
p=Path('/tmp/ginux-contribution-preparation/G04/source/README.md');s=p.read_text().replace(oldtext,'''select `profile = "balanced"` and `backend = "ptrace-native"`. Only the `null`
device assignment and memory-storage backend described below are supported.''').replace('directory descriptors, directory enumeration/removal, symlinks, hardlinks,','directory descriptors, directory enumeration/removal, owned symlinks, hardlinks,').replace('to 4096 bytes per call. Capacity is\n32 objects','to 4096 bytes per call. Capacity is 32 objects');p.write_text(s)
