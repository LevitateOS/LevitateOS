from pathlib import Path
import subprocess,os,tempfile,json,hashlib,tarfile,io,re
repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
root=Path('/tmp/ginux-contribution-preparation/G03b')
base='bb2c82bf18bb30a7ebc514af5131fa5b03a5fcc5'
file='crates/ginux-vfs/src/lib.rs'
def git(*args,env=None,input=None):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*args],env=env,input=input)
with tempfile.TemporaryDirectory(prefix='ginux-g03b-index-') as temp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(temp)/'index')};git('read-tree',base,env=env)
 blob=git('hash-object','-w','--stdin',input=(root/'source'/file).read_bytes()).decode().strip()
 git('update-index','--add','--cacheinfo','100644',blob,file,env=env)
 tree=git('write-tree',env=env).decode().strip()
 name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip()
 msg=('feat(vfs): add bounded writable metadata and file positioning\n\n'
      'Add virtual inode metadata, owned directories, mode changes, seek,\n'
      'append/exclusive create and descriptor flag access for writable VFS\n'
      'clients. Preserve component-wise lookup and live unlinked objects.\n\n'
      'Cover sparse/empty I/O, alias seeks, exclusive final links and failed\n'
      'operations while retaining all existing VFS regressions.\n\n'
      f'Signed-off-by: {name} <{email}>\n')
 head=git('commit-tree',tree,'-p',base,input=msg.encode()).decode().strip()
patch=git('format-patch','-1','--stdout','--no-signature',head);assert b'Levitate' not in patch and b'Recipe' not in patch
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head,'--'))
assert git('diff','--name-only',base,head).decode().splitlines()==[file]
assert not git('diff','--summary',base,head)
fresh=root/'clean-apply';assert not fresh.exists();fresh.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(fresh,filter='data')
subprocess.run(['git','apply','--check',str(root/'candidate.patch')],cwd=fresh,check=True)
subprocess.run(['git','apply',str(root/'candidate.patch')],cwd=fresh,check=True)
for name in git('ls-tree','-r','--name-only',base).decode().splitlines():
 a=fresh/name;b=root/'source'/name
 if a.is_symlink():assert a.readlink()==b.readlink()
 elif a.is_file():assert a.read_bytes()==b.read_bytes(),name
m={'packet':'G03b','parent_packet':'G03','purpose':'bounded writable VFS metadata/directory/positioning primitives','upstream_base':'3f2fe7dfadd4b40e235d982a6a3d386dc6490177','local_prerequisite':'G05a','base':base,'head':head,'tree':tree,'changed_files':[file],'patch_sha256':hashlib.sha256(patch).hexdigest(),'source_sha256':hashlib.sha256((root/'source'/file).read_bytes()).hexdigest(),'unit_tests':sum(int(x) for x in re.findall(r'test result: ok\. (\d+) passed',(root/'static-unit.log').read_text())),'vfs_tests':24,'regressions':'4 review cases fail on original donor10091e4e, all24 VFS tests pass on corrected extraction','standalone':False,'publication_condition':'G05a merged into upstream main, then refresh this isolated feature against that main and revalidate; no public stack','status':'reviewed on explicit local prerequisite; clean replay finishing; not standalone-ready','remote_ci':'not run; publication unauthorized'}
(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
(root/'title.txt').write_text('feat(vfs): add bounded writable metadata and file positioning\n')
(root/'body.md').write_text('''Writable VFS clients need metadata, directory creation and file positioning for ordinary file operations. Add virtual inode metadata, owned directories, mode changes, seek, append/exclusive create and descriptor flags while preserving component-wise lookup and open-object lifetime.

Local validation with the duplicated-offset prerequisite:77 unit tests (24 VFS), static checks, build and required Linux launch/native/process/setup scenarios pass. Review regressions cover aliases, sparse/empty I/O, final symlinks, directory capacity and rejected mutations. macOS Actions/full Rocky VM checks are unrun.
''')
print('G03b local-prerequisite commit:',head,'unit tests:',m['unit_tests'])
print(git('diff','--stat',base,head).decode())
