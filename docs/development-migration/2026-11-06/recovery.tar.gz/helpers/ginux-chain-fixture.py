from pathlib import Path
p=Path('tests/fixtures/launch-owned-exec-fixture.c');s=p.read_text();a='long owned_exec_main(word *stack)';s=s.replace(a,'''static int equal(const char *a, const char *b)
{
    for (word i=0;;++i) { if (a[i]!=b[i]) return 0; if (!a[i]) return 1; }
}
'''+a,1)
a="    if (mode=='r' && argc>2";i=s.index(a);s=s[:i]+'''    if (mode=='b') {
        CHECK(argc==5 || argc==7,100);
        int native=equal(argv[argc-1],"native");
        CHECK(equal(argv[0],native?"/bin/payload":"/work/program") && equal(argv[1],"beta"),101);
        if (argc==7) CHECK(equal(argv[2],"/work/middle") && equal(argv[3],"alpha option"),102);
        CHECK(equal(argv[argc-3],"/work/script") && equal(argv[argc-2],"spaced argument"),103);
        CHECK(env[0] && equal(env[0],"OWNED=yes") && !env[1],104);
        CHECK(DO(2,"/work/program",1,0)==(native?3:-26),105);
        if (native) CHECK(DO(3,3,0,0)==0,106);
        CHECK(DO(2,"/work/script",1,0)==3 && DO(3,3,0,0)==0,107);
        if (argc==7) CHECK(DO(2,"/work/middle",1,0)==3 && DO(3,3,0,0)==0,108);
        CHECK(DO(1,1,"script-ready\\n",13)==13 && DO(0,0,buffer,1)==1,109);
        DO(1,1,"script-chain: PASS\\n",19); return 0;
    }
'''+s[i:]
a='''    CHECK(DO(2,"/work/program",02000000,0)==3,34);''';s=s.replace(a,'''    if (mode=='i' || mode=='j' || mode=='k') {
        char *args[]={"ignored argv zero","spaced argument",mode=='k'?"native":"owned",0};
        char *values[]={"OWNED=yes",0};
        const char direct[]="#!/work/program beta\\n";
        const char outer[]="#!/work/middle alpha option\\n";
        const char native[]="#!/bin/payload beta\\n";
        const char cycle[]="#!/work/loop\\n";
        CHECK(publish("/work/loop",cycle,sizeof cycle-1)==0,110);
        CHECK(DO(59,"/work/loop",args,values)==-40,111);
        CHECK(DO(2,"/work/loop",1,0)==3 && DO(3,3,0,0)==0,112);
        CHECK(publish("/work/script",direct,sizeof direct-1)==0,113);
        CHECK(DO(90,"/work/program",0644,0)==0 && DO(59,"/work/script",args,values)==-13,114);
        CHECK(DO(90,"/work/program",0755,0)==0,115);
        CHECK(DO(2,"/work/script",1,0)==3 && DO(3,3,0,0)==0,116);
        if (mode!='i') {
            CHECK(publish("/work/middle",mode=='k'?native:direct,mode=='k'?sizeof native-1:sizeof direct-1)==0,117);
            CHECK(publish("/work/script",outer,sizeof outer-1)==0,118);
        }
        DO(59,"/work/script",args,values); return 119;
    }
'''+a,1);p.write_text(s)
p=Path('scripts/test-launch-owned-exec.py');s=p.read_text();a="        print('test-launch-owned-exec: PASS";i=s.index(a);s=s[:i]+'''        for mode in ('interpreter', 'joined-interpreters', 'kernel-interpreter'):
            path = work / f'{mode}.toml'
            path.write_text(config.replace('args = []', 'args = ' + json.dumps([mode])))
            with (work / f'{mode}.audit').open('wb') as audit:
                proc = subprocess.Popen([binary, 'launch', str(path), str(root)],
                    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=audit)
                try:
                    assert select.select([proc.stdout], [], [], 10)[0], mode
                    assert proc.stdout.readline() == b'script-ready\\n', (mode, (work / f'{mode}.audit').read_text())
                    target, = children(proc.pid)
                    assert sorted(int(p.name) for p in Path(f'/proc/{target}/fd').iterdir()) == [0, 1, 2]
                    stdout, _ = proc.communicate(b'G', timeout=10)
                    assert proc.returncode == 0 and stdout == b'script-chain: PASS\\n', (mode, proc.returncode, stdout)
                    assert b'teardown tasks=0 owned-handles=0' in (work / f'{mode}.audit').read_bytes()
                finally:
                    if proc.poll() is None:
                        proc.kill()
                        proc.communicate(timeout=5)
            print('PASS script chain ' + mode, flush=True)
'''+s[i:];p.write_text(s)
