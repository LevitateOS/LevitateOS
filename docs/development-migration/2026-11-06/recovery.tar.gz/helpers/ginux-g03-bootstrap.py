from pathlib import Path
import subprocess,tarfile,io
repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux')
root=Path('/tmp/ginux-contribution-preparation')
def archive(target):
 assert not target.exists(),target
 target.mkdir(parents=True)
 data=subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),'archive','3f2fe7df'])
 with tarfile.open(fileobj=io.BytesIO(data)) as t:t.extractall(target,filter='data')
archive(root/'baseline-main/source')
source=root/'G03a/source';archive(source)
p=source/'crates/ginux-init/src/launch.rs'
s=p.read_text();assert s.count('const SYS_MKDIRAT: usize = 259;')==1
p.write_text(s.replace('const SYS_MKDIRAT: usize = 259;','const SYS_MKDIRAT: usize = 258;'))
p=source/'scripts/test-launch.py'
s=p.read_text();needle='''        invoke(["exit"], 0, "exited", changes={"args = [": 'workdir = "/work/a..b"\\nargs = ['})'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
        invoke(["exit"], 0, "exited", changes={"args = [": 'workdir = "/created-workdir"\\nargs = ['})
        if not (root / "created-workdir").is_dir():
            raise RuntimeError("missing workload directory was not created as a directory")''')
p.write_text(s)
print('Prepared G03a independent mkdirat correction and missing-workdir regression')
