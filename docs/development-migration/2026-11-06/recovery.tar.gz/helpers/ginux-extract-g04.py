from pathlib import Path
import subprocess,tarfile,io,json
repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux');root=Path('/tmp/ginux-contribution-preparation/G04');src=root/'source';assert not src.exists();src.mkdir(parents=True)
def git(*a):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*a])
base='5ee456348905c4985689053f259484706ac3c8c0';donor='e3458063'
with tarfile.open(fileobj=io.BytesIO(git('archive',base))) as t:t.extractall(src,filter='data')
for file in ['crates/ginux-init/src/device_hooks.rs','crates/ginux-init/src/tracee_io.rs','scripts/test-launch-devices.py','tests/fixtures/launch-device-fixture.c']:(src/file).write_bytes(git('show',donor+':'+file))
p=src/'crates/ginux-init/src/fs_hooks.rs';s=p.read_text().replace('use crate::supervisor::{syscall4, syscall6, UserRegs};','use crate::supervisor::{syscall4, UserRegs};\nuse crate::tracee_io::{copy_memory, read_path};');s=s.replace('    cwd: Path,','    cwd: Path,\n    null: bool,');s=s.replace('''            count,
            cwd:''','''            count,
            null: config.devices.as_slice().iter().any(|name| name.as_bytes() == b"null"),
            cwd:''')
a=s.index('    pub fn enabled(&self)');b=s.index('        let mut limits',a);s=s[:a]+'''    /// Both virtual object ranges remain disjoint from native descriptors.
    pub fn reserve_descriptors(&self) -> bool {
'''+s[b:]
s=s.replace('''            image.lookup(path, target)''','''            if path == b"/dev" { return Ok((NodeKind::Directory, 0)); }
            if path == b"/dev/null" && self.null { return Ok((NodeKind::File, 0)); }
            if within(path, b"/dev") { return Err(VfsError::NotFound); }
            image.lookup(path, target)''');s=s.replace('    fn request_path(', '    pub(crate) fn request_path(').replace('            268 => (1, r.rsi, r.rdi, true, false),','            268 | 269 => (1, r.rsi, r.rdi, true, false),')
s=s.replace('''        if !self.enabled() {
            return Ok(None);
        }
''','').replace('''        if !self.enabled() {
            return None;
        }
''','')
a=s.index('#[repr(C)]\nstruct IoVec');b=s.index('fn copy_metadata(',a);s=s[:a]+s[b:];a=s.index('    let mut bytes = [0u8; 256];',s.index('fn copy_metadata('));b=s.index('\nfn errno(',a)
s=s[:a]+'''    crate::tracee_io::write_stat(pid, address, crate::tracee_io::Stat {
        inode: metadata.inode,
        mode: metadata.mode | if metadata.kind == NodeKind::Directory { 0o40000 } else { 0o100000 },
        size: metadata.size,
        device_major: 0,
        device_minor: 0,
    }, statx)
}
''' + s[b:];s=s.replace('fn valid_statx(', 'pub(crate) fn valid_statx(');p.write_text(s)
p=src/'crates/ginux-init/src/path_hooks.rs';s=p.read_text().replace('use crate::fs_hooks::copy_memory;','use crate::tracee_io::copy_memory;');p.write_text(s)
p=src/'crates/ginux-init/src/device_hooks.rs';s=p.read_text();a=s.index('    pub fn enabled(');b=s.index('    pub fn claim(',a);s=s[:a]+s[b:];a=s.index('        let (pointer, dirfd)');b=s.index('        if path.as_bytes()',a)
s=s[:a]+'''        let path = match fs.request_path(pid, r) {
            Ok(Some((_, path))) => path,
            Ok(None) => return None,
            Err(error) => return Some(error),
        };
'''+s[b:];s=s.replace('if r.r10 & !0x100 != 0 {','if r.r10 & !0x1900 != 0 {').replace('if r.rdx & !0x9100 != 0 {','if !crate::fs_hooks::valid_statx(r.rdx, r.r10) {');s=s.replace('''                if flags != 0x1000 {
                    Err(-22)
                } else {''','''                let valid = if r.orig_rax == 262 { flags & !0x1900 == 0 }
                    else { crate::fs_hooks::valid_statx(flags, r.r10) };
                if flags & 0x1000 == 0 || !valid {
                    Err(-22)
                } else {''');p.write_text(s)
p=src/'crates/ginux-init/src/launch.rs';s=p.read_text();s=s.replace('''    let mut filesystem = crate::fs_hooks::LaunchFs::prepare(&config)''','''    let mut devices = crate::device_hooks::LaunchDevices::prepare(&config)
        .unwrap_or_else(|reason| launch_startup_fail(reason));
    let mut filesystem = crate::fs_hooks::LaunchFs::prepare(&config)''',1)
s=s.replace('supervise_launch(child as usize, &mut domain, &mut filesystem)','supervise_launch(child as usize, &mut domain, &mut filesystem, &mut devices)',1);s=s.replace('''    if !config.devices.as_slice().is_empty() {
        launch_startup_fail(b"launch does not support device assignments");
    }
''','');s=s.replace('''    filesystem: &mut crate::fs_hooks::LaunchFs,
) -> ! {''','''    filesystem: &mut crate::fs_hooks::LaunchFs,
    devices: &mut crate::device_hooks::LaunchDevices,
) -> ! {''',1)
s=s.replace('''        let dispatched = match filesystem.claim(pid, &registers) {
            Some(result) => NativeDecision::Hooked {
                lane: crate::dispatch::Lane::Filesystem,
                result,
            },''','''        let claimed = devices.claim(pid, &registers, filesystem)
            .map(|result| (crate::dispatch::Lane::Device, result))
            .or_else(|| filesystem.claim(pid, &registers).map(|result| (crate::dispatch::Lane::Filesystem, result)));
        let dispatched = match claimed {
            Some((lane, result)) => NativeDecision::Hooked { lane, result },''')
s=s.replace('''                    crate::dispatch::Lane::Filesystem => b"filesystem",''','''                    crate::dispatch::Lane::Filesystem => b"filesystem",
                    crate::dispatch::Lane::Device => b"device",''');p.write_text(s)
p=src/'crates/ginux-init/src/dispatch.rs';s=p.read_text().replace('    Filesystem,','    Filesystem,\n    Device,',1).replace('        Lane::Contract => NativeDecision::Contract(decide_balanced(syscall)),','        Lane::Device | Lane::Contract => NativeDecision::Contract(decide_balanced(syscall)),',1);p.write_text(s)
p=src/'crates/ginux-init/src/main.rs';s=p.read_text().replace('mod channel_hooks;','mod channel_hooks;\nmod device_hooks;',1).replace('mod supervisor;','mod supervisor;\nmod tracee_io;',1).replace('                    Lane::Filesystem => b"filesystem",','                    Lane::Filesystem => b"filesystem",\n                    Lane::Device => b"device",');p.write_text(s)
p=src/'Makefile';s=p.read_text()+'''
.PHONY: build-launch-device-fixture test-launch-devices
build-launch-device-fixture:
	mkdir -p .artifacts/launch
	$(CC) -nostdlib -static -fno-stack-protector -fno-builtin -O2 -Wall -Wextra -Werror tests/fixtures/launch-device-fixture.c -o .artifacts/launch/launch-device-fixture

test-launch-devices:
	python3 scripts/test-launch-devices.py $(GINUX) .artifacts/launch/launch-device-fixture
''';p.write_text(s)
p=src/'.github/workflows/check.yml';s=p.read_text().replace('build-launch-storage-fixture build-process-fixtures','build-launch-storage-fixture build-launch-device-fixture build-process-fixtures').replace('      - run: sudo make test-launch-storage','      - run: sudo make test-launch-storage\n      - run: sudo make test-launch-devices');p.write_text(s)
p=src/'README.md';s=p.read_text();d=git('show',donor+':README.md').decode();a=d.index('The configured `/dev` view');b=d.index('\nWhen requested, the result file',a);s=s.replace('\nWhen requested, the result file','\n'+d[a:b]+'\nWhen requested, the result file',1);s=s.replace('Device assignments\nand storage backends other than the memory backend below are rejected.','Only the `null`\ndevice assignment and memory-storage backend described below are supported.');s=s.replace('sudo make test-launch-storage\n```','sudo make test-launch-storage\nmake build-launch-device-fixture\nsudo make test-launch-devices\n```');p.write_text(s)
(root/'composition.json').write_text(json.dumps({'upstream':'3f2fe7df','base':base,'donor':donor,'dependencies':['G03c'],'reason':'runtime uses configured LaunchFs path resolution and controlled memory/stat copy owner; shared code is moved, not duplicated','source':str(src)},indent=2)+'\n')
print('G04 source exported; no branch/index/ref changed')
