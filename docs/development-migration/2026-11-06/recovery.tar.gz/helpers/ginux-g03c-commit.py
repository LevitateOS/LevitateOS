from pathlib import Path
import subprocess,os,tempfile,json,hashlib,tarfile,io,re
repo=Path('/home/vince/.codex/worktrees/ginux-recipe-local-integration/ginux');root=Path('/tmp/ginux-contribution-preparation/G03c');src=root/'source'
def git(*args,env=None,input=None):return subprocess.check_output(['git','-C',str(repo),'--work-tree='+str(repo),*args],env=env,input=input)
composition=json.loads((root/'composition.json').read_text());base=composition['base']
expected=['.github/workflows/check.yml','Makefile','README.md','crates/ginux-init/src/fs_hooks.rs','crates/ginux-init/src/launch.rs','crates/ginux-init/src/main.rs','crates/ginux-init/src/path_hooks.rs','crates/ginux-vfs/src/lib.rs','scripts/test-launch-storage.py','tests/fixtures/launch-storage-fixture.c']
with tempfile.TemporaryDirectory(prefix='ginux-g03c-index-') as temp:
 env={**os.environ,'GIT_INDEX_FILE':str(Path(temp)/'index')};git('read-tree',base,env=env)
 entries={}
 for line in git('ls-tree','-r',base).decode().splitlines():
  info,name=line.split('\t');mode,kind,blob=info.split();entries[name]=(mode,blob)
 changed=[]
 for name in sorted(set(entries)|set(expected)):
  p=src/name;assert p.exists(),name
  data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes();mode,old=entries.get(name,('100644',None));blob=git('hash-object','-w','--stdin',input=data).decode().strip()
  if blob!=old:git('update-index','--add','--cacheinfo',mode,blob,name,env=env);changed.append(name)
 assert changed==sorted(expected),changed
 tree=git('write-tree',env=env).decode().strip();name=git('config','user.name').decode().strip();email=git('config','user.email').decode().strip()
 msg=('feat(launch): add assigned ephemeral memory storage\n\n'
 'Keep configured writable files in supervisor memory, with bounded data,\n'
 'metadata and descriptors. Resolve paths component by component so image\n'
 'links cannot bypass assignment precedence or hide invalid parents.\n\n'
 'Cover storage isolation, copy protections, bounds and temporary native\n'
 'path restoration while retaining existing unit and integration checks.\n\n'
 f'Signed-off-by: {name} <{email}>\n')
 head=git('commit-tree',tree,'-p',base,input=msg.encode()).decode().strip()
patch=git('format-patch','-1','--stdout','--no-signature',head)
assert b'Levitate' not in patch and b'Recipe' not in patch
assert not git('diff','--summary','--diff-filter=M',base,head)
git('diff','--check',base,head)
(root/'candidate.patch').write_bytes(patch);(root/'candidate.diff').write_bytes(git('diff',base,head,'--'))
m={'packet':'G03c','parent_packet':'G03','purpose':'configured bounded ephemeral memory storage runtime','upstream_base':git('rev-parse','3f2fe7df').decode().strip(),'base':base,'local_prerequisites':composition['local_prerequisites'],'head':head,'tree':tree,'changed_files':changed,'patch_sha256':hashlib.sha256(patch).hexdigest(),'unit_tests':sum(int(x) for x in re.findall(r'test result: ok\. (\d+) passed',(root/'validation-static-build.log').read_text())),'standalone':False,'status':'review and clean replay pending','remote_ci':'not run; publication unauthorized'}
(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));print(git('diff','--stat',base,head).decode())
