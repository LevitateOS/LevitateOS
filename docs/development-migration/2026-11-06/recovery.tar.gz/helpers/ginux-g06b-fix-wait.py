from pathlib import Path
src=Path('/tmp/ginux-contribution-preparation/G06b/source')
p=src/'crates/ginux-init/src/tracee_io.rs';s=p.read_text();s+='''
/// Publish a word all or nothing across a page boundary. Reads may use ptrace,
/// but every write goes through the strict copy path and honors page protections.
pub fn store_u32(pid: usize, address: u64, value: u32) -> Result<(), i64> {
    let mut bytes = value.to_ne_bytes();
    address.checked_add(4).ok_or(-14)?;
    let head = 4096 - (address as usize & 4095);
    if head >= 4 {
        return if copy_memory(pid, address, &mut bytes, true) == Ok(4) { Ok(()) } else { Err(-14) };
    }
    let tail = address + head as u64;
    let mut previous = 0usize;
    if crate::supervisor::ptrace(crate::supervisor::PTRACE_PEEKTEXT, pid, tail as usize,
        &mut previous as *mut _ as usize) < 0 { return Err(-14); }
    if copy_memory(pid, tail, &mut bytes[head..], true) != Ok((4-head) as i64) { return Err(-14); }
    if copy_memory(pid, address, &mut bytes[..head], true) != Ok(head as i64) {
        let mut original = previous.to_ne_bytes();
        if copy_memory(pid, tail, &mut original[..4-head], true) != Ok((4-head) as i64) { return Err(-5); }
        return Err(-14);
    }
    Ok(())
}
''';p.write_text(s)
p=src/'crates/ginux-init/src/launch_tasks.rs';s=p.read_text();s=s.replace('''    Wait { child: usize, original: [u64; 7] },''','''    Wait { child: usize, original: [u64; 7], status: u32 },''')
# rustfmt expanded the existing enum; handle its multiline spelling too.
s=s.replace('''        original: [u64; 7],
    },''','''        original: [u64; 7],
        status: u32,
    },''',1)
s=s.replace('''            Pending::Wait { child, original } => {''','''            Pending::Wait { child, original, status } => {''',1)
s=s.replace('''                    r.rax = id.pid as u64;
                }
                r.rdi = original[0];''','''                    r.rax = id.pid as u64;
                    if original[1] != 0 {
                        match crate::tracee_io::store_u32(self.task(index).host, original[1], status) {
                            Ok(()) => {}
                            Err(-5) => self.fail(domain, b"wait status rollback failed"),
                            Err(error) => r.rax = error as u64,
                        }
                    }
                }
                r.rdi = original[0];''',1)
a=s.index('                if r.rsi != 0 {',s.index('    fn wait_entry('));b=s.index('                let original = ',a);s=s[:a]+s[b:]
s=s.replace('''self.task_mut(index).pending = Pending::Wait { child, original };''','''self.task_mut(index).pending = Pending::Wait { child, original, status: result.status.word() };''',1)
s=s.replace('''                r.rdi = self.task(child).host as u64;
                r.rdx = 0;''','''                r.rdi = self.task(child).host as u64;
                // Reap natively before status copyout, including when the
                // caller's buffer faults. Never publish host wait status.
                r.rsi = 0;
                r.rdx = 0;''',1)
s=s.replace('''                // already copied out came from its observed ptrace death.''','''                // reported status comes from its observed ptrace death.''');p.write_text(s)
p=src/'tests/fixtures/launch-task-fixture.c';s=p.read_text().replace('''CHECK(DO(61,child,1,0)==-14,35); // Must not consume the exited child.
        CHECK(DO(61,child,&status,0)==child && status==(42<<8),36);''','''CHECK(DO(61,child,1,0)==-14,35); // Linux still reaps the child on a copy fault.
        CHECK(DO(61,child,&status,0)==-10 && status==123,36);''');p.write_text(s)
p=src/'scripts/test-launch-tasks.py';s=p.read_text().replace("'fork', 'vfork',", "'qfault', 'fork', 'vfork',",1);p.write_text(s)
